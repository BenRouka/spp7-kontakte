import type { Metadata } from "next";
import type { ReactNode } from "react";
import "./globals.css";

export const metadata: Metadata = {
  title: "SPP7 · Datenwerkstatt",
  description: "Eine lesende Prüfansicht für Originalquellen, vier Adventswochenenden und durchgehende Veranstaltungszeiträume. Kein automatischer Import.",
};
export default function RootLayout({ children }: { children: ReactNode }) {
  return <html lang="de"><body>{children}</body></html>;
}
