# SPP7 · FREEZE-08 — Stufe 3 (Abgleich) abgeschlossen

**Status: Stufe 3 abgeschlossen** · Stand 2026-10-01 UTC
**Nächster Schritt:** Stufe 4 (Entscheidungen über gefundene Konflikte und Dubletten) wartet auf Freigabe.

> 🔒 **Am Datenbankcode und Schema wurde weiterhin NICHTS geändert.** Die Datenbank enthält 0 Tabellen. Es wurde kein Import ausgeführt.
> Neu hinzugekommen sind ausschließlich **Berichts- und Abgleich-Dateien** in `werkstatt/03-berichte/` sowie die interaktive Abgleich-Ansicht in Option A.

---

## 1. Ergebnisse des Abgleichs (Stufe 3)

### 1.1 Kurverwaltungen & Kontakte (32 saubere Blöcke ↔ 74 App-Kontakte)

- **34 App-Kontakte** beziehen sich auf die 32 sauberen Kurverwaltungen Rügens.
- **40 App-Kontakte** sind andere Kontakte aus dem Chat (Bands, Agenturen, Veranstalter, Ämter ohne Kurstatus). Sie werden als separate Gruppe „Veranstalter & Partner“ erhalten.
- **Dubletten-Cluster in der App:**
  - **Putbus:** 9 Kontakte in der App (`K22`–`K28`, `K70`, `K71`) für 2 saubere MD-Blöcke (`KV27`, `KV28`).
  - **ruegen.de / Tourismusverband:** 7 Kontakte in der App (`K01`, `K02`, `K35`–`K39`) für 1 sauberen MD-Block (`KV01`).
  - **Amt Nord-Rügen:** 5 Kontakte in der App (`K41`–`K45`).
  - **S. Schönke (privat):** `K57` in App ist die Inhaberin/Mail der gewerblichen Zimmervermittlung Grubnow (`KV24`).
  - **Middelhagen:** `K09` hatte in der App Kanal `(nicht genannt)` — saubere Quelle/Nutzerangaben liefern alle Kanäle.
  - **Notiz-Missbrauch:** Mangels Feldern wurden Adressen/Telefone in das Freitext-Feld `NOTIZ` gepackt (`K70`, `K71`).

### 1.2 Sündenfrei-Termine (54 saubere Zeilen ↔ 206 Bestands-Events)

- In der Bestands-App existieren nur **6 Events mit `QUELLE_TYP = 'Sündenfrei'`** (`S01`–`S06`) plus 2 Chat-Events (`M21`, `M44`).
- **40 von 54 Terminen (74.1 %) fehlen vollständig** als eigenständige Events im App-Bestand.
- **Generischer-Name-Fehler:** In der Bestands-App wurden Veranstaltungen nach generischen Namen wie „Mittelalterspektakel“ oder „Ritterturnier“ dedupliziert, wodurch unterschiedliche Orte fälschlich denselben Event-Eintrag überschrieben haben.

### 1.3 Flyer & Bildlinks (79 Quellen ↔ 158 Bilder)

- 79 Flyer-Quellen in der App haben tote Bildlinks (Verzeichnis `/flyers/` fehlt im App-ZIP).
- Im `ChatExport_2026-09-20.zip` liegen genau 158 JPGs (79 Originale + 79 Thumbnails).
- Rekonstruktion in Stufe 6 ist zu 100 % vorbereitet.

---

## 2. Erzeugte Berichts- und Arbeitsdateien

| Datei | Art | Inhalt |
|---|---|---|
| `werkstatt/03-berichte/abgleich-bericht.md` | Markdown-Report | Vollständiger, lesbarer Abgleich-Bericht mit allen Clustern |
| `werkstatt/03-berichte/abgleich-kontakte.csv` | CSV-Tabelle | Gegenüberstellung aller 32 sauberen Blöcke mit den 74 App-Kontakten |
| `werkstatt/03-berichte/abgleich-termine.csv` | CSV-Tabelle | Gegenüberstellung aller 54 Termine mit den App-Events |
| `werkstatt/03-berichte/abgleich-zusammenfassung.json` | JSON | Strukturierte Kennzahlen und Statistiken |
| `src/components/abgleich-view.tsx` | React / UI | Interaktive Abgleich-Ansicht mit 3 Tabs, Filtern, Suche und Downloads |
| `src/app/api/review/abgleich/route.ts` | API | Lesender Export-Endpunkt (`?format=md`, `?format=csv`, `?format=json`) |

---

## 3. Schutzbereich & Validierung

- **Rohquellen (`werkstatt/01-roh/`):** unverändert, SHA-256 geprüft.
- **Datenbank (`app_db`):** 0 Tabellen im Schema `public`. Kein Import ausgeführt.
- **Option-B-Paket:** unverändert, SHA-256 geprüft.
- **Validierung:** Next.js Typegen, TypeScript (0 Fehler), Production Build und Playwright Browser-Tests (Desktop & Mobil 390px) bestanden.
