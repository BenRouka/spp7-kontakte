// One-off extraction: builds public/data/flyer-mapping.csv and public/data/spp7-chat.json
// from the Telegram export (result.json) + public/data/spp7-datasets.json.
// Usage: node scripts/build-chat-data.mjs <path-to-ChatExport-dir>
import fs from "node:fs";
import path from "node:path";

const exportDir = process.argv[2];
if (!exportDir) throw new Error("Pfad zum ChatExport-Ordner fehlt");

const archive = JSON.parse(fs.readFileSync("public/data/spp7-datasets.json", "utf8"));
const chat = JSON.parse(fs.readFileSync(path.join(exportDir, "result.json"), "utf8"));

/* ---------- 1. flyer mapping CSV ---------- */
const csvCell = (value) => {
  const text = String(value ?? "").replace(/\r?\n/g, " ").trim();
  return /[",;]/.test(text) ? `"${text.replace(/"/g, '""')}"` : text;
};

const flyers = archive.datasets.flyer_sources;
const csv = [
  ["FLYER", "EVENT_ID", "EVENT", "FORMAT", "STATUS", "DATUM", "MSG", "THUMB", "ORIGINAL", "HINWEIS"],
  ...flyers.map((row) => [
    row.FLYER,
    row.EVENT_ID,
    row.EVENT_NAME,
    row.FORMAT,
    row.STATUS,
    row.DATUM,
    row.MSG,
    `/flyers/flyer_${row.FLYER}_thumb.jpg`,
    `/flyers/flyer_${row.FLYER}.jpg`,
    row.HINWEIS,
  ]),
]
  .map((line) => line.map(csvCell).join(","))
  .join("\n");
fs.writeFileSync("public/data/flyer-mapping.csv", `${csv}\n`);

/* ---------- 2. chat transcript JSON ---------- */
const flyerByMsg = new Map(flyers.map((row) => [String(row.MSG), row]));

const plainText = (value) => {
  if (typeof value === "string") return value;
  if (Array.isArray(value)) return value.map((part) => (typeof part === "string" ? part : part.text ?? "")).join("");
  return "";
};

const links = (message) =>
  (message.text_entities ?? [])
    .filter((entity) => entity.type === "link" || entity.type === "text_link")
    .map((entity) => entity.href ?? entity.text)
    .filter((href, index, all) => href && all.indexOf(href) === index);

const messages = chat.messages.map((message) => {
  const flyer = flyerByMsg.get(String(message.id));
  return {
    MSG: String(message.id),
    TYP: message.type === "service" ? "Service" : "Nachricht",
    DATUM: message.date,
    ABSENDER: message.from ?? message.actor ?? "",
    WEITERGELEITET_VON: message.forwarded_from ?? "",
    TEXT: plainText(message.text),
    LINKS: links(message).join(" "),
    MEDIUM: message.photo ? "Foto" : message.media_type ? message.media_type : "",
    FLYER: flyer?.FLYER ?? "",
    EVENT_ID: flyer?.EVENT_ID ?? "",
    EVENT_NAME: flyer?.EVENT_NAME ?? "",
    AKTION: message.action ?? "",
  };
});

fs.writeFileSync(
  "public/data/spp7-chat.json",
  `${JSON.stringify(
    {
      meta: {
        chat: chat.name,
        chatId: String(chat.id),
        typ: chat.type,
        nachrichten: messages.length,
        quelle: path.basename(exportDir),
      },
      messages,
    },
    null,
    2,
  )}\n`,
);

console.log(`CSV: ${flyers.length} Flyer · Chat: ${messages.length} Nachrichten, davon ${messages.filter((m) => m.FLYER).length} mit Flyer`);
