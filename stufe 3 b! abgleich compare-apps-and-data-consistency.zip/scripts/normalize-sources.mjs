#!/usr/bin/env node
// Stage 2 only: reads original sources and explicit user supplements; no database.
// Writes allowlisted derived files to werkstatt/02-normiert/.
// Missing CSV values are exactly space-hyphen-space: " - ".
// node scripts/normalize-sources.mjs          => generate
// node scripts/normalize-sources.mjs --verify => compare, no writes
import assert from "node:assert/strict";
import { createHash } from "node:crypto";
import { mkdir, readFile, writeFile } from "node:fs/promises";
import { existsSync, readFileSync } from "node:fs";
import { createRequire } from "node:module";
import path from "node:path";
import ts from "typescript";

const verifyOnly = process.argv.includes("--verify");
const require = createRequire(import.meta.url);
const cache = new Map();
function loadTs(specifier) {
  const file = specifier.startsWith("@/") ? `src/${specifier.slice(2)}.ts` : specifier;
  if (cache.has(file)) return cache.get(file).exports;
  const module = { exports: {} }; cache.set(file, module);
  const code = ts.transpileModule(readFileSync(file, "utf8"), {
    compilerOptions: { module: ts.ModuleKind.CommonJS, target: ts.ScriptTarget.ES2022, esModuleInterop: true },
  }).outputText;
  new Function("require", "module", "exports", code)(
    (id) => id === "server-only" ? {} : id.startsWith("@/") ? loadTs(id) : require(id), module, module.exports);
  return module.exports;
}
const calendar = loadTs("src/lib/calendar-model.ts");
const reference = loadTs("src/lib/reference-data.ts");
const csv = loadTs("src/lib/normalization-csv.ts");
const contactsModel = loadTs("src/lib/contact-model.ts");
const MISSING = csv.NORMALIZED_MISSING_VALUE;
assert.equal(MISSING, " - ");
const RAW_MD = "werkstatt/01-roh/Kurverwaltungen_2025.md";
const RAW_TXT = "werkstatt/01-roh/Termine_2027_suendenfrei.txt";
const OUT = "werkstatt/02-normiert";
const SUPPLEMENTS = `${OUT}/nutzer-ergaenzungen.json`;
const sha256 = (value) => createHash("sha256").update(value).digest("hex");
const [mdBytes, txtBytes, supplementBytes] = await Promise.all([readFile(RAW_MD), readFile(RAW_TXT), readFile(SUPPLEMENTS)]);
assert.equal(sha256(mdBytes), "28512c72423ac270d4c423007b29dc85266e6938441d830bf0ec8a3239c1bfa1", "MD-Rohquelle ist verändert");
assert.equal(sha256(txtBytes), reference.verifiedInventory.originalScheduleSha256, "TXT-Rohquelle ist verändert");
const reviews = { 2026: calendar.buildCalendarReview(2026), 2027: calendar.buildCalendarReview(2027) };
const clean = (value) => value.replace(/\s+/g, " ").trim();
const stripStars = (value) => value.replace(/\*+$/, "").trim();
const joinHyphen = (value) => value.replace(/([A-Za-zÄÖÜäöüß])-\s+(?!(und|bzw)\b)([A-Za-zÄÖÜäöüß])/g, "$1-$3");
const joinSlash = (value) => value.replace(/\s*\/\s*/g, "/");
const fixTypo = (value) => value.replaceAll("Mittealter", "Mittelalter");
const MONTHS = { Januar: 1, Februar: 2, März: 3, April: 4, Mai: 5, Juni: 6, Juli: 7, August: 8, September: 9, Oktober: 10, November: 11, Dezember: 12 };
function iso(year, month, day) {
  const date = new Date(Date.UTC(year, month - 1, day, 12));
  assert.equal(date.getUTCFullYear(), year); assert.equal(date.getUTCMonth(), month - 1); assert.equal(date.getUTCDate(), day);
  return date.toISOString().slice(0, 10);
}
function parseDate(original) {
  const text = stripStars(original);
  let match = text.match(/^1\.\s*-\s*4\.\s*Advent\s+(\d{4})$/);
  if (match) return { kind: "advent", year: Number(match[1]) };
  match = text.match(/^(\d{1,2})\.\s*(\d{1,2})\.\s*-\s*(\d{1,2})\.\s*([^\d\s]+)\s+(\d{4})$/);
  if (match) {
    const [, d1, mo1, d2, mo2, y] = match; assert.ok(MONTHS[mo2]);
    return { kind: "range", year: Number(y), from: iso(Number(y), Number(mo1), Number(d1)), to: iso(Number(y), MONTHS[mo2], Number(d2)) };
  }
  match = text.match(/^(\d{1,2})\.\s*([^\d\s]+)\s*-\s*(\d{1,2})\.\s*([^\d\s]+)\s+(\d{4})$/);
  if (match) {
    const [, d1, mo1, d2, mo2, y] = match; assert.ok(MONTHS[mo1] && MONTHS[mo2]);
    return { kind: "range", year: Number(y), from: iso(Number(y), MONTHS[mo1], Number(d1)), to: iso(Number(y) + (MONTHS[mo2] < MONTHS[mo1] ? 1 : 0), MONTHS[mo2], Number(d2)) };
  }
  match = text.match(/^(\d{1,2})\.\s*-\s*(\d{1,2})\.\s*([^\d\s]+)\s+(\d{4})$/);
  if (match) {
    const [, d1, d2, mo, y] = match; assert.ok(MONTHS[mo]);
    return { kind: "range", year: Number(y), from: iso(Number(y), MONTHS[mo], Number(d1)), to: iso(Number(y), MONTHS[mo], Number(d2)) };
  }
  throw new Error(`Datumsform nicht eindeutig: ${original}`);
}
function buildScheduleRows() {
  const text = txtBytes.toString("utf8").replaceAll("\r\n", "\n");
  assert.equal(text.trimEnd(), reference.originalSchedule.trimEnd());
  const rows = [];
  for (const [index, line] of text.split("\n").entries()) {
    const parts = line.split("\t"); if (parts.length !== 3) continue;
    const [dateOriginal, nameOriginal, placeOriginal] = parts.map((part) => part.trim());
    const parsed = parseDate(dateOriginal), year = parsed.year;
    const star = (line.match(/\*+/) || [""])[0];
    const weekends = parsed.kind === "advent";
    const periods = weekends ? reviews[year].advent.periods.map((p) => ({ start: p.start, end: p.end })) : [{ start: parsed.from, end: parsed.to }];
    assert.ok(periods.every((p) => p.start <= p.end));
    const placeOpen = /^x+$/.test(placeOriginal), nameOpen = /^noch offen$/i.test(nameOriginal);
    const placeNorm = placeOpen ? MISSING : fixTypo(joinSlash(stripStars(clean(placeOriginal))));
    const postal = placeNorm.match(/^(\d{5})\s+(.+)$/);
    const remarks = [weekends ? `1 Quelltermin, 4 getrennte Adventswochenenden (${reviews[year].advent.weekdayLabel}) – kein durchgehender Zeitraum` : "durchgehender Zeitraum aus der Quelle, keine Adventsberechnung"];
    if (star) remarks.push("Sternchen laut Quelle: Termin oder Ort wahrscheinlich, jedoch noch unbestätigt");
    if (placeOpen) remarks.push('Ort ist Platzhalter (xxxx/xxxxx); PLZ und Ort mit " - " markiert');
    if (nameOpen) remarks.push('Name ist Platzhalter (noch offen); name_normiert mit " - " markiert');
    rows.push({ sf_id: `SF${String(rows.length + 1).padStart(2, "0")}`, jahr: String(year), quellzeile: String(index + 1),
      datum_original: dateOriginal, name_original: nameOriginal,
      name_normiert: nameOpen ? MISSING : fixTypo(joinHyphen(joinSlash(stripStars(clean(nameOriginal))))),
      plz_ort_original: placeOriginal, plz_normiert: postal ? postal[1] : MISSING, ort_normiert: postal ? postal[2] : MISSING,
      zeitfenster_art: weekends ? "wochenenden" : "zeitraum", datumsherkunft: weekends ? "berechnet" : "aus_quelle",
      zeitfenster_anzahl: String(periods.length), zeitfenster_iso: periods.map((p) => `${p.start}/${p.end}`).join(";"),
      start_iso: periods[0].start, end_iso: periods[periods.length - 1].end, sternchen: star || "kein",
      bestaetigungsstatus: star ? "unbestaetigt" : "nicht_markiert", ort_offen: placeOpen ? "ja" : "nein",
      hinweis: remarks.join(" · "), status_verifikation: "nicht_verifiziert" });
  }
  return rows;
}
const scheduleHeaders = ["sf_id", "jahr", "quellzeile", "datum_original", "name_original", "name_normiert", "plz_ort_original", "plz_normiert", "ort_normiert",
  "zeitfenster_art", "datumsherkunft", "zeitfenster_anzahl", "zeitfenster_iso", "start_iso", "end_iso", "sternchen", "bestaetigungsstatus", "ort_offen", "hinweis", "status_verifikation"];
const scheduleRows = buildScheduleRows();
const supplementFile = JSON.parse(supplementBytes.toString("utf8"));
const structure = contactsModel.buildContactStructure(mdBytes.toString("utf8"), supplementFile);
const workspace = { ...structure, source: {
  file: RAW_MD, url: "https://github.com/BenRouka/spp7-kontakte/blob/main/Kurverwaltungen_2025.md", sha256: sha256(mdBytes),
  supplementFile: SUPPLEMENTS, supplementSha256: sha256(supplementBytes),
} };
assert.equal(scheduleRows.length, 54); assert.equal(scheduleRows.filter((r) => r.jahr === "2026").length, 9);
assert.equal(scheduleRows.filter((r) => r.jahr === "2027").length, 45);
assert.equal(scheduleRows.filter((r) => r.sternchen !== "kein").length, 14);
assert.equal(scheduleRows.filter((r) => r.ort_offen === "ja").length, 2);
assert.equal(scheduleRows.reduce((n, r) => n + Number(r.zeitfenster_anzahl), 0), 60);
assert.deepEqual(workspace.counts, { rawBlocks: 32, contacts: 32, regions: 8, groups: 1, places: 22, sourcePlaceHeadings: 24, treeNodes: 63, explicitDistricts: 3, supplementedContacts: 5 });
assert.equal(workspace.nodes.find((node) => node.id === "REG01").name, "Rügen Übergreifend");
assert.equal(workspace.nodes.find((node) => node.id === "REG01").typ, "gruppe");
const vitte = workspace.nodes.filter((node) => node.typ === "ort" && node.name === "Vitte");
assert.equal(vitte.length, 1);
assert.deepEqual(vitte[0].quellvorkommen.map((source) => source.quellzeile), ["294", "313"]);
assert.equal(new Set(workspace.contacts.map((c) => c.kv_id)).size, 32);
const byId = Object.fromEntries(workspace.contacts.map((c) => [c.kv_id, c]));
assert.equal(byId.KV12.parent_id, byId.KV13.parent_id);
assert.equal(byId.KV12.name_zusatz_original, "Tourist-Information Middelhagen");
assert.equal(byId.KV13.organisations_parent_id, "KV12");
assert.equal(byId.KV12.ort_normiert, "Ostseebad Mönchgut");
assert.equal(byId.KV12.ortsteil_normiert, "Middelhagen");
assert.equal(byId.KV13.ortsteil_normiert, "Thiessow");
assert.equal(byId.KV24.ortsteil_normiert, "Grubnow");
assert.equal(byId.KV10.web_original, MISSING); assert.equal(byId.KV10.email_1_original, MISSING);
assert.equal(byId.KV10.web_normiert, "www.baabe.de"); assert.equal(byId.KV10.email_1_normiert, "willkommen@baabe.de");
assert.equal(byId.KV10.fax_normiert, MISSING); assert.equal(byId.KV13.fax_normiert, MISSING);
assert.equal(byId.KV13.telefon_normiert, "+49 38308 66010");
assert.deepEqual(workspace.contacts.filter((c) => c.region_original === "Halbinsel Mönchgut").map((c) => c.hierarchie_pfad), ["3.1.1", "3.1.2", "3.1.3", "3.2.1", "3.2.2", "3.3.1", "3.3.2"]);
for (const row of [...scheduleRows, ...workspace.contacts]) {
  assert.ok(Object.values(row).every((v) => typeof v === "string" && v !== "" && v !== "-"));
  assert.equal(row.status_verifikation, "nicht_verifiziert");
}
function rowValues(headers, records) {
  return records.map((record) => headers.map((key) => {
    assert.ok(Object.hasOwn(record, key), `CSV-Feld fehlt: ${key}`);
    return record[key];
  }));
}
function structureReport() {
  const lines = ["# Kontaktstruktur · Region → Ort → Einrichtung", "", `Stand: ${workspace.version}.`,
    "32 Einrichtungen aus 32 Rohblöcken; 8 Regionen + 1 übergreifende Quellgruppe; 22 angezeigte Orte; insgesamt 63 Knoten.",
    "Die 24 ursprünglichen H3-Fundstellen bleiben nachweisbar. Rügen Übergreifend ist kein Ort; Vitte wird nur nach ausdrücklicher Nutzerfreigabe zusammengeführt.",
    'Fehlende Werte sind exakt " - " (Leerzeichen–Bindestrich–Leerzeichen), keine Minus-Zahl.',
    "Baabe-Web/E-Mail und Middelhagens frühere Angaben sind ausdrücklich bestätigt, keine allgemeine Kontaktvererbung.", ""];
  for (const node of workspace.nodes) {
    if (node.typ !== "einrichtung") {
      lines.push(`${node.typ === "ort" ? "###" : "##"} ${node.hierarchie_pfad}. ${node.name}`, "");
      if (node.typ === "gruppe") lines.push("Übergreifende Quellgruppe, ausdrücklich kein Ort.", "");
      if (node.name !== node.name_original || node.quellvorkommen.length > 1) {
        lines.push(`Quellfundstellen: ${node.quellvorkommen.map((source) => `${source.id}: „${source.name}“, MD-Zeile ${source.quellzeile}`).join("; ")}.`,
          `Zuordnung: ${node.herkunft}`, "");
      }
      continue;
    }
    const contact = byId[node.id];
    lines.push(`#### ${node.hierarchie_pfad}. ${contact.name_haupt_original}`);
    if (contact.name_zusatz_normiert !== MISSING) lines.push(contact.name_zusatz_normiert);
    if (contact.name_zusatz_ergaenzung !== MISSING) lines.push(`Namenszusatz-Herkunft: ${contact.name_zusatz_herkunft}`);
    lines.push("", `- Straße: ${contact.strasse_original}`, `- PLZ/Ort · Original: ${contact.plz_ort_original}`,
      `- Ort: ${contact.ort_normiert}`, `- Ortsteil: \`${contact.ortsteil_normiert}\``,
      `- Telefon · normiert: ${contact.telefon_normiert}`, `- Fax · normiert: \`${contact.fax_normiert}\``,
      `- Internet: ${contact.web_normiert}`, `- E-Mail: ${contact.email_1_normiert}`,
      `- E-Mail 2: \`${contact.email_2_normiert}\``, `- Originalfundstelle: MD-Zeilen ${contact.quellzeile}`);
    if (contact.quelle_ergaenzung !== MISSING) lines.push(`- Ergänzungsherkunft: ${contact.quelle_ergaenzung}`);
    if (contact.organisations_parent_id !== MISSING) lines.push(`- Organisatorische Zuordnung (separat vom Ort): ${contact.organisations_parent_id}`);
    lines.push("- Verifikation: nicht verifiziert", "");
  }
  lines.push("## Grenzen", "", "Rügen Übergreifend ist eine Quellgruppe über dem Verband. Seine echte Adresse Markt 25, 18528 Bergen auf Rügen bleibt unverändert. Die rohe Gliederung ist in den Original-/Fundstellenfeldern erhalten.",
    "", "Unter Seebad Insel Hiddensee stehen Vitte (Insel Information und HTS) und Kloster (Hafencenter). Die Vitte-Fundstellen MD 294 und 313 sind gemeinsam verzeichnet; Einrichtungen, Anschriften und Kontaktdaten bleiben getrennt. Keine organisatorische Beziehung zwischen HTS und Insel Information abgeleitet.",
    "", "HTS bleibt als Originalname erhalten; Hiddensee Touristik & Service ist ein zusätzlicher Nutzer-Namenszusatz, nicht nachträglich in die MD geschrieben.",
    "", "Fax bleibt eigenes Feld. +49-Normierung nur für Telefonnummern. Keine automatische Vererbung, keine allgemeine Zusammenführung gleichnamiger Orte.",
    "", "Stufe 3 und Datenbankimport nicht begonnen.", "");
  return lines.join("\n");
}
const files = [
  ["suendenfrei-termine.csv", csv.normalizedCsvFile(scheduleHeaders, rowValues(scheduleHeaders, scheduleRows))],
  ["kurverwaltungen.csv", csv.normalizedCsvFile(contactsModel.contactCsvHeaders, rowValues(contactsModel.contactCsvHeaders, workspace.contacts))],
  ["kontaktstruktur.csv", csv.normalizedCsvFile(contactsModel.contactTreeCsvHeaders, rowValues(contactsModel.contactTreeCsvHeaders, workspace.nodes))],
  ["kontakte-struktur.json", JSON.stringify(workspace, null, 2) + "\n"],
  ["kontaktstruktur.md", structureReport()],
];
const checksums = [...files, ["nutzer-ergaenzungen.json", supplementBytes]]
  .map(([name, content]) => `${sha256(content)}  ${name}`).join("\n") + "\n";
if (verifyOnly) {
  for (const [name, content] of files) {
    assert.ok(existsSync(path.join(OUT, name)), `Fehlt: ${name}`);
    assert.equal(await readFile(path.join(OUT, name), "utf8"), content, `Normierung weicht ab: ${name}`);
  }
  assert.equal(await readFile(path.join(OUT, "PRUEFSUMMEN.sha256"), "utf8"), checksums);
} else {
  await mkdir(OUT, { recursive: true });
  for (const [name, content] of files) await writeFile(path.join(OUT, name), content, "utf8");
  await writeFile(path.join(OUT, "PRUEFSUMMEN.sha256"), checksums, "utf8");
}
console.log(`Modus: ${verifyOnly ? "nur prüfen, keine Schreibzugriffe" : "abgeleitete Dateien erzeugt"}`);
console.log(`Termine: 54 Zeilen / 60 Zeitfenster / 14 unbestätigte / 2 Ortsplatzhalter; Fehlmarker exakt ${JSON.stringify(MISSING)}.`);
console.log("Kontakte: 32 Einrichtungen; 8 Regionen + 1 übergreifende Gruppe; 22 angezeigte Orte; 63 Knoten. 24 Roh-H3-Fundstellen erhalten.");
for (const c of workspace.contacts.filter((c) => c.region_original === "Halbinsel Mönchgut" || c.region_original === "Seebad Insel Hiddensee")) {
  console.log(`  ${c.hierarchie_pfad} ${c.kv_id} ${c.name_haupt_original}${c.name_zusatz_normiert !== MISSING ? ` / ${c.name_zusatz_normiert}` : ""}`);
}
console.log(`Ortsteile nur aus explizitem OT: ${workspace.contacts.filter((c) => c.ortsteil_normiert !== MISSING).map((c) => `${c.kv_id} ${c.ortsteil_normiert}`).join(", ")}.`);
console.log("KV10: ausdrückliche Baabe-Ergänzung bestätigt. KV12: frühere Middelhagen-Web/E-Mail ausdrücklich beibehalten. Keine allgemeine Vererbung.");
console.log("Rügen Übergreifend: Gruppe statt künstlichem Ort; Originalüberschriften erhalten.");
console.log("Vitte: gemeinsamer Ortsknoten ausschließlich aufgrund Nutzerregel; beide MD-Fundstellen erhalten. HTS-Zusatz aus Nutzerangabe.");
console.log("Rohquellen, Zeitmodell, Option-B-Paket und Datenbank unverändert. Keine externe Verifikation.");
