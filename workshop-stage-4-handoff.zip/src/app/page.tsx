import type { Metadata } from "next";
import {
  ArrowRight,
  FileDown,
  FileText,
  PackageX,
  ScrollText,
  ShieldCheck,
} from "lucide-react";
import {
  BeschlussRow,
  TerminRow,
  kontaktStats,
  loadFreeze,
  terminStats,
} from "@/lib/freeze";
import { Badge, Panel, Section, Stat } from "@/components/ui";
import { VerifyWidget } from "@/components/verify-widget";

export const metadata: Metadata = {
  title: "Übersicht · Werkstatt Stufe 4 · Freeze",
};

const PACK = [
  {
    file: "HANDOFF.md",
    desc: "Übergabeprotokoll · Regeln, Struktur, offene Punkte, nächster Schritt",
  },
  {
    file: "arbeitsstand-kontakte.csv",
    desc: "Arbeitsstand · 9 Regionen · email_1 / email_2 / email_3",
  },
  {
    file: "arbeitsstand-termine.csv",
    desc: "Arbeitsstand · 54 Quellzeilen · 60 Zeitfenster · 2026 + 2027",
  },
  {
    file: "beschlussverzeichnis.csv",
    desc: "Verbindlich · 20 Beschlüsse mit Prio-1-Basis und Status",
  },
  {
    file: "PRUEFSUMMEN.sha256",
    desc: "sha256 über die vier Paket-Dateien · 2026-10-01 erzeugt",
  },
];

const NICHT_IM_PAKET = [
  "41 weitere Befund-IDs aus werkstatt/03-berichte/abgleich-01-entscheidungen.csv (Variante A, 65 nummerierte Befunde) — nicht gelesen, nicht entschieden (B-18).",
  "Flyer-/Bild-Audit — 79 tote Bildlinks ↔ 158 JPGs im Chat-Export; Zahlen aus Variante B, nie nachgezählt. Geparkt (B-19).",
  "Die ZIPs var a2 und var b2 (399 kB / 463 kB) — bewusst nicht geprüft, keine zweite A/B-Gabelung (B-14).",
  "Archiv-Reparaturen — im A-ZIP fehlen 6 Manifest-Dateien, 8 CSVs ohne UTF-8-BOM. Nur dokumentiert (B-13, Option a).",
  "Datenbank — unverändert, 0 Tabellen, kein Import, kein Schema angefasst. Stufe 5 nicht begonnen (B-20).",
];

const NAECHSTER_SCHRITT = [
  "Prüfsummen erzeugen (erledigt — PRUEFSUMMEN.sha256 liegt im Paket).",
  "ZIP packen — die Arena-Oberfläche kann das.",
  "Neuen Chat im Single-Mode starten und HANDOFF.md als erste Datei übergeben.",
  "Dort: Stufe 5 (Import) vorbereiten — nicht ausführen, bevor das Schema steht.",
];

export default function UebersichtPage() {
  const { handoff, kontakte, termine, beschluesse, pruefsummen } = loadFreeze();
  const kStats = kontaktStats(kontakte);
  const t26 = terminStats(termine, "2026");
  const t27 = terminStats(termine, "2027");
  const entschieden = beschluesse.filter(
    (b: BeschlussRow) => b.status === "entschieden"
  ).length;
  const provisorisch = beschluesse.filter(
    (b: BeschlussRow) => b.status === "provisorisch"
  ).length;
  const fensterGesamt = termine.reduce(
    (s: number, t: TerminRow) => s + t.anzahl,
    0
  );

  return (
    <>
      {/* HERO */}
      <div className="border-b border-line pb-8">
        <p className="font-mono text-[10.5px] font-semibold uppercase tracking-[0.24em] text-lime">
          Übergabeprotokoll · Paket Stufe 4 · Stand 2026-10-01
        </p>
        <h1 className="mt-3 max-w-4xl text-[34px] font-semibold leading-[1.08] tracking-tight text-ink sm:text-[44px]">
          Freeze ist gesetzt.
          <br />
          <span className="text-muted">Nichts schreibt ohne dein Ja.</span>
        </h1>
        <p className="mt-4 max-w-3xl text-[14px] leading-relaxed text-ink-soft">
          Arbeitsstand sind <span className="font-mono text-lime-soft">arbeitsstand-kontakte.csv</span> und{" "}
          <span className="font-mono text-lime-soft">arbeitsstand-termine.csv</span>. Verbindlich ist{" "}
          <span className="font-mono text-amber-soft">beschlussverzeichnis.csv</span>. Keine
          A/B-Entscheidungen, keine Recherche, keine Vorannahmen.
        </p>
        <div className="mt-5 flex flex-wrap items-center gap-2">
          <Badge tone="a">
            <ShieldCheck className="h-3 w-3" />
            Regeln 1–7 · nicht verhandelbar
          </Badge>
          <Badge tone="warn">Datenbank: 0 Tabellen · B-20</Badge>
          <Badge tone="mute">Stufe 5: vorbereitet, nicht ausgeführt</Badge>
          <Badge tone="mute">Prüfsummen: siehe Paket-Verifikation</Badge>
        </div>
      </div>

      {/* KENNZAHLEN */}
      <div className="mt-8 grid grid-cols-2 gap-3 md:grid-cols-3 xl:grid-cols-6">
        <Stat label="Regionen" value={kStats.regionen} sub="Übergreifend zuerst (§3)" />
        <Stat
          label="KV-Datensätze"
          value={kStats.kvGekennzeichnet}
          sub={`+${kStats.sonderdatensaetze} Sonderdatensatz (STADT-PUTBUS, kein MD-Block)`}
        />
        <Stat
          label="Termin-Quellzeilen"
          value={termine.length}
          sub={`2026: ${t26.quellzeilen} · 2027: ${t27.quellzeilen}`}
        />
        <Stat
          label="Zeitfenster"
          value={fensterGesamt}
          sub={`2026: ${t26.zeitfenster} · 2027: ${t27.zeitfenster} (B-12)`}
          tone="lime"
        />
        <Stat
          label="Beschlüsse"
          value={beschluesse.length}
          sub={`${entschieden} entschieden · ${provisorisch} provisorisch`}
        />
        <Stat
          label="Freeze-Dateien"
          value={pruefsummen.length}
          sub="sha256-verifiziert"
          tone="lime"
        />
      </div>

      {/* ÜBERGABEPAKET */}
      <Section
        eyebrow="Übergabepaket · export/FREEZE"
        title="Freeze · Dateien für den neuen Chat (Single-Mode)"
        desc="Vier Dateien plus Prüfsummen. Zusammen mit den unveränderten Ausgangsquellen in ein ZIP packen — das kann die Arena-Oberfläche."
      >
        <Panel className="border-lime/30 bg-lime/[0.02]">
          <div className="grid gap-2.5 sm:grid-cols-2 lg:grid-cols-3">
            {PACK.map((f) => (
              <a
                key={f.file}
                href={`/export/FREEZE/${encodeURIComponent(f.file)}`}
                download
                className="group flex items-start gap-3 rounded-lg border border-line bg-raised/50 p-3 transition-colors hover:border-lime/40 hover:bg-raised"
              >
                <FileDown className="mt-0.5 h-4 w-4 shrink-0 text-lime" />
                <span className="min-w-0">
                  <span className="block break-all font-mono text-[12px] text-ink group-hover:text-lime-soft">
                    {f.file}
                  </span>
                  <span className="mt-0.5 block text-[11px] leading-relaxed text-muted">
                    {f.desc}
                  </span>
                </span>
              </a>
            ))}
            <div className="rounded-lg border border-line bg-raised/50 p-3">
              <p className="flex items-center gap-2 font-mono text-[10px] uppercase tracking-[0.16em] text-muted">
                <FileText className="h-3.5 w-3.5" /> Packen & prüfen
              </p>
              <pre className="mt-2 overflow-x-auto rounded bg-base/80 p-2 font-mono text-[10.5px] leading-relaxed text-lime-soft">
{`cd export/FREEZE && sha256sum \\
  HANDOFF.md \\
  arbeitsstand-kontakte.csv \\
  arbeitsstand-termine.csv \\
  beschlussverzeichnis.csv \\
  > PRUEFSUMMEN.sha256
sha256sum -c PRUEFSUMMEN.sha256`}
              </pre>
            </div>
          </div>
          <div className="mt-3">
            <VerifyWidget />
          </div>
        </Panel>
      </Section>

      {/* NICHT IM PAKET */}
      <Section
        eyebrow="Ausgeschlossen · nicht erledigt"
        title="Was bewusst NICHT in diesem Paket ist"
        desc="Diese Punkte sind ausdrücklich ausgeschlossen — dokumentiert, nicht vergessen."
      >
        <Panel className="border-amber/25 bg-amber/[0.03]">
          <ul className="space-y-2.5">
            {NICHT_IM_PAKET.map((item, i) => (
              <li key={i} className="flex items-start gap-2.5 text-[13px] leading-relaxed text-amber-soft">
                <PackageX className="mt-0.5 h-4 w-4 shrink-0 text-amber" />
                <span>{item}</span>
              </li>
            ))}
          </ul>
        </Panel>
      </Section>

      {/* NÄCHSTER SCHRITT + PROTOKOLL */}
      <div className="mt-14 grid gap-6 lg:grid-cols-[minmax(0,5fr)_minmax(0,7fr)]">
        <Section
          eyebrow="Ablauf · §7"
          title="Nächster einzelner Schritt"
          desc="Genau einer, in dieser Reihenfolge."
          className="mt-0"
        >
          <ol className="space-y-2.5">
            {NAECHSTER_SCHRITT.map((s, i) => (
              <li
                key={i}
                className="flex items-start gap-3 rounded-lg border border-line bg-raised p-3.5"
              >
                <span className="flex h-6 w-6 shrink-0 items-center justify-center rounded-md border border-lime/40 bg-lime/10 font-mono text-[11px] font-semibold text-lime">
                  {i + 1}
                </span>
                <span className="text-[13px] leading-relaxed text-ink-soft">{s}</span>
              </li>
            ))}
          </ol>
          <a
            href="/stufe-5"
            className="mt-4 inline-flex items-center gap-2 rounded-lg border border-lime/40 bg-lime/[0.08] px-4 py-2.5 text-[13px] font-medium text-lime transition-colors hover:bg-lime/[0.14]"
          >
            Zur Stufe-5-Vorbereitung
            <ArrowRight className="h-4 w-4" />
          </a>
        </Section>

        <Section
          eyebrow="Verbindlich · HANDOFF.md"
          title="Übergabeprotokoll · Rohfassung"
          desc="Byteidentisch zur Paket-Datei — sha256-geprüft, nichts umformuliert."
          className="mt-0"
          aside={
            <a
              href="/export/FREEZE/HANDOFF.md"
              download
              className="mb-1 inline-flex items-center gap-1.5 font-mono text-[11px] text-lime hover:text-lime-soft"
            >
              <FileDown className="h-3.5 w-3.5" /> HANDOFF.md
            </a>
          }
        >
          <Panel className="p-0">
            <div className="flex items-center gap-2 border-b border-line px-4 py-2.5">
              <ScrollText className="h-3.5 w-3.5 text-lime" />
              <span className="font-mono text-[10.5px] uppercase tracking-[0.16em] text-muted">
                export/FREEZE/HANDOFF.md
              </span>
            </div>
            <pre className="max-h-[520px] overflow-auto whitespace-pre-wrap p-4 font-mono text-[11px] leading-[1.7] text-ink-soft">
              {handoff}
            </pre>
          </Panel>
        </Section>
      </div>
    </>
  );
}
