# SPP7 – Rohextrakt Kontakte (Telegram-Export „Locations zum abtippen“)

Quelle: `ChatExport_2026-09-20.zip`, 79 Flyer-Originale (Thumbs + UI-Bilder verworfen).
Erfasst: 30 Flyer → 28 Datensätze (1 Duplikat: flyer_08 = NEXUS).

---

## Flyer 01 · NEXUS Festival

| Feld | Inhalt |
|---|---|
| **Typ** | Festival |
| **Location** | Agra Messepark |
| **Ort** | Leipzig |
| **Region** | Sachsen |
| **Social** | IG @nerdrockfestival |
| **Headliner** | Stand Atlantic (First Leipzig Festival Show Ever) |
| **Special Guest** | Coldmirror |
| **Sponsoren/Partner** | Nerdgaming Convention; Gaming & Indie Area; Artist Area; Mittelalter Markt; Merch Area; Cosplay Area; Food Area; Workshops; Wasteland Area; Karaoke; Creator & Streamer |
| **Tags** | Metal;Nerdrock;Gaming;Cosplay;MittelalterMarkt;Indie |
| **Passung SPP7** | mittel-hoch: Mittelalter-/Markt-Buehne + offene Indie-Flaeche |
| **Unklar** | Ticketpreise, Anzahl Buehnen, Kontaktdaten, Bewerbungsschluss; Line-Up teils durch IG-Overlay verdeckt |
| **Quelle** | photo_1@14-09-2026_08-32-31.jpg / msg 43930 |
| **Termine** | 18.09.2026-20.09.2026 – Haupttermin, 3 Tage |
| **Bands/Acts** | Stand Atlantic; Smash Into Pieces; Dead by April; As December Falls; Within Destruction; Our Mirage; Elwood Stray; MittelAltA; Grainknights; Enemy Inside; Kontrollverlust; Coldmirror; The New Asura |

**Kurz:** Dreitgiges Nerd-Rock-/Metal-Festival plus Gaming-Convention auf der Agra Messepark Leipzig, Headliner Stand Atlantic.

**Lang:** Wirbt als 'das weltweit erste' Nerd-Rock-Festival. Konzert-Line-Up (Metal/Post-Hardcore/Indie bis Mittelalter-Rock) kombiniert mit Convention-Flaechen: Gaming & Indie, Artist Area, Mittelalter Markt, Cosplay, Food, Workshops, Wasteland, Karaoke, Creator & Streamer. Als Facebook-Anzeige gesichtet (399 Kommentare, 57 Shares) -> Reichweite vorhanden. Fuer SPP7 relevant wegen Mittelalter-Markt-Flaeche und Indie-Schiene (zwei unterschiedliche Buehnen/Publikumsschichten).

---

## Flyer 02 · BOOKWOOD

| Feld | Inhalt |
|---|---|
| **Typ** | Festival |
| **Location** | Suedharz |
| **Ort** | Nordhausen / Suedharz |
| **Region** | Thueringen |
| **Website** | www.mf-suedharz.de |
| **Social** | IG @metal.foundation.suedharz |
| **Headliner** | Brainstorm |
| **Sponsoren/Partner** | Koestritzer; Kreissparkasse Nordhausen; KNAUF |
| **Tags** | Metal;Suedharz;Festival;OpenAir |
| **Passung SPP7** | hoch: klassisches Metal-Open-Air mit Regionalsponsoren |
| **Unklar** | Kein Datum und keine Adresse auf dem Plakat -> Recherche noetig; keine Kontakt-Mail sichtbar |
| **Quelle** | photo_2@14-09-2026_08-32-31.jpg (Repo-Referenz) / msg 43931 |
| **Bands/Acts** | Brainstorm; Lacrimas Profundere; Zero Degree; RUECKHALT; FIGHTING CHANCE; VIREPTIC; Buchfinken; OUR MIRAGE; Restrisiko; MYRA; Mandragora; Titanith; LETTERSSENT; Prophecy/Rising Dead; CALLING CHARISMA; Endless Core; MAGICAL HEART; BURNING MISERY |

**Kurz:** Metal-Festival im Suedharz (MF Suedharz), Freitag/Samstag-Programm mit Brainstorm als Headliner.

**Lang:** Zweitägiges Line-Up (Freitag + Samstag), strukturiert nach Tagen auf dem Flyer. Sponsoren aus Getraenke-, Bank- und Baumarkt-Sektor deuten auf kommunal-regionale Finanzierung. Nahe Verlag/Partner 'Metal Foundation Suedharz' als Veranstalter-Account. OUR MIRAGE und MittelAltA ueberschneiden sich mit anderen Festivals im Datensatz.

---

## Flyer 03 · Schlichtenfest Open-Air 2027

| Feld | Inhalt |
|---|---|
| **Typ** | Festival_Bewerbung |
| **Ort** | Schlichten (recherche) |
| **Social** | IG @schlichtenfest_e.v |
| **Sponsoren/Partner** | Schlichtenfest e.V. |
| **Tags** | OpenAir;Metal;ExtremeMetal;Verein;DIY |
| **Passung SPP7** | hoch: DIY-Verein, Suche nach Pirate/Mittelalter/Rock, aktive Bewerbungsphase |
| **Unklar** | Festivaltermin, Ort, Buehnen, Ticketpreis, Kontakt-Mail |
| **Quelle** | photo_3 / msg 43932 |
| **Termine** | 01.11.2026 – Bewerbungsportal bis einschliesslich (Bandbewerbung 2027) <br> 01.08.2026 – Post-Datum IG: Portalstart <br> 2027 – Festivaltermin, genaunes Datum nicht genannt |
| **Bands/Acts** | – |

**Kurz:** Vereinsorganisiertes Open-Air mit geoeffnetem Bewerbungsportal bis 01.11.2026 - Pitch direkt moeglich.

**Lang:** Schwarzes Plakat mit gothischem Schriftzug 'Bewerbungsportal fuer Bands ab jetzt geoeffnet!!!', schreiender Kopf mit Tannenreisig als Maskottchen. Verein statt Agentur, hohe Community-Bindung (784 Likes, 186 Kommentare, 937 Saves) - typisch fuer kleine Open-Airs mit Zeltplatz. Line-Up noch offen, d.h. reale Chance fuer neue Bands.

---

## Flyer 04 · ROCKAFREEZE

| Feld | Inhalt |
|---|---|
| **Typ** | Festival_Bewerbung |
| **Social** | IG @rockafreeze |
| **Tags** | Metal;Winter;Bandbewerbung;OpenCall |
| **Passung SPP7** | hoch: Aesthetik passt zur Piraten-/Mittelalterlinie, offener Open Call |
| **Unklar** | Datum, Ort, Buehne, Kontakt; Caption abgeschnitten ('Wir suchen Bands fuer das... mehr') |
| **Quelle** | photo_4 / msg 43933 |
| **Termine** | 2027 – 'Bandbewerbung fuer 2027 jetzt moeglich' - Frist unbekannt <br> 13.09.2026 – Post 'Vor 9 Stunden' vor Export |
| **Bands/Acts** | – |

**Kurz:** Rockafreeze sucht Bands fuer 2027 - Bewerbung sofort moeglich, kleine aber sehr aktive Community.

**Lang:** Raureif-/Eisoptik, weisses Logo mit Totenkopf + Geweihzweigen + Blitz, Blocktypo 'BAND BEWERBUNG FUER 2027 JETZT MOEGLICH'. Visuelle Sprache (schaedel/Geweih/Frost) -> Metal/Hard-Rock mit Winter-/Nordic-Flair. Save-Quote (529) hoch im Verhaeltnis zu Likes (592): Post wird gespeichert und weitergeleitet, also echte Buchungsabsicht.

---

## Flyer 05 · Wolfszeit Festival (20. Jubilaeum)

| Feld | Inhalt |
|---|---|
| **Typ** | Festival |
| **Location** | Feriendorf Auenland |
| **Ort** | Eisfeld |
| **Region** | Thueringen/Hessen |
| **Social** | geteilt von eisregenoffiziell + headbangerheaven |
| **Headliner** | Varg; Taake |
| **Special Guest** | Vintersorg |
| **Tags** | PaganMetal;BlackMetal;HeidnischesDorf;Camping;MittelalterFlair |
| **Passung SPP7** | hoch: heidnisches Dorf, Pagan-Schiene, Feuer/Lager |
| **Unklar** | Kontakt-Mail, Website, Ticketworkflow, Vollstaendigkeit Line-Up |
| **Quelle** | photo_5 / msg 43934 |
| **Termine** | 13.08.2026-15.08.2026 – Haupttermin, 3 Tage |
| **Bands/Acts** | Varg; Taake; Fulgur; Asagr; Orogen; Wolfchant; Mimir; MittelAltA; Vintersorg; XIV Dark Centuries; Myrdal; Moroden?; Kaim? |

**Kurz:** Pagan-/Black-Metal-Open-Air mit heidischem Dorf, Feriendorf Auenland bei Eisfeld, 13.-15.08.2026.

**Lang:** Etabliertes Klein-Festival (20. Ausgabe) mit Camping im Feriendorf; 'heidnisches Dorf' = Markt-/Lagerleebe-Flaeche, strukturell Open Air + Mittelaltermarkt-Hybrid. Sehr hohe Save-/Share-Quote (11,3 Tsd Likes, 232 Shares, 11,2 Tsd Saves) -> starke Community. Line-Up in gotischer Typografie, teils durch Overlay verdeckt.

---

## Flyer 06 · COEX - Cottbuser Veranstaltungsfirma GmbH

| Feld | Inhalt |
|---|---|
| **Typ** | Veranstalter |
| **Ort** | Cottbus |
| **Region** | Brandenburg |
| **Website** | coex-gmbh.de |
| **Social** | IG @coex_gmbh; FB 'COEX Veranstaltungen' |
| **Sponsoren/Partner** | Stadt Cottbus (Stadtfest) |
| **Tags** | Stadtfest;Cottbus;Veranstalter;Booking-Partner |
| **Passung SPP7** | mittel-hoch: Stadtfest-Buehnen, Agentur-Booking |
| **Unklar** | Ansprechpartner, E-Mail, Telefon nicht im Screenshot |
| **Quelle** | photo_6 / msg 43935 |
| **Bands/Acts** | – |

**Kurz:** Cottbuser Eventagentur, Ausrichter u.a. Stadtfest Cottbus - Tuereoeffner fuer Brandenburg-Buehnen.

**Lang:** IG-Profil: 238 Beitraege, 1.273 Follower, 1.467 folgend, Highlights 'Cottbus 2024' und 'Stadtfest CB'. Dass Bands wie deus_cult_arrr und turasmath folgen, deutet auf offenes Booking. Kommunale Grossformate ueber Agentur = Gage und Technik meist vorhanden, Bewerbung formell.

---

## Flyer 07 · Rock im Hinterland

| Feld | Inhalt |
|---|---|
| **Typ** | Festival |
| **Location** | Stoppelacker Obrigheim |
| **Ort** | Obrigheim (Pfalz) |
| **Region** | Rheinland-Pfalz |
| **Social** | IG @rockimhinterland |
| **Headliner** | Swiss & die Andern |
| **Sponsoren/Partner** | BOB! Brauerei; Gemeinde Obrigheim; Filmwelt GmbH Restaurant/Bar; Bill Muessig?; Armbaurn Lichtspiele; Sparkasse; Scharder?; Kaiser? |
| **Tags** | Rock;Pfalz;OpenAir;Kommunal;Kinderprogramm |
| **Passung SPP7** | mittel: eher Party-/Open-Air-Profil als Metal-Nische |
| **Unklar** | Ticketpreis, Tageszuordnung, Technik, Kontakt, Bewerbungsfrist |
| **Quelle** | photo_7 / msg 43936 |
| **Termine** | 21.08.2026-22.08.2026 – Haupttermin <br> 20.08.2026 – Vorabend Pfaelzer Abend - separat bespielbarer Slot |
| **Bands/Acts** | Swiss & die Andern; Engst; Kupfergold; Velvet Rush; Franck Carducci; Escandalos; Alle to get her; The 1478; Liebe & Bravall?; Grabowsky (Vorabend); Woufeschkoenisch? (Vorabend) |
| **Randnotiz** | Im selben Screenshot: tattoo.maus (10.08., Tattoo-Studio, Sponsor-/Stage-Art-Kandidat); Post Torkel mit Sverrir Bergmann Island Tour 2026 (14.-24.08.); initiative_kulturkommunikation: kostenloses Webinar fuer Spielstaetten/Veranstalter Mi 02.09. 14 Uhr; musikschutzgebiet (MSC) |

**Kurz:** Kommunales Kultfestival auf dem Stoppelacker Obrigheim, 21./22.08.2026 plus Pfaelzer Abend am 20.08.

**Lang:** Buergerfestival mit Rock-/Party-Mix und kraeftigem Regional-/Dialekteinschlag, finanziert ueber Gemeinde und lokale Sponsoren, Ticketverkauf ueber Social Ad. Zwei Programmbloecke (Vorabend + Festival) = zwei Bewerbungschancen. Rahmenprogramm Highlandgames, Bierolympia, Kinderprogramm -> Unterhaltung vor Genre.

---

## Flyer 08 · NEXUS Festival

| Feld | Inhalt |
|---|---|
| **Typ** | Festival_Duplikat |
| **Unklar** | Identische FB-Anzeige wie flyer_01, nur anderer Screenshot-Zeitstempel (18:07) - im Datenmodell als zweiter Quellenvermerk, kein eigener Datensatz |
| **Quelle** | photo_8 / msg 43937 |
| **Bands/Acts** | – |

**Kurz:** undefined

**Lang:** 

---

## Flyer 09 · Pell Mell Festival (20th Anniversary)

| Feld | Inhalt |
|---|---|
| **Typ** | Festival |
| **Location** | Sportgelände Obererbach |
| **Ort** | Obererbach (Westerwald) |
| **Region** | Rheinland-Pfalz |
| **Social** | IG @pellmellfest |
| **Headliner** | Haematom; Raised Fist; Itchy; Caliban; Samurai Pizza Cats |
| **Sponsoren/Partner** | BOB! Brauerei; morecore.de; moshed.net; Sparkasse Westerwald-Sieg; Honorine Distribution? |
| **Tags** | Punk;Rock;Metalcore;OpenAir;Westerwald;Camping |
| **Passung SPP7** | hoch: Newcomer-Wellen, regionale Naehe, Zeltplatz-Flair |
| **Unklar** | Altersfreigabe, Ticketpreis, Tageszuordnung, Kontakt-Mail |
| **Quelle** | photo_9 / msg 43938 |
| **Termine** | 04.09.2026-05.09.2026 – Haupttermin, 2 Tage, Camping <br> letzte Bandwelle – Orga kündigt letzte Booking-Welle an -> spaete Bewerbung evtl. moeglich |
| **Bands/Acts** | Haematom; Raised Fist; Itchy; Caliban; Samurai Pizza Cats; Bantamplan; Evil Jared; Destination Anywhere; The Narrator; Venues; Lost in Hollywood; BOA; VMZT; Never Back Down; Palebloom; Left Betrayed; Damn It! |

**Kurz:** Punk-/Rock-Open-Air, 20. Ausgabe, 04./05.09.2026 auf dem Sportgelaende Obererbach bei Koblenz.

**Lang:** Regionales Vereinsfestival mit Camping und Ticketverkauf ueber Social Ads; Line-Up erscheint in Wellen, die letzte Bandwelle wird aktiv beworben -> kurze Dienstwege zur Orga, Newcomer-Slots realistisch. Breites Publikum zwischen Punk und Metal, Buehnentechnik vorhanden.

---

## Flyer 10 · Musikschutzgebiet Festival

| Feld | Inhalt |
|---|---|
| **Typ** | Festival |
| **Location** | Grünhof |
| **Ort** | Nordhessen |
| **Region** | Hessen |
| **Social** | IG @musikschutzgebiet |
| **Headliner** | Team Scheisse; SONO$; Anda Morts |
| **Sponsoren/Partner** | Goldkehlchen Zelt; Gartenfloor (Buehnen-/Zelt-Namen) |
| **Tags** | Punk;Chanson;Theater;Indie;Zelt;OpenAir;Nordhessen |
| **Passung SPP7** | HOCH - Gartenfloor/Goldkehlchen-Zelt passt zu Pirate/Acoustic-Set, explizit offene Stilpalette |
| **Unklar** | Bewerbungsschluss, Kontakt-Mail, Camping, Ticketpreis |
| **Quelle** | photo_10 / msg 43939 |
| **Termine** | 27.08.2026-30.08.2026 – Haupttermin, 4 Tage <br> 13.08.2026 – Post 'NOCH 200 TICKETS' -> ausverkauft-nah, Vorverkauf laeuft |
| **Bands/Acts** | Team Scheisse; SONO$; Anda Morts; Bangerfabrik; Social Dance; 24/7 Diva Heaven; OK KID; Roller Derby; Yung Pepp?; Varley; TZK; BUSH.IDA; Haus F; Fruchtiger Beigeschmack; Antagon Theateraktion; Rathmann; Dark Vatter; Latex; Nina Jacob; Frau Supertramp; Marilyn Harvest; Basalt Yenga; Below A Silent Sky; Boomhorns; Derallerbestebecker; Elara Sunstreak Band; Work In Progress; The Imperial Mustard; DJ Karo; Lolli goes MSG; Tito's Soul Cafe; Shanty-Chor; Brausepoeter; Flower Issues; Ladaria; Andreas Moethe?; Ma Fleur; Ole Oscar; Chris Decker; Streichelmolle; Krishan Drittes OG [Live]; Bernhardt Baum; Klangtrauma; Muetzerich; Der Funkenpilot; Ismir Schnuppe; Justrance; Cypher; Neke Keu; TwentySeconds |
| **Randnotiz** | Direkt darueber im Feed: rockimwald.festival (Nach dem Fest ist vo...), darunter trikaya.festival -> beide als eigene Kandidaten vormerken |

**Kurz:** Musikschutzgebiet Festival 27.-30.08.2026 im Gruenhof/Nordhessen - mehrere benannte Buehnen/Zelte (Mainstage, Goldkehlchen Zelt, Gartenfloor), breiter Punk/Kultur-Mix.

**Lang:** Dezentrales Kulturfestival mit klarer Programmstruktur ueber drei Buehnenformate: Mainstage (gross, Punk/Party), Goldkehlchen Zelt (liedermacherisch/akustisch, auch Shanty-Chor) und Gartenfloor (klein, indie/elektronisch, sehr lange Namensliste). Diese Struktur ist ideal fuer unbekannte Bands: ueber Zelt-/Gartenfloor ist ein Einstieg realistisch. Theateraktion, DJ-Formate und Shanty-Chor zeigen grosse stilistische Offenheit.

---

## Flyer 11 · Hatikwa (hatikwa_official)

| Feld | Inhalt |
|---|---|
| **Typ** | Unklar/Kollektiv |
| **Social** | IG @hatikwa_official; IG @adriakustik |
| **Tags** | Akustik;Sitzkonzert;Nomadenzelt;Community |
| **Passung SPP7** | mittel-hoch als Format-Inspiration, nicht als Festival |
| **Unklar** | Kein Name, Ort, Datum oder Kontakt im Bild - nur Accountnamen; zunaechst zurueckstellen |
| **Quelle** | photo_11 / msg 43940 |
| **Termine** | 05.08.2026 – Post-Datum |
| **Bands/Acts** | – |

**Kurz:** Bildpost von hatikwa_official (Akustik-Konzert im Nomadenzelt mit Buecherregal, Sitzpublikum) - untypisches, sehr nahbares Konzertformat.

**Lang:** Kein Line-Up-Plakat, sondern Stimmungsbild: Musiker mit Akustikgitarre in einem Zelt mit Buecherregalen und Lampen, Publikum auf Sofa/Stühlen im Halbkreis, Gegenlicht. Caption 'Sometimes it's about more...' (EN, 5. August, 892 Likes). Darunter adriakustik mit 'noch ein kurzer, auch unvollstaen...'. Fuer SPP7 relevant als Format-Idee ( acoustic/Zelt-Konzert) und als Kontaktanbahnung zu adriakustik (Netzwerk fuer akustische Bookings).

---

## Flyer 12 · Kleinstadtfestival Meppen

| Feld | Inhalt |
|---|---|
| **Typ** | Festival/Stadtfest |
| **Location** | Innenstadt-Meppen, Buhne am Platz |
| **Ort** | Meppen |
| **Region** | Emsland, Niedersachsen |
| **Social** | IG @waslosinmeppen |
| **Sponsoren/Partner** | Tischlerei Shepers (Danke-Tafel); diverse lokale Staende |
| **Tags** | Stadtfest;Emsland;OpenAir;Kommunal;Nachwuchsbuehne |
| **Passung SPP7** | mittel: kommunale Buehne, geringer Gender-Fit, aber gute Gagen-/Technikchancen |
| **Unklar** | Termin, Bewerbungsweg, Buehnengroesse, Altersstruktur |
| **Quelle** | photo_12 / msg 43941 |
| **Termine** | Vor 2 Stunden (14.09.2026 ca. 17:45) – Bildpost '1/7' mit Dank an Sponsoren - Rueckblick/Ausblick |
| **Bands/Acts** | (auf dem Wegweiser-Schild, Vorabend-/Nachmittagsprogramm): JUNGTAL?; PLAWS; Äänssl & Frank Casino?; CALLI; Ben Newbury |
| **Randnotiz** | Darueber im Feed: jungefreiheit mit Collien Fernandes (1.347 Likes) - kein Bezug |

**Kurz:** Kleinstadtfestival Meppen - kommunales Strassen-/Stadtfest mit Buehne und lokaler Nachwuchsbandschiene, gepuscht ueber das Stadt-Magazin waslosinmeppen.

**Lang:** Foto mit schwarzer Buegen-Banner 'KLEINSTADTFESTIVAL' und Holz-Wegweiser mit dem Tagesprogramm (FREITAG-Spalte sichtbar). Sehr kleiner Kreis an lokalen Acts, dazu Danke-Tafel an die Tischlerei - typisch fuer gefoerderte Stadtfeste mit Buehne der Stadt. Kein Metal-/Punk-Profil, aber niedrige Einstiegshuerde; Reichweite moderat (275 Likes, 24 Shares).

---

## Flyer 13 · Open Air am Berg

| Feld | Inhalt |
|---|---|
| **Typ** | Festival_Bewerbung |
| **Location** | am Berg |
| **Ort** | Eichstätt |
| **Region** | Bayern |
| **Website** | www.openairamberg.de |
| **Social** | IG @openairambergei; FB 'Open Air am Berg' |
| **Sponsoren/Partner** | Kulturverein Joke e.V. |
| **Tags** | OpenAir;Bayern;Verein;EST1992;Bandbewerbung |
| **Passung SPP7** | hoch: etabliertes Familien-/Wiesen-Open-Air mit Bewerbungsfenster, Folk/Rock-Publikum |
| **Unklar** | Kontakt-Mail (vermutlich über Website), Gage, Buehnenzahl, Alter |
| **Quelle** | photo_13 / msg 43942 |
| **Termine** | 01.08.2026-30.09.2026 – Bewerbungsphase fuer 2027 (hartes Fenster!) <br> 14.05.2027-15.05.2027 – Festivaltermin, 2 Tage |
| **Bands/Acts** | – |
| **Randnotiz** | Darueber im Feed: erfolg.zukunft (franzoesischer Street-Art-Kuenstler, 13.08., 954 Likes) - kein Festivalbezug |

**Kurz:** Open Air am Berg bei Eichstätt (Kulturverein Joke e.V., gegr. 1992) - Bewerbungsphase 2027 laeuft vom 01.08. bis 30.09.2026.

**Lang:** Plakat im Retro-Look (schwarz-gold, Noten, Tannenbaeume, Radweg-Sonne): 'Band-Bewerbungsphase 2027', Bewerbungen moeglich 01.08.-30.09.2026, Festival 14./15.05.2027. Verein mit 30-jaehriger Historie und eigener Website = strukturierter Verein, regulaeres Auswahlverfahren. Sehr aktive Community (Post 'Servus Festivalgemeinde': 1.251 Likes, 1.611 Saves).

---

## Flyer 14 · Rock am Beckenrand

| Feld | Inhalt |
|---|---|
| **Typ** | Festival |
| **Social** | IG @rockambeckenrand |
| **Headliner** | Royal Republic; Das Lumpenpack; TBS |
| **Special Guest** | Mr. Hurley & Die Pulveraffen* |
| **Tags** | Punk;Oi;Ska;Folk;Party;OpenAir;WarmUp |
| **Passung SPP7** | SEHR HOCH - Pirate-Folk-/Punk-Publikum, dritter Tag = realistische Slot-Chance |
| **Unklar** | Ort/Location nicht im Screenshot lesbar, keine Website/Mail, Ticketpreis |
| **Quelle** | photo_14 / msg 43943 |
| **Termine** | 28.08.2026-29.08.2026 – Haupttermin <br> 27.08.2026 – Warm-Up-Programm am Donnerstag (Sternchen-Eintrag RAUM27*, Butterwegge*) |
| **Bands/Acts** | TBS; Royal Republic; Das Lumpenpack; Swiss & die Andern; Dritte Wahl; RAUM27*; Mr. Hurley & Die Pulveraffen*; Paula Carolina; Montreal; Engst; Blackout Problems; OK.Danke.Tschüss; Drei Meter Feldweg; Liedfett; Focus; Alex Mofa Gang; Butterwegge*; Tyna; Bruchbude; Nikra; Awesome Scampis; Lina-Mariah; Uli Sailor; Himitzu; Dorfterror; Richie Miller House Band; Womuka; Skaboom; Mitch.One; Bettkantenentscheidung |
| **Randnotiz** | Darueber: rockfor tolerance 'Wir haben ein Festivalpro... mehr' (Vor 5 Tagen) - moeglicher Festival-Partner/Bewerbungsaufruf, vormerken; darunter pauleraulekaule |

**Kurz:** Rock am Beckenrand 28./29.08.2026 (plus Donnerstag-Warm-Up) - grosses Punk-/Oi-/Ska-/Party-Line-Up mit Royal Republic, Das Lumpenpack, TBS, Mr. Hurley & Die Pulveraffen.

**Lang:** Rundes, professionell gestaltetes Line-Up-Plakat (Pinguin-Maskottchen mit Ski-Brille, Brandungs-Welle). Breiter Mix aus Punk, Oi, Ska, Folk-Punk, Liedermacher und Party - explizit auch ein Warm-Up-Programm am Donnerstag, also ein dritter bespielbarer Tag mit kleineren Bands (Sternchen-Eintraege). Mr. Hurley & Die Pulveraffen (Pirate-Folk) als Headline-Referenz: genau das Publikum, das SPP7 mitbringen. Enorm starke Resonanz (1.856 Likes, 470 Saves).

---

## Flyer 15 · Muddy Roots Music (muddyyrootsmusic)

| Feld | Inhalt |
|---|---|
| **Typ** | Location/Label |
| **Location** | Scheune / Stall-Gebäude mit Holzbalken und Buehne |
| **Social** | IG @muddyyrootsmusic |
| **Tags** | Roots;Amphitheater;Scheunenlocation;Liveclub |
| **Passung SPP7** | mittel: akustik-/rootslastig, Format passt zu Unplugged-Set |
| **Unklar** | Ort, Name der Location, Kapazitaet, Ansprechpartner, Konditionen |
| **Quelle** | photo_15 / msg 43944 |
| **Termine** | 01.08.2026 – Post-Datum 'The spirit of... mehr' |
| **Bands/Acts** | – |

**Kurz:** Foto-Post von muddyyrootsmusic: ausverkaufte Scheunen-/Sallenlocation mit Buehne - Roots-/Livemusik-Spielstaette oder Label.

**Lang:** Bild zeigt eine umgebaute Scheune mit sichtbarem Dachstuhl, abgeseilter Buehne mit farbigem Backdrop und dicht stehendem Publikum. Caption nur 'The spirit of...' (UEbersetzung angezeigt, englisch), Reichweite klein (89 Likes, 5 Shares). Typisch fuer einen Club-/Booking-Kreis mit eigener Location statt Festival. Fuer SPP7 als Konzert-Slot ausserhalb von Festivals interessant.

---

## Flyer 16 · Rock im Garten – Ackerfest Open Air

| Feld | Inhalt |
|---|---|
| **Typ** | Festival |
| **Location** | Acker / Schoppenstadt |
| **Ort** | Rohrsheim |
| **Region** | Hessen |
| **Social** | IG @rock_im_garten |
| **Tags** | OpenAir;Hessen;Verein;EST2007;Ska;Punk;Tanzen |
| **Passung SPP7** | hoch: regional, DIY, tanzerisches Publikum, vermutlich Bewerbung/Anfrage moeglich |
| **Unklar** | Datum, Ort der Flaeche, Line-Up, Kontakt, Bewerbungsstatus |
| **Quelle** | photo_16 / msg 43945 |
| **Termine** | 31.07.2026 – Post-Datum (Ankuendigung, Musik Massendefekt) <br> 2026 – Festivaltermin nicht im Bild -> recherche |
| **Bands/Acts** | (Slogan-/Bandverweis: Massendefekt als Sound des Posts) |
| **Randnotiz** | Darueber: kein_bock_auf_nazis 'Hallo August! Kalender ist voll!' (3.379 Likes) – aufmerksames linkes/engagiertes Publikum im Umfeld, kein Festival |

**Kurz:** Rock im Garten (Rohrsheim, gegr. 2007) – 'Wir sehen uns aufm Acker!', Ackerfest Open Air in der Schoppenstadt, Plakat mit Mohnblumen und Punk-Illustration.

**Lang:** Buendeliges Plakat im Linoldruck-Look: 'ROHRSHEIM Rock im Garten EST. 2007 / ACKERFEST OPEN AIR Schoppenstadt', dazu die Zeile 'TANZEN NICHT VERGESSEN.' und ein Pink Mohrrueben-verwaister Punk mit Blume im Mund. Klingt nach Verein/Initiative mit sehr persoenlichem Auftritt (Handletterty), Region Hessen. Slogan verweist auf ein Publikum, das tantoen will - Ska/Punk/Reggae-Wahrscheinlichkeit hoch.

---

## Flyer 17 · Let The Bad Times Roll Open Air

| Feld | Inhalt |
|---|---|
| **Typ** | Festival_Bewerbung |
| **Ort** | Manslagt |
| **Region** | Niedersachsen |
| **Social** | IG @letthebadtimesrollfestival |
| **Tags** | OpenAir;Ostfriesland;DIY;Bandbewerbung;Verein |
| **Passung SPP7** | hoch stilistisch (DIY/Punk), aber Bewerbungsjahr verpasst |
| **Unklar** | Festivaltermin, Ort der Flaeche, Kontakt-Mail, Bewerbungszeitraum 2028 |
| **Quelle** | photo_17 / msg 43946 |
| **Termine** | 7. August 2026 – Post-Datum 'Wir sind platt! 476...' <br> 2027 – Bewerbungen galten fuer das Festival 2027 – Bewerbungsfrist beendet |
| **Bands/Acts** | – |
| **Randnotiz** | Darueber: jey_g_hairytales 'Ich bin als Friseurin eine...' (Vor 6 Tagen) – irrelevant |

**Kurz:** Let The Bad Times Roll Open Air (Manslagt, Niedersachsen) – 476 Bandbewerbungen fuer 2027: dokumentiert enorme Nachfrage bei kleinformatigen DIY-Festivals.

**Lang:** Schwarz-weiss-lila Plakat mit Silhouette und Blitz: '476 FUER 2027 BANDBEWERBUNGEN'. Die Zahl ist die eigentliche Info: ein Dorf-/Wiesen-Open-Air bekommt hunderte Bewerbungen, aber die Orga freut sich ('Wir sind platt'). heisst fuer SPP7: 2027-Fenster ist zu, fuer 2028 frueh bewerben und sich persoenlich bekannt machen.

---

## Flyer 18 · Walterrak Festival (walterrakfestival)

| Feld | Inhalt |
|---|---|
| **Typ** | Festival |
| **Location** | Seecamping-Gelände mit Buehne und Marktstrasse |
| **Social** | IG @walterrakfestival |
| **Tags** | Camping;See;Wald;OpenAir;Anzeige |
| **Passung SPP7** | niedrig-mittel: Camping-Festival mit Mainstream-Ausrichtung |
| **Unklar** | Termin, Line-Up, Ort, Veranstalter, Bewerbung – alles offen |
| **Quelle** | photo_18 / msg 43947 |
| **Termine** | 9. August – Post-Datum des darueberliegenden Beitrags; Festivaltermin nicht im Bild |
| **Bands/Acts** | – |
| **Randnotiz** | Darueber: goslarsche.de-Beitrag 'Gemeinsam mit seinen Eltern...' (9. August) – Lokaljournalismus, irrelevant |

**Kurz:** Werbe-Anzeige mit Luftaufnahme: grosses Zeltlager am See/Baggersee mit Buehnen- und Marktstrasse – Walterrak Festival.

**Lang:** Drohnenbild zeigt hunderte Wohnmobile/Zelte im Wald, eine zentrale Buehne mit Vorplatz, eine lange Markt-/Versorungsmeile und einen Badestrand mit Menschen. Kein Plakat, keine Typo – die Botschaft ist Camping-Infrastruktur. Fuer SPP7 heisst das: Festival mit Uebernachtungs-und Badefaktor, eher grosses Mainstream-/Camping-Publikum, Buchung wohl ueber Agentur/Anzeige.

---

## Flyer 22 · Rock2gether Festival

| Feld | Inhalt |
|---|---|
| **Typ** | Festival |
| **Location** | Herzberg am Harz |
| **Ort** | Herzberg am Harz |
| **Region** | Niedersachsen |
| **Social** | IG @rock2gether (MEHR INFOS @ROCK2GETHER) |
| **Headliner** | Dani Lia; Vince |
| **Sponsoren/Partner** | Demokratie Leben!; Stiftung der Sparkasse Osterode am Harz; bunt statt braun; Lions Club Südharz; JAH; BLCS; Rockgwerkz?; Gloeck am Stein?; Democrazy Crew?; Umsonst & Draußen |
| **Tags** | Umsonst&Draussen;Politisch;Vielfalt;Toleranz;Demokratie;Oberharz |
| **Passung SPP7** | hoch: Foerderkulisse, keine Ticket-Gate, buergernahe Buehne; SPP7 mit politischem/Community-Profil gut vermittelbar |
| **Unklar** | Mail/Ansprechpartner, Buehnengroesse, Alter, Bewerbertool |
| **Quelle** | photo_22 / msg 43951 |
| **Termine** | 05.09.2026 – Festivaltermin, Einlass ab 15:00 Uhr <br> Vor 6 Tagen (ca. 08.09.2026) – Post-Datum im Feed-Kontext |
| **Bands/Acts** | Dani Lia; Vince; Purple Trees; Tante Emma; DJ Versatill |
| **Randnotiz** | Darueber: jungefreiheit 'Neun Tage nach seinem Rücktr...' (995 Likes) – irrelevant |

**Kurz:** Rock2gether Festival, 05.09.2026 Herzberg am Harz – umsonst & draussen, Motto 'Für Vielfalt, Toleranz & Demokratie', vier Acts plus DJ.

**Lang:** Buendnisfestival aus Demokratieförderung und Musik: Plakat im Berg-/Waldlook mit der Zeile 'UMSONST & DRAUSSEN' und einer langen Logo-Leiste der Förderer (Demokratie Leben!, Sparkassenstiftung, bunt statt braun, Lions Club, Jugendhilfe JAH, BLCS). Eintritt frei, Finanzierung über Projektgelder – das bedeutet Honorar ueber Foerdermittel und sehr niedrige Bewerbungshuerde (Vereine suchen regelmaessig lokale Acts). Line-Up deutschsprachig/Pop-Rock bis Singer-Songwriter.

---

## Flyer 23 · Bülow Straßenmusik Festival

| Feld | Inhalt |
|---|---|
| **Typ** | Strassenfest/Location |
| **Location** | Bülowstraße / Ecke Paulinenstraße |
| **Ort** | Leipzig |
| **Region** | Sachsen |
| **Social** | IG @buelowstrassenmusikfestival |
| **Sponsoren/Partner** | leipzig.eintrittsfrei (Index freier Events) |
| **Tags** | Strassenmusik;Leipzig;Eintrittsfrei;Magie;Nachbarschaftsfest |
| **Passung SPP7** | niedrig als Gig, mittel als Netzwerk-Kontakt in Leipzig (gleiche Stadt wie NEXUS) |
| **Unklar** | Kein Contact, keine Bewerbungsregeln im Bild |
| **Quelle** | photo_23 / msg 43952 |
| **Termine** | 22.08.2026 – Festivaltag, 15-20 Uhr |
| **Bands/Acts** | Zauberer Marinko (Charme, Humor, Illusionen, 'ganz nah beim Publikum'); Künstler Zamir (Kunst und Magie, überredende Momente für Staunen) |
| **Randnotiz** | Darueber: alarmsignal_official 'Hey, wir unterstützen…' (Vor 7 Std) – Buendnis-/Unterstuetzungsaufruf; darunter cutratedruggist |

**Kurz:** Bülow Straßenmusik Festival, 22.08.2026, 15–20 Uhr, Bülowstraße/Ecke Paulinenstraße Leipzig – Strassenmusikformat mit Artistik/Magie.

**Lang:** Gelb-schwarzes Plakat (Sonnenmotiv) fuer ein kleine Nachbarschaftsfest: kein Headliner, dafuer Programmpunkte wie Zauberer und Kuenstler. Typisch für ein Straßenmusik-Format mit Buehnenpunkt-Booking: kurzes Set, kein Gage, aber hohe Sichtbarkeit und direktes Kennenlernen von Veranstaltern. Sehr kleine Reichweite (13 Likes),dafuer Support von leipzig.eintrittsfrei – dort lassen sich weitere kostenlose Leipziger Buennen recherchieren.

---

## Flyer 24 · Festival DisTORAMA

| Feld | Inhalt |
|---|---|
| **Typ** | Festival |
| **Social** | IG @distorama_agenda |
| **Special Guest** | Maury♥Tanja – 'Tropical kraut hallucination' |
| **Tags** | Kraut;Psych;Art-Festival;Lagerfeuer;DIY |
| **Passung SPP7** | mittel-hoch stilistisch (Kraut/Theater), aber sehr klein |
| **Unklar** | Termin, Ort, Line-Up, Kontakt komplett offen |
| **Quelle** | photo_24 / msg 43953 |
| **Bands/Acts** | Maury♥Tanja (Tropical Kraut / Psychedelic) |

**Kurz:** Festival DisTORAMA – Kunst-/Kraut-Festival mit buntem Logo, Feuer-Atmosphäre und psychedelischem Auftritt (Maury♥Tanja).

**Lang:** Bildpost: Nachtaufnahme eines Lagerfeuers mit Holzgestell vor blauem Dämmerungshimmel, darunter im Plakat-Stil 'Maury♥Tanja Tropical kraut hallucination' und ein handgezeichnetes Logo mit spiraleförmigem Auge, das einen Fisch/Kaulquappe zeigt. Sehr kleine Reichweite (21 Likes, 5 Shares) und Carousel mit 'Dear Miss Olivia,'-Ansprache – das ist ein Kunst-/Performance-Kontext, kein klassisches Musikfestival. Fuer SPP7 interessant wegen Kraut/Psychedelic-Naehe und buendnisbasieter Buchung.

---

## Flyer 25 · Roots & Sprouts Festival

| Feld | Inhalt |
|---|---|
| **Typ** | Festival |
| **Location** | Freitreppe / Stadtteilbühne (Plakatfoto: Chor auf Treppen) |
| **Ort** | Kassel (zu verifizieren) |
| **Region** | Hessen/NRW-Rand |
| **Social** | IG @_roots_and_sprouts_ |
| **Tags** | Roots;Folk;World;Stadtteilfestival;Chor;OpenAir;Eintrittfrei |
| **Passung SPP7** | hoch für Acoustic-/Gassenformate, hohes Ansehen in der Szene |
| **Unklar** | Exakter Ort, Festivaltermin, Bewerbungsweg, Kontakt |
| **Quelle** | photo_25 / msg 43951 |
| **Termine** | 13.09.2026 – Programmpunkt 'Küko Chor' auf dem Plakat-Carousel <br> Vor 20 Stunden (ca. 13.09.2026) – Post 'SHIFTING VOICES' mit 31,4 Tsd Likes – grosse Resonanz |
| **Bands/Acts** | Küko Chor (Chorformat); weitere Acts im Carousel |

**Kurz:** Roots & Sprouts Festival – Stadtteil-/Weltmusikfestival mit Auftritten auf Freitreppen und Strassen, sehr hohe Reichweite (31,4 Tsd Likes).

**Lang:** Buntes Plakat (gruener Titelbalken, Pink-Muster, SonnenLogo) mit einem Live-Foto: grosser gemischter Chor (Küko Chor) singt von einer Aussenfreitreppe, davor Publikum auf Klappstühlen. Der Post 'SHIFTING VOICES' erreicht 31,4 Tsd Likes und 1.793 Shares – das ist der mit Abstand reichweitenstärkste Eintrag im Export. Stil: World/Folk/Community-Chöre, Eintritt frei, geförderter Stadtteil-Kontext. Für SPP7 als akustisches/Gassen-Set sehr gut vorstellbar.

---

## Flyer 26 · Fockebergfest

| Feld | Inhalt |
|---|---|
| **Typ** | Stadtteilfest |
| **Location** | Fockeberg, Südvorstadt |
| **Ort** | Leipzig |
| **Region** | Sachsen |
| **Social** | IG @nato.leipzig (geteilt), Leipzig.eintrittsfrei |
| **Headliner** | Tim Adieu |
| **Tags** | Stadtteilfest;Leipzig;Eintrittfrei;Bühne |
| **Passung SPP7** | mittel: Stadtteilbuehne, akustisch/Chanson-Publikum |
| **Unklar** | Veranstalter-Mail, Buehnentechnik, Bewerbung |
| **Quelle** | photo_26 / msg 43952 |
| **Termine** | 23.08.2026 – Festtermin <br> 17:30 Uhr – Auftrittszeit von Tim Adieu (Live-Musik, Ballade und Disco) |
| **Bands/Acts** | Tim Adieu (Live-Musik / Ballade und Disco) |
| **Randnotiz** | Darueber: oviva_de 'Individuell statt von der Stange' (208 Likes) – Hochzeits-/Event-Dienstleister, moeglicher Gagen-Partner fuer Privatanlaesse |

**Kurz:** Fockebergfest, 23.08.2026 am Fockeberg (Leipzig Südvorstadt), Eintritt frei, Musik ab 17:30 Uhr.

**Lang:** Plakat in Lila/Pfirsichtönen mit Kirmes-Karussell und Wolle-Mütze-Foto: 'FOCKEBERG FEST / EINTRITT FREI / 17³⁰ Uhr / Tim Adieu / Live-Musik'. Kleines Stadtteilfest mit Buehne am Hang, Programm ueber Anwohner-Initiativen; Reichweite klein (208/29 Likes), aber Teil des Leipziger 'eintrittsfrei'-Netzwerks, das mehrere Bühnen desselben Umkreises listet.

---

## Flyer 27 · Tapetenwerkfest 36.0

| Feld | Inhalt |
|---|---|
| **Typ** | Location/Verein |
| **Location** | Tapetenwerk, Sommerhof |
| **Ort** | Leipzig |
| **Region** | Sachsen |
| **Social** | IG @tapetenwerk; leipzig.eintrittsfrei |
| **Tags** | Kunstareal;Leipzig;Sommerfest;Eintrittfrei;Industriebrache |
| **Passung SPP7** | hoch als Leipzig-Basis/Netzwerk, Hof- und Hallenauftritte |
| **Unklar** | Line-up, Buehnen, Bewerbung, Kontakt-Mail |
| **Quelle** | photo_27 / msg 43953 |
| **Termine** | 04.09.2026 – FREITAG, 04 SEP, 17–0 Uhr <br> Vor 10 Stunden (ca. 22.08.2026) – Post 'IN 2 WOCHEN ist…' |
| **Bands/Acts** | – |

**Kurz:** Tapetenwerkfest 36.0, 04.09.2026 17–0 Uhr im Kunstareal Tapetenwerk Leipzig – Werkhof-Sommerfest mit Hallen, Hof und Nachtprogramm.

**Lang:** Nacht-Foto des Ziegelei-/Fabrikareals mit beleuchteter offener Halle, Treppe und Menschenmenge auf dem Innenhof. Plakatzeile 'TAPETENWERKFEST 36.0 / #TAPETENWERKFEST / FREITAG, 04 SEP, 17 – 0 UHR'. Das Areal vermietet/ateliers und hat multiple Spielstaetten – fuer Bands interessant als ganzjaehriger Konzertkontakt, nicht nur als Festtag. 36. Ausgabe = sehr etabliert.

---

## Flyer 28 · Camp Razzepezzepuff Open Air

| Feld | Inhalt |
|---|---|
| **Typ** | Festival |
| **Location** | Erlebnisgut Riesa-Göhlis |
| **Ort** | Riesa |
| **Region** | Sachsen |
| **Social** | IG @camprazzepezzepuff |
| **Headliner** | Focus.; Tancred |
| **Sponsoren/Partner** | Sprungbrett (Förderung); Razzepezzepuff e.V. |
| **Tags** | OpenAir;Sachsen;DIY;Punk;Indie;Camp;Förderung |
| **Passung SPP7** | hoch: DIY-Camp, Sachsen, gemischtes Indie/Punk-Publikum |
| **Unklar** | Mail, Gage, Zeltplatzregeln |
| **Quelle** | photo_28 / msg 43957 |
| **Termine** | 11.09.2026 – Festivaltermin, ab 18:00 Uhr <br> 21.08.2026 – Post 'FEHLER PASSIEREN…' (Vor 3 Wochen) – Aufbau-/Volunteer-Call |
| **Bands/Acts** | Focus.; Alarmbaby; Tancred; Club 37; Kiosk61 |
| **Randnotiz** | Darueber: kiosk61.music mit Song 'Focus · Viel zu schöner Tag' – die Band selbst hat den Gig beworben |

**Kurz:** Camp Razzepezzepuff Open Air, 11.09.2026 ab 18 Uhr auf dem Erlebnisgut Riesa-Göhlis – Indie/Punk-Camp-Festival mit Funf-Acts-Booking.

**Lang:** Rotes Plakat im DIY-Style: grosses Datum 11.09.2026, 'OPEN AIR', 'ab 18.00 Uhr', Line-Up handschriftlich (Focus., Alarmbaby, Tancred), 'Club 37' als Würfel, Kiosk61 als Bandlogo; dazu das Maskottchen (Erde auf Bockbeinen) und das Sprungbrett-Förderlogo. Post 'FEHLER PASSIEREN…' deutet auf Volunteer-/Aufbauhelfer-Aufruf. Struktur: Zeltcamp + eine Buehne,foerderfähig (Sprungbrett = Landesprogramm Sachsen).

---

## Flyer 29 · Bülowstraßenmusikfestival – Timetable

| Feld | Inhalt |
|---|---|
| **Typ** | Festival_Detail |
| **Location** | Bülowstraße / Ecke Paulinenstraße |
| **Ort** | Leipzig |
| **Region** | Sachsen |
| **Social** | IG @buelowstrassenmusikfestival |
| **Tags** | Strassenmusik;Leipzig;Timetable;Chor;Clownerie;Eintrittfrei |
| **Passung SPP7** | niedrig-mittel: Format-Referenz, kein Headliner-Slot |
| **Unklar** | Kein Contact |
| **Quelle** | photo_29 / msg 43958 |
| **Termine** | 22.08.2026 – Festivaltag, 15:00–20:45 Uhr |
| **Bands/Acts** | – |
| **Zeitplan** | 15:00 Eröffnung; 15:05 Das offene Chor-Projekt; 15:30 Kurzvorstellung Wortartist; 15:35 The Kartals; 16:15 Clowns 'Leipziger Nasen'; 16:45 Komplizen; 17:30 Zauberer; 18:00 Sonnenregen; 18:45 Alina Dalsegno & Jan Kosyk; 19:15 Zychodok; 20:00 Richard Limbert; 20:30 Josepha Wawaa; 20:45 ggf. Richard Limbert |
| **Randnotiz** | Darueber: faktglaublich 'Bayern zahlt 3.000 Euro an alle…' (9. August) – irrelevant |

**Kurz:** Ausführlicher Zeitplan des Bülowstraßenmusikfestivals 22.08.2026 in Leipzig – 13 Programmpunkte, alle 15–45 Minuten im Wechsel.

**Lang:** Gelb-oranges Timetable-Plakat mit Sonnen- und Palettenlogo. Wichtig fuer SPP7 weniger als Gig, sondern als Blaupause: Slotlaenge kurz, viele Programmpunkte, Strassen-/Platzformat ohne Buehne. Shows laufen von 15 bis 20:45 Uhr, auch Chöre und Clownerie. Solche Formate eignen sich fuer akustische Kurzauftritte und Mundpropaganda, nicht fuer Gagen-Booking.

---

## Flyer 30 · Anklamer Hansefest

| Feld | Inhalt |
|---|---|
| **Typ** | Fest/Markt |
| **Location** | Hansestadt Anklam (Innenstadt/Hafen) |
| **Ort** | Anklam |
| **Region** | Mecklenburg-Vorpommern |
| **Website** | (Facebook-Seite 'Hansestadt Anklam') |
| **Social** | Facebook Hansestadt Anklam |
| **Sponsoren/Partner** | Hansestadt Anklam; Region Pomorze Zachodnie (Westpommern, PL) |
| **Tags** | Hansefest;Markt;Stadtjubilaeum;MV;Polen-Naehe |
| **Passung SPP7** | hoch thematisch (Schiff/Hanse = Piratenband-Ästhetik), kommunale Buehne |
| **Unklar** | Datum, Buehnen, Gagen, Bewerbungsweg – alles aus Ad nicht ersichtlich |
| **Quelle** | photo_30 / msg 43959 |
| **Termine** | 2026 – Facebook-Ad fuer die 20. Ausgabe (Pomorze Zachodnie) <br> 2027 – 'Das 21. Anklamer Hansefest findet statt!' + '150 TAGE BIS ZUM' -> Vorlauf 150 Tage, Termin recherche |
| **Bands/Acts** | – |
| **Randnotiz** | Oben im Screenshot die App 'Rowery WZP' (Fahrradverleih Westpommern) – Hinweis auf polnisches Publikum im Umfeld |

**Kurz:** Anklamer Hansefest – städtisches Hansetfest (20./21. Ausgabe) in Anklam, MV; beworben auch über die polnische Region Westpommern.

**Lang:** Facebook-Screenshot: Logo mit Wikinger-/Hanseschiff, Nachtfoto mit Riesenrad am Wasser, dazu '150 TAGE BIS ZUM Anklamer hansefest' und 'Das 21. Anklamer Hansefest findet statt!'. Kommunales Grossfest mit Markt, Riesenrad und Hafenlage – fuer海盗-Themen (Schiff-Logo!) sehr anschlussfähig. Die Ad kommt von der polnischen Nachbarregion, d.h. touristische Vermarktung ueber Grenze, potenziell mit Programm fuer Strassenkuenstler und Buehnen.

---

## Flyer 33 · Piraten-Nacht (Born to Rock, München)

| Feld | Inhalt |
|---|---|
| **Typ** | Reihe/Event |
| **Location** | BTR – Landsberger Str. 185 |
| **Ort** | München |
| **Region** | Bayern |
| **Social** | IG @borntorockmunich (Facebook-Anzeige) |
| **Special Guest** | DJ MicDi |
| **Sponsoren/Partner** | Born to Rock (Veranstalter); DJ MicDi |
| **Tags** | Piratenmusik;FolkMetal;Irish;PirateMetal;Reihe;Clubabend;München |
| **Passung SPP7** | MAXIMAL – Kernzielgruppe, Kerngenre, Kern-Ästhetik |
| **Unklar** | Mail/Telefon, Eintritt, ob Bandbewerbung moeglich ist, weitere Termine |
| **Quelle** | photo_33 / msg 43962 |
| **Termine** | 20.06.2026 – Termin, ab 21:00 Uhr <br> 2026 – Carousel 2/4 – Reihe laeuft weiter, weitere Termine recherche |
| **Bands/Acts** | Referenzliste der Reihe: Mr. Hurley und die Pulveraffen; Santiano; D'Artagnan; Rauhbein; Alestorm; Ye Banished Privateers; The Rumjacks; Feuerschwanz; The Irish Rovers; Saltatio Mortis; Vroudenspil; Tortuga; Cala Rook; Die Gossenpoeten; Storm Seeker; The Blackbeers; Rumahoy; Visions of Atlantis; The O'Rillys and the Paddyhats; Knasterbart; Rumproof; Tanzwut; Fiddlers Green; Dragony; Soundtracks von Piratenfilmen |
| **Randnotiz** | Darueber im Feed: allforjolly 'Things I am missing about band life….' (Vor 6 Tagen, 86 Likes, 25 Shares) – Band-Netzwerk-Account, fuer Erfahrungs-/Tourinfos vormerken |

**Kurz:** PIRATEN-NACHT im Born to Rock München, 20.06.2026 ab 21 Uhr – Piratenmusik-, Folk- & Rock-Abend mit DJ MicDi; die Referenzliste liest sich wie exakt das Booking-Profil von SPP7.

**Lang:** Facebook-Anzeige mit KI-gestochenem Piraten-Skelett-Motiv (Totenköpfe in Dreispitz und Redingote an einem Fass mit Bierkrügen, Karte im Hintergrund) und der Zeile 'Piraten-, Folk- & Rockmusic mit Bands wie z.B.' – danach 25 Bandnamen. Das ist der mit Abstand passendste Eintrag im gesamten Export: hier wird nicht ein Festival beworben, sondern ein Format, in dem eine Piratenband Stammgast sein kann. Die Genre-Bandbreite reicht von Alestorm/Santiano bis Saltatio Mortis/Fiddlers Green, also Folk-Punk über Pirate-Metal bis Mittelalter. Als Clubabend mit DJ-Bestueckung niedrigschwellig, über mehrere Carousel-Folien verteilt (2/4).

---

## Flyer 34 · Badewannen Rennen

| Feld | Inhalt |
|---|---|
| **Typ** | Wettkampf/ Dorf-Event |
| **Location** | Dorfteich Würchwitz |
| **Ort** | Würchwitz (Zeitzer Land) |
| **Region** | Sachsen-Anhalt |
| **Social** | Chat-Screenshot (Tine Bockwitz, gestern 19:31) |
| **Tags** | Dorffest;Schwimmen;Kultur;Freizeit;SAA |
| **Passung SPP7** | niedrig-mittel: kein Buehnenformat, aber Sehbeteiligung im ländlichen Raum |
| **Unklar** | Veranstalter, ob Musikprogramm vorhanden, Kontakt |
| **Quelle** | photo_34 / msg 43963 |
| **Termine** | 12.06.2026 – Termin, Beginn 18:00 Uhr |
| **Bands/Acts** | – |

**Kurz:** Badewannen Rennen am 12.06.2026, 18 Uhr, Dorfteich Würchwitz – Spass-Wettkampf mit Badewannen, typisches Dorf-Kulturformat.

**Lang:** Illustration (Vater, Mutter, Kind in der Badewanne mit Poes) auf blauem Feld, darunter orangefarbener Infoblock mit Datum, Beginn und Ort. Der Screenshot stammt aus einem Chat, nicht aus einem Oeffentlichen Feed – Hinweis: dies ist ein Tipp aus dem persönlichen Umfeld. Fuer SPP7 eventuell relevant als Kurzauftritt/Begleitprogramm bei Dorf-/See-Events (vgl. 'Musik am Bergsee' im Chat, 11.07.2026, Kloster Posa, Eintritt frei).

---

## Flyer 35 · unreleaseD Tour 2026 – Leipzig Wildcard

| Feld | Inhalt |
|---|---|
| **Typ** | Newcomer-Contest |
| **Location** | Leipzig (Tour-Stop) |
| **Ort** | Leipzig |
| **Region** | Sachsen |
| **Social** | IG @tunecore.de |
| **Sponsoren/Partner** | unreleaseD; TuneCore Deutschland |
| **Tags** | Newcomer;Contest;Wildcard;TuneCore;Leipzig;Bewerbung |
| **Passung SPP7** | hoch als Newcomer-Buehne, kein Gagen-Booking |
| **Unklar** | Termin des Leipzig-Stops, Ablauf, Auswahlgremium |
| **Quelle** | photo_35 / msg 43964 |
| **Termine** | 2026 – Tour 2026, letzter Newcomer-Slot Leipzig – Frist offen |
| **Bands/Acts** | – |

**Kurz:** GESUCHT: LEIPZIG ARTISTS – die letzte Newcomer-Wildcard für den unreleaseD-Tourstop in Leipzig, Registrierung über TuneCore.

**Lang:** Reel-Screenshot (IG, 7 Likes) mit rotem 'Registrieren'-Button: 'DER LETZTE NEWCOMER SLOT FÜR DEN TOUR STOP IN LEIPZIG – unreleaseD WILDCARD – Deine Performance bei der unreleaseD Tour 2026'. Kampagne von TuneCore: Bands auf der unreleaseD-Stage (Festivalbühne mit Label-Partnern) koennen sich online registrieren, ohne Manager/Agentur. Perfekt als 'schneller' Meilenstein neben den Festivalbewerbungen – Leipzig-Cluster (NEXUS, Tapetenwerk, Bülow-Festival, Fockebergfest).

---

## Noch nicht extrahiert (49 Flyer)

flyer_19, flyer_20, flyer_21, flyer_31, flyer_32, flyer_36, flyer_37, flyer_38, flyer_39, flyer_40, flyer_41, flyer_42, flyer_43, flyer_44, flyer_45, flyer_46, flyer_47, flyer_48, flyer_49, flyer_50, flyer_51, flyer_52, flyer_53, flyer_54, flyer_55, flyer_56, flyer_57, flyer_58, flyer_59, flyer_60, flyer_61, flyer_62, flyer_63, flyer_64, flyer_65, flyer_66, flyer_67, flyer_68, flyer_69, flyer_70, flyer_71, flyer_72, flyer_73, flyer_74, flyer_75, flyer_76, flyer_77, flyer_78, flyer_79

> Pipeline steht: 3 Flyer pro Montage-Durchgang, 1 Schritt = 3 Flyer.
