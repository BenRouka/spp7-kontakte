import { addDays, shortRange, type CalendarReview, type ReviewedEvent } from "@/lib/calendar-model";

// Shared by the retained Arena surface and the aligned Option-B package.
export function confirmation(event: ReviewedEvent) {
  return event.source.uncertain ? "unbestätigt" : "in Quelle nicht als unbestätigt markiert";
}
export function csvCell(value: string | number) {
  const text = String(value);
  const safe = /^[=+@-]/.test(text) ? `'${text}` : text;
  return `"${safe.replaceAll('"', '""')}"`;
}
export function csvReport(data: CalendarReview, originals = false) {
  const headers = originals
    ? ["Quellzeilen_ID", "Quellzeile", "Datum_Original", "Name_Original", "Ort_Original", "Sternchen", "Ort_offen"]
    : ["Quellzeilen_ID", "Zeitraum_ID", "Name_Original", "Datum_Original", "Ort_Original", "Beginn_ISO", "Ende_ISO", "Zeitraumtyp", "Datumsherkunft", "Bestätigungsstatus"];
  const rows = originals
    ? data.rows.map((row) => [row.id, row.lineNumber, row.dateOriginal, row.nameOriginal, row.placeOriginal, row.uncertain ? "unbestätigt" : "nicht markiert", row.locationOpen ? "ja" : "nein"])
    : [data.advent, data.christmas].flatMap((event) => event.periods.map((period) => [event.source.id, period.id, event.source.nameOriginal, event.source.dateOriginal, event.source.placeOriginal, period.start, period.end, event.kind === "weekends" ? "getrennte Adventswochenenden" : "durchgehend", event.dateOrigin, confirmation(event)]));
  return "\uFEFF" + [headers, ...rows].map((row) => row.map(csvCell).join(";")).join("\r\n");
}
export function markdownReport(data: CalendarReview) {
  return [
    `# SPP7 · Klärung des Zeitmodells ${data.year}`,
    "", `Gemeinsamer Stand A/B: ${data.modelVersion}.`,
    "Nur Prüfansicht. Keine Änderung der Originalquellen, kein Datenbankimport.",
    "", "## Vier Adventswochenenden · Herne / Schloss Strünkede", "",
    `Original: ${data.advent.source.originalLine.replaceAll("\t", " | ")}`,
    `Datumsherkunft: berechnet. Bestätigungsstatus: ${confirmation(data.advent)}.`, "",
    "| Advent | Beginn | Ende | Wochentage |", "|---|---|---|---|",
    ...data.advent.periods.map((period) => `| ${period.ordinal}. Advent | ${period.start} | ${period.end} | ${data.advent.weekdayLabel} |`),
    "", "Ein Quelltermin mit vier getrennten Zeitfenstern; die Tage dazwischen sind keine Veranstaltungstage dieses Eintrags.",
    "", `Kirchenregel: ${data.adventRule.fourthSunday}`, data.adventRule.christmasSunday,
    `Beleg zur Regel: ${data.adventRule.sourceUrl}`,
    "", "## Durchgehender Weihnachtsmarkt · Dresden / Stallhof", "",
    `Original: ${data.christmas.source.originalLine.replaceAll("\t", " | ")}`,
    `Zeitraum: ${shortRange(data.christmas.periods[0])} ${data.year} (${data.christmas.dayCount} Kalendertage).`,
    `Datumsherkunft: aus Quelle. Bestätigungsstatus: ${confirmation(data.christmas)}.`,
    "Eigener Termin. Keine Adventsberechnung und keine Aufteilung in Wochenenden.",
    "", "## Festgehaltene Regeln", "",
    "- Termine Januar–September 2026 werden nicht nacherfasst; die Originalquelle bleibt erhalten.",
    `- „180 maps“ entspricht ${data.inventory.geocodedEvents} Event-Einträgen mit Koordinaten, nicht der Bilderzahl. Es sind ${data.inventory.uniqueEventCoordinates} unterschiedliche Koordinatenpaare.`,
    "- * und ** bedeuten gleichermaßen: Termin oder Ort wahrscheinlich, jedoch noch unbestätigt.",
    "- Originalschreibweisen bleiben erhalten; eine spätere Normierung wird nur zusätzlich geführt.",
    "- Zwei Namen in einem Adressblock bleiben eine Zeile mit Haupt- und Zusatzname.",
    "- Berechnete Daten sind nicht automatisch bestätigte Termine.",
    "", "Vorsicht: Vier getrennte Zeitfenster erfordern beim späteren Import eine Zuordnung mehrerer Zeiträume zu einem Quelltermin. Eine Schemaänderung ist hier nicht vorgenommen worden.",
    "", `Quelle: ${data.sourceUrl}`, `Stand der Terminliste 2027: 22. September 2026. ${data.totals.all} Quellzeilen (${data.totals.year2026} aus 2026, ${data.totals.year2027} aus 2027).`, "",
  ].join("\n");
}
function icalEscape(value: string) {
  return value.replaceAll("\\", "\\\\").replaceAll("\n", "\\n").replaceAll(";", "\\;").replaceAll(",", "\\,");
}
function foldLine(line: string) {
  const encoder = new TextEncoder();
  const lines: string[] = [];
  let current = "";
  for (const char of line) {
    if (encoder.encode(current + char).length > 75) { lines.push(current); current = " " + char; }
    else current += char;
  }
  lines.push(current);
  return lines.join("\r\n");
}
export function calendarReport(data: CalendarReview, now = new Date()) {
  const stamp = now.toISOString().replaceAll("-", "").replaceAll(":", "").split(".")[0] + "Z";
  const lines = ["BEGIN:VCALENDAR", "VERSION:2.0", "PRODID:-//SPP7//Read-only review//DE", "CALSCALE:GREGORIAN", "METHOD:PUBLISH", `X-WR-CALNAME:SPP7 Zeitmodell ${data.year} – Prüfansicht`, `X-SPP7-MODEL-VERSION:${data.modelVersion}`];
  for (const event of [data.advent, data.christmas]) {
    for (const period of event.periods) {
      const description = `${event.source.originalLine.replaceAll("\t", " | ")}\nDatumsherkunft: ${event.dateOrigin}. Status: ${confirmation(event)}. Nur Prüfansicht; kein bestätigter Buchungstermin.`;
      lines.push("BEGIN:VEVENT", `UID:${period.id}@spp7-werkstatt`, `DTSTAMP:${stamp}`, `DTSTART;VALUE=DATE:${period.start.replaceAll("-", "")}`, `DTEND;VALUE=DATE:${addDays(period.end, 1).replaceAll("-", "")}`, `SUMMARY:${icalEscape(`${event.source.uncertain ? "Unbestätigt: " : "Prüfansicht: "}${event.source.nameOriginal}${event.kind === "weekends" ? ` – ${period.ordinal}. Advent` : ""}`)}`, `DESCRIPTION:${icalEscape(description)}`, `LOCATION:${icalEscape(event.source.placeOriginal)}`, `URL:${data.sourceUrl}`, "TRANSP:TRANSPARENT", "END:VEVENT");
    }
  }
  lines.push("END:VCALENDAR");
  return lines.map(foldLine).join("\r\n") + "\r\n";
}
