import "server-only";
import { and, asc, count, desc, eq, ilike, or, sql } from "drizzle-orm";
import { db } from "@/db";
import {
  altActs,
  altChatMessages,
  altContacts,
  altEventActs,
  altEventChannels,
  altEventDates,
  altEventFeatures,
  altEventPartners,
  altEventTags,
  altEvents,
  altFeedContext,
  altFlyerSources,
  altPartners,
  altTimetable,
  kontakte,
  terminAltEvent,
  termine,
} from "@/db/schema";

/* ------------------------------------------------------------------ */
/* Altbestand — ausschließlich lesender Zugriff.                       */
/* Kuratierte Daten bleiben führend; hier wird nur ergänzt (Prio 2).   */
/* ------------------------------------------------------------------ */

export async function getAltKennzahlen() {
  const r = await db.execute(sql`
    select
      (select count(*) from alt_events)                                as events,
      (select count(*) from alt_events where zuordnung = 'kuratiert')  as events_kuratiert,
      (select count(distinct termin_sf_id) from termin_alt_event)      as termine_verknuepft,
      (select count(*) from alt_acts)                                  as acts,
      (select count(*) from alt_partners)                              as partners,
      (select count(*) from alt_flyer_sources)                         as flyer,
      (select count(*) from alt_chat_messages)                         as chat,
      (select count(*) from alt_contacts where zuordnung = 'kuratiert') as kontakte_verknuepft,
      (select count(*) from alt_contacts)                              as kontakte,
      (select count(*) from alt_events where lat is not null)          as geocodiert,
      (select count(*) from alt_events where geo_qualitaet = 'zentroid') as geo_zentroid,
      (select count(*) from alt_event_tags)                            as tags,
      (select count(*) from alt_feed_context where verwaist)           as feed_verwaist
  `);
  const x = r.rows[0] as Record<string, string | number>;
  const n = (v: string | number) => Number(v);
  return {
    events: n(x.events),
    eventsKuratiert: n(x.events_kuratiert),
    termineVerknuepft: n(x.termine_verknuepft),
    acts: n(x.acts),
    partners: n(x.partners),
    flyer: n(x.flyer),
    chat: n(x.chat),
    kontakteVerknuepft: n(x.kontakte_verknuepft),
    kontakte: n(x.kontakte),
    geocodiert: n(x.geocodiert),
    geoZentroid: n(x.geo_zentroid),
    tags: n(x.tags),
    feedVerwaist: n(x.feed_verwaist),
  };
}

export type AltFilter = "alle" | "kuratiert" | "rest";

export async function getAltEventListe(filter: AltFilter, suche: string) {
  const where = [];
  if (filter !== "alle") where.push(eq(altEvents.zuordnung, filter));
  const q = suche.trim();
  if (q.length > 0) {
    where.push(
      or(
        ilike(altEvents.name, `%${q}%`),
        ilike(altEvents.ort, `%${q}%`),
        ilike(altEvents.eventId, `%${q}%`),
        ilike(altEvents.typ, `%${q}%`),
      ),
    );
  }
  const rows = await db
    .select({
      eventId: altEvents.eventId,
      name: altEvents.name,
      typ: altEvents.typ,
      ort: altEvents.ort,
      plz: altEvents.plz,
      region: altEvents.region,
      quelleTyp: altEvents.quelleTyp,
      zuordnung: altEvents.zuordnung,
      geoQualitaet: altEvents.geoQualitaet,
      lat: altEvents.lat,
      flyer: altEvents.flyer,
      bewerbungStatus: altEvents.bewerbungStatus,
      gage: altEvents.gage,
    })
    .from(altEvents)
    .where(where.length > 0 ? and(...where) : undefined)
    .orderBy(asc(altEvents.eventId))
    .limit(400);

  const acts = await db
    .select({ eventId: altEventActs.altEventId, n: count() })
    .from(altEventActs)
    .groupBy(altEventActs.altEventId);
  const actMap = new Map(acts.map((a) => [a.eventId, Number(a.n)]));

  const sf = await db
    .select({
      eventId: terminAltEvent.altEventId,
      sfId: terminAltEvent.terminSfId,
    })
    .from(terminAltEvent);
  const sfMap = new Map<string, string[]>();
  for (const r of sf)
    sfMap.set(r.eventId, [...(sfMap.get(r.eventId) ?? []), r.sfId]);

  return rows.map((r) => ({
    ...r,
    actCount: actMap.get(r.eventId) ?? 0,
    sfIds: sfMap.get(r.eventId) ?? [],
  }));
}

/** Vollständige Formularansicht eines Events — alles, was daran hängt. */
export async function getAltEventDetail(eventId: string) {
  const event = await db.query.altEvents.findFirst({
    where: eq(altEvents.eventId, eventId),
  });
  if (!event) return null;

  const [
    dates,
    acts,
    partners,
    features,
    channels,
    tags,
    timetable,
    flyers,
    chat,
    feed,
    verknuepfte,
  ] = await Promise.all([
    db
      .select()
      .from(altEventDates)
      .where(eq(altEventDates.altEventId, eventId))
      .orderBy(asc(altEventDates.vonIso)),
    db
      .select({
        linkId: altEventActs.linkId,
        actId: altEventActs.actId,
        name: altActs.name,
        rolle: altEventActs.rolle,
        slotTag: altEventActs.slotTag,
        unsicher: altEventActs.unsicher,
        notiz: altEventActs.notiz,
        anzahlEvents: altActs.anzahlEvents,
      })
      .from(altEventActs)
      .innerJoin(altActs, eq(altEventActs.actId, altActs.actId))
      .where(eq(altEventActs.altEventId, eventId))
      .orderBy(asc(altEventActs.linkId)),
    db
      .select({
        linkId: altEventPartners.linkId,
        partnerId: altEventPartners.partnerId,
        name: altPartners.name,
        rolle: altEventPartners.rolle,
        unsicher: altEventPartners.unsicher,
      })
      .from(altEventPartners)
      .innerJoin(
        altPartners,
        eq(altEventPartners.partnerId, altPartners.partnerId),
      )
      .where(eq(altEventPartners.altEventId, eventId)),
    db
      .select()
      .from(altEventFeatures)
      .where(eq(altEventFeatures.altEventId, eventId)),
    db
      .select()
      .from(altEventChannels)
      .where(eq(altEventChannels.altEventId, eventId)),
    db
      .select({ tag: altEventTags.tag })
      .from(altEventTags)
      .where(eq(altEventTags.altEventId, eventId))
      .orderBy(asc(altEventTags.tag)),
    db
      .select()
      .from(altTimetable)
      .where(eq(altTimetable.altEventId, eventId))
      .orderBy(asc(altTimetable.zeit)),
    db
      .select()
      .from(altFlyerSources)
      .where(eq(altFlyerSources.altEventId, eventId)),
    db
      .select()
      .from(altChatMessages)
      .where(eq(altChatMessages.altEventId, eventId))
      .orderBy(asc(altChatMessages.datum)),
    db
      .select()
      .from(altFeedContext)
      .where(eq(altFeedContext.altEventId, eventId)),
    db
      .select({
        sfId: terminAltEvent.terminSfId,
        basis: terminAltEvent.basis,
        score: terminAltEvent.score,
        hinweis: terminAltEvent.hinweis,
        name: termine.nameOriginal,
        datum: termine.datumOriginal,
        plzOrt: termine.plzOrtOriginal,
        jahr: termine.jahr,
        anzahl: termine.zeitfensterAnzahl,
      })
      .from(terminAltEvent)
      .innerJoin(termine, eq(terminAltEvent.terminSfId, termine.sfId))
      .where(eq(terminAltEvent.altEventId, eventId))
      .orderBy(asc(terminAltEvent.terminSfId)),
  ]);

  return {
    event,
    dates,
    acts,
    partners,
    features,
    channels,
    tags: tags.map((t) => t.tag),
    timetable,
    flyers,
    chat,
    feed,
    verknuepfte,
  };
}

export type AltEventDetail = NonNullable<
  Awaited<ReturnType<typeof getAltEventDetail>>
>;

/** Band-zentrierte Sicht: Act → Festivals → Chats. */
export async function getActListe(suche: string) {
  const q = suche.trim();
  const rows = await db
    .select({
      actId: altActs.actId,
      name: altActs.name,
      rollen: altActs.rollen,
      anzahlEvents: altActs.anzahlEvents,
      verknuepft: count(altEventActs.linkId),
    })
    .from(altActs)
    .leftJoin(altEventActs, eq(altEventActs.actId, altActs.actId))
    .where(q.length > 0 ? ilike(altActs.name, `%${q}%`) : undefined)
    .groupBy(altActs.actId)
    .orderBy(desc(count(altEventActs.linkId)), asc(altActs.name))
    .limit(300);
  return rows.map((r) => ({ ...r, verknuepft: Number(r.verknuepft) }));
}

export async function getActDetail(actId: string) {
  const act = await db.query.altActs.findFirst({
    where: eq(altActs.actId, actId),
  });
  if (!act) return null;
  const events = await db
    .select({
      eventId: altEvents.eventId,
      name: altEvents.name,
      typ: altEvents.typ,
      ort: altEvents.ort,
      plz: altEvents.plz,
      quelleTyp: altEvents.quelleTyp,
      zuordnung: altEvents.zuordnung,
      rolle: altEventActs.rolle,
      slotTag: altEventActs.slotTag,
      unsicher: altEventActs.unsicher,
      notiz: altEventActs.notiz,
    })
    .from(altEventActs)
    .innerJoin(altEvents, eq(altEventActs.altEventId, altEvents.eventId))
    .where(eq(altEventActs.actId, actId))
    .orderBy(asc(altEvents.eventId));

  const eventIds = events.map((e) => e.eventId);
  const chat =
    eventIds.length > 0
      ? await db
          .select()
          .from(altChatMessages)
          .where(
            sql`${altChatMessages.altEventId} in ${sql.raw(
              `(${eventIds.map((e) => `'${e.replace(/'/g, "''")}'`).join(",")})`,
            )}`,
          )
          .orderBy(asc(altChatMessages.datum))
          .limit(40)
      : [];
  return { act, events, chat };
}

/** Kontaktbezug: kuratierter KV ↔ Alt-Kontakte (Kanaltrennung, O-09). */
export async function getAltKontaktBruecke() {
  const rows = await db
    .select({
      contactId: altContacts.contactId,
      organisation: altContacts.organisation,
      typ: altContacts.typ,
      ort: altContacts.ort,
      region: altContacts.region,
      lat: altContacts.lat,
      notiz: altContacts.notiz,
      msg: altContacts.msg,
      zuordnung: altContacts.zuordnung,
      kvId: altContacts.kuratiertKvId,
      kvName: kontakte.name,
      vermerk: altContacts.vermerk,
    })
    .from(altContacts)
    .leftJoin(kontakte, eq(altContacts.kuratiertKvId, kontakte.kvId))
    .orderBy(asc(altContacts.contactId));
  return rows;
}

/** Geo-Prüfliste (O-11): Koordinaten nie ungeprüft übernehmen. */
export async function getGeoPruefliste() {
  const rows = await db
    .select({
      qualitaet: altEvents.geoQualitaet,
      n: count(),
    })
    .from(altEvents)
    .groupBy(altEvents.geoQualitaet)
    .orderBy(desc(count()));
  return rows.map((r) => ({ ...r, n: Number(r.n) }));
}

export async function getFlyerListe(limit = 120) {
  return db
    .select({
      flyer: altFlyerSources.flyer,
      thumb: altFlyerSources.bildThumb,
      original: altFlyerSources.bildOriginal,
      status: altFlyerSources.status,
      eventId: altFlyerSources.altEventId,
      eventName: altEvents.name,
      format: altFlyerSources.format,
      ocr: altFlyerSources.ocrRohtext,
    })
    .from(altFlyerSources)
    .leftJoin(altEvents, eq(altFlyerSources.altEventId, altEvents.eventId))
    .orderBy(asc(altFlyerSources.flyer))
    .limit(limit);
}

/** Termine der Werkstatt mit ihrem Altbestands-Bezug (oder ohne). */
export async function getTermineMitAltBezug() {
  const rows = await db
    .select({
      sfId: termine.sfId,
      jahr: termine.jahr,
      name: termine.nameOriginal,
      plzOrt: termine.plzOrtOriginal,
      datum: termine.datumOriginal,
      altEventId: terminAltEvent.altEventId,
      basis: terminAltEvent.basis,
      hinweis: terminAltEvent.hinweis,
      altName: altEvents.name,
      lat: altEvents.lat,
      lng: altEvents.lng,
      geoQualitaet: altEvents.geoQualitaet,
    })
    .from(termine)
    .leftJoin(terminAltEvent, eq(terminAltEvent.terminSfId, termine.sfId))
    .leftJoin(altEvents, eq(terminAltEvent.altEventId, altEvents.eventId))
    .orderBy(asc(termine.sortierung));
  return rows;
}
