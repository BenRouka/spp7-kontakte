# SPP7 · Aktueller Handoff für den Zeitmodell-Abgleich A/B

**Maßgeblicher Zeitmodell-Stand: zeitmodell-2026-2027-v2.**
Option A bleibt die gewählte Arena-Oberfläche. Die freigegebenen Zeitmodell-Änderungen sind in der lokalen aktualisierten Option-B-Kopie nachgezogen.
GitHub und eine separate Arena-Instanz wurden nicht direkt bearbeitet.

## Arbeitsroutinen

- Nicht raten, schätzen oder Angaben stillschweigend interpretieren.
- Originaldateien nie verändern. Zusätzlich berechnete oder normierte Angaben gesondert kennzeichnen.
- Keine Schemaänderung oder Datenbankimporte ohne gesonderte Freigabe.
- Nächste Stufen nicht automatisch starten.

## Jetzt gültig

1. Herne 2026: vier getrennte Do.–So.-Wochenenden; Datum berechnet; in Quelle ohne Sternchen. Ohne Sternchen bedeutet nicht bestätigt.
2. Herne 2027: vier getrennte Fr.–So.-Wochenenden; Datum berechnet; unbestätigt (*).
3. Dresden/Stallhof 2027: durchgehend 24.11.–23.12.2027; eigenes Datum aus Quelle; unbestätigt (*), nicht Advent.
4. Dresden 2026 bleibt unverändert als durchgehender Quellzeitraum 25.11.–23.12.2026 erhalten.
5. Datumsherkunft und Bestätigungsstatus sind unabhängig. Kein automatischer Wechsel auf „verifiziert“.
6. F1 ist geklärt: vergangene Termine Januar–September 2026 nicht nacherfassen.
7. F2 ist geklärt: 180 Event-Einträge mit Koordinaten; 149 verschiedene Koordinatenpaare. Nicht die Bildzahl.
8. * und ** bedeuten unbestätigt. Zwei Namen im Adressblock werden als Haupt-/Zusatzname geführt. Originalschreibweisen bleiben erhalten.

## Kirchenregel

Der 4. Advent ist der letzte Sonntag vor dem 25. Dezember (18.–24. Dezember).
Fällt der 25. Dezember auf einen Sonntag, ist der 4. Advent am 18. Dezember, nicht am 25. Dezember.
Beleg: https://katholisch.de/artikel/15657-das-bedeuten-die-vier-advenssonntage

## Dateien und Reproduzierbarkeit

- werkstatt/03-berichte/zeitmodell-a-b.md: lesbarer Abgleich samt Korrektur der alten Angaben.
- werkstatt/03-berichte/zeitmodell-stand.json: vier geprüfte Quelltermine mit insgesamt zehn Zeitfenstern; berechnete Herne-Termine getrennt von Dresden.
- werkstatt/03-berichte/zeitfenster-pruefung.csv: die zehn Zeitfenster; kein vollständiger Stufe-2-Import.
- werkstatt/03-berichte/option-b-manifest.json: Änderungen, Dateiprüfsummen und unverändert übernommene Quellen.
- docs/archiv/: unveränderte historische Notizen, ausdrücklich nicht die aktive Berechnungsgrundlage.
- scripts/check-time-model.mjs: Regressionstest für die acht Adventsfenster, Dresden, Quellstatus und Weihnachten am Sonntag.
- /api/review?year=2026 bzw. 2027: gemeinsame lesende Prüfdaten.
- /api/review/export?year=2027&format=md bzw. csv oder ics: gemeinsame Berichtserzeugung.

## Tatsächlicher Pipeline-Stand

| Stufe | Stand |
|---|---|
| 1 · Quellen sichern | Im ursprünglichen Option-B-ZIP sind nur zwei der fünf benannten Originale enthalten. Drei weitere sind extern referenziert. Vollständige Ablage nicht nachgewiesen. |
| 2 · Normieren | Zeitmodell geklärt und als Prüfdaten abgebildet; vollständige Normierung der 32 Adressblöcke / 54 Quellzeilen noch nicht durchgeführt. |
| 3 · Abgleich | Nur der A/B-Zeitmodell-Abgleich durchgeführt; vollständiger Quellen↔App-Abgleich steht aus. |
| 4 · Entscheidungen | Zeitmodell, F1/F2 und Erhalt der Originale geklärt; Konflikt-/Dublettenentscheidungen stehen aus. |
| 5 · Import | Nicht begonnen. Kein neues Schema und keine DB-Schreibzugriffe. |
| 6 · App | Option A als Prüfansicht beibehalten; kein Umbau der ursprünglichen Bestands-App. |

## Weiterhin offen

- E3: Tabellen-/Zuordnungskonzept vor dem späteren Import entscheiden.
- E4: Kontakte-Felder für Straße, PLZ, Telefon, Fax, Website und mehrere Kontaktkanäle entscheiden. Vorsicht: verändert das Datenmodell.
- E5: Datenschutz und Umgang mit den bereits öffentlich liegenden Bestandsdaten entscheiden.
- F3: Kontakt-Dubletten nicht automatisch zusammenführen.

werkstatt/ liegt außerhalb von public/ und wird nicht automatisch als statische Datei ausgeliefert. Das ist keine allgemeine Zugriffskontrolle. Das Downloadpaket enthält nur die bereits bereitgestellte Werkstatt und den eng begrenzten Zeitmodell-Abgleich, keinen privaten Chat.
