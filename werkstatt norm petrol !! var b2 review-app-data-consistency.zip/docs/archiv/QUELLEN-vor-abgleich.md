# Herkunftsprotokoll — Rohquellen

**Gesichert am:** 2026-10-01 · **Stufe 1 der Pipeline** · Status: abgeschlossen

> 🔒 **Diese Dateien werden NIEMALS bearbeitet.**
> Sie sind der Beweis, was ursprünglich in den Quellen stand. Jede Normierung,
> Korrektur oder Ergänzung passiert ausschließlich in `../02-normiert/`.
> Wenn später eine Frage auftaucht („stand das wirklich so da?"), schlagen wir hier nach.

Alle Dateien stammen aus dem GitHub-Repository **`BenRouka/spp7-kontakte`**, Branch `main`,
geladen über `https://raw.githubusercontent.com/BenRouka/spp7-kontakte/main/…`.

---

## Übersicht

| # | Datei | Größe | Rolle |
|---|---|---|---|
| 1 | `Kurverwaltungen_2025.md` | 7.143 B | ✅ **saubere Quelle** — Adressen Rügen |
| 2 | `Termine_2027_suendenfrei.txt` | 4.063 B | ✅ **saubere Quelle** — Termine 2026/2027 |
| 3 | `app-workflow-setup.zip` | 977.096 B | bestehende App + Datenbestand |
| 4 | `ChatExport_2026-09-20.zip` | 9.437.194 B | Original-Chat + 158 Bilder |
| 5 | `logo-spp.pdf` | 1.329.579 B | Logo |

---

## 1. `Kurverwaltungen_2025.md`

- **Original-Dateiname im Repo:** `Kurverwaltungen_2025.md`
- **SHA-256:** `28512c72423ac270d4c423007b29dc85266e6938441d830bf0ec8a3239c1bfa1`
- **Inhalt:** „Kurverwaltungen und Infostellen auf Rügen" (RügenINFO), **32 Adressblöcke**
- **Eigener Stand-Vermerk:** „Stand 2025 — Alle Angaben ohne Gewähr"
- **Struktur:** Markdown, gegliedert nach Regionen (`##`) und Orten (`###`); je Block Name(n) fett, Straße, PLZ+Ort, Telefon, Fax, Internet, E-Mail
- **Geprüfte Vollständigkeit:**

| Befund | Anzahl | Betroffene |
|---|---|---|
| vollständig (Tel + Fax + Web + Mail) | 21 | — |
| ohne Fax | 3 | Lancken-Granitz · Infopavillon Baabe · Thiessow |
| ohne Internet | 4 | Lancken-Granitz · Infopavillon Baabe · Mönchgut/Middelhagen · Hafencenter Kloster |
| **ohne Telefon** | 1 | Tourist-Information Thiessow (Außenstelle) |
| **ohne E-Mail** | 1 | Infopavillion KV Baabe |
| **zwei E-Mails** | 1 | Infopoint Sellin (`info@` + `zimmervermittlung@`) |
| Zusatznotiz | 1 | Tourismus-/Gewerbeverein Putbus: „_(keine Zimmervermittlung)_" |
| Saisonhinweis | 1 | Infopavillion KV Baabe: „(außer Winter)" |
| **zwei Namen im Block** | 5 | Mönchgut+Middelhagen · Bergen+Touristik Service UG · West-Rügen+Info-Stube Gingst · Altefähr+Eigenbetrieb · Thiessow (Außenstelle) |

- ⚠️ **Stolperstein:** Die Orts-Überschrift **„Vitte" kommt zweimal** vor (Insel Information Hiddensee + HTS).
  → Ortsnamen taugen **nicht als Schlüssel**; in Stufe 2 bekommt jede Zeile eine eigene ID `KV01`…`KV32`.

---

## 2. `Termine_2027_suendenfrei.txt`

- **Original-Dateiname im Repo:** `Termine 2027 Veranstalter suendenfrei.txt`
  *(Leerzeichen im Namen hier durch Unterstriche ersetzt — Inhalt unverändert, siehe Prüfsumme)*
- **SHA-256:** `2ed2f631b158a8e3eaffc1f85d67d01abfdf8672c9f794f293e4ded263161cc7`
- **Herausgeber:** „Veranstalter Sündenfrei Mittelalteragentur"
- **Eigener Stand-Vermerk:** „Termine 2027 (Stand 22. September 2026)"
- **Umfang: 54 Terminzeilen** — davon **9 × 2026**, **45 × 2027**
  *(Korrektur: in einer früheren Zählung stand irrtümlich 56 — richtig sind 54.)*
- **Format:** reiner Text, **alle 54 Zeilen sauber TAB-getrennt** in 3 Spalten:
  `Datum ⇥ Veranstaltungsname ⇥ PLZ Ort` — maschinenlesbar ohne Rätselraten ✅
- **Zeichenkodierung:** UTF-8, Zeilenenden CRLF

### Besonderheiten (mit dem Auftraggeber geklärt)

| Fundstelle | Anzahl | Klärung |
|---|---|---|
| Sternchen `*` | 14 Zeilen | Legende der Quelle: „Termin oder Ort wahrscheinlich, **jedoch noch unbestätigt**" |
| Doppelsternchen `**` | 2 Zeilen (Kloster-Weihnacht Chemnitz 2026 + 2027) | ✅ **geklärt:** bedeutet **dasselbe** wie `*` — unbestätigt. *(Stand nicht in der Legende.)* |
| Echte Platzhalter | 2 Zeilen | `3.- 4. April 2027 ⇥ noch offen ⇥ xxxxx` und `28. - 29. August 2027 ⇥ Burgfest* ⇥ xxxx` → Ort **unbekannt**, bleibt leer + Status „offen" |
| Ohne PLZ | 2 Zeilen | identisch mit den beiden Platzhaltern oben |
| „Advent" statt Datum | 2 Zeilen | ✅ **Entscheidung:** nach **Kirchenregel berechnen** (siehe unten), Originaltext bleibt erhalten |
| Schreibvarianten | mehrere | „Mitt**e**alterspektakel" (2×), „Castrop- Rauxel", „Mittelalter- Markttage" → Original bleibt, Normierung zusätzlich |

### Adventsberechnung (Entscheidung des Auftraggebers)

Regel: *1. Advent = 4. Sonntag vor dem 25. Dezember.* Ergebnis per Datumsarithmetik:

| Jahr | 1. Advent | 2. Advent | 3. Advent | 4. Advent | Event „1.–4. Advent" |
|---|---|---|---|---|---|
| 2026 | So 29.11. | 06.12. | 13.12. | So 20.12. | **2026-11-26 bis 2026-12-20** (Do–So, laut Quelle) |
| 2027 | So 28.11. | 05.12. | 12.12. | So 19.12. | **2027-11-25 bis 2027-12-19** (Fr–So, laut Quelle) |

→ In Stufe 2 wird dies als `datum_status = "berechnet"` gekennzeichnet; der Originaltext
(`1. - 4. Advent 2026`) bleibt in der Spalte `datum_original` stehen.

### ❗ Bekannte Lücke (offene Faktenfrage F1)

**Für 2026 enthält die Datei nur 9 Termine ab dem 3. Oktober.** Januar–September 2026 fehlen
vollständig. Ob das Absicht ist (Restliste zum Stand 22.09.2026) oder eine vollständige
2026-Liste nachgereicht wird, ist **noch nicht beantwortet**.

---

## 3. `app-workflow-setup.zip`

- **Original-Dateiname im Repo:** `varB chat! pics scharf 180 maps app-replication-workflow-setup.zip`
- **SHA-256:** `3776094a1a5b3015ea4bbc8f4343bedaa0b7746ec4c19b1bcd6ad4e76ba2adef`
- **Integrität:** `unzip -t` → **keine Fehler** ✅
- **Umfang:** 29 Einträge (Next.js-App inkl. `public/data/spp7-datasets.json` mit 14 Datensätzen)
- ❗ **Referenziert `/flyers/flyer_XX.jpg` + `_thumb.jpg` — diese Bilder sind NICHT enthalten** (tote Links)
- ❓ Der Dateiname nennt **„180 maps"**; im Chat-Export liegen aber nur 158 Bilder → offene Faktenfrage **F2**

---

## 4. `ChatExport_2026-09-20.zip`

- **SHA-256:** `2586f208b874a1b000081182255350b0988eae614d878637f753b2d3add9049d`
- **Integrität:** `unzip -t` → **keine Fehler** ✅
- **Umfang:** 209 Einträge, davon **158 JPGs** in `photos/` (= 79 Bilder × Original + Thumbnail)
- **Enthält:** `result.json` (142 KB, maschinenlesbar), `messages.html`, css/js/images
- **Chat:** „Locations zum abtippen", `private_group`, ID 5349594086, **121 Nachrichten**, Absender durchgehend „Hanna Mvb"
- ⚠️ **Personenbezogene Daten:** 91 E-Mail-Adressen, Telefonnummern, Klarnamen → siehe Datenschutz-Hinweis unten

---

## 5. `logo-spp.pdf`

- **SHA-256:** `715fb170dd645a581c45828e7e44bb662015d6cdc469374d884f0aa696f9f1b9`
- **Erzeuger:** IrfanView PDF plugin, Titel „logo spp", erstellt 2026-09-30
- **Technischer Befund:** enthält **keine Vektoren**, sondern ein eingebettetes
  **FlateDecode-Rasterbild, 1080 × 1090 px, RGB**, heller Hintergrund (`#f8f8f8`)
- **Folge:** verlustfreie Umwandlung nach **PNG** möglich ✅ — **SVG ist nicht sinnvoll**
  (Auto-Tracing der detaillierten Illustration würde Qualität kosten und die Datei aufblähen)

---

## Datenschutz-Hinweis

`werkstatt/` liegt **außerhalb von `public/`** und ist damit **nicht über das Internet abrufbar**. ✅

⚠️ Davon unberührt: Die bestehende App legt ihre Rohdaten in `public/data/` ab — dieser Ordner
**ist** öffentlich erreichbar und enthält E-Mail-Adressen, Telefonnummern und den kompletten
Chatverlauf. Das wird in **Stufe 6** behandelt (Verschieben wäre ein Eingriff in die App-Struktur
und erfolgt erst, wenn die App läuft).

---

## Prüfsummen auf einen Blick

```
2586f208b874a1b000081182255350b0988eae614d878637f753b2d3add9049d  ChatExport_2026-09-20.zip
28512c72423ac270d4c423007b29dc85266e6938441d830bf0ec8a3239c1bfa1  Kurverwaltungen_2025.md
2ed2f631b158a8e3eaffc1f85d67d01abfdf8672c9f794f293e4ded263161cc7  Termine_2027_suendenfrei.txt
3776094a1a5b3015ea4bbc8f4343bedaa0b7746ec4c19b1bcd6ad4e76ba2adef  app-workflow-setup.zip
715fb170dd645a581c45828e7e44bb662015d6cdc469374d884f0aa696f9f1b9  logo-spp.pdf
```

**Erneut prüfen** (muss „OK" für alle 5 ergeben):

```bash
cd werkstatt/01-roh && sha256sum -c PRUEFSUMMEN.sha256
```
