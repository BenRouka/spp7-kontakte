"use client";

import { useMemo, useState } from "react";
import { Icon } from "@/components/icons";
import { ContactHierarchyReview } from "@/components/contact-hierarchy-review";
import {
  normalizationDecisions,
  normalizationFiles,
  normalizationProposal,
  normalizationRules,
  type NormalizationFieldRole,
} from "@/lib/normalization-schema";

const roleLabels: Record<NormalizationFieldRole, string> = {
  schluessel: "Schlüssel", herkunft: "Herkunft", original: "Original",
  normiert: "Normiert", status: "Status", relation: "Zuordnung",
};

export function NormalizationProposalView() {
  const [selectedId, setSelectedId] = useState<(typeof normalizationFiles)[number]["id"]>("kurverwaltungen");
  const selected = useMemo(() => normalizationFiles.find((file) => file.id === selectedId) ?? normalizationFiles[0], [selectedId]);

  return <section className="schema-proposal" aria-label="Vorschlag zum CSV-Spaltenaufbau">
    <div className="schema-proposal-head">
      <div><span className="schema-kicker">Stufe 2 · Kontaktklärung und Vorschlag</span><h2>Original, Ergänzung und Ableitung trennen.</h2><p>32 MD-Standorte und 54 Terminzeilen bleiben erhalten. Der Vorschlag ergänzt getrennte Parents, individuelle Kontaktwege und Zeitfenster; noch keine vollständigen CSV-Datenzeilen.</p></div>
      <div className="schema-head-actions"><span className="badge badge-amber"><Icon name="lock" size={13} /> Kein Import</span><a className="secondary-button" href="/api/review/normalization-schema?format=md"><Icon name="download" size={16} /> Vorschlag als MD</a></div>
    </div>

    <ContactHierarchyReview />

    <div className="schema-warning"><Icon name="info" size={20} /><div><strong>Vorsicht, Parent/Child ergänzt den vorgeschlagenen Aufbau.</strong><p>Eine Parent-Gruppendatei macht aus vier vorgeschlagenen CSV-Dateien fünf. Zwei Gruppen sind ausdrücklich benannt; andere Zuordnungen bleiben offen. Datenbank und Originalquellen sind unverändert. Die vollständige Normierung ist noch nicht gestartet.</p></div></div>

    <div className="schema-source-audit">
      <div><b>{normalizationProposal.sourceAudit.addressBlocks}</b><span>MD-Adressblöcke</span></div>
      <div><b>{normalizationProposal.sourceAudit.twoNameBlocks}</b><span>MD-Doppel-Namensblöcke</span></div>
      <div><b>{normalizationProposal.sourceAudit.contactChannels.telefon}</b><span>Telefon im MD</span></div>
      <div><b>{normalizationProposal.sourceAudit.contactChannels.fax}</b><span>Fax im MD</span></div>
      <div><b>{normalizationProposal.sourceAudit.contactChannels.internet}</b><span>Internet im MD</span></div>
      <div><b>{normalizationProposal.sourceAudit.contactChannels.email}</b><span>E-Mail im MD</span></div>
      <p><Icon name="info" size={15} /> Unveränderte MD-Zählung: 119 Kontaktwerte und zwei E-Mail-Lücken. Nutzerergänzungen ändern die Quelle nicht: Website/E-Mail Middelhagen und Telefon Thiessow ergeben 122 Kontaktwerte in der ergänzten Arbeitsebene. Baabes Infopavillion bleibt ohne E-Mail.</p>
    </div>

    <div className="schema-file-grid" role="list" aria-label="Vorgeschlagene CSV-Dateien">
      {normalizationFiles.map((file) => <button className={`schema-file-card ${selected.id === file.id ? "selected" : ""}`} key={file.id} onClick={() => setSelectedId(file.id)} type="button" role="listitem" aria-pressed={selected.id === file.id}>
        <span className="schema-file-icon"><Icon name={file.id === "gruppen" ? "layers" : file.kind === "kern" ? "file" : "layers"} size={21} /></span>
        <span className="schema-file-copy"><small>{file.id === "gruppen" ? "Parents · bisher benannt" : file.kind === "kern" ? "Kerndatei" : "Zuordnung"}</small><b>{file.filename}</b><span>{file.rowMeaning}</span></span>
        <strong>{file.expectedRows}<small>Zeilen</small></strong>
      </button>)}
    </div>

    <div className="schema-detail">
      <div className="schema-detail-heading"><div><span className="schema-kicker">{selected.id === "gruppen" ? "Parent-Gruppen" : selected.kind === "kern" ? "Kerndatei" : "Zuordnungsdatei"}</span><h2>{selected.label}</h2><p>{selected.purpose}</p></div>
        <div className="schema-detail-meta"><span><b>{selected.expectedRows}</b> {selected.id === "gruppen" ? "bisher benannte Parents" : "erwartete Zeilen"}</span><span><b>{selected.fields.length}</b> Spalten</span><a className="primary-button" href={`/api/review/normalization-schema?format=csv&file=${selected.id}`}><Icon name="download" size={16} /> Nur Kopfzeile</a></div>
      </div>
      <div className="schema-table-scroll"><table className="schema-table"><thead><tr><th>Feldname</th><th>Rolle</th><th>Typ</th><th>Pflicht</th><th>Bedeutung</th><th>Beispiel</th></tr></thead><tbody>
        {selected.fields.map((item) => <tr key={item.name}><td><code>{item.name}</code><small>{item.label}</small></td><td><span className={`schema-role role-${item.role}`}>{roleLabels[item.role]}</span></td><td><code>{item.type}</code>{item.values && <small>{item.values.join(" · ")}</small>}</td><td>{item.required ? <span className="schema-required">ja</span> : <span className="schema-optional">nein</span>}</td><td>{item.description}</td><td><code>{item.example || "-"}</code></td></tr>)}
      </tbody></table></div>
    </div>

    <div className="schema-bottom-grid">
      <article className="schema-rules"><div className="schema-card-heading"><span className="schema-card-icon"><Icon name="shield" size={19} /></span><div><h3>Festgehaltene Regeln</h3><p>Nichts erfinden, Originale immer erhalten.</p></div></div><ol>{normalizationRules.map((rule) => <li key={rule}>{rule}</li>)}</ol></article>
      <article className="schema-decisions"><div className="schema-card-heading"><span className="schema-card-icon"><Icon name="decisions" size={19} /></span><div><h3>Freigaben und offene Vorschlagspunkte</h3><p>Kontaktklärung und Telefonform sind festgehalten; das ist keine Importfreigabe.</p></div></div>
        <div className="schema-decision-list">{normalizationDecisions.map((item) => <div key={item.id}><span>{item.id}</span><section><h4>{item.title}</h4><p>{item.reason}</p></section><span className={`badge ${item.status === "bestaetigt" ? "badge-green" : "badge-amber"}`}>{item.status === "bestaetigt" ? "Bestätigt" : "Vorschlag"}</span></div>)}</div>
      </article>
    </div>
    <div className="schema-footer-note"><Icon name="lock" size={16} /><span>Status <code>{normalizationProposal.status}</code> · Version <code>{normalizationProposal.version}</code> · vier Beispielstandorte geklärt · keine Datenbankänderung · keine vollständigen CSV-Datenzeilen</span></div>
  </section>;
}
