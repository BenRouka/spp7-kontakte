import "server-only";
import { asc, count, desc, eq, sql } from "drizzle-orm";
import { db } from "@/db";
import {
  altEvents,
  beschluesse,
  geoOrte,
  importProtokoll,
  kontakte,
  regionen,
  terminAltEvent,
  terminZeitfenster,
  termine,
  type Termin,
  type TerminZeitfenster,
} from "@/db/schema";
import { geoKey, KORRIDOR, parsePlzOrt, projektion } from "@/lib/geo";
import {
  fmtDatum,
  fmtMonat,
  fmtTag,
  monatKey,
  tageZwischen,
} from "@/lib/freeze";

/* ------------------------------------------------------------------ */
/* Übersicht / Stufe 5                                                  */
/* ------------------------------------------------------------------ */

export async function getDbCounts() {
  const rows = await db.execute(sql`
    select
      (select count(*) from regionen)           as regionen,
      (select count(*) from kontakte)           as kontakte,
      (select count(*) from termine)            as termine,
      (select count(*) from termin_zeitfenster)  as zeitfenster,
      (select count(*) from beschluesse)         as beschluesse,
      (select count(*) from import_protokoll)    as protokoll
  `);
  const r = rows.rows[0] as Record<string, string | number>;
  const n = (v: string | number) => Number(v);
  return {
    regionen: n(r.regionen),
    kontakte: n(r.kontakte),
    termine: n(r.termine),
    zeitfenster: n(r.zeitfenster),
    beschluesse: n(r.beschluesse),
    protokoll: n(r.protokoll),
  };
}

export async function getLetzterImportLauf() {
  const eintraege = await db
    .select()
    .from(importProtokoll)
    .orderBy(desc(importProtokoll.importiertAm));
  if (eintraege.length === 0)
    return null as null | {
      laufId: string;
      importiertAm: string;
      eintraege: typeof eintraege;
    };
  const laufId = eintraege[0].laufId;
  return {
    laufId,
    importiertAm: eintraege[0].importiertAm,
    eintraege: eintraege.filter((e) => e.laufId === laufId),
  };
}

/* ------------------------------------------------------------------ */
/* Kontakte — Hierarchie Region → Ort → Einrichtung                     */
/* ------------------------------------------------------------------ */

export async function getKontakteHierarchie() {
  const regs = await db.select().from(regionen).orderBy(asc(regionen.id));
  const rows = await db.query.kontakte.findMany({
    orderBy: [asc(kontakte.regionId), asc(kontakte.sortierung)],
  });
  return regs
    .map((region) => {
      const regionRows = rows.filter((r) => r.regionId === region.id);
      const orte: { ort: string; einrichtungen: typeof regionRows }[] = [];
      for (const r of regionRows) {
        const last = orte[orte.length - 1];
        if (last && last.ort === r.ort) last.einrichtungen.push(r);
        else orte.push({ ort: r.ort, einrichtungen: [r] });
      }
      return { region, orte, anzahl: regionRows.length };
    })
    .filter((g) => g.anzahl > 0);
}

export type KontaktHierarchie = Awaited<
  ReturnType<typeof getKontakteHierarchie>
>;
export type KontaktRecord = KontaktHierarchie[number]["orte"][number]["einrichtungen"][number];

export async function getRegionChips() {
  const rows = await db
    .select({
      id: regionen.id,
      name: regionen.name,
      anzahl: count(kontakte.kvId),
    })
    .from(regionen)
    .leftJoin(kontakte, eq(kontakte.regionId, regionen.id))
    .groupBy(regionen.id)
    .orderBy(asc(regionen.id));
  return rows;
}

/* ------------------------------------------------------------------ */
/* Termine — Quellzeilen mit Zeitfenstern, formatiert für die Anzeige   */
/* ------------------------------------------------------------------ */

export interface TerminAnzeige {
  sfId: string;
  jahr: number;
  datumOriginal: string;
  name: string;
  plzOrt: string;
  anzahl: number;
  sternchen: string;
  hinweis: string | null;
  monatKey: string;
  monatLabel: string;
  fenster: {
    nr: number;
    von: string;
    bis: string;
    label: string; // "Do 26.11.26 – So 29.11.26"
    tage: number;
  }[];
}

function toAnzeige(t: Termin, fenster: TerminZeitfenster[]): TerminAnzeige {
  const sorted = [...fenster].sort((a, b) => a.nr - b.nr);
  const first = sorted[0];
  return {
    sfId: t.sfId,
    jahr: t.jahr,
    datumOriginal: t.datumOriginal,
    name: t.nameOriginal,
    plzOrt: t.plzOrtOriginal,
    anzahl: t.zeitfensterAnzahl,
    sternchen: t.sternchen,
    hinweis: t.hinweis,
    monatKey: monatKey(first.von),
    monatLabel: fmtMonat(first.von),
    fenster: sorted.map((f) => ({
      nr: f.nr,
      von: f.von,
      bis: f.bis,
      label: `${fmtTag(f.von)} – ${fmtTag(f.bis)}`,
      tage: tageZwischen(f.von, f.bis),
    })),
  };
}

export async function getTermineAnzeige(jahr: number) {
  const rows = await db.query.termine.findMany({
    where: eq(termine.jahr, jahr),
    orderBy: [asc(termine.sortierung)],
    with: { zeitfenster: true },
  });
  const anzeigen = rows.map((t) => toAnzeige(t, t.zeitfenster));
  // Gruppieren nach Monat des ersten Fensters, Einträge intern nach Datum
  const monate = new Map<string, { label: string; termine: TerminAnzeige[] }>();
  for (const t of anzeigen) {
    const g = monate.get(t.monatKey) ?? { label: t.monatLabel, termine: [] };
    g.termine.push(t);
    monate.set(t.monatKey, g);
  }
  for (const g of monate.values()) {
    g.termine.sort((a, b) => a.fenster[0].von.localeCompare(b.fenster[0].von));
  }
  const gruppen = [...monate.entries()]
    .sort(([a], [b]) => a.localeCompare(b))
    .map(([key, g]) => ({ key, label: g.label, termine: g.termine }));
  return { gruppen, alle: anzeigen };
}

export async function getTerminJahresStats() {
  const rows = await db
    .select({
      jahr: termine.jahr,
      quellzeilen: count(termine.sfId),
    })
    .from(termine)
    .groupBy(termine.jahr)
    .orderBy(asc(termine.jahr));
  const fenster = await db
    .select({
      jahr: termine.jahr,
      anzahl: count(terminZeitfenster.id),
    })
    .from(terminZeitfenster)
    .innerJoin(termine, eq(terminZeitfenster.terminSfId, termine.sfId))
    .groupBy(termine.jahr);
  const fMap = new Map(fenster.map((f) => [f.jahr, Number(f.anzahl)]));
  return rows.map((r) => ({
    jahr: r.jahr,
    quellzeilen: Number(r.quellzeilen),
    zeitfenster: fMap.get(r.jahr) ?? 0,
  }));
}

/* ------------------------------------------------------------------ */
/* Beschlüsse                                                           */
/* ------------------------------------------------------------------ */

export async function getBeschluesseGruppiert() {
  const rows = await db
    .select()
    .from(beschluesse)
    .orderBy(asc(beschluesse.sortierung));
  const order = ["Kontakte", "Termine", "Archiv", "Ablauf", "Offen"];
  return order
    .map((bereich) => ({
      bereich,
      beschluesse: rows.filter((r) => r.bereich === bereich),
    }))
    .filter((g) => g.beschluesse.length > 0);
}

export async function getBeschlussStats() {
  const rows = await db.select().from(beschluesse);
  return {
    gesamt: rows.length,
    entschieden: rows.filter((r) => r.status === "entschieden").length,
    provisorisch: rows.filter((r) => r.status === "provisorisch").length,
  };
}

/** Formatiert "2026-10-04 11:20:13.922+00" → "04.10.2026, 13:20 Uhr" */
export function fmtZeitstempel(iso: string): string {
  const d = new Date(iso);
  if (Number.isNaN(d.getTime())) return iso;
  const p = (n: number) => String(n).padStart(2, "0");
  return `${p(d.getUTCDate())}.${p(d.getUTCMonth() + 1)}.${d.getUTCFullYear()}, ${p(d.getUTCHours())}:${p(d.getUTCMinutes())} UTC`;
}

export { fmtDatum };

/* ------------------------------------------------------------------ */
/* Karte — Schritt C2: Event-Radar auf O-11-konformer Geo-Basis.       */
/* Kuratierte Punkte kommen AUSSCHLIESSLICH aus geo_orte (frisch       */
/* geocodiert, Quelle/Status je Eintrag). Alt-Koordinaten werden nur   */
/* als gekennzeichneter Vergleichs-Layer gezeichnet; Zentroide und     */
/* Einträge ohne Koordinate erscheinen nicht (O-11).                   */
/* ------------------------------------------------------------------ */

export interface KartePunktKuratiert {
  sfId: string;
  jahr: number;
  name: string;
  plzOrt: string;
  x: number;
  y: number;
}

export interface KartePunktAlt {
  eventId: string;
  name: string;
  ort: string;
  qualitaet: string; // osm | sonstige — zentroid/offen bleiben draußen
  x: number;
  y: number;
}

export interface KorridorHalt {
  altEventId: string;
  label: string;
  untertitel: string;
  x: number;
  y: number;
  zustand: "kuratiert" | "vorgemerkt";
  datumLabel: string | null;
  sfId: string | null;
}

export interface KarteDaten {
  kuratiert: KartePunktKuratiert[];
  alt: KartePunktAlt[];
  korridor: KorridorHalt[];
  audit: typeof geoOrte.$inferSelect[];
  stats: {
    kuratiertGeocodiert: number;
    kuratiertOhneZuordnung: number;
    sf2027Anzahl: number;
    sf2027Spanne: string | null;
    altAngezeigt: number;
    altZentroidAusgeblendet: number;
    altOhneKoordinate: number;
  };
}

export async function getKarteDaten(): Promise<KarteDaten> {
  const [geo, terminRows, fensterRows, altRows, bruecken] = await Promise.all([
    db.select().from(geoOrte).orderBy(asc(geoOrte.plz), asc(geoOrte.ort)),
    db.select().from(termine).orderBy(asc(termine.sortierung)),
    db.select().from(terminZeitfenster),
    db.select().from(altEvents),
    db.select().from(terminAltEvent),
  ]);

  const geoIndex = new Map(geo.map((g) => [geoKey(g.plz, g.ort), g]));

  /* Kuratierte Punkte: termine → geo_orte (erster auflösbarer Kandidat) */
  const kuratiert: KartePunktKuratiert[] = [];
  let ohneZuordnung = 0;
  for (const t of terminRows) {
    const parsed = parsePlzOrt(t.plzOrtOriginal);
    const g = parsed
      ? parsed.kandidaten
          .map((k) => geoIndex.get(geoKey(parsed.plz, k)))
          .find((v) => v !== undefined)
      : undefined;
    if (!g) {
      ohneZuordnung++;
      continue;
    }
    const { x, y } = projektion(Number(g.lng), Number(g.lat));
    kuratiert.push({
      sfId: t.sfId,
      jahr: t.jahr,
      name: t.nameOriginal,
      plzOrt: t.plzOrtOriginal,
      x,
      y,
    });
  }

  /* Alt-Vergleichslayer: nur osm/sonstige mit Koordinaten — nie Zentroide */
  let zentroid = 0;
  let ohneKoordinate = 0;
  const alt: KartePunktAlt[] = [];
  for (const e of altRows) {
    const lat = (e.lat ?? "").trim().replace(",", ".");
    const lng = (e.lng ?? "").trim().replace(",", ".");
    if (!lat || !lng) {
      ohneKoordinate++;
      continue;
    }
    if (e.geoQualitaet === "zentroid") {
      zentroid++;
      continue;
    }
    if (e.geoQualitaet !== "osm" && e.geoQualitaet !== "sonstige") continue;
    const { x, y } = projektion(Number(lng), Number(lat));
    if (!Number.isFinite(x) || !Number.isFinite(y)) {
      ohneKoordinate++;
      continue;
    }
    alt.push({
      eventId: e.eventId,
      name: e.name,
      ort: e.ort ?? "",
      qualitaet: e.geoQualitaet,
      x,
      y,
    });
  }

  /* Sündenfrei-2027-Spanne aus den kuratierten Zeitfenstern */
  const fensterNachTermin = new Map<string, typeof fensterRows>();
  for (const f of fensterRows) {
    const l = fensterNachTermin.get(f.terminSfId) ?? [];
    l.push(f);
    fensterNachTermin.set(f.terminSfId, l);
  }
  const t27 = terminRows.filter((t) => t.jahr === 2027);
  const alle27 = fensterRows
    .filter((f) => t27.some((t) => t.sfId === f.terminSfId))
    .map((f) => f.von)
    .sort();
  const bis27 = fensterRows
    .filter((f) => t27.some((t) => t.sfId === f.terminSfId))
    .map((f) => f.bis)
    .sort();
  const fmtKurz = (iso: string) => `${iso.slice(8, 10)}.${iso.slice(5, 7)}.`;
  const sf2027Spanne =
    alle27.length > 0
      ? `${fmtKurz(alle27[0])}–${fmtKurz(bis27[bis27.length - 1])}2027`
      : null;

  /* Tour-Korridor: Geo aus geo_orte, Zustand aus den Brücken */
  const korridor: KorridorHalt[] = KORRIDOR.map((def): KorridorHalt => {
    const g = geoIndex.get(geoKey(def.plz, def.ort));
    const pos = g
      ? projektion(Number(g.lng), Number(g.lat))
      : { x: 0, y: 0 };
    const bruecke = bruecken.find((b) => b.altEventId === def.altEventId);
    const termin = bruecke
      ? terminRows.find((t) => t.sfId === bruecke.terminSfId)
      : undefined;
    let datumLabel: string | null = null;
    if (termin) {
      const fenster = (fensterNachTermin.get(termin.sfId) ?? [])
        .map((f) => f)
        .sort((a, b) => a.von.localeCompare(b.von));
      if (fenster.length > 0) {
        const von = fenster[0].von;
        const bis = fenster[fenster.length - 1].bis;
        datumLabel = `${fmtKurz(von)}–${bis.slice(8, 10)}.${bis.slice(5, 7)}.${bis.slice(0, 4)}`;
      }
    }
    return {
      altEventId: def.altEventId,
      label: def.label,
      untertitel: def.untertitel,
      x: pos.x,
      y: pos.y,
      zustand: termin ? "kuratiert" : "vorgemerkt",
      datumLabel,
      sfId: termin?.sfId ?? null,
    };
  }).filter((h) => h.x !== 0 || h.y !== 0);

  return {
    kuratiert,
    alt,
    korridor,
    audit: geo,
    stats: {
      kuratiertGeocodiert: kuratiert.length,
      kuratiertOhneZuordnung: ohneZuordnung,
      sf2027Anzahl: kuratiert.filter((k) => k.jahr === 2027).length,
      sf2027Spanne,
      altAngezeigt: alt.length,
      altZentroidAusgeblendet: zentroid,
      altOhneKoordinate: ohneKoordinate,
    },
  };
}
