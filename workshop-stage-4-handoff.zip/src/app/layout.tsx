import type { Metadata } from "next";
import type { ReactNode } from "react";
import { Lock, Snowflake } from "lucide-react";
import { ShellNav } from "@/components/shell";
import "./globals.css";

export const metadata: Metadata = {
  title: "Werkstatt Rügen · Stufe 4 · Freeze",
  description:
    "Übergabepaket Werkstatt Stufe 4 — Arbeitsstand Kontakte & Termine, verbindliches Beschlussverzeichnis. Interner Bandgebrauch (B-17).",
};

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="de">
      <body className="bg-base text-ink antialiased">
        <div className="texture min-h-screen">
          <header className="sticky top-0 z-40 border-b border-line bg-base/85 backdrop-blur">
            <div className="mx-auto flex max-w-[1240px] flex-wrap items-center gap-x-4 gap-y-2 px-4 py-3 sm:px-6">
              <a href="/" className="group flex items-center gap-2.5">
                <span className="flex h-7 w-7 items-center justify-center rounded-md bg-lime text-base transition-transform group-hover:rotate-45">
                  <Snowflake className="h-4 w-4 text-base" strokeWidth={2.4} />
                </span>
                <span className="leading-tight">
                  <span className="block font-mono text-[11px] font-semibold uppercase tracking-[0.18em] text-ink">
                    Werkstatt · Stufe 4
                  </span>
                  <span className="block font-mono text-[10px] uppercase tracking-[0.14em] text-muted">
                    Freeze · Stand 2026-10-01
                  </span>
                </span>
              </a>
              <div className="order-3 w-full sm:order-2 sm:w-auto sm:flex-1">
                <ShellNav />
              </div>
              <span className="order-2 ml-auto inline-flex items-center gap-1.5 rounded-full border border-amber/30 bg-amber/[0.06] px-2.5 py-1 font-mono text-[10px] uppercase tracking-[0.12em] text-amber sm:order-3 sm:ml-0">
                <Lock className="h-3 w-3" />
                Interner Bandgebrauch · B-17
              </span>
            </div>
          </header>

          <main className="mx-auto max-w-[1240px] px-4 pb-24 pt-10 sm:px-6">
            {children}
          </main>

          <footer className="border-t border-line">
            <div className="mx-auto flex max-w-[1240px] flex-wrap items-center justify-between gap-x-6 gap-y-2 px-4 py-5 sm:px-6">
              <p className="text-[12px] leading-relaxed text-muted">
                Ohne ausdrückliches Ja wird nichts in Quellen, Archive oder
                Datenbank geschrieben.
              </p>
              <p className="font-mono text-[11px] uppercase tracking-[0.12em] text-muted">
                Datenbank: 0 Tabellen · B-20 · Kein Import begonnen
              </p>
            </div>
          </footer>
        </div>
      </body>
    </html>
  );
}
