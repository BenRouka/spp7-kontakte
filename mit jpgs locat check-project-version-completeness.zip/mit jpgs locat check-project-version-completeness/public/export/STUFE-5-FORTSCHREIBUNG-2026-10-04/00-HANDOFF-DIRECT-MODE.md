# HANDOFF · Direct Mode · Fortschreibung zum Stufe-5-Freeze

**Stand:** 2026-10-04  
**Art:** ergänzender Entscheidungs- und Gesprächsstand; kein Ersatz für den ursprünglichen Freeze  
**Grundlage:** `public/export/STUFE-5-FREEZE-2026-10-04/00-HANDOFF-DIRECT-MODE.md` und die anschließende manuelle Befundprüfung im Chat  
**Datenschutz:** interner Gebrauch (B-17)

---

## 0. Verbindliche Einordnung

Diese Fortschreibung hält die im Chat bestätigten fachlichen Ergebnisse und die zurückgestellten technischen Arbeiten fest. Sie ist **kein** Nachweis, dass Änderungen in der Alt-App ausgeführt wurden.

- Der ursprüngliche Stufe-4-Freeze und das ursprüngliche Stufe-5-Handoff bleiben unverändert.
- Die ursprüngliche `01-OFFENE-PUNKTE.csv` bleibt byteidentisch; sie enthält weiterhin den beim Export festgehaltenen Ausgangsstatus der 13 Punkte.
- Keine Alt-App-Datei, kein Alt-App-Code und keine Alt-App-Datenbank liegt diesem Fortschreibungsordner bei.
- Es wurden keine Beschlüsse B-21 ff. in die Datenbank oder den ursprünglichen Freeze eingetragen.
- Für die Werkstattdatenbank wurden in dieser Besprechungsrunde keine Daten-, Schema- oder Importänderungen ausgeführt.
- Die 13 Gesprächsergebnisse stehen in `01-ENTSCHEIDUNGSSTAND-13-PUNKTE.md`; Einschränkungen und Prüfsperren stehen in `02-AUDIT-UND-RESTPUNKTE.md`.

**Wichtig:** „fachlich bestätigt“ bedeutet hier eine im Chat bestätigte Arbeitsregel oder Anweisung. Es bedeutet nicht, dass eine Alt-App-Änderung bereits umgesetzt oder unabhängig anhand des Alt-App-Projekts verifiziert wurde.

---

## 1. Bestätigte Arbeitsregeln

1. Keine Vermutung, kein Schätzen, kein stilles Zusammenführen oder Löschen.
2. Kontakte: Prio 1 ist der maßgebliche MD-/offizielle Beleg; Chat/Altbestand ergänzt nur und überschreibt Prio 1 nicht.
3. Termine: Prio 1 ist die offizielle Website bzw. `sündenfrei.txt`; Chat-/KI-Angaben bleiben als solche gekennzeichnet und überschreiben Prio 1 nicht.
4. Gleiche E-Mail oder gleicher Kanal ist allein kein Identitäts- oder Merge-Beweis.
5. KI-/Chat-Datensätze werden nicht als Ganzes verifiziert, nur weil einzelne Felder mit einer Prio-1-Quelle übereinstimmen.
6. Bei jeder möglichen Datenbank-, Schema-, Import- oder Synchronisationsänderung: erst den genauen Vorschlag vorlegen, die Freigabe abwarten und in kleinen, überprüfbaren Schritten vorgehen.
7. Keine Arbeit an der Alt-App, bevor ihr JSON-Sync gegen Überschreiben kuratierter Werte abgesichert und der Neustart-Regressionstest bestanden ist.
8. Personenbezogene und persönliche Kanalwerte bleiben intern (B-17).

---

## 2. Status der Werkstatt beim Fortschreibungsstand

Die unmittelbar vor Erstellung dieses Ergänzungspakets erneut geprüften Bestände:

| Tabelle | Bestand |
|---|---:|
| `regionen` | 9 |
| `kontakte` | 35 |
| `termine` | 54 |
| `termin_zeitfenster` | 60 |
| `beschluesse` | 20 |
| `import_protokoll` | 3 |

Die ursprünglichen Manifeste des Stufe-4-Freeze und des Stufe-5-Handoffs wurden geprüft; alle darin geführten Dateien stimmten mit ihren Prüfsummen überein. Die Datenbankzahlen entsprechen dem ursprünglichen Sollbestand.

---

## 3. Nächste Phase — ausdrücklich noch nicht gestartet

Der nächste Gegenstand ist ein **rein lesender Audit des Alt-App-Projekts**. Das Alt-App-ZIP wurde noch nicht bereitgestellt und ist nicht Teil dieses Werkstatt-Projekts.

Nach Bereitstellung des ZIPs:

1. Alt-App-Code und JSON-Synchronisationspfad rein lesend lokalisieren.
2. Prüfen, welche Tabellen/Felder der JSON-Sync schreibt und wann er läuft.
3. Befund, Risiko und eng begrenzte Umbauoptionen erklären; noch keinen Code ändern.
4. Änderung erst nach separater ausdrücklicher Startfreigabe (`ok, leg los`).
5. In einer isolierten Arbeitskopie Regressionstest: kuratierten Werkstattwert setzen → Sync/Neustart → Erhalt prüfen.
6. Erst nach bestandenem Test einzelne, belegte Datensätze rückportieren.
7. Danach neuen Audit- und Übergabefreeze erstellen; alte Freeze-Dateien unangetastet lassen.

Bildquellen werden erst inventarisiert, wenn die betreffenden Dateien tatsächlich vorliegen. Ihre Vollständigkeit wird nicht vorweggenommen.

---

## 4. Startpunkt für eine Fortsetzung

Zuerst dieses Handoff und `01-ENTSCHEIDUNGSSTAND-13-PUNKTE.md` lesen, danach `02-AUDIT-UND-RESTPUNKTE.md` und beide ursprünglichen Manifeste prüfen. Keine offenen technischen Aufgaben automatisch ausführen. Die nächste Aufgabe ist die Wahl, ob die Fortsetzung in einem neuen Direct-Mode-Chat oder in diesem Chat erfolgen soll.
