#!/usr/bin/env node
// Stage 3: read-only input analysis; writes only allowlisted new reports under 03-berichte.
// No source edits, no normalization edits, no database. --verify writes nothing.
import assert from "node:assert/strict";
import { createHash } from "node:crypto";
import { readFileSync } from "node:fs";
import { readFile, writeFile, mkdir } from "node:fs/promises";
import { createRequire } from "node:module";
import path from "node:path";
import { unzipSync, strFromU8 } from "fflate";
import ts from "typescript";

const verify = process.argv.includes("--verify");
const require = createRequire(import.meta.url), cache = new Map();
function load(file) {
  const resolved = file.startsWith("@/") ? `src/${file.slice(2)}.ts` : file;
  if (cache.has(resolved)) return cache.get(resolved).exports;
  const module = { exports: {} }; cache.set(resolved, module);
  const code = ts.transpileModule(readFileSync(resolved, "utf8"), { compilerOptions: {
    target: ts.ScriptTarget.ES2022, module: ts.ModuleKind.CommonJS, esModuleInterop: true,
  } }).outputText;
  new Function("require", "module", "exports", code)((id) => id.startsWith("@/") ? load(id) : require(id), module, module.exports);
  return module.exports;
}
function parseCSV(text) {
  const raw = text.replace(/^\uFEFF/, "");
  let row = [], cell = "", quoted = false;
  const rows = [];
  for (let i = 0; i < raw.length; i++) {
    const char = raw[i];
    if (quoted) {
      if (char === '"' && raw[i + 1] === '"') { cell += '"'; i++; }
      else if (char === '"') quoted = false;
      else cell += char;
    } else if (char === '"') quoted = true;
    else if (char === ";") { row.push(cell); cell = ""; }
    else if (char === "\r" && raw[i + 1] === "\n") { row.push(cell); rows.push(row); row = []; cell = ""; i++; }
    else cell += char;
  }
  assert.equal(quoted, false);
  if (cell || row.length) { row.push(cell); rows.push(row); }
  const headers = rows.shift();
  return rows.map((values) => { assert.equal(values.length, headers.length); return Object.fromEntries(headers.map((key, i) => [key, values[i]])); });
}
const root = "werkstatt/03-berichte";
const inputDefs = [
  ["werkstatt/01-roh/app-workflow-setup.zip", "unveränderter App-Bestand"],
  ["werkstatt/01-roh/app-workflow-setup.herkunft.json", "Herkunft des App-ZIPs"],
  ["werkstatt/01-roh/Kurverwaltungen_2025.md", "Original-Adressreferenz"],
  ["werkstatt/01-roh/Termine_2027_suendenfrei.txt", "Original-Terminreferenz"],
  ["werkstatt/02-normiert/kontakte-struktur.json", "normierte Kontaktreferenz und Nutzerregeln"],
  ["werkstatt/02-normiert/suendenfrei-termine.csv", "54 normierte Terminzeilen"],
  ["werkstatt/02-normiert/nutzer-ergaenzungen.json", "ausdrückliche Nutzerergänzungen"],
  ["src/lib/comparison-model.ts", "deterministisches Vergleichsmodell"],
  ["scripts/build-comparison.mjs", "Berichtserzeugung"],
];
const sha = (value) => createHash("sha256").update(value).digest("hex");
const inputs = await Promise.all(inputDefs.map(async ([file, role]) => ({ path: file, role, sha256: sha(await readFile(file)) })));
const app = await readFile(inputDefs[0][0]);
assert.equal(sha(app), "3776094a1a5b3015ea4bbc8f4343bedaa0b7746ec4c19b1bcd6ad4e76ba2adef");
const archived = unzipSync(app);
const archiveJson = JSON.parse(strFromU8(archived["public/data/spp7-datasets.json"]));
const archiveChat = JSON.parse(strFromU8(archived["public/data/spp7-chat.json"]));
assert.equal(archiveJson.datasets.events.length, 206); assert.equal(archiveJson.datasets.contacts.length, 74);
assert.equal(archiveJson.datasets.event_dates.length, 203); assert.equal(Object.keys(archiveJson.datasets).length, 14);
assert.equal(archiveChat.messages.length, 121);
// Verify technical claims against actual archive files, not ZIP filename assumptions.
assert.equal(Object.keys(archived).some((name) => name.startsWith("public/flyers/")), false);
assert.ok(strFromU8(archived["src/lib/spp7-repository.ts"]).includes("onConflictDoUpdate"));
assert.ok(strFromU8(archived["src/components/spp7-dashboard.tsx"]).includes('fetch("/data/spp7-datasets.json")'));
const workspace = JSON.parse(await readFile(inputDefs[4][0], "utf8"));
assert.equal(workspace.source.sha256, inputs.find((i) => i.path === inputDefs[2][0]).sha256);
assert.equal(workspace.source.supplementSha256, inputs.find((i) => i.path === inputDefs[6][0]).sha256);
const references = parseCSV(await readFile(inputDefs[5][0], "utf8"));
assert.equal(workspace.contacts.length, 32); assert.equal(references.length, 54);
const model = load("src/lib/comparison-model.ts");
const report = model.buildComparisonReport(workspace, references, archiveJson.datasets, archiveChat.messages, inputs);
assert.equal(report.contacts.length, 32); assert.equal(report.schedules.length, 54);
assert.equal(report.findings.every((f) => f.decision === "offen"), true);
assert.equal(new Set(report.findings.map((f) => f.id)).size, report.findings.length);
const allValues = JSON.stringify(report);
for (const contact of archiveJson.datasets.contacts.filter((c) => c.TYP === "Person")) {
  assert.equal(allValues.includes(contact.ORGANISATION), false, `Personenname im Bericht: ${contact.CONTACT_ID}`);
  if (contact.CONTACT_ID !== "K57") assert.equal(allValues.includes(contact.EMAIL_TELEFON), false, `Personenkanal im Bericht: ${contact.CONTACT_ID}`);
}
const intro = [
  "# Stufe 3 · Abgleich 01", "", `Berichtsversion: ${report.version}.`,
  "Der Bericht vergleicht den unveränderten App-ZIP-Bestand mit den normierten Referenzen und expliziten Nutzerergänzungen.",
  "Keine Quelle, keine CSV-Normierung und keine Datenbank wurde dadurch verändert. Keine Zusammenführung, Löschung oder Stufe-4-Entscheidung ist ausgeführt.",
  "", "## Dateien", "",
  "- abgleich-01.md: vollständiger lesbarer Bericht mit allen Kandidaten, Feldvergleichen und Entscheidungspunkten.",
  "- abgleich-01.json: dieselben Prüfergebnisse für die lesende Option-A-Oberfläche.",
  "- abgleich-01-kontakte.csv: 32 Referenzeinrichtungen mit Status, Kandidaten und Fundstelle.",
  "- abgleich-01-termine.csv: 54 Terminzeilen mit Fensterliste, Quellstatus und Abgleichstatus.",
  "- abgleich-01-feldvergleich.csv: jedes geprüfte Kandidatenfeld, Original/Ergänzung/Bestand und Herkunft.",
  "- abgleich-01-entscheidungen.csv: nummerierte Fragen für Stufe 4, überall Entscheidung=offen.",
  "- abgleich-01.pruefsummen.sha256: Prüfsummen der Berichte einschließlich dieser Erläuterung.",
  "", "## Ausführen", "", "node scripts/build-comparison.mjs        # nur Berichte erzeugen",
  "node scripts/build-comparison.mjs --verify # nur vorhandene Berichte prüfen", "",
  "## Grenzen", "",
  "Datum+Ort ist eine konkrete Werteübereinstimmung, kein automatischer Identitätsnachweis. Name, PLZ, Quelltyp, unsichere Marker und Institutionsbeziehungen bleiben gesonderte Fragen.",
  "Gleiche E-Mail kann mehrere Einrichtungen bedienen. Namenskandidaten sind nur wörtliche/normalisierte Wortfolgen, keine semantische Interpretation. Nicht zugeordneter Bestand ist nicht automatisch ungültig oder zum Löschen bestimmt.",
  "Kein privates Chatarchiv wurde neu geöffnet. Bericht enthält Organisationsreferenz-Kanäle, aber Personennamen/-kanäle des Bestands sind ausgeblendet. Der interne App-ZIP-Bestand liegt außerhalb public/ und wird nicht als Berichtdownload geliefert.",
  "Die bereits bestätigten Quellen und Nutzerangaben werden separat behandelt; eine Nutzerangabe ist keine unabhängig extern verifizierte Information.",
  "Frühere Handoff-Zählung „46 von 54 fehlen“ ist methodisch nicht belastbar, weil Eventdatensätze und Terminzeilen verschiedene Ebenen sind. Der vorliegende Bericht zählt Quellzeilen/Fenster, nicht bloß Eventnamen.",
  "", "## Nächster Schritt", "",
  "Stufe 4: anhand der Befund-IDs Punkt für Punkt entscheiden. Das Ausfüllen einer Entscheidung wird nicht automatisch importiert. Stufe 5 bleibt gesondert freigabepflichtig.", "",
].join("\n");
const outputs = {
  "abgleich-01.md": model.comparisonMarkdown(report),
  "abgleich-01.json": JSON.stringify(report, null, 2) + "\n",
  ...model.comparisonCsvReports(report),
  "LIESMICH-abgleich-01.md": intro,
};
const manifest = Object.entries(outputs).map(([name, value]) => `${sha(value)}  ${name}`).join("\n") + "\n";
if (verify) {
  for (const [name, content] of Object.entries(outputs)) assert.equal(await readFile(path.join(root, name), "utf8"), content, `Bericht weicht ab: ${name}`);
  assert.equal(await readFile(path.join(root, "abgleich-01.pruefsummen.sha256"), "utf8"), manifest);
} else {
  await mkdir(root, { recursive: true });
  for (const [name, content] of Object.entries(outputs)) await writeFile(path.join(root, name), content, "utf8");
  await writeFile(path.join(root, "abgleich-01.pruefsummen.sha256"), manifest, "utf8");
}
console.log(`Stufe 3: ${verify ? "reproduziert, keine Dateien geschrieben" : "nur Abgleichberichte geschrieben"}.`);
console.log(JSON.stringify(report.summary, null, 2));
console.log("Datum-/Ort-Hinweise:", report.schedules.filter((r) => r.status === "datum_ort").map((r) => `${r.id} => ${r.candidates.filter((c) => c.evidence === 'datum_ort').map((c) => `${c.id} (${c.nameEvidence === ' - ' ? 'Name anders' : 'Name-Hinweis'})`).join(',')}`).join('; '));
console.log("Kontakte nur Kanal:", report.contacts.filter((r) => r.status === "nur_kanal").map((r) => `${r.id} => ${r.candidates.map((c) => c.id)}`).join('; '));
console.log("Personendaten im Bericht ausgeblendet; alle Entscheidungen offen. Rohquellen/Normierung/Schema unverändert.");
