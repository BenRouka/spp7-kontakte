# SPP7 · FREEZE-04 — alle Kleinbeschriftungen in normaler Schreibweise

**Status: eingefroren (Pause)** · 2026-10-01 UTC
**Aktueller Einstieg bei Wiederaufnahme.** Ergänzt FREEZE-03. Die Prüfpunkte FREEZE-01, -02 und -03 bleiben unverändert erhalten.

> Bis zur Wiederaufnahme: keine Code-, Layout-, Daten- oder Schemaänderung.
> Weiter erst nach ausdrücklicher Freigabe.

Begleitdateien:
- `docs/FREEZE-04-pruefprotokoll.txt` — Browser-, Regression-, Build- und Laufzeitprotokoll
- `docs/FREEZE-04.sha256` — SHA-256-Prüfsummen des aktuellen Arbeitsstands

## 1. Bestätigte Änderung („Ok leg los, alle bitte“)

Alle verbliebenen Kleinbeschriftungen stehen jetzt in normaler Schreibweise, damit die Oberfläche einheitlich ist:

| Vorher | Jetzt |
|---|---|
| ORIGINAL AUS DER QUELLE (Karten und Original-Boxen) | Original aus der Quelle |
| BEVOR STUFE 2 BEGINNT | Bevor Stufe 2 beginnt |
| SPP7 · PRÜFANSICHT (Dialog-Kopf) | SPP7 · Prüfansicht |
| DATUMSHERKUNFT | Datumsherkunft |
| BESTÄTIGUNGSSTATUS | Bestätigungsstatus |
| ZEITMODELL 2027 (Export-Menü, jahresabhängig) | Zeitmodell 2027 |
| NOV 2027 · DEZ 2027 (Dresden-Karte, jahresabhängig) | Nov 2027 · Dez 2027 |

Zusammen mit FREEZE-03 (`Tour Intelligence`, `Klärung vor Stufe 2 · Option A`, `Arbeitsbereich`) sind damit alle gemeldeten Beschriftungen umgestellt.

**Bleibt bewusst groß:** Fachbegriffe und Abkürzungen — ZIP, MD, TXT, PDF, CSV, ICS, PLZ, LAT, LNG, SHA-256, JSON — sowie das Produktkürzel „SPP7“.

**Unverändert:** Schriftart (Roboto Mono, Lime), Schriftgröße (12 px), Farben, Positionen und Abstände. Geändert wurde ausschließlich Text in `src/components/workshop.tsx`; Stylesheet und alle anderen Dateien sind unberührt.

## 2. Gemessene Werte (Browser, Produktionsbuild)

- Alle acht Texte erscheinen wie in der Tabelle, jeweils 12 px.
- „Nov/Dez“ erscheint auch nach dem Jahreswechsel korrekt (2026: Nov 2026 · Dez 2026).
- Dateikacheln zeigen weiterhin TXT, MD, ZIP, PDF; Export-Menü weiterhin CSV und ICS; A/B-Dialog weiterhin ZIP und MD / TXT.
- Vollständiger Durchlauf von Übersicht, Quellen, Festlegungen und den drei Normierungs-Tabs: **kein** weiteres großgeschriebenes Wort außer den genannten Fachbegriffen.
- Keine Browserfehler. `/api/health` → 200.

## 3. Unverändert

- Option-A-Petrol-Dunkelschema und die Typografie aus FREEZE-02.
- Zeitmodell `zeitmodell-2026-2027-v2`, A/B-Gleichstand, Rohquellen MD/TXT (bytegleich).
- Pipeline-Stufe 2 (vollständige Normierung): **nicht begonnen**.
- Datenbank: 0 Tabellen, kein Import, keine Schreibzugriffe; Schema unverändert.
- Option-B-Paket und seine Oberfläche: unverändert.
- Alle Entscheidungen und offenen Punkte aus `docs/FREEZE-01.md` und `docs/FREEZE-02.md` bleiben gültig.

Vergleich zur `docs/FREEZE-03.sha256`: Erwartete Abweichung ist genau `src/components/workshop.tsx`.

## 4. Wiederaufnahme

1. Dieses Dokument lesen.
2. `sha256sum -c docs/FREEZE-04.sha256` aus der Projektwurzel ausführen.
3. `node scripts/check-time-model.mjs` und `cd werkstatt/01-roh && sha256sum -c PRUEFSUMMEN.sha256` ausführen.
4. Preview ansehen und den nächsten Schritt separat abstimmen; Stufe 2 bleibt bis zur Freigabe unangetastet.

Die vorherigen Manifeste (`FREEZE-01/02/03.sha256`) werden absichtlich nicht überschrieben.
