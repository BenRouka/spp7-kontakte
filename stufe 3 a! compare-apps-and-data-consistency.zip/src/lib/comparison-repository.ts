import "server-only";
import { createHash } from "node:crypto";
import { readFile } from "node:fs/promises";
import path from "node:path";
import { COMPARISON_VERSION, type ComparisonReport } from "@/lib/comparison-model";

export const comparisonReportFiles = ["abgleich-01.json", "abgleich-01.md", "abgleich-01-kontakte.csv", "abgleich-01-termine.csv",
  "abgleich-01-feldvergleich.csv", "abgleich-01-entscheidungen.csv", "LIESMICH-abgleich-01.md"] as const;
const inputPaths = ["werkstatt/01-roh/app-workflow-setup.zip", "werkstatt/01-roh/app-workflow-setup.herkunft.json",
  "werkstatt/01-roh/Kurverwaltungen_2025.md", "werkstatt/01-roh/Termine_2027_suendenfrei.txt",
  "werkstatt/02-normiert/kontakte-struktur.json", "werkstatt/02-normiert/suendenfrei-termine.csv",
  "werkstatt/02-normiert/nutzer-ergaenzungen.json", "src/lib/comparison-model.ts", "scripts/build-comparison.mjs"];
const digest = (bytes: Uint8Array) => createHash("sha256").update(bytes).digest("hex");
function inputFile(file: string) {
  if (!inputPaths.includes(file) || file.split("/").includes("..")) throw new Error("Eingabe nicht freigegeben.");
  if (file.startsWith("werkstatt/")) return path.join(process.cwd(), "werkstatt", file.slice(10));
  if (file.startsWith("src/lib/")) return path.join(process.cwd(), "src", "lib", file.slice(8));
  return path.join(process.cwd(), "scripts", file.slice(8));
}

// Report is computed offline. API checks hashes only, never writes or returns original archive/chat data.
export async function getComparisonReport() {
  const base = path.join(process.cwd(), "werkstatt", "03-berichte");
  const manifestName = "abgleich-01.pruefsummen.sha256";
  const files = Object.fromEntries(await Promise.all([...comparisonReportFiles, manifestName].map(async (name) => [name, await readFile(path.join(base, name))] as const))) as Record<string, Buffer>;
  const lines = files[manifestName].toString("utf8").trim().split("\n");
  if (lines.length !== comparisonReportFiles.length) throw new Error("Unvollständiger Abgleichmanifest.");
  const seen = new Set<string>();
  for (const line of lines) {
    const match = line.match(/^([a-f0-9]{64})  ([a-zA-Z0-9_.-]+)$/);
    if (!match || !(comparisonReportFiles as readonly string[]).includes(match[2]) || seen.has(match[2])) throw new Error("Nicht erlaubte Berichtsdatei.");
    seen.add(match[2]); if (digest(files[match[2]]) !== match[1]) throw new Error("Bericht entspricht nicht seiner Prüfsumme.");
  }
  const report = JSON.parse(files["abgleich-01.json"].toString("utf8")) as ComparisonReport;
  if (report.version !== COMPARISON_VERSION || report.inputFiles.length !== inputPaths.length || report.findings.some((r) => r.decision !== "offen")) throw new Error("Kein aktueller offener Abgleichbericht.");
  const inputSeen = new Set<string>();
  await Promise.all(report.inputFiles.map(async (input) => {
    if (inputSeen.has(input.path)) throw new Error("Doppelte Eingabe im Bericht."); inputSeen.add(input.path);
    if (digest(await readFile(inputFile(input.path))) !== input.sha256) throw new Error("Bericht wurde vor einer Eingabeänderung erstellt.");
  }));
  return { report, files };
}
