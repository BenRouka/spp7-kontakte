import { getReviewData, parseReviewYear } from "@/lib/review-repository";

export const dynamic = "force-dynamic";
export async function GET(request: Request) {
  const year = parseReviewYear(new URL(request.url).searchParams.get("year"));
  if (!year) return Response.json({ error: "Verfügbar sind ausschließlich die Quelljahre 2026 und 2027." }, { status: 400 });
  try {
    return Response.json(await getReviewData(year), { headers: { "Cache-Control": "no-store" } });
  } catch {
    return Response.json({ error: "Die Prüfdaten konnten nicht gelesen werden." }, { status: 500 });
  }
}
