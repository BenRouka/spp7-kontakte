# SPP7 · FREEZE-08 — Stufe 3, Abgleich 01 erstellt

**Aktueller Einstieg für die Wiederaufnahme.** Stufe 3 ist als reproduzierbarer, lesender Bericht ausgeführt. **Stufe 4 und Stufe 5 sind nicht ausgeführt.** Alle historischen Freeze-Dokumente bleiben unverändert erhalten.

## Freigegebener Umfang / Ergebnis

Verglichen wurden die unveränderte ursprüngliche Dashboard-App-ZIP und die bestehenden normierten Referenzdaten einschließlich ausdrücklicher Nutzerergänzungen.

- **Kontakte:** 32 Referenzeinrichtungen ↔ 74 Bestandszeilen. 20 haben einen Namens-/Kanalhinweis, 12 nur einen gleichen Kanal. 38 Kandidatenpaare, 38 Bestandskontakte ohne Kandidat nach diesen Regeln.
- Gleiche E-Mail ist **kein** Identitätsnachweis. Baabe-Kurverwaltung/Pavillon sowie Middelhagen/Thiessow teilen ausdrücklich genannte Kanäle und bleiben getrennte Einrichtungen.
- **Termine:** 54 Quellzeilen, 60 Zeitfenster. 10 Zeilen mit vollständigem Datum-/Ort-Hinweis, davon 9 mit zusätzlichem Namenswortfolge-Hinweis.
- 44 Zeilen ohne vollständigen Datum-/Ort-Nachweis, darunter 2 offene Ortsplatzhalter. Das bedeutet nicht, dass diese Veranstaltungen extern fehlen.
- 10 von 60 Referenzzeitfenstern haben Datum-/Ort-Hinweise. Die vier Adventswochenenden je Jahr sind getrennte Fenster, nicht ein durchgehender Termin.
- **65 offene Befund-IDs:** jeder Beleg, Vorschlag und jede Frage ist nummeriert; `entscheidung=offen` überall. Keine Zuordnung wird als verifiziert oder freigegeben ausgegeben.

Die frühere Handoff-Zählung „46 von 54 fehlen“ wird nicht übernommen. Eventdatensätze und Terminzeilen wurden dort vermischt; der aktuelle Abgleich prüft jede Referenzzeile und deren genaue Fenster.

## Methoden / Grenzen

- Literalvergleich mit dokumentierter Interpunktions-/Schreibform-Bereinigung; keine Fuzzy-Score-Entscheidungen oder semantische Identitätsbehauptungen.
- Kontakte: gleicher Kanal oder gleiche/enthaltene Namenswortfolge erzeugt einen **Kandidaten**. Gemeinsame Kanäle und unterschiedliche Einrichtungen bleiben sichtbar.
- Termine: vollständige ISO-Fenster und wörtlicher Ortstext müssen beim selben Bestands-Event vorkommen. Name, PLZ und Quelltyp werden zusätzlich und getrennt geprüft.
- Postdatum, Bewerbungsfrist/-phase, Feed-Kontext, Booking-Hinweise und unvollständige Datumseinträge werden nicht als komplette Veranstaltungszeiträume gezählt.
- Feldstatus `gleich` ist von `enthalten` getrennt: Ein Referenzdatum kann passen, obwohl das Bestands-Event weitere Jahre oder Zeitfenster enthält.
- Straße, PLZ, Telefon, Fax, Web, Ortsteil und Parent fehlen als eigene Bestands-Kontaktfelder. Informationen in `NOTIZ` sind Freitext, nicht plötzlich strukturiert.
- Die Statistik bezieht sich auf die gepinnte App-ZIP, **nicht** auf einen unbekannten Live-Arena-Datenbestand.
- Keine externen Webseiten oder privaten Chat-Archive neu geprüft. Nutzerangaben bleiben als Nutzerangaben gekennzeichnet.

## Beispielbefunde für Stufe 4

- **K-01:** Putbus K22/K23/K70 mit unterschiedlichen Kontaktkanälen; Institutszuordnung nicht automatisch entschieden.
- **K-03:** Infopoint Sellin – zwei Referenz-E-Mails auf K07/K68, Zwecke getrennt betrachten.
- **K-04:** Baabe gemeinsamer Kanal – eigener Pavillon-Eintrag im App-Bestand nicht dadurch bewiesen.
- **K-05:** Touristik Lohme GmbH ↔ Gemeinde Lohme mit gleicher E-Mail, unterschiedlichem Namen/Typ.
- **K-06:** Zimmervermittlung Rügen ↔ Personenkontakt K57, keine stille Umbenennung.
- **K-07:** Middelhagen K09 hat nur `(nicht genannt)` als Kanal; Thiessow ist keine Ersatzinstitution.
- **T-SF37:** Stolpen – Datum und Ort passen zu S06, Veranstaltungsname weicht ab.
- **T-KI:** M14/M21/M44 liefern Datum-/Ort-Hinweise, tragen aber weiterhin KI-Listenherkunft; keine globale Verifikation.
- **B-REL-feed_context-EVENT_ID:** F29 wird referenziert, ist in `events` nicht vorhanden.
- **B-DATE-D113-D198:** M21 trägt denselben Zeitraum zweimal mit unterschiedlicher `ART`; keine automatische Löschung.

## Dateien / Prüfansicht

- `werkstatt/01-roh/app-workflow-setup.zip`: originale Vergleichseingabe, SHA-256 `3776094a1a5b3015ea4bbc8f4343bedaa0b7746ec4c19b1bcd6ad4e76ba2adef`.
- `app-workflow-setup.herkunft.json`: URL, Abrufzeit, Größe, Prüfsumme. Nicht als statische Web-Datei ausgeliefert.
- `scripts/build-comparison.mjs`: erzeugt ausschließlich neue Berichtdateien; `--verify` schreibt nichts.
- `scripts/check-comparison.mjs`: unabhängige Gegenproben zu falschem Ort, Postdatum, gemeinsamen Kanälen und Advents-Gesamtspanne.
- `werkstatt/03-berichte/abgleich-01.md`: gesamter lesbarer Bericht.
- `abgleich-01.json`: derselbe Bericht für die Prüfansicht.
- CSVs `abgleich-01-kontakte`, `-termine`, `-feldvergleich`, `-entscheidungen`: vollständige Tabellen, eindeutige IDs/Fundstellen.
- `LIESMICH-abgleich-01.md`: Methoden und Ausführungsanleitung.
- `abgleich-01.pruefsummen.sha256`: Bericht-Prüfsummen.
- **Option A → Abgleich**, Direktadresse `/abgleich`: lesende Übersicht, Suche/Filter, Kandidaten, Felder, offene Fragen, Berichtdownloads. Keine Übernahme-/Importfunktion.
- `GET /api/review/comparison`: prüft Bericht- und Eingabeprüfsummen. Downloads nur feste Bericht-Formate; das App-ZIP wird nicht ausgeliefert.

## Datenschutz / Schutzbereich

Personennamen und Bestandskanäle von Personenkontakten sind in Berichten ausgeblendet. Bestandskontakte/-events außerhalb der Referenzkandidaten erscheinen nur mit ID und Typ; auch persönliche Bestandteile in Firmennamen oder Chat-/Linkbezeichnungen werden dort nicht neu veröffentlicht. Der Bericht enthält die institutionellen Referenz-Kontaktangaben; seine Prüfansicht ist keine Authentifizierung oder allgemeine Zugriffskontrolle. Kein privates Chat-ZIP, keine .env und keine Datenbankexporte im Berichtdownload.

Roh-MD/TXT, Nutzerergänzungen, Normierungs-CSVs/JSON, Kontakthierarchie, Datenbankschema, Zeitmodell und Option-B-Paket sind unverändert. Die aktuelle .env wird nicht in das Freeze-Manifest aufgenommen. Kein Geocoding, keine externe Verifikation, keine Adresskorrektur, kein Merge, keine Löschung.

Das Hinzufügen der Original-App-ZIP als Vergleichseingabe bedeutet nicht, dass alle fünf ursprünglichen Quellen lokal gesichert sind. Chat-ZIP und Logo bleiben extern referenziert; nicht stillschweigend ergänzt.

## Wiederaufnahme

1. Diesen FREEZE-08 und den Bericht `werkstatt/03-berichte/abgleich-01.md` lesen.
2. `sha256sum -c docs/FREEZE-08.sha256`.
3. `node scripts/build-comparison.mjs --verify` und `node scripts/check-comparison.mjs`.
4. `node scripts/normalize-sources.mjs --verify`, Kontakt-/Kalenderregression, Rohquellen-Prüfsummen.
5. Nächster Schritt: Stufe 4, Befund-IDs einzeln entscheiden. Keine freie Interpretation von „ja“ als pauschale Importfreigabe.

Prüfergebnisse: `docs/FREEZE-08-pruefprotokoll.txt`. Bis zum nächsten ausdrücklich bestätigten Schritt bleibt dieser Stand eingefroren.
