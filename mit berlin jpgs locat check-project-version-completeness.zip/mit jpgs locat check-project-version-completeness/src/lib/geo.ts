/* ------------------------------------------------------------------ */
/* C1/C2 — Geo-Hilfen der Werkstatt.                                   */
/*                                                                    */
/* Grundsatz (freigegebene Geo-Strategie + O-11):                      */
/*   · Koordinaten in geo_orte sind frisch per Nominatim/OSM erzeugt.  */
/*   · Jeder Eintrag trägt Quelle, Genauigkeit (OSM-addresstype) und   */
/*     Prüfstatus — nichts wird still aus dem Altbestand übernommen.   */
/*   · Zentroide/PLZ-Punkte gelten nie als Veranstaltungsgelände.      */
/* Projektion = Alt-Formel des Event-Radars (SVG viewBox 460 × 330).   */
/* ------------------------------------------------------------------ */

export const RADAR_VIEWBOX = { w: 460, h: 330 } as const;

/** Alt-Formel, bytegenau aus dem Alt-System übernommen. */
export function projX(lng: number): number {
  return 105 + ((lng - 5) / 11) * 250;
}
export function projY(lat: number): number {
  return 300 - ((lat - 47) / 8.5) * 270;
}

/* ------------------------------------------------------------------ */
/* Normalisierung „PLZ Ort / Venue" → { plz, ort }                     */
/* Rein mechanisch — keinerlei Ortswissen, alles Weitere prüft der     */
/* Geocoder und der Prüfstatus in geo_orte.                            */
/* ------------------------------------------------------------------ */

export interface PlzOrt {
  plz: string;
  ort: string;
}

export function normalizePlzOrt(raw: string): PlzOrt | null {
  const m = raw.match(/^\s*(\d{5})\s+(.+?)\s*$/);
  if (!m) return null;
  const ort = m[2]
    .split(/[/,]/)[0] // Venue-/Lage-Suffix abtrennen („/ Stallhof“, „, Schladitzer Bucht“, „/Thür.“)
    .replace(/-\s+/g, "-") // OCR-Leerraum hinter Bindestrich („Castrop- Rauxel“)
    .trim();
  if (!ort) return null;
  return { plz: m[1], ort };
}

/** Tour-Korridor · Sommer 2027 — Beleg:                                  */
/*   SF35 (Insel Poel)  ↔ alt_events S04 · kuratiert verknüpft, datiert    */
/*   SF36 (Stralsund)   ↔ alt_events S03 · kuratiert verknüpft, datiert    */
/*   Putgarten/Rügenhof ↔ alt_events T04 · Vormerkung (PLZ 18556)          */
/*   Schaprode          ↔ alt_events T09 · Vormerkung (PLZ 18569)          */
/*   Wagendorf Karow    ↔ Nutzer-Tourplanung 2027 · Vormerkung (13125)     */
/*   Arcanoa            ↔ Nutzer-Tourplanung 2027 · Vormerkung (10965)     */
/*   CLASH Berlin       ↔ Nutzer-Tourplanung 2027 · Vormerkung (10961)     */
/*   Schokoladen e.V.   ↔ Nutzer-Tourplanung 2027 · Vormerkung (10115)     */
/*   Supamolly          ↔ Nutzer-Tourplanung 2027 · Vormerkung (10247)     */
/*   Trinkteufel        ↔ Nutzer-Tourplanung 2027 · Vormerkung (10997)     */
export const KORRIDOR_PLZ = [
  "23999",
  "18439",
  "18556",
  "18569",
  "13125",
  "10965",
  "10961",
  "10115",
  "10247",
  "10997",
] as const;

export type Pruefstatus = "ungeprueft" | "pruefen" | "geprueft";

export const PRUEFSTATUS_LABEL: Record<Pruefstatus, string> = {
  ungeprueft: "ungeprüft",
  pruefen: "prüfen",
  geprueft: "geprüft",
};
