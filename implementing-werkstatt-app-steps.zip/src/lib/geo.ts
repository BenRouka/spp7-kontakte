/* ------------------------------------------------------------------ */
/* GEO — reine Helfer (kein server-only): wird vom Geocode-Skript     */
/* und von der Karte gemeinsam genutzt.                                */
/*                                                                     */
/* Projektion 1:1 aus dem Alt-Event-Radar (Mockup index.html),        */
/* dokumentiert im Handoff:                                            */
/*   x = 105 + (LNG − 5) / 11 × 250                                    */
/*   y = 300 − (LAT − 47) / 8,5 × 270                                  */
/* viewBox des Radars: 460 × 330.                                      */
/* ------------------------------------------------------------------ */

export function projektion(lng: number, lat: number): { x: number; y: number } {
  return {
    x: 105 + ((lng - 5) / 11) * 250,
    y: 300 - ((lat - 47) / 8.5) * 270,
  };
}

/* Stilisierte Deutschland-Silhouette (Pfad aus dem Alt-Radar, 1:1) --- */
export const DEUTSCHLAND_PFAD =
  "M213 18l32 18 29-4 19 29 35 14-8 32 22 28-17 24 10 38-27 17-6 36-35 9-15 39-36 18-27-27-39-3-9-39-27-21 15-33-11-35 28-26-3-39 34-17 13-35z";

/* Gitterlinien (1:1 aus dem Alt-Radar) ------------------------------- */
export const GITTER_H = "M0 55H460M0 110H460M0 165H460M0 220H460M0 275H460";
export const GITTER_V = "M77 0V330M154 0V330M231 0V330M308 0V330M385 0V330";

/* ------------------------------------------------------------------ */
/* Tour-Korridor Ostsee · Sommer 2027 (hart aus dem Alt-System       */
/* übernommen: S04 Poel · S03 Stralsund · T04 Rügenhof · T09          */
/* Schaprode). Geo-Bezug läuft über die frisch geocodierten            */
/* geo_orte-Schlüssel, nicht über Alt-Koordinaten.                     */
/* ------------------------------------------------------------------ */
export interface KorridorDef {
  altEventId: string; // Brücke zum Altbestand (Prio 2)
  label: string;
  plz: string;
  ort: string; // geo_orte-Schlüssel
  untertitel: string;
}

export const KORRIDOR: readonly KorridorDef[] = [
  {
    altEventId: "S04",
    label: "Insel Poel",
    plz: "23999",
    ort: "Insel Poel",
    untertitel: "Mittelalterspektakel",
  },
  {
    altEventId: "S03",
    label: "Stralsund",
    plz: "18439",
    ort: "Stralsund",
    untertitel: "Wallensteintage",
  },
  {
    altEventId: "T04",
    label: "Rügenhof",
    plz: "18556",
    ort: "Putgarten",
    untertitel: "Kap Arkona · Zentralcamp",
  },
  {
    altEventId: "T09",
    label: "Schaprode",
    plz: "18569",
    ort: "Schaprode",
    untertitel: "Hafen",
  },
];

/* ------------------------------------------------------------------ */
/* Ortsschlüssel aus dem kuratierten PLZ+Ort-Feld.                     */
/* Regeln (rein mechanisch, kein Deuten):                              */
/*   PLZ = führende 5 Ziffern; ohne PLZ => null („xxxx“-Platzhalter).  */
/*   Kandidaten = links vom „/“, danach rechte Seite; je Kandidat      */
/*   werden „(…)-“, „, …“- und „ b. …“-Zusätze entfernt.               */
/* Beispiele:                                                          */
/*   „01833 Stolpen (Burg)“            → Stolpen                       */
/*   „56346 Loreley/ St. Goarshausen“  → Loreley, dann St. Goarshausen */
/*   „90513 Zirndorf b. Nürnberg“      → Zirndorf                      */
/* ------------------------------------------------------------------ */
export interface OrtSchluessel {
  plz: string;
  kandidaten: string[];
}

export function parsePlzOrt(raw: string): OrtSchluessel | null {
  const m = raw.match(/^\s*(\d{5})\s+(.+)$/);
  if (!m) return null;
  const plz = m[1];
  const rest = m[2];
  const seiten = rest.split("/").map((s) => s.trim()).filter(Boolean);

  const bereinige = (s: string) =>
    s
      .replace(/\(.*?\)/g, "")
      .split(",")[0]
      .replace(/\s+b\.\s.*$/, "") // „Zirndorf b. Nürnberg“ → „Zirndorf“
      .replace(/\s{2,}/g, " ")
      .trim();

  const kandidaten: string[] = [];
  for (const seite of seiten) {
    const k = bereinige(seite);
    if (k.length >= 3 && !kandidaten.includes(k)) kandidaten.push(k);
  }
  if (kandidaten.length === 0) return null;
  return { plz, kandidaten };
}

export function geoKey(plz: string, ort: string): string {
  return `${plz}|${ort}`;
}

/* ------------------------------------------------------------------ */
/* Statische Fallback-Koordinaten (Ortskern, öffentliches Wissen).     */
/* Nur Sicherheitsnetz: wird ausschließlich benutzt, wenn der          */
/* Geocoder keinen Treffer liefert. Solche Einträge tragen             */
/* quelle = statisch-fallback, genauigkeit = statisch,                 */
/* pruefstatus = pruefen — und sind damit auditierbar markiert.        */
/* ------------------------------------------------------------------ */
export const FALLBACK_KOORDINATEN: Record<string, { lat: string; lng: string }> = {
  "01067|Dresden": { lat: "51.050409", lng: "13.737262" },
  "01683|Altzella": { lat: "51.056800", lng: "13.300200" },
  "01833|Stolpen": { lat: "51.048600", lng: "14.083700" },
  "02829|Königshain": { lat: "51.183300", lng: "14.866700" },
  "04107|Leipzig": { lat: "51.339700", lng: "12.373100" },
  "04229|Leipzig": { lat: "51.326700", lng: "12.357000" },
  "04519|Rackwitz": { lat: "51.433300", lng: "12.383300" },
  "06543|Falkenstein": { lat: "51.681400", lng: "10.900900" },
  "06632|Freyburg": { lat: "51.213600", lng: "11.770600" },
  "07929|Saalburg": { lat: "50.633300", lng: "11.733300" },
  "09111|Chemnitz": { lat: "50.833300", lng: "12.916700" },
  "18439|Stralsund": { lat: "54.309632", lng: "13.082085" },
  "23999|Insel Poel": { lat: "53.990887", lng: "11.405026" },
  "34131|Kassel": { lat: "51.312711", lng: "9.479746" },
  "34346|Hann. Münden": { lat: "51.419400", lng: "9.650600" },
  "41844|Wegberg": { lat: "51.141400", lng: "6.279400" },
  "44286|Dorsten": { lat: "51.661900", lng: "6.965300" },
  "44575|Castrop-Rauxel": { lat: "51.556600", lng: "7.311700" },
  "44629|Herne": { lat: "51.540100", lng: "7.221400" },
  "45899|Gelsenkirchen": { lat: "51.517745", lng: "7.085718" },
  "46509|Xanten": { lat: "51.661400", lng: "6.453900" },
  "47447|Moers": { lat: "51.451600", lng: "6.640800" },
  "52349|Düren": { lat: "50.802400", lng: "6.482800" },
  "56346|Loreley": { lat: "50.139200", lng: "7.728900" },
  "56346|St. Goarshausen": { lat: "50.154800", lng: "7.711700" },
  "58455|Witten": { lat: "51.440000", lng: "7.350000" },
  "69120|Heidelberg": { lat: "49.398752", lng: "8.672434" },
  "85399|Hallbergmoos": { lat: "48.326600", lng: "11.748900" },
  "90513|Zirndorf": { lat: "49.444700", lng: "10.958600" },
  "93186|Adlersberg": { lat: "49.052800", lng: "12.313900" },
  "93186|Pettendorf": { lat: "49.056700", lng: "12.311400" },
  "96178|Schloss Weissenstein": { lat: "49.761700", lng: "10.821100" },
  "96178|Pommersfelden": { lat: "49.759700", lng: "10.819400" },
  "97877|Wertheim": { lat: "49.759000", lng: "9.517600" },
  "99423|Weimar": { lat: "50.979493", lng: "11.323544" },
  "99448|Kranichfeld": { lat: "50.853100", lng: "11.199200" },
  "99510|Apolda": { lat: "51.024200", lng: "11.515800" },
  "99707|Kyffhäuser": { lat: "51.409400", lng: "11.109700" },
  "99885|Weißensee": { lat: "51.197800", lng: "10.865800" },
  "18556|Putgarten": { lat: "54.672392", lng: "13.415759" },
  "18569|Schaprode": { lat: "54.513165", lng: "13.164420" },
};
