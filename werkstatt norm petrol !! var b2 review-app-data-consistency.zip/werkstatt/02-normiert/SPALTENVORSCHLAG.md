# Stufe 2 · Vorschlag zum CSV-Spaltenaufbau

**Status: nur Vorschlag — keine Datenzeilen erzeugt, keine Datenbankänderung.**

> Vorsicht: Parent/Child ergänzt den vorgeschlagenen Aufbau um eine fünfte CSV-Datei. Das Datenbankschema bleibt unverändert; vollständige Normierung ist noch nicht gestartet.

## Fünf vorgeschlagene Dateien

- `kurverwaltungen-gruppen.csv`: bisher zwei ausdrücklich benannte Parents (Mönchgut und Baabe); andere Parents nicht geraten.
- `kurverwaltungen.csv`: 32 Adressblöcke bleiben 32 Standortzeilen mit parent_id und Hierarchie-Beleg.
- `kurverwaltungen-kontaktwege.csv`: 119 MD-Werte plus Website und E-Mail Middelhagen sowie Telefon Thiessow = 122. Keine Übertragung gleicher Werte auf andere Standorte.
- `suendenfrei-termine.csv`: 54 TAB-getrennte Quellzeilen bleiben 54 Kernzeilen.
- `suendenfrei-zeitfenster.csv`: 60 Zeitfenster; insbesondere je vier Wochenenden für die zwei Adventszeilen.

## Korrigierte Quellenzählung

- 32 Adressblöcke aus 36 fett gesetzten Namenszeilen; vier Blöcke haben einen direkt folgenden Zusatznamen.
- 119 Kontaktwege: 31 Telefon, 29 Fax, 28 Internet und 31 E-Mail.
- Im MD sind zwei Blöcke ohne E-Mail: Infopavillion KV Baabe sowie Mönchgut/Middelhagen. Der Infopoint Sellin enthält zwei E-Mail-Zeilen.
- Deine Ergänzung liefert Middelhagens E-Mail und Website sowie Thiessows Telefon. Nur in der ergänzten Arbeitsebene bleibt eine E-Mail-Lücke: Infopavillion KV Baabe. Keine automatische Übernahme von willkommen@baabe.de.
- Die Nutzerzuordnung und vier Beispielstandorte sind in KONTAKTKLAERUNG.md / kontaktklaerung-beispiele.json dokumentiert. Die vollständigen CSV-Datenzeilen sind noch nicht erzeugt.
- Damit sind die alten Angaben ‚fünf Doppel-Namensblöcke‘, ‚nur eine fehlende E-Mail‘ und ‚120 Kontaktwege‘ überholt.

## Grundregeln

- MD-Originale werden nie überschrieben. Nutzerkorrekturen tragen eigene Herkunft; Telefonableitungen eine eigene Regel.
- Belegte Parents und Child-Standorte werden getrennt geführt. Getrennte Adressen bleiben eigenständige Children, auch bei gleicher E-Mail oder Telefonnummer.
- Zwei Namenszeilen an derselben Adresse allein beweisen keine Außenstelle. Andere Hierarchien bleiben offen statt aus Ortsnamen geraten zu werden.
- Fehlende Angaben erscheinen als -. Intern bleiben sie null mit Fehlstatus; originale Abwesenheit wird nicht als Quellenwert umgeschrieben.
- Keine automatische Kontaktvererbung: Baabes Infopavillion erhält weder E-Mail noch Fax noch Internet von der Kurverwaltung.
- Für diese deutsche/Rügen-Quelle ist die zusätzliche +49-Telefonform freigegeben. Die führende nationale 0 entfällt; Original bleibt erhalten. Keine Erreichbarkeitsprüfung.
- www-Adressen behalten ihre ursprüngliche Form; http/https wird weiterhin nicht angenommen.
- Nicht markiert ist kein Verifikationsnachweis; Quellen-/Ergänzungsstatus und Normierungsstatus bleiben getrennt.
- Ein Quelltermin bleibt ein Termin, auch wenn vier getrennte Adventszeitfenster dazugehören.
- Straße, Hausnummer, Ort und Spielort werden nur bei eindeutiger Quelle getrennt; sonst Status pruefen.

## kurverwaltungen-gruppen.csv

**2 Zeilen erwartet · bisher zwei ausdrücklich benannte Parent-Gruppen.**

Ostseebad Mönchgut und Ostseebad Baabe als Standortgruppen aus Nutzervorgabe. Keine rechtliche Organisationshierarchie und keine automatisch abgeleiteten weiteren Parents.

| Feld | Typ | Pflicht | Rolle | Bedeutung | Beispiel |
|---|---|---|---|---|---|
| `gruppe_id` | text | ja | schluessel | Stabile Gruppen-ID; die sichtbare Nummer ist kein Schlüssel. | KVG01 |
| `name_original` | text | ja | original | Gruppenname aus der ausdrücklich gelieferten Zuordnung. | Ostseebad Mönchgut |
| `name_normiert` | text | ja | normiert | Zusätzliche Vergleichsschreibweise, Original unverändert. | Ostseebad Mönchgut |
| `quelle_art` | enum (md / nutzer) | ja | herkunft | Herkunft der Parent-Zuordnung, nicht bloß gleicher Ortsname. | nutzer |
| `quelle_ref` | text | ja | herkunft | Verweist auf die Nutzerklärung oder eine spätere ausdrücklich belegte Quelle. | nutzer-kontaktklaerung-01 |
| `normierungsstatus` | enum (offen / normiert / pruefen) | ja | status | Bearbeitungsstatus; keine rechtliche Verifikation. | offen |

## kurverwaltungen.csv

**32 Zeilen erwartet · eine Zeile je Adressblock.**

Bewahrt 32 MD-Standorte. Belegte Außenstellen werden über parent_id getrennt zugeordnet. Zwei Namen an derselben Adresse bleiben originale Namensfelder; unbekannte Beziehungen werden nicht erfunden.

| Feld | Typ | Pflicht | Rolle | Bedeutung | Beispiel |
|---|---|---|---|---|---|
| `kurverwaltung_id` | text | ja | schluessel | Stabiler Schlüssel; Ortsnamen und Anzeigeordnungen sind nicht eindeutig. | KV12 |
| `parent_id` | text | nein | relation | Verweist auf gruppe_id. Nur bei belegter Zuordnung; sonst - und Hierarchiestatus offen. | KVG01 |
| `parent_quelle_ref` | text | nein | herkunft | Herkunft der Parent/Child-Beziehung; nicht automatisch aus identischer E-Mail abgeleitet. | nutzer-kontaktklaerung-01 |
| `hierarchiestatus` | enum (zugeordnet / offen) | ja | status | Zugeordnet, wenn ausdrücklich belegt; sonst offen. | zugeordnet |
| `quelle_datei` | text | ja | herkunft | Unveränderter Dateiname der Referenzquelle. | Kurverwaltungen_2025.md |
| `quelle_zeile_von` | integer | ja | herkunft | Erste Zeile des Originalblocks. | 9 |
| `quelle_zeile_bis` | integer | ja | herkunft | Letzte Zeile des Originalblocks. | 15 |
| `bereich_original` | text | ja | original | Übergeordnete Markdown-Überschrift unverändert. | Rund um die Granitz |
| `ortsueberschrift_original` | text | ja | original | Lokale Markdown-Überschrift unverändert; kann doppelt vorkommen. | Vitte |
| `name_haupt_original` | text | ja | original | Erste fett gesetzte Namenszeile unverändert. | Kurverwaltung Mönchgut |
| `name_zusatz_original` | text | nein | original | Zweite fett gesetzte Namenszeile; leer, wenn nicht vorhanden. | Tourist-Information Middelhagen |
| `strasse_original` | text | ja | original | Vollständige Straßenzeile unverändert. | Dorfstraße 4 |
| `plz_ort_original` | text | ja | original | Vollständige PLZ-/Ortszeile unverändert. | 18586 Ostseebad Mönchgut OT Middelhagen |
| `hinweis_original` | text | nein | original | Separater oder klar abtrennbarer Quellenhinweis; sonst leer. | keine Zimmervermittlung |
| `name_haupt_normiert` | text | ja | normiert | Zusätzliche Vergleichsschreibweise; Original bleibt maßgeblich. | Kurverwaltung Mönchgut |
| `name_zusatz_normiert` | text | nein | normiert | Zusätzliche Vergleichsschreibweise des Zusatznamens. | Tourist-Information Middelhagen |
| `strasse_normiert` | text | ja | normiert | Straßenname ohne stillschweigende Ergänzungen. | Dorfstraße |
| `hausnummer_normiert` | text | nein | normiert | Nur abtrennen, wenn die Quelle eindeutig ist. | 4 |
| `adresszusatz_normiert` | text | nein | normiert | Klammer- oder Gebäudeteil; leer, wenn nicht vorhanden. | Haus des Gastes |
| `plz_normiert` | text | ja | normiert | Fünfstellige PLZ; als Text, damit führende Nullen erhalten bleiben. | 18586 |
| `ort_normiert` | text | ja | normiert | Ort aus derselben Quellenzeile; keine externe Anreicherung. | Ostseebad Mönchgut |
| `ortsteil_normiert` | text | nein | normiert | Nur bei ausdrücklichem OT-Hinweis; Schrägstriche nicht automatisch deuten. | Middelhagen |
| `hinweis_normiert` | text | nein | normiert | Lesbare Zusatzangabe, ohne den Sinn zu erweitern. | keine Zimmervermittlung |
| `quellenstand` | text | ja | herkunft | Standangabe aus der Quelle. | 2025 |
| `haftungshinweis` | text | ja | herkunft | Hinweis der Quelle unverändert. | Alle Angaben ohne Gewähr |
| `normierungsstatus` | enum (offen / normiert / pruefen) | ja | status | Bearbeitungsstatus, keine Aussage zur fachlichen Richtigkeit. | offen |

## kurverwaltungen-kontaktwege.csv

**122 Zeilen erwartet · 119 originale Kontaktwerte plus drei ausdrückliche Nutzerergänzungen.**

Ein Wert je Standort und Kontaktweg: 119 MD-Werte bleiben erhalten; Website und E-Mail Middelhagen sowie Telefon Thiessow werden als Nutzerwerte geführt. - ist kein Kontaktwert und erzeugt keine Kontaktweg-Zeile.

| Feld | Typ | Pflicht | Rolle | Bedeutung | Beispiel |
|---|---|---|---|---|---|
| `kontaktweg_id` | text | ja | schluessel | Stabiler Schlüssel für einen einzelnen Kanal. | KW001 |
| `kurverwaltung_id` | text | ja | relation | Gehört zum konkreten Child-Standort, nicht automatisch zum Parent oder Nachbarstandort. | KV13 |
| `quelle_art` | enum (md / nutzer) | ja | herkunft | MD-Original oder ausdrücklich ergänzter Nutzerwert. | nutzer |
| `quelle_ref` | text | ja | herkunft | Datei/Quellstelle oder dokumentierte Nutzerklärung. | nutzer-kontaktklaerung-01 |
| `quelle_zeile` | integer | nein | herkunft | Bei MD-Werten die ursprüngliche Zeile; bei einer Nutzerergänzung nicht vorhanden. Intern null, Anzeige -. | 15 |
| `reihenfolge` | integer | ja | herkunft | Reihenfolge gleicher Kanäle derselben Stelle. | 1 |
| `typ` | enum (telefon / fax / email / internet) | ja | normiert | Kontaktart; kein Sammelfeld und keine Vererbung. | telefon |
| `wert_original` | text | ja | original | Originalwert seiner tatsächlichen Quelle, Nutzer oder MD. | +49 38308 66010 |
| `wert_md_original` | text | nein | original | Ergänzungen füllen dieses Feld nicht rückwirkend. Fehlte der Wert im MD, bleibt es intern leer. | - |
| `wert_normiert` | text | ja | normiert | Zusätzlicher Vergleichswert; keine externe Verifikation. | +493830866010 |
| `telefon_international` | text | nein | normiert | Zusätzliche +49-Form nur für die freigegebene DE-Quelle; kein blindes Ersetzen vorhandener Länderkennungen. | +493838807780 |
| `normalisierungsregel` | enum (de_49_freigegeben / international_bereits_in_quelle / international_00_zu_plus / fax_original / email_klein / domain_klein) | ja | status | Dokumentiert die freigegebene Umrechnung; Original immer erhalten. | de_49_freigegeben |
| `normierungsstatus` | enum (offen / normiert / pruefen) | ja | status | Bearbeitungsstatus des Werts, keine Erreichbarkeitsprüfung. | offen |

## suendenfrei-termine.csv

**54 Zeilen erwartet · eine Zeile je TAB-getrennter Quellzeile.**

Erhält exakt 9 Quellzeilen aus 2026 und 45 aus 2027; Sternchenpositionen bleiben nachvollziehbar.

| Feld | Typ | Pflicht | Rolle | Bedeutung | Beispiel |
|---|---|---|---|---|---|
| `termin_id` | text | ja | schluessel | Stabiler Schlüssel in Quellenreihenfolge. | ST01 |
| `quelle_datei` | text | ja | herkunft | Unveränderter Dateiname der Referenzquelle. | Termine_2027_suendenfrei.txt |
| `quelle_zeile` | integer | ja | herkunft | Physische Zeilennummer der Originaldatei. | 56 |
| `quelljahr` | integer | ja | herkunft | Jahr aus der Datumsangabe. | 2027 |
| `datum_original` | text | ja | original | Erste TAB-Spalte unverändert, einschließlich Sternchen. | 1. - 4. Advent 2027* |
| `veranstaltung_original` | text | ja | original | Zweite TAB-Spalte unverändert, einschließlich Tippfehlern und Sternchen. | Mittelalter- Advent (Fr.- So.) |
| `ort_original` | text | ja | original | Dritte TAB-Spalte unverändert, einschließlich Platzhaltern und Sternchen. | 44629 Herne/ Schloss Strünkede |
| `sternchen_datum` | integer | ja | herkunft | Anzahl der Sternchen in der Original-Datumsspalte. | 1 |
| `sternchen_veranstaltung` | integer | ja | herkunft | Anzahl der Sternchen in der Original-Namensspalte. | 0 |
| `sternchen_ort` | integer | ja | herkunft | Anzahl der Sternchen in der Original-Ortsspalte. | 0 |
| `quellstatus` | enum (nicht_markiert / unbestaetigt) | ja | status | Aus Sternchen abgeleitet; nicht markiert bedeutet nicht bestätigt. | unbestaetigt |
| `zeitmodell` | enum (ein_zeitfenster / vier_adventswochenenden) | ja | normiert | Verweist auf ein oder vier Einträge in der Zeitfensterdatei. | vier_adventswochenenden |
| `veranstaltung_normiert` | text | ja | normiert | Zusätzliche Vergleichsschreibweise; Original bleibt erhalten. | Mittelalter-Advent (Fr.–So.) |
| `plz_normiert` | text | nein | normiert | Fünfstellige PLZ als Text; leer bei xxxx/xxxxx. | 44629 |
| `ort_normiert` | text | nein | normiert | Ort ohne stillschweigende Ergänzungen. | Herne |
| `spielort_normiert` | text | nein | normiert | Zusatz nach Schrägstrich oder eindeutigem Quellenhinweis. | Schloss Strünkede |
| `veranstaltung_status` | enum (vorhanden / offen) | ja | status | Kennzeichnet den echten Platzhalter „noch offen“. | vorhanden |
| `ort_status` | enum (vorhanden / offen) | ja | status | Kennzeichnet xxxx/xxxxx als offen; keine erfundene PLZ. | vorhanden |
| `quellenstand` | text | nein | herkunft | Standangabe der 2027-Liste; für 2026 bleibt das Feld leer, weil dort kein Stand genannt ist. | 22. September 2026 |
| `normierungsstatus` | enum (offen / normiert / pruefen) | ja | status | Bearbeitungsstatus, getrennt vom Quellstatus. | offen |

## suendenfrei-zeitfenster.csv

**60 Zeilen erwartet · eine Zeile je durchgehendem Zeitraum oder Adventswochenende.**

Hält einen Quelltermin mit mehreren Zeitfenstern korrekt abbildbar; 52 normale Zeilen plus 8 Adventsfenster.

| Feld | Typ | Pflicht | Rolle | Bedeutung | Beispiel |
|---|---|---|---|---|---|
| `zeitfenster_id` | text | ja | schluessel | Aus Termin-ID und laufender Nummer gebildet. | ST45-Z01 |
| `termin_id` | text | ja | relation | Verweist auf genau eine der 54 Terminzeilen. | ST45 |
| `laufnummer` | integer | ja | relation | 1 bei normalen Terminen, 1–4 beim Advent. | 1 |
| `beginn` | date | ja | normiert | ISO-Datum YYYY-MM-DD. | 2027-11-26 |
| `ende` | date | ja | normiert | Inklusives ISO-Enddatum YYYY-MM-DD. | 2027-11-28 |
| `zeitraum_typ` | enum (durchgehend / adventswochenende) | ja | normiert | Durchgehender Quellzeitraum oder getrenntes Adventswochenende. | adventswochenende |
| `datumsherkunft` | enum (quelle / berechnet) | ja | status | Unterscheidet Quellenübertragung und Kalenderberechnung. | berechnet |
| `berechnungsregel` | enum (kirchenregel_advent) | nein | status | Nur für berechnete Adventsfenster; sonst leer. | kirchenregel_advent |
| `wochentage_original` | text | nein | original | Do.–So. oder Fr.–So. aus der Advents-Quellzeile; sonst leer. | Fr.- So. |
| `normierungsstatus` | enum (offen / normiert / pruefen) | ja | status | Bearbeitungsstatus des Zeitfensters; bestätigt nicht den Termin. | offen |

## Freigaben und offene Vorschlagspunkte

- **S2-1 · Fünf CSV-Dateien mit getrennten Parents: Vorschlag (Empfehlung ja).** Zusätzliche Gruppen-Datei zu den vier bisherigen Vorlagen. 32 Standorte und 54 Termine bleiben erhalten; bisher zwei Parents sind ausdrücklich benannt. Vollständiger Aufbau noch zu bestätigen.
- **S2-2 · ASCII-Feldnamen in snake_case: Vorschlag (Empfehlung ja).** Technische Feldnamen konsistent führen; sichtbare deutsche Bezeichnungen bleiben in Dokumentation und App.
- **S2-3 · Zusätzliche internationale Telefonform +49: bestätigt.** Das Nutzer-ja gilt für die zusätzliche DE-Form: (0 38 38) 80 77 80 → +49 3838 807780. Keine globale Länderannahme und kein Überschreiben des Originals.
- **S2-4 · URL-Protokoll nicht automatisch ergänzen: Vorschlag (Empfehlung ja).** Die Telefonfreigabe bestätigt nicht zugleich https. www-Adressen bleiben vorerst so wie geliefert.
- **S2-5 · Fehlende Werte als - anzeigen: bestätigt.** In Anzeige und späteren normierten CSV-Feldern -, intern null und Fehlstatus. - wird kein Kontaktwert und Originalquellen bleiben leer, wenn nichts genannt war.
- **S2-6 · Parent/Child für Mönchgut und Baabe: bestätigt.** Zwei Parent-Gruppen, jeweils zwei getrennte Standorte. Keine automatische Wertvererbung an Außenstellen.

Nur die vier konkret benannten Standorte werden als Kontaktklärung gezeigt. Erst nach Freigabe des vollständigen Aufbaus werden die 32 + 54 CSV-Kernzeilen und ihre Zuordnungen erzeugt.

