import type { Period, ReviewYear } from "@/lib/calendar-model";

export type AlignmentValue = {
  kind: "weekends" | "continuous";
  dateOrigin: "berechnet" | "aus Quelle";
  uncertain: boolean;
  weekdayLabel: string;
  originalLine: string;
  periods: Period[];
};
export type AlignmentCheck = {
  id: string;
  year: ReviewYear;
  label: string;
  matches: boolean;
  optionA: AlignmentValue;
  optionB: AlignmentValue;
};
export type OptionBAlignment = {
  modelVersion: string;
  aligned: boolean;
  remoteArenaChanged: false;
  optionAInterfacePreserved: true;
  databaseChanged: false;
  originalSourcesPreserved: boolean;
  originalArchiveSha256: string;
  updatedArchiveSha256: string;
  sharedFiles: Array<{ path: string; matches: boolean; optionASha256: string; optionBSha256: string }>;
  checks: AlignmentCheck[];
  downloads: { zip: string; report: string };
};
