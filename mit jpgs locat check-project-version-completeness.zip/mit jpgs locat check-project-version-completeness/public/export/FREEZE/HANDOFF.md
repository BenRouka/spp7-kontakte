HANDOFF · Übergabeprotokoll
**Paket:** Übergabepaket Werkstatt Stufe 4 (Arbeitsstand, nicht importiert)
**Stand:** 2026-10-01
**Bestimmt für:** neuen Chat im Single-Mode, Fortsetzung ohne erneute Recherche
**Ziel:** Werkstatt abschließen, danach sauberer Export in Projekt und Datenbank
---
## 1. Was in diesem Paket gilt
| Datei | Inhalt |
|---|---|
| `arbeitsstand-kontakte.csv` | 34 Einrichtungen, 9 Regionen, Spalten `email_1`/`email_2`/`email_3` |
| `arbeitsstand-termine.csv` | 54 Quellzeilen, 60 Zeitfenster, Sündenfrei 2026 + 2027 |
| `beschlussverzeichnis.csv` | alle gefassten Beschlüsse mit Prio-1-Basis, Prio-2-Ergänzung und Status |
| `HANDOFF.md` | dieses Protokoll |
## 2. Verbindliche Regeln (nicht verhandeln)
1. **Prio 1 = MD / offizielle Website / Register.** Das ist die Basis. Sie gilt.
2. **Prio 2 = Chat / App-Altbestand.** Ergänzt Lücken, überschreibt nie Prio 1.
3. **Müll fliegt raus.** Platzhalter wie `(nicht genannt)` werden gelöscht, nicht gepflegt.
4. **Ein Datensatz pro echter Einrichtung.** Andere Rechtsform, anderer Zweck oder eigener Standort = eigener Datensatz. GmbH und Gemeinde sind nie dasselbe.
5. **Mehrere E-Mails = Spalten.** `email_1`, `email_2`, `email_3` — nicht mehrere Datensätze für dieselbe Einrichtung.
6. **Hierarchie:** Region → Ort → Einrichtung. 9 Regionen, `Übergreifend` an erster Stelle.
7. **Nicht genauer sein als das Basismaterial.** Wenn eine Quelle nicht weiterhilft: getrennter Datensatz mit Prüfhinweis, kein Rätselraten.
## 3. Kontakte — Struktur
Neun Regionen in dieser Reihenfolge:
```
Übergreifend
Rund um die Granitz
Halbinsel Mönchgut
Halbinsel Jasmund
Halbinsel Wittow
Nord-West-Rügen
Süd-Rügen
Zentralrügen
Seebad Insel Hiddensee
```
Besonderheiten, die im neuen Chat sofort bekannt sein müssen:
- **`Übergreifend` → Markt 25, Bergen auf Rügen** hat **drei** Datensätze:
  - `KV01` Tourismusverband Rügen e. V. — `info@ruegen.de`, `hallo@ruegen.de`
  - `KV01.1` Baltic Project GmbH (Tochter, betreibt Info- & Buchungscenter) — `inselexperten@ruegen.de`
  - `KV01.2` Tourismusverband Rügen (Kampagne, eigene Website) — `mail@tourismus-ruegen.de`, Tel. `+49 3838 8077-24`
  - Als MD-Block KV01 ist ein **Kombiblock** und bleibt in der eingefrorenen Normierung ungeteilt (32 Einträge). Die Dreierteilung ist die Arbeitsansicht.
- **Putbus hat drei Träger:** `KV27` Kurverwaltung · `STADT-PUTBUS` Rathaus (nur aus Chat, kein MD-Block) · `KV28` Tourismus- und Gewerbeverein.
- **Die Tourismuszentrale Rügen GmbH existiert nicht mehr.** Sie wurde am 20.01.2021 zur Infrastrukturgesellschaft Mönchgut-Granitz GmbH (Sellin, HRB 5368) umfirmiert. Nicht als aktiven Eintrag anlegen. Ihre früheren Adressen (Ringstraße 113–115, Bahnhofstraße 15, Circus 16 Putbus) sind historische Phasen derselben Gesellschaft.
- **Infopoint Sellin** hat zwei E-Mails → ein Datensatz mit `email_1` und `email_2`.
- **K57** (Personenkontakt, Chat) bleibt eigenständig, mit unverifiziertem Prüfverweis auf `KV24` Zimmervermittlung Rügen. Kein Merge, kein Typwechsel.
- **K34** (Tourismus-Service Rügen) bleibt ohne Zuordnung. Keine Organisation passt belegt.
## 4. Termine — Ground Truth
- **54 Quellzeilen, 60 Zeitfenster.** Vollständig, von der offiziellen Sündenfrei-Website.
- **2026:** 9 Quellzeilen / **12** Zeitfenster (8 andere + 4 Herne-Wochenenden). Sichtbare Listenzeilen: 13 = 9 Haupteinträge + 4 Advents-Unterzeilen.
- **2027:** 45 Quellzeilen / **48** Zeitfenster (44 Einzeiler + 4 Herne-Wochenenden).
- **Herne-Advent bleibt eine Quellzeile mit vier Zeitfenstern.** Keine Aufteilung in eigene Termine — das würde das Datenmodell von 54 auf 58 Zeilen ändern.
- **Sternchen** (`*`/`**`) bedeuten: Termin oder Ort wahrscheinlich, noch unbestätigt. Sie sind Qualitätsmarker, keine Formatierung.
- **Die alte App hatte nur 14 dieser 54 Termine erfasst.** Das ist ein Befund über den Altbestand, keine Lücke in dieser Liste. Diese Liste wird vollständig übernommen.
## 5. Beschlüsse
Alle in `beschlussverzeichnis.csv`, je mit Prio-1-Basis, Prio-2-Ergänzung, Maßnahme und Status (`entschieden` oder `provisorisch`).
Kurz: Putbus dreifach geteilt · Markt 25 dreifach geteilt · TZR nur als Historie · K57 eigenständig · K09 (Middelhagen) mit KV12-Werten angereichert · Termine vollständig übernehmen · Archiv A unangetastet lassen (Option a).
## 6. Was NICHT in diesem Paket ist
Diese Punkte sind bewusst nicht enthalten. Sie sind **nicht erledigt**, nur ausdrücklich ausgeschlossen:
1. **41 weitere Befund-IDs** aus `werkstatt/03-berichte/abgleich-01-entscheidungen.csv`. Variante A hat **65** nummerierte Befunde; dieses Paket behandelt die Kontakt- und Termin-Hauptfälle plus zwei Integritätsbefunde. Der Rest wurde nicht gelesen und nicht entschieden.
2. **Flyer-/Bild-Audit** (79 tote Bildlinks ↔ 158 JPGs im Chat-Export). Zahlen stammen aus Variante B und wurden **nie nachgezählt**. Geparkt.
3. **Die ZIPs `var a2` und `var b2`** (je 399 kB / 463 kB, im Repo vorhanden). Bewusst **nicht** geprüft, um keine zweite A/B-Gabelung zu erzeugen.
4. **Archiv-Reparaturen.** Im A-ZIP fehlen 6 im Manifest gelistete Dateien; 8 CSVs weichen byteweise ab, weil das UTF-8-BOM fehlt. Nur dokumentiert, nichts repariert.
5. **Datenbank.** Unverändert, **0 Tabellen**, kein Import, kein Schema angefasst. Stufe 5 (Importieren) wurde nicht begonnen.
## 7. Nächster einzelner Schritt
**Genau einer, in dieser Reihenfolge:**
1. Prüfsummen erzeugen (optional, siehe unten).
2. ZIP packen — die Arena-Oberfläche kann das.
3. Neuen Chat im Single-Mode starten und **diese HANDOFF.md als erste Datei** übergeben.
4. Dort: Stufe 5 (Import) vorbereiten — **nicht** ausführen, bevor das Schema steht.
## 8. Prüfsummen (optional)
Nach dem Zusammenbau im Projektstamm ausführen:
```bash
sha256sum export/arbeitsstand-kontakte.csv \
          export/arbeitsstand-termine.csv \
          export/beschlussverzeichnis.csv \
          export/HANDOFF.md > export/PRUEFSUMMEN.sha256
sha256sum -c export/PRUEFSUMMEN.sha256
```
## 9. Datenschutz-Hinweis
Dieses Paket enthält Personennamen und persönliche E-Mail-Adressen (u. a. Mitarbeiterkontakte, K57). Es ist **für den internen Bandgebrauch** bestimmt. Keine Veröffentlichung, kein Upload an öffentlicher Stelle, keine Weitergabe outside des Teams. Eine Ausblend-Ansicht im Dashboard ist **keine Zugriffskontrolle** — die Werte bleiben im Bundle enthalten.
---
*Ende des Übergabeprotokolls.*
