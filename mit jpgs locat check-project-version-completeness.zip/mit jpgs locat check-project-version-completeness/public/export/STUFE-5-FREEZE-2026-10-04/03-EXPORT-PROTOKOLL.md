# EXPORT-PROTOKOLL · Stufe-5-Freeze

**Exportstand:** 2026-10-04  
**Zweck:** Projektübergabe aus Arena in einen neuen Chat im Direct Mode  
**Status:** eingefroren; keine offene Entscheidung ausgeführt

## 1. Was in der Arena-GUI zu exportieren ist

Bitte das **gesamte Projekt als ZIP** exportieren, nicht nur diesen Ordner. Nur der vollständige Projektexport enthält:

- Next.js-Anwendung und UI
- Drizzle-Schema `src/db/schema.ts`
- prüfsummengeprüften Import `src/db/seed.ts`
- unverändertes Stufe-4-Freeze unter `public/export/FREEZE/`
- dieses Direct-Mode-Handoff unter `public/export/STUFE-5-FREEZE-2026-10-04/`

Die laufende PostgreSQL-Datenbank ist nicht als Binärdump nötig. Sie ist aus dem Freeze deterministisch wiederherstellbar.

## 2. Im neuen Chat zuerst übergeben

1. Projekt-ZIP hochladen.
2. Als erste Arbeitsanweisung auf diese Datei verweisen:
   `public/export/STUFE-5-FREEZE-2026-10-04/00-HANDOFF-DIRECT-MODE.md`
3. Optional den Inhalt von `04-STARTPROMPT-DIRECT-MODE.txt` in die erste Nachricht kopieren.
4. Noch keine offene Befund-ID zur Bearbeitung freigeben, wenn nur der Stand geprüft werden soll.

## 3. Enthaltene Exportdateien

| Datei | Zweck |
|---|---|
| `00-HANDOFF-DIRECT-MODE.md` | Verbindlicher Startpunkt für den neuen Chat |
| `01-OFFENE-PUNKTE.csv` | 13 später manuell zu entscheidende Befunde mit Originalbeleg und Aktion |
| `02-BEFUND-ABGRENZUNG-65.csv` | Audit aller 65 Befunde: 52 abgedeckt, 13 offen |
| `03-EXPORT-PROTOKOLL.md` | Dieses Protokoll |
| `04-STARTPROMPT-DIRECT-MODE.txt` | Kurze, kopierbare Startanweisung |
| `PRUEFSUMMEN.sha256` | Integritätsmanifest dieses Exportordners |

CSV-Format: UTF-8 mit BOM, Semikolon als Trennzeichen, alle Felder in Anführungszeichen, CRLF-Zeilenenden. Das ist beabsichtigt und erleichtert die manuelle Bearbeitung in Excel/LibreOffice.

## 4. Datenbankstand beim Export

**Importlauf:** `b7d22ca1-b43f-400d-a2fb-bc031ebb0062`  
**Importiert:** 2026-10-04 11:35:32 UTC  
**Protokolleinträge:** 3

| Tabelle | Zeilen |
|---|---:|
| `regionen` | 9 |
| `kontakte` | 35 |
| `termine` | 54 |
| `termin_zeitfenster` | 60 |
| `beschluesse` | 20 |
| `import_protokoll` | 3 |

Ground Truth Termine:

- 2026: 9 Quellzeilen / 12 Zeitfenster
- 2027: 45 Quellzeilen / 48 Zeitfenster
- Gesamt: 54 Quellzeilen / 60 Zeitfenster

## 5. Integrität des ursprünglichen Stufe-4-Freeze

Beim Export erneut geprüft:

```text
HANDOFF.md: OK
arbeitsstand-kontakte.csv: OK
arbeitsstand-termine.csv: OK
beschlussverzeichnis.csv: OK
```

Verbindliche Hashes:

```text
ec1bc5f64bc92ae75ac1f99365af19fb68ba82f80f3334e5347fbe043a63a7cb  HANDOFF.md
443c06f424edcf887ca97bc24002ea501040493eace910801d6a45d267816e21  arbeitsstand-kontakte.csv
4099626f8d42291d2155790a2cb7fa246e2301ef9fe5ac49cd6cab73ff2d5cda  arbeitsstand-termine.csv
247b4d699183c9efcd2259092f088e63875ff65abc3729746df71281a2b1ac23  beschlussverzeichnis.csv
```

## 6. Herkunft der 65 Befunde

Quelle im Repository:

```text
stufe 3 a! compare-apps-and-data-consistency.zip
└── werkstatt/03-berichte/abgleich-01-entscheidungen.csv
```

- Berichtsversion: `abgleich-01-v1`
- Datei-/ZIP-Zeitstempel: 2026-10-01 21:07
- Repo-Upload der Variante-A-Datei: 2026-10-01 21:37:26Z
- Umfang: 65 Befunde, im Original alle `entscheidung=offen`

Bekannter Archivbefund: Vier CSVs der Variante A wurden ohne das vom Manifest erwartete UTF-8-BOM verpackt. Für `abgleich-01-entscheidungen.csv` ist der extrahierte Hash `aa3db9b7353afca8dd14024f98d8d71e6e892d1016e4c92d387ea9bbb1c12603`; mit vorangestelltem BOM entspricht sie dem Manifest-Hash `57072af834996a3d9b294e0a9bf90b2ecb6e3fbab6eda7c13dc3992431d09a1c`. Keine Reparatur am Archiv wurde ausgeführt.

## 7. Triage-Ergebnis

- 42 Termin-Lücken: bulk-abgedeckt durch B-09/B-12
- 9 Befunde: abgedeckt durch bestehende Beschlüsse
- 1 Befund (`K-08`): durch das Stufe-5-Schema umgesetzt
- 13 Befunde: offen für spätere manuelle Einzelentscheidung

Die 13 offenen Zeilen sind kein Änderungsauftrag. Sie sind eine Warteschlange. Vor einer Änderung muss ein neuer, freigegebener Beschluss ab `B-21` entstehen.

## 8. Wiederanlauf im neuen Projekt

```bash
# Abhängigkeiten / Build werden durch Arena vorbereitet.
# Danach Schema und Datenbestand herstellen:
npx drizzle-kit push --force
npx tsx src/db/seed.ts

# Export-Handoff verifizieren:
cd public/export/STUFE-5-FREEZE-2026-10-04
sha256sum -c PRUEFSUMMEN.sha256

# Ursprüngliches Freeze verifizieren:
cd ../FREEZE
sha256sum -c PRUEFSUMMEN.sha256
```

Danach Anwendung starten und `/api/import/verify` prüfen. Erwartet wird `ok: true`.

## 9. Prüfstatus des Projekts beim Freeze

- Next.js Typegen: bestanden
- TypeScript `tsc --noEmit`: bestanden
- Next.js Production Build: bestanden
- Production Start / `/api/health`: bestanden
- `/api/import/verify`: Freeze und Datenbank vollständig konsistent

Nach dem Hinzufügen dieses Exportpakets wird die vollständige Validierungsfolge erneut ausgeführt und im Abschluss bestätigt.

## 10. Datenschutz

Das gesamte Projekt-ZIP enthält persönliche E-Mail-Adressen und weitere Kontaktdaten. Nur intern weitergeben. Nicht in ein öffentliches Repository, einen öffentlichen Chat oder einen frei zugänglichen Dateidienst hochladen. Eine ausgeblendete Dashboard-Ansicht ist keine Zugriffskontrolle.
