# Stufe 3 · Abgleich 01

Berichtsversion: abgleich-01-v1.
Der Bericht vergleicht den unveränderten App-ZIP-Bestand mit den normierten Referenzen und expliziten Nutzerergänzungen.
Keine Quelle, keine CSV-Normierung und keine Datenbank wurde dadurch verändert. Keine Zusammenführung, Löschung oder Stufe-4-Entscheidung ist ausgeführt.

## Dateien

- abgleich-01.md: vollständiger lesbarer Bericht mit allen Kandidaten, Feldvergleichen und Entscheidungspunkten.
- abgleich-01.json: dieselben Prüfergebnisse für die lesende Option-A-Oberfläche.
- abgleich-01-kontakte.csv: 32 Referenzeinrichtungen mit Status, Kandidaten und Fundstelle.
- abgleich-01-termine.csv: 54 Terminzeilen mit Fensterliste, Quellstatus und Abgleichstatus.
- abgleich-01-feldvergleich.csv: jedes geprüfte Kandidatenfeld, Original/Ergänzung/Bestand und Herkunft.
- abgleich-01-entscheidungen.csv: nummerierte Fragen für Stufe 4, überall Entscheidung=offen.
- abgleich-01.pruefsummen.sha256: Prüfsummen der Berichte einschließlich dieser Erläuterung.

## Ausführen

node scripts/build-comparison.mjs        # nur Berichte erzeugen
node scripts/build-comparison.mjs --verify # nur vorhandene Berichte prüfen

## Grenzen

Datum+Ort ist eine konkrete Werteübereinstimmung, kein automatischer Identitätsnachweis. Name, PLZ, Quelltyp, unsichere Marker und Institutionsbeziehungen bleiben gesonderte Fragen.
Gleiche E-Mail kann mehrere Einrichtungen bedienen. Namenskandidaten sind nur wörtliche/normalisierte Wortfolgen, keine semantische Interpretation. Nicht zugeordneter Bestand ist nicht automatisch ungültig oder zum Löschen bestimmt.
Kein privates Chatarchiv wurde neu geöffnet. Bericht enthält Organisationsreferenz-Kanäle, aber Personennamen/-kanäle des Bestands sind ausgeblendet. Der interne App-ZIP-Bestand liegt außerhalb public/ und wird nicht als Berichtdownload geliefert.
Die bereits bestätigten Quellen und Nutzerangaben werden separat behandelt; eine Nutzerangabe ist keine unabhängig extern verifizierte Information.
Frühere Handoff-Zählung „46 von 54 fehlen“ ist methodisch nicht belastbar, weil Eventdatensätze und Terminzeilen verschiedene Ebenen sind. Der vorliegende Bericht zählt Quellzeilen/Fenster, nicht bloß Eventnamen.

## Nächster Schritt

Stufe 4: anhand der Befund-IDs Punkt für Punkt entscheiden. Das Ausfüllen einer Entscheidung wird nicht automatisch importiert. Stufe 5 bleibt gesondert freigabepflichtig.
