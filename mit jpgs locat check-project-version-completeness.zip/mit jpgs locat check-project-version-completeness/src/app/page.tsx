import Link from "next/link";
import {
  Archive,
  ArrowRight,
  ArrowUpRight,
  CalendarDays,
  CheckCircle2,
  CircleDashed,
  FileSpreadsheet,
  Gavel,
  MapPinned,
} from "lucide-react";
import { getBeschlussStats, getDbCounts, getLetzterImportLauf, fmtZeitstempel } from "@/lib/data";
import { VerifyWidget } from "@/components/verify-widget";
import { Badge, Card, Eyebrow, SectionHead } from "@/components/ui";

export const dynamic = "force-dynamic";

const STUFEN = [
  { nr: 1, titel: "Erfassen", notiz: "Chat-Export, App-Altbestand, MD" },
  { nr: 2, titel: "Abgleichen", notiz: "65 Befunde, Variante A/B" },
  { nr: 3, titel: "Entscheiden", notiz: "20 Beschlüsse, Prio 1 vor Prio 2" },
  { nr: 4, titel: "Einfrieren", notiz: "Freeze 2026-10-01, sha256-Manifest" },
  { nr: 5, titel: "Importieren", notiz: "Schema, Integritäts-Gate, Datenbank" },
];

const AUSGESCHLOSSEN = [
  {
    id: "§6.1",
    titel: "41 weitere Befund-IDs",
    text: "Variante A zählt 65 nummerierte Befunde. Dieses Paket entscheidet die Hauptfälle; der Rest ist weder gelesen noch entschieden.",
  },
  {
    id: "§6.2",
    titel: "Flyer-/Bild-Audit",
    text: "79 tote Bildlinks ↔ 158 JPGs — Zahlen aus Variante B, nie nachgezählt. Geparkt.",
  },
  {
    id: "§6.3",
    titel: "ZIPs var a2 / var b2",
    text: "Bewusst nicht geöffnet, um keine zweite A/B-Gabelung zu erzeugen.",
  },
  {
    id: "§6.4",
    titel: "Archiv-Reparaturen",
    text: "6 fehlende Manifest-Dateien, 8 CSVs ohne UTF-8-BOM — dokumentiert, nichts repariert (B-13, Option a).",
  },
  {
    id: "§6.5",
    titel: "Datenbank (Stand Stufe 4)",
    text: "War bei Übergabe unverändert: 0 Tabellen (B-20). Stufe 5 setzt genau hier an — und ist jetzt abgeschlossen.",
  },
];

export default async function UebersichtPage() {
  const [counts, lauf, bStats] = await Promise.all([
    getDbCounts(),
    getLetzterImportLauf(),
    getBeschlussStats(),
  ]);

  const kpis = [
    { label: "Einrichtungen", wert: counts.kontakte, sub: "34 KV-nummeriert + 1 Sonderdatensatz", href: "/kontakte" },
    { label: "Regionen", wert: counts.regionen, sub: "Hierarchie: Region → Ort → Einrichtung", href: "/kontakte" },
    { label: "Termin-Quellzeilen", wert: counts.termine, sub: "2026: 9 · 2027: 45", href: "/termine" },
    { label: "Zeitfenster", wert: counts.zeitfenster, sub: "2026: 12 · 2027: 48", href: "/termine" },
    { label: "Beschlüsse", wert: counts.beschluesse, sub: `${bStats.entschieden} entschieden · ${bStats.provisorisch} provisorisch`, href: "/beschluesse" },
  ];

  return (
    <div className="space-y-16">
      {/* Hero ------------------------------------------------------ */}
      <section className="rise pt-4">
        <Eyebrow>SPP7-Kontakte · Werkstatt abgeschlossen</Eyebrow>
        <div className="mt-4 grid gap-8 lg:grid-cols-[1.5fr_1fr] lg:items-end">
          <h1 className="font-display text-[clamp(2.6rem,6.4vw,4.9rem)] font-medium leading-[0.98] tracking-tight text-ink">
            Aus dem Freeze wird
            <span className="text-lime"> eine Datenbank.</span>
          </h1>
          <div className="space-y-4 lg:pb-2">
            <p className="max-w-md text-[15px] leading-relaxed text-ink-soft">
              Stufe 5 ist umgesetzt: Das Übergabepaket vom 2026-10-01 wurde
              gegen sein sha256-Manifest verifiziert und vollständig in
              PostgreSQL importiert. Diese Ansichten lesen ausschließlich aus
              der Datenbank — das Paket selbst bleibt byteidentisch
              unangetastet.
            </p>
            <div className="flex flex-wrap items-center gap-2">
              <Badge tone="lime">
                <CheckCircle2 className="h-3 w-3" />
                Import abgeschlossen
              </Badge>
              {lauf ? (
                <Badge>Letzter Lauf · {fmtZeitstempel(lauf.importiertAm)}</Badge>
              ) : null}
              <Badge tone="amber">Intern (B-17)</Badge>
            </div>
          </div>
        </div>
      </section>

      {/* KPI-Band --------------------------------------------------- */}
      <section className="rise grid grid-cols-2 gap-px overflow-hidden rounded-xl border border-line bg-line md:grid-cols-5" style={{ animationDelay: "80ms" }}>
        {kpis.map((k) => (
          <Link
            key={k.label}
            href={k.href}
            className="group bg-raised/90 p-5 transition-colors hover:bg-raised2"
          >
            <p className="font-mono text-[10px] uppercase tracking-[0.18em] text-muted">
              {k.label}
            </p>
            <p className="tnum mt-2 flex items-baseline gap-2 text-[clamp(2rem,3.4vw,2.9rem)] font-medium leading-none text-ink">
              {k.wert}
              <ArrowUpRight className="h-4 w-4 text-lime opacity-0 transition-all group-hover:translate-x-0.5 group-hover:opacity-100" />
            </p>
            <p className="mt-2 text-[11.5px] leading-snug text-muted">{k.sub}</p>
          </Link>
        ))}
      </section>

      {/* Pipeline --------------------------------------------------- */}
      <section className="rise" style={{ animationDelay: "140ms" }}>
        <SectionHead
          eyebrow="Die fünf Stufen der Werkstatt"
          title={
            <>
              Vier waren erledigt. <em className="text-lime not-italic">Stufe 5 fehlte.</em>
            </>
          }
          right={<Badge tone="lime">5 / 5 abgeschlossen</Badge>}
        />
        <ol className="grid gap-3 md:grid-cols-5">
          {STUFEN.map((s, i) => (
            <li key={s.nr}>
              <Card lift className="relative h-full overflow-hidden p-4">
                <div
                  className="tick-in absolute inset-x-0 top-0 h-[2px] bg-lime/70"
                  style={{ animationDelay: `${300 + i * 120}ms` }}
                />
                <div className="flex items-center justify-between">
                  <span className="font-mono text-[10px] uppercase tracking-[0.18em] text-muted">
                    Stufe {s.nr}
                  </span>
                  {i < 4 ? (
                    <CheckCircle2 className="h-3.5 w-3.5 text-lime/60" />
                  ) : (
                    <CheckCircle2 className="h-3.5 w-3.5 text-lime" />
                  )}
                </div>
                <p className="font-display mt-3 text-[19px] font-medium text-ink">
                  {s.titel}
                </p>
                <p className="mt-1 text-[12px] leading-snug text-muted">
                  {s.notiz}
                </p>
                {i === 4 ? (
                  <p className="mt-3 font-mono text-[10px] uppercase tracking-[0.12em] text-lime">
                    ← dieser Chat
                  </p>
                ) : null}
              </Card>
            </li>
          ))}
        </ol>
      </section>

      {/* Verifikation + Ausschlüsse -------------------------------- */}
      <section className="rise grid gap-6 lg:grid-cols-2" style={{ animationDelay: "200ms" }}>
        <div>
          <SectionHead eyebrow="Integrität" title="Verifiziert, nicht vertraut." />
          <VerifyWidget />
          <p className="mt-3 text-[12px] leading-relaxed text-muted">
            Live-Abfrage gegen <code className="font-mono text-[11px] text-ink-soft">/api/import/verify</code>:
            sha256 der vier Freeze-Dateien und der Ist-Bestand aller Tabellen
            gegen die Ground-Truth-Zahlen (35 · 9 · 54 · 60 · 20).
          </p>
        </div>
        <div>
          <SectionHead
            eyebrow="Handoff §6"
            title="Bewusst ausgeschlossen — nicht erledigt."
            right={<CircleDashed className="h-4 w-4 text-amber" />}
          />
          <ul className="space-y-2">
            {AUSGESCHLOSSEN.map((a) => (
              <li
                key={a.id}
                className="flex gap-3 rounded-lg border border-line bg-raised/60 px-3.5 py-2.5"
              >
                <span className="mt-0.5 shrink-0 font-mono text-[10px] font-semibold uppercase tracking-[0.1em] text-amber">
                  {a.id}
                </span>
                <span className="min-w-0">
                  <span className="block text-[13px] font-medium text-ink">
                    {a.titel}
                  </span>
                  <span className="mt-0.5 block text-[12px] leading-snug text-muted">
                    {a.text}
                  </span>
                </span>
              </li>
            ))}
          </ul>
        </div>
      </section>

      {/* Bereiche --------------------------------------------------- */}
      <section className="rise" style={{ animationDelay: "260ms" }}>
        <SectionHead eyebrow="Bestände" title="Drei Register, ein Protokoll." />
        <div className="grid gap-4 md:grid-cols-2 xl:grid-cols-4">
          {[
            {
              href: "/kontakte",
              icon: MapPinned,
              titel: "Kontakte",
              text: "35 Datensätze in 9 Regionen — Verband, Kurverwaltung, Verein und Rathaus sauber getrennt.",
              meta: "Region → Ort → Einrichtung",
            },
            {
              href: "/termine",
              icon: CalendarDays,
              titel: "Termine",
              text: "Sündenfrei 2026/2027 vollständig: 54 Quellzeilen, 60 Zeitfenster, Sternchen als Qualitätsmarker.",
              meta: "Herne-Advent = 1 Zeile, 4 Fenster",
            },
            {
              href: "/beschluesse",
              icon: Gavel,
              titel: "Beschlüsse",
              text: "Das komplette Verzeichnis: Prio-1-Basis, Prio-2-Ergänzung, Maßnahme und Status je Beschluss.",
              meta: "17 entschieden · 3 provisorisch",
            },
            {
              href: "/stufe-5",
              icon: FileSpreadsheet,
              titel: "Stufe 5 · Protokoll",
              text: "Import-Protokoll mit Lauf-ID und Hashes, Tabellenübersicht, Wiederholbarkeit und Export-Downloads.",
              meta: "Audit-Trail in der Datenbank",
            },
          ].map((c) => (
            <Link key={c.href} href={c.href} className="group">
              <Card lift className="flex h-full flex-col p-5">
                <c.icon className="h-5 w-5 text-lime" strokeWidth={1.8} />
                <p className="font-display mt-4 text-[21px] font-medium text-ink">
                  {c.titel}
                </p>
                <p className="mt-2 flex-1 text-[13px] leading-relaxed text-muted">
                  {c.text}
                </p>
                <p className="mt-4 flex items-center justify-between border-t border-line-soft pt-3 font-mono text-[10px] uppercase tracking-[0.12em] text-ink-soft">
                  {c.meta}
                  <ArrowRight className="h-3.5 w-3.5 text-lime transition-transform group-hover:translate-x-1" />
                </p>
              </Card>
            </Link>
          ))}
        </div>
        <p className="mt-6 flex items-center gap-2 text-[12px] text-muted">
          <Archive className="h-3.5 w-3.5" />
          Archiv A bleibt unangetastet (B-13). Kein Neuverpacken ohne ausdrückliche Freigabe.
        </p>
      </section>
    </div>
  );
}
