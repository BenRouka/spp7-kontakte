"use client";

import {
  Activity,
  ArrowDownToLine,
  ArrowRight,
  CalendarDays,
  Check,
  ChevronDown,
  CircleDot,
  Clock3,
  ContactRound,
  Database,
  ExternalLink,
  FileText,
  Filter,
  GitBranch,
  LayoutDashboard,
  Link2,
  Map,
  MapPin,
  Menu,
  PanelLeftClose,
  Radio,
  Search,
  Sparkles,
  Table2,
  Tag,
  UsersRound,
  X,
  Zap,
} from "lucide-react";
import { useEffect, useMemo, useState } from "react";
import type { Spp7Overview } from "@/lib/spp7-repository";

type DataRow = Record<string, string>;
type DatasetKey =
  | "events"
  | "event_dates"
  | "event_acts"
  | "acts"
  | "event_partners"
  | "partners"
  | "event_features"
  | "event_channels"
  | "event_tags"
  | "timetable"
  | "feed_context"
  | "contacts"
  | "chat_items"
  | "flyer_sources";
type ViewKey = "overview" | "model" | "opportunities" | "contacts";
type ArchivePayload = {
  meta: { flyers: number; flyersCaptured: number; chatMessages: number };
  datasets: Record<DatasetKey, DataRow[]>;
};

type DatasetDefinition = {
  key: DatasetKey;
  label: string;
  description: string;
};

const DATASETS: DatasetDefinition[] = [
  { key: "events", label: "Events", description: "Parent-Datensätze für Festivals, Locations und Tourstopps" },
  { key: "event_dates", label: "Termine", description: "Spieltermine, Fristen und Veröffentlichungsdaten" },
  { key: "event_acts", label: "Event × Acts", description: "Verknüpfungen zwischen Events und auftretenden Acts" },
  { key: "acts", label: "Acts", description: "Konsolidierte Künstler und Namensvarianten" },
  { key: "event_partners", label: "Event × Partner", description: "Partner- und Sponsoring-Beziehungen" },
  { key: "partners", label: "Partner", description: "Konsolidierte Veranstalter, Partner und Sponsoren" },
  { key: "event_features", label: "Features", description: "Besondere Merkmale und Angebotsbausteine" },
  { key: "event_channels", label: "Kanäle", description: "Websites, Social Media und Kontaktkanäle" },
  { key: "event_tags", label: "Tags", description: "Normalisierte Themen- und Genre-Schlagwörter" },
  { key: "timetable", label: "Timetable", description: "Programm- und Slotinformationen" },
  { key: "feed_context", label: "Feed-Kontext", description: "Kontext aus Social-Media-Quellen" },
  { key: "contacts", label: "Kontakte", description: "Organisationen und direkte Kontaktmöglichkeiten" },
  { key: "chat_items", label: "Chat-Items", description: "Strukturierte Fundstücke aus Chat-Nachrichten" },
  { key: "flyer_sources", label: "Flyer-Quellen", description: "Einzelne Originalbilder mit Verknüpfung oder OCR-Prüfstatus" },
];

const viewTitles: Record<ViewKey, { eyebrow: string; title: string }> = {
  overview: { eyebrow: "Workspace", title: "Tour Intelligence" },
  model: { eyebrow: "Datensatz", title: "Events · Termine" },
  opportunities: { eyebrow: "Booking", title: "Opportunities" },
  contacts: { eyebrow: "Outreach", title: "Kontakte" },
};

function DottedModelTitle() {
  return (
    <span className="dotted-phrase">
      Events<span className="dotted-sep">·</span>Termine
    </span>
  );
}

const preferredColumns: Partial<Record<DatasetKey, string[]>> = {
  events: ["EVENT_ID", "QUELLE_TYP", "TYP", "NAME", "ORT", "REGION", "BEWERBUNG", "BEWERBUNG_STATUS", "KI_RANG", "PASSUNG_SPP7", "TAGS"],
  event_dates: ["DATE_ID", "EVENT_ID", "EVENT_NAME", "VON", "BIS", "ART", "KOMMENTAR"],
  event_acts: ["LINK_ID", "EVENT_ID", "EVENT_NAME", "ACT_NAME", "ROLLE", "SLOT_TAG", "UNSICHER"],
  acts: ["ACT_ID", "ACT_NAME", "ANZAHL_EVENTS", "ROLLEN", "EVENTS"],
  contacts: ["CONTACT_ID", "ORGANISATION", "TYP", "EMAIL_TELEFON", "ORT", "REGION", "NOTIZ"],
  flyer_sources: ["FLYER", "SOURCE_DATE", "SOURCE_STATUS", "SOURCE_KIND", "EVENT_ID", "NAME", "LOCATION", "DATE_TEXT", "FREE_SLOTS", "ACTS_SOUGHT", "GENRES", "FEE", "COSTS", "APPLICATION_STATUS", "REVIEW_STATUS"],
};

function formatColumn(column: string) {
  const labels: Record<string, string> = {
    EVENT_ID: "Event ID",
    QUELLE_TYP: "Quelle",
    EVENT_NAME: "Event",
    ACT_NAME: "Act",
    CONTACT_ID: "Kontakt ID",
    PASSUNG_SPP7: "Passung SPP7",
    EMAIL_TELEFON: "E-Mail / Telefon",
    VON_ISO: "Von (ISO)",
    BIS_ISO: "Bis (ISO)",
    SOURCE_STATUS: "Zuordnung",
    SOURCE_KIND: "Quellentyp",
    SOURCE_FILE: "Originaldatei",
    SOURCE_DATE: "Quellenstand",
    THUMB_URL: "Thumbnail",
    PERFORMANCE: "Performance",
    PROVIDER: "Anbieter",
    DATE_TEXT: "Datum / Zeitraum",
    FREE_SLOTS: "Freie Slots",
    ACTS_SOUGHT: "Gesuchte Acts",
    GENRES: "Genre",
    EXCLUDED_GENRES: "Ausgeschlossene Genres",
    FEE: "Gage",
    COSTS: "Kosten",
    POSTED: "Gepostet",
    APPLICATION_STATUS: "Bewerbungsstatus",
    STATUS_BASIS: "Statusgrundlage",
    REVIEW_STATUS: "Prüfstatus",
    OCR_CONFIDENCE: "OCR-Konfidenz",
    OCR_TEXT: "OCR-Rohtext",
  };
  return labels[column] ?? column.replaceAll("_", " ");
}

function isIdColumn(column: string) {
  return column.endsWith("_ID") || column === "MSG";
}

function flyerThumbSrc(row: DataRow) {
  const flyer = row.FLYER?.trim();
  if (!flyer || !row.QUELLE_TYP?.startsWith("Flyer")) return null;
  const num = flyer.padStart(2, "0");
  return `/flyers/flyer_${num}_thumb.jpg`;
}

function tokenize(value: string) {
  return value.split(/[;|]/).map((token) => token.trim()).filter(Boolean);
}

function humanNumber(value: number) {
  return new Intl.NumberFormat("de-DE").format(value);
}

function initials(name: string) {
  return name
    .split(/\s+/)
    .slice(0, 2)
    .map((part) => part[0])
    .join("")
    .toUpperCase();
}

function downloadRows(rows: DataRow[], name: string) {
  if (!rows.length) return;
  const columns = Object.keys(rows[0]);
  const escape = (value: string) => `"${String(value ?? "").replaceAll('"', '""')}"`;
  const csv = [columns.join(";"), ...rows.map((row) => columns.map((column) => escape(row[column])).join(";"))].join("\n");
  const url = URL.createObjectURL(new Blob([`\uFEFF${csv}`], { type: "text/csv;charset=utf-8" }));
  const anchor = document.createElement("a");
  anchor.href = url;
  anchor.download = `spp7-${name}.csv`;
  anchor.click();
  URL.revokeObjectURL(url);
}

function DatasetIcon({ dataset }: { dataset: DatasetKey }) {
  const className = "size-4";
  if (dataset.includes("date") || dataset === "timetable") return <CalendarDays className={className} />;
  if (dataset.includes("act")) return <Radio className={className} />;
  if (dataset.includes("partner")) return <UsersRound className={className} />;
  if (dataset === "contacts") return <ContactRound className={className} />;
  if (dataset.includes("channel")) return <Link2 className={className} />;
  if (dataset.includes("tag") || dataset.includes("feature")) return <Tag className={className} />;
  if (dataset === "chat_items" || dataset === "feed_context") return <FileText className={className} />;
  return <Database className={className} />;
}

function LoadingState() {
  return (
    <div className="loading-grid" aria-label="Daten werden geladen">
      {Array.from({ length: 4 }).map((_, index) => <div className="skeleton-card" key={index} />)}
      <div className="skeleton-card skeleton-wide" />
      <div className="skeleton-card skeleton-tall" />
    </div>
  );
}

export function Spp7Dashboard({ overview }: { overview: Spp7Overview }) {
  const [payload, setPayload] = useState<ArchivePayload | null>(null);
  const [view, setView] = useState<ViewKey>("overview");
  const [dataset, setDataset] = useState<DatasetKey>("events");
  const [search, setSearch] = useState("");
  const [source, setSource] = useState("Alle Quellen");
  const [page, setPage] = useState(1);
  const [selected, setSelected] = useState<{ dataset: DatasetKey; row: DataRow } | null>(null);
  const [mobileNav, setMobileNav] = useState(false);
  const [compactNav, setCompactNav] = useState(false);

  useEffect(() => {
    fetch("/data/spp7-datasets.json")
      .then((response) => {
        if (!response.ok) throw new Error("Datensatz konnte nicht geladen werden");
        return response.json() as Promise<ArchivePayload>;
      })
      .then(setPayload)
      .catch(() => setPayload(null));
  }, []);

  const rows = useMemo(() => payload?.datasets[dataset] ?? [], [dataset, payload]);
  const filteredRows = useMemo(() => {
    const query = search.trim().toLocaleLowerCase("de");
    return rows.filter((row) => {
      const matchesQuery = !query || Object.values(row).some((value) => value.toLocaleLowerCase("de").includes(query));
      const matchesSource = dataset !== "events" || source === "Alle Quellen" || row.QUELLE_TYP === source;
      return matchesQuery && matchesSource;
    });
  }, [dataset, rows, search, source]);
  const pageSize = 20;
  const pageCount = Math.max(1, Math.ceil(filteredRows.length / pageSize));
  const pagedRows = filteredRows.slice((page - 1) * pageSize, page * pageSize);
  const columns = useMemo(() => {
    if (!rows[0]) return [];
    return preferredColumns[dataset] ?? Object.keys(rows[0]);
  }, [dataset, rows]);
  const sourceOptions = useMemo(
    () => ["Alle Quellen", ...Array.from(new Set((payload?.datasets.events ?? []).map((row) => row.QUELLE_TYP).filter(Boolean)))],
    [payload],
  );

  function openDataset(nextDataset: DatasetKey) {
    setDataset(nextDataset);
    setView("model");
    setSearch("");
    setSource("Alle Quellen");
    setPage(1);
    setMobileNav(false);
  }

  function changeView(nextView: ViewKey) {
    setView(nextView);
    setSearch("");
    setMobileNav(false);
  }

  const navItems: Array<{ key: ViewKey; label: string; icon: typeof LayoutDashboard; count?: number }> = [
    { key: "overview", label: "Übersicht", icon: LayoutDashboard },
    { key: "model", label: "Events · Termine", icon: GitBranch, count: overview.eventCount },
    { key: "opportunities", label: "Opportunities", icon: Sparkles, count: overview.openApplicationCount },
    { key: "contacts", label: "Kontakte", icon: ContactRound, count: overview.contactCount },
  ];

  const currentTitle = viewTitles[view];

  return (
    <div className={`app-shell ${compactNav ? "nav-compact" : ""}`}>
      {mobileNav && <button className="nav-scrim" aria-label="Navigation schließen" onClick={() => setMobileNav(false)} />}
      <aside className={`side-nav ${mobileNav ? "is-open" : ""}`}>
        <div className="brand-row">
          <button className="brand" onClick={() => changeView("overview")} aria-label="SPP7 Übersicht">
            {/* eslint-disable-next-line @next/next/no-img-element */}
            <img className="brand-logo" src="/spp7-logo.png" alt="SPP7 Logo" />
            <span className="brand-copy"><strong>SPP7</strong><small>Tour Intelligence</small></span>
          </button>
          <button className="icon-button collapse-button" onClick={() => setCompactNav((value) => !value)} aria-label="Navigation einklappen">
            <PanelLeftClose className="size-4" />
          </button>
        </div>

        <nav className="main-nav" aria-label="Hauptnavigation">
          <p className="nav-label">Workspace</p>
          {navItems.map((item) => {
            const Icon = item.icon;
            const isModel = item.key === "model";
            return (
              <button
                key={item.key}
                className={view === item.key ? "active" : ""}
                onClick={() => changeView(item.key)}
                title={item.label}
              >
                <Icon className="size-[18px]" />
                <span>{isModel ? <DottedModelTitle /> : item.label}</span>
                {item.count !== undefined && <small>{item.count}</small>}
              </button>
            );
          })}
          <p className="nav-label nav-label-spaced">Datenquellen</p>
          <button className={view === "model" && dataset === "events" ? "sub-active" : ""} onClick={() => openDataset("events")} title="Events">
            <CircleDot className="size-[18px]" /><span>Events</span><small>{payload?.datasets.events.length ?? 154}</small>
          </button>
          <button className={view === "model" && dataset === "event_dates" ? "sub-active" : ""} onClick={() => openDataset("event_dates")} title="Termine">
            <CalendarDays className="size-[18px]" /><span>Termine</span><small>{payload?.datasets.event_dates.length ?? 133}</small>
          </button>
          <button className={view === "model" && dataset === "acts" ? "sub-active" : ""} onClick={() => openDataset("acts")} title="Acts">
            <Radio className="size-[18px]" /><span>Acts</span><small>{payload?.datasets.acts.length ?? 221}</small>
          </button>
        </nav>

        <div className="data-health">
          <div className="health-heading"><span className="status-pulse" /><span>Datenstatus</span><strong>Live</strong></div>
          <div className="health-track"><span style={{ width: `${Math.max(34, Math.round((overview.geocodedCount / overview.eventCount) * 100))}%` }} /></div>
          <p>{overview.geocodedCount} von {overview.eventCount} Events geocodiert</p>
        </div>
        <div className="profile-row">
          <span className="profile-avatar">SP</span>
          <span><strong>SPP7 Research</strong><small>Band workspace</small></span>
          <ChevronDown className="size-4" />
        </div>
      </aside>

      <main className="main-area">
        <header className="top-bar">
          <div className="title-cluster">
            <button className="icon-button mobile-menu" onClick={() => setMobileNav(true)} aria-label="Menü öffnen"><Menu className="size-5" /></button>
            {/* eslint-disable-next-line @next/next/no-img-element */}
            <img className="topbar-logo" src="/spp7-logo.png" alt="SPP7 Logo" />
            <div><p>{currentTitle.eyebrow}</p><h1>{view === "model" ? <DottedModelTitle /> : currentTitle.title}</h1></div>
          </div>
          <div className="top-actions">
            {(view === "model" || view === "contacts") && (
              <label className="header-search"><Search className="size-4" /><input value={search} onChange={(event) => { setSearch(event.target.value); setPage(1); }} placeholder="Daten durchsuchen…" /><kbd>⌘ K</kbd></label>
            )}
            <button className="secondary-button" onClick={() => downloadRows(filteredRows, dataset)} disabled={!payload}><ArrowDownToLine className="size-4" /><span>Export</span></button>
            <span className="sync-pill"><span /><em>Synchronisiert</em></span>
          </div>
        </header>

        <div className="content-area">
          {!payload ? <LoadingState /> : (
            <>
              {view === "overview" && <OverviewView payload={payload} overview={overview} openDataset={openDataset} setSelected={setSelected} />}
              {view === "model" && (
                <ModelView
                  payload={payload}
                  dataset={dataset}
                  setDataset={setDataset}
                  search={search}
                  setSearch={setSearch}
                  source={source}
                  setSource={setSource}
                  sourceOptions={sourceOptions}
                  columns={columns}
                  rows={pagedRows}
                  filteredCount={filteredRows.length}
                  page={page}
                  pageCount={pageCount}
                  setPage={setPage}
                  setSelected={setSelected}
                  exportRows={() => downloadRows(filteredRows, dataset)}
                />
              )}
              {view === "opportunities" && <OpportunitiesView payload={payload} setSelected={setSelected} />}
              {view === "contacts" && <ContactsView payload={payload} search={search} setSearch={setSearch} setSelected={setSelected} />}
            </>
          )}
        </div>
      </main>
      {selected && payload && <DetailDrawer selected={selected} payload={payload} onClose={() => setSelected(null)} />}
    </div>
  );
}

function OverviewView({
  payload,
  overview,
  openDataset,
  setSelected,
}: {
  payload: ArchivePayload;
  overview: Spp7Overview;
  openDataset: (dataset: DatasetKey) => void;
  setSelected: (value: { dataset: DatasetKey; row: DataRow }) => void;
}) {
  const totalRecords = Object.values(payload.datasets).reduce((sum, rows) => sum + rows.length, 0);
  const events = payload.datasets.events;
  const datedApplications = payload.datasets.event_dates
    .filter((row) => row.ART.toLocaleLowerCase("de").includes("bewerbung"))
    .slice(0, 4);
  const topActs = [...payload.datasets.acts]
    .sort((a, b) => Number(b.ANZAHL_EVENTS || 0) - Number(a.ANZAHL_EVENTS || 0))
    .slice(0, 5);
  const sourceCounts = events.reduce<Record<string, number>>((acc, row) => {
    acc[row.QUELLE_TYP || "Sonstige"] = (acc[row.QUELLE_TYP || "Sonstige"] ?? 0) + 1;
    return acc;
  }, {});
  const mapEvents = events.filter((row) => row.LAT && row.LNG).slice(0, 44);
  const findEvent = (eventId: string) => events.find((event) => event.EVENT_ID === eventId);

  return (
    <div className="overview-view">
      <section className="welcome-row">
        <div><p className="section-kicker"><span /> Live dataset · September 2026</p><h2>Guten Morgen, <em>SPP7.</em></h2><p>Dein Booking-Netzwerk auf einen Blick — von der Quelle bis zum nächsten Pitch.</p></div>
        <div className="source-stack"><span>79</span><div><strong>Flyer-Quellen</strong><small>29 vollständig erfasst</small></div></div>
      </section>

      <section className="metric-grid">
        <button className="metric-card metric-blue" onClick={() => openDataset("events")}><span className="metric-icon"><CalendarDays /></span><span className="metric-content"><small>Events gesamt</small><strong>{humanNumber(overview.eventCount)}</strong><em><i>+12</i> seit letztem Import</em></span><ArrowRight className="metric-arrow" /></button>
        <button className="metric-card metric-violet" onClick={() => openDataset("event_acts")}><span className="metric-icon"><GitBranch /></span><span className="metric-content"><small>Datensätze verknüpft</small><strong>{humanNumber(totalRecords)}</strong><em><i>13</i> relationale Tabellen</em></span><ArrowRight className="metric-arrow" /></button>
        <button className="metric-card metric-green" onClick={() => openDataset("contacts")}><span className="metric-icon"><ContactRound /></span><span className="metric-content"><small>Direkte Kontakte</small><strong>{humanNumber(overview.contactCount)}</strong><em><i>+8</i> neu qualifiziert</em></span><ArrowRight className="metric-arrow" /></button>
        <button className="metric-card metric-orange" onClick={() => openDataset("events")}><span className="metric-icon"><Zap /></span><span className="metric-content"><small>Bewerbungen bestätigt</small><strong>{humanNumber(overview.openApplicationCount)}</strong><em><i>{overview.unclearApplicationCount} unklar</i> · {overview.closedApplicationCount} geschlossen</em></span><ArrowRight className="metric-arrow" /></button>
      </section>

      <section className="overview-grid">
        <div className="panel map-panel">
          <div className="panel-heading"><div><p>Geografische Abdeckung</p><h3>Event-Radar</h3></div><button onClick={() => openDataset("events")}><Map className="size-4" /> Alle Orte</button></div>
          <div className="map-wrap">
            <svg viewBox="0 0 460 330" role="img" aria-label="Karte der erfassten Events in Deutschland">
              <defs><filter id="glow"><feGaussianBlur stdDeviation="4" result="blur" /><feMerge><feMergeNode in="blur" /><feMergeNode in="SourceGraphic" /></feMerge></filter></defs>
              <g className="map-grid-lines"><path d="M0 55H460M0 110H460M0 165H460M0 220H460M0 275H460" /><path d="M77 0V330M154 0V330M231 0V330M308 0V330M385 0V330" /></g>
              <path className="germany-shape" d="M213 18l32 18 29-4 19 29 35 14-8 32 22 28-17 24 10 38-27 17-6 36-35 9-15 39-36 18-27-27-39-3-9-39-27-21 15-33-11-35 28-26-3-39 34-17 13-35z" fill="#111927" />
              {mapEvents.map((event, index) => {
                const lon = Number(event.LNG.replace(",", "."));
                const lat = Number(event.LAT.replace(",", "."));
                const x = 105 + ((lon - 5) / 11) * 250;
                const y = 300 - ((lat - 47) / 8.5) * 270;
                return Number.isFinite(x) && Number.isFinite(y) ? <g key={`${event.EVENT_ID}-${index}`} className="map-dot" transform={`translate(${x} ${y})`}><circle r={index < 5 ? 4.5 : 3} filter={index < 5 ? "url(#glow)" : undefined} /><title>{event.NAME} · {event.ORT}</title></g> : null;
              })}
            </svg>
            <div className="map-legend"><span><i className="legend-primary" /> Erfasster Event</span><span><i className="legend-muted" /> Regionale Dichte</span></div>
            <div className="map-stat"><strong>{overview.geocodedCount}</strong><span>geocodierte<br />Orte</span></div>
          </div>
        </div>

        <div className="panel deadlines-panel">
          <div className="panel-heading"><div><p>Handlungsbedarf</p><h3>Nächste Fristen</h3></div><button onClick={() => openDataset("event_dates")}>Alle Termine <ArrowRight className="size-4" /></button></div>
          <div className="deadline-list">
            {datedApplications.map((date, index) => {
              const event = findEvent(date.EVENT_ID);
              return (
                <button key={date.DATE_ID} onClick={() => event && setSelected({ dataset: "events", row: event })}>
                  <span className={`date-tile date-${index}`}><strong>{date.VON.split(".")[0] || "–"}</strong><small>{date.VON.split(".")[1] ? ["JAN", "FEB", "MÄR", "APR", "MAI", "JUN", "JUL", "AUG", "SEP", "OKT", "NOV", "DEZ"][Number(date.VON.split(".")[1]) - 1] : "2027"}</small></span>
                  <span className="deadline-copy"><strong>{date.EVENT_NAME}</strong><small>{date.ART} · {date.KOMMENTAR || "Termin prüfen"}</small></span>
                  <ArrowRight className="size-4" />
                </button>
              );
            })}
          </div>
          <div className="deadline-footer"><Clock3 className="size-4" /><span><strong>4 Bewerbungen</strong> benötigen in den nächsten Wochen Aufmerksamkeit.</span></div>
        </div>

        <div className="panel connections-panel">
          <div className="panel-heading"><div><p>Netzwerk</p><h3>Stärkste Verbindungen</h3></div><button onClick={() => openDataset("acts")}>221 Acts <ArrowRight className="size-4" /></button></div>
          <div className="connection-list">
            {topActs.map((act, index) => (
              <button key={act.ACT_ID} onClick={() => setSelected({ dataset: "acts", row: act })}>
                <span className={`rank rank-${index}`}>{index + 1}</span><span className="act-avatar">{initials(act.ACT_NAME)}</span><span className="act-copy"><strong>{act.ACT_NAME}</strong><small>{act.ROLLEN || "Act"}</small></span><span className="event-count"><strong>{act.ANZAHL_EVENTS}</strong><small>Events</small></span>
              </button>
            ))}
          </div>
        </div>

        <div className="panel sources-panel">
          <div className="panel-heading"><div><p>Quellenqualität</p><h3>Daten-Mix</h3></div><Activity className="size-5 panel-icon" /></div>
          <div className="donut-wrap"><div className="donut"><div><strong>{overview.eventCount}</strong><small>Events</small></div></div><div className="donut-legend">{Object.entries(sourceCounts).sort((a, b) => b[1] - a[1]).slice(0, 4).map(([label, count], index) => <div key={label}><i className={`source-color source-${index}`} /><span>{label}</span><strong>{count}</strong></div>)}</div></div>
          <div className="quality-row"><span><Check className="size-3" /> Dedupliziert</span><span><Check className="size-3" /> Relational</span><span><Check className="size-3" /> Exportbereit</span></div>
        </div>
      </section>
    </div>
  );
}

function ModelView({
  payload, dataset, setDataset, search, setSearch, source, setSource, sourceOptions, columns, rows,
  filteredCount, page, pageCount, setPage, setSelected, exportRows,
}: {
  payload: ArchivePayload; dataset: DatasetKey; setDataset: (value: DatasetKey) => void;
  search: string; setSearch: (value: string) => void; source: string; setSource: (value: string) => void;
  sourceOptions: string[]; columns: string[]; rows: DataRow[]; filteredCount: number; page: number; pageCount: number;
  setPage: (value: number) => void; setSelected: (value: { dataset: DatasetKey; row: DataRow }) => void; exportRows: () => void;
}) {
  const definition = DATASETS.find((item) => item.key === dataset) ?? DATASETS[0];
  const hasFlyerColumn = dataset === "events" || dataset === "flyer_sources";
  return (
    <div className="model-view">
      <section className="model-intro"><div><span className="model-badge"><Database className="size-4" /> Relationaler Datensatz</span><h2><DottedModelTitle /></h2><p>79 Flyer, 120 Chat-Nachrichten und 13 normalisierte Tabellen — vollständig durchsuchbar und verknüpft.</p></div><div className="model-mini-stats"><span><strong>1.756</strong><small>Records</small></span><i /><span><strong>13</strong><small>Tabellen</small></span><i /><span><strong>100%</strong><small>Exportfähig</small></span></div></section>
      <section className="dataset-tabs" aria-label="Datentabellen">
        {DATASETS.map((item) => <button key={item.key} className={dataset === item.key ? "active" : ""} onClick={() => { setDataset(item.key); setSource("Alle Quellen"); setPage(1); }}><DatasetIcon dataset={item.key} /><span>{item.label}</span><small>{payload.datasets[item.key].length}</small></button>)}
      </section>
      <section className="data-panel">
        <div className="data-panel-head"><div><p>{definition.label}</p><h3>{definition.description}</h3></div><span><i /> {filteredCount} Einträge</span></div>
        <div className="table-toolbar">
          <label className="table-search"><Search className="size-4" /><input value={search} onChange={(event) => { setSearch(event.target.value); setPage(1); }} placeholder={`In ${definition.label} suchen…`} />{search && <button onClick={() => { setSearch(""); setPage(1); }} aria-label="Suche löschen"><X className="size-3.5" /></button>}</label>
          {dataset === "events" && <label className="select-control"><Filter className="size-4" /><select value={source} onChange={(event) => { setSource(event.target.value); setPage(1); }}>{sourceOptions.map((item) => <option key={item}>{item}</option>)}</select><ChevronDown className="size-4" /></label>}
          <button className="toolbar-button" onClick={exportRows}><ArrowDownToLine className="size-4" /> CSV exportieren</button>
        </div>
        <div className="table-scroll">
          <table className="data-table"><thead><tr>{hasFlyerColumn && <th className="thumb-column">Flyer</th>}{columns.map((column) => <th key={column}>{formatColumn(column)}</th>)}<th className="action-column" /></tr></thead><tbody>{rows.length ? rows.map((row, rowIndex) => {
            const thumb = hasFlyerColumn ? flyerThumbSrc(row) : null;
            return (
              <tr key={row[columns[0]] || rowIndex} onClick={() => setSelected({ dataset, row })}>
                {hasFlyerColumn && <td className="thumb-column">{thumb ? (
                  /* eslint-disable-next-line @next/next/no-img-element */
                  <img className="flyer-thumb" src={thumb} alt={`Flyer zu ${row.NAME || row.FLYER}`} loading="lazy" />
                ) : <span className="thumb-empty" aria-hidden="true"><FileText className="size-3.5" /></span>}</td>}
                {columns.map((column) => <td key={column} className={isIdColumn(column) ? "id-cell" : ""}>{renderCell(column, column === "BEWERBUNG_STATUS" && !row.BEWERBUNG ? "" : row[column])}</td>)}
                <td className="action-column"><ArrowRight className="size-4" /></td>
              </tr>
            );
          }) : <tr><td colSpan={columns.length + (hasFlyerColumn ? 2 : 1)} className="empty-row"><Search className="size-5" /> Keine passenden Einträge gefunden.</td></tr>}</tbody></table>
        </div>
        <div className="pagination"><span>Zeige {rows.length ? (page - 1) * 20 + 1 : 0}–{Math.min(page * 20, filteredCount)} von {filteredCount}</span><div><button onClick={() => setPage(Math.max(1, page - 1))} disabled={page === 1}>Zurück</button><span>{page} / {pageCount}</span><button onClick={() => setPage(Math.min(pageCount, page + 1))} disabled={page === pageCount}>Weiter</button></div></div>
      </section>
    </div>
  );
}

function applicationStatusClass(value = "") {
  if (value === "bestätigt") return "status-confirmed";
  if (value === "geschlossen") return "status-closed";
  return "status-unclear";
}

function renderCell(column: string, value = "") {
  if (!value) return <span className="empty-value">—</span>;
  if (column === "APPLICATION_STATUS" || column === "BEWERBUNG_STATUS") {
    return <span className={`application-status ${applicationStatusClass(value)}`}><i />{value}</span>;
  }
  if (column === "SOURCE_STATUS") {
    const labels: Record<string, string> = {
      linked_event: "Event verknüpft",
      known_duplicate: "Dublette",
      needs_review: "Einzelquelle · prüfen",
      transcribed_source: "Screenshot geprüft",
    };
    const state = value === "linked_event" ? "confirmed" : value === "known_duplicate" ? "duplicate" : "unclear";
    return <span className={`application-status status-${state}`}>{labels[value] ?? value}</span>;
  }
  if (column === "SOURCE_KIND") {
    return <span className="source-badge">{value === "booking_listing" ? "Buchungsanzeige" : value === "event_source" ? "Eventquelle" : value}</span>;
  }
  if (column === "REVIEW_STATUS") {
    const labels: Record<string, string> = {
      already_in_structured_export: "Strukturiert erfasst",
      duplicate_verified_in_archive: "Dublette belegt",
      OCR_draft_unverified: "OCR-Entwurf · ungeprüft",
      verified_against_user_screenshot: "Screenshot gegengeprüft",
    };
    return <span className={`review-status ${value === "verified_against_user_screenshot" ? "review-verified" : ""}`}>{labels[value] ?? value}</span>;
  }
  if ((column === "TAGS" || column === "ROLLEN") && tokenize(value).length > 1) return <div className="cell-tags">{tokenize(value).slice(0, 3).map((tag) => <span key={tag}>{tag}</span>)}{tokenize(value).length > 3 && <small>+{tokenize(value).length - 3}</small>}</div>;
  if (column === "QUELLE_TYP") return <span className={`source-badge badge-${value.toLowerCase().replace(/[^a-z]/g, "")}`}>{value}</span>;
  if (column === "PASSUNG_SPP7") return <span className={`fit-badge ${value.toLowerCase().includes("hoch") ? "high" : ""}`}><i />{value}</span>;
  if (column === "EMAIL_TELEFON" && value.includes("@")) return <a href={`mailto:${value}`} onClick={(event) => event.stopPropagation()}>{value}<ExternalLink className="size-3" /></a>;
  return <span className={value.length > 90 ? "clamped-cell" : ""} title={value}>{value}</span>;
}

function OpportunitiesView({ payload, setSelected }: { payload: ArchivePayload; setSelected: (value: { dataset: DatasetKey; row: DataRow }) => void }) {
  const events = payload.datasets.events.filter((row) => Boolean(row.BEWERBUNG?.trim()));
  const groups = [
    { title: "Bestätigt", subtitle: "Bewerbung im Quelltext bestätigt", tone: "green", rows: events.filter((row) => row.BEWERBUNG_STATUS === "bestätigt").slice(0, 8) },
    { title: "Unklar", subtitle: "Status bitte an der Quelle prüfen", tone: "violet", rows: events.filter((row) => row.BEWERBUNG_STATUS === "unklar").slice(0, 8) },
    { title: "Geschlossen", subtitle: "Quelle meldet geschlossen", tone: "red", rows: events.filter((row) => row.BEWERBUNG_STATUS === "geschlossen").slice(0, 8) },
  ];
  return <div className="opportunity-view"><section className="view-intro"><div><span className="model-badge"><Sparkles className="size-4" /> Booking Pipeline</span><h2>Vom Signal zum <em>Pitch.</em></h2><p>Qualifizierte Festival-Chancen, priorisiert nach Bewerbungslage und SPP7-Passung.</p></div><div className="pipeline-total"><strong>{groups.reduce((sum, group) => sum + group.rows.length, 0)}</strong><span>Bewerbungen<br />mit Status</span></div></section><section className="pipeline-grid">{groups.map((group) => <div className={`pipeline-column tone-${group.tone}`} key={group.title}><header><span /><div><h3>{group.title}</h3><p>{group.subtitle}</p></div><strong>{group.rows.length}</strong></header><div className="pipeline-list">{group.rows.map((event) => {
              const thumb = flyerThumbSrc(event);
              return (
                <button key={event.EVENT_ID} onClick={() => setSelected({ dataset: "events", row: event })}>
                  <div className="pipeline-card-head"><span>{event.EVENT_ID}</span><small>{event.QUELLE_TYP}</small></div>
                  <div className="pipeline-card-body">
                    {thumb && (
                      /* eslint-disable-next-line @next/next/no-img-element */
                      <img className="pipeline-thumb" src={thumb} alt="" loading="lazy" />
                    )}
                    <h4>{event.NAME}</h4>
                  </div>
                  <p><MapPin className="size-3.5" /> {event.ORT || event.REGION || "Ort noch offen"}</p>
                  <div className="pipeline-tags">{tokenize(event.TAGS).slice(0, 3).map((tag) => <span key={tag}>{tag}</span>)}</div>
                  <footer><span>{event.PASSUNG_SPP7 || "Passung prüfen"}</span><ArrowRight className="size-4" /></footer>
                </button>
              );
            })}</div></div>)}</section></div>;
}

function ContactsView({ payload, search, setSearch, setSelected }: { payload: ArchivePayload; search: string; setSearch: (value: string) => void; setSelected: (value: { dataset: DatasetKey; row: DataRow }) => void }) {
  const query = search.toLowerCase();
  const contacts = payload.datasets.contacts.filter((row) => !query || Object.values(row).some((value) => value.toLowerCase().includes(query)));
  const regions = Object.entries(payload.datasets.contacts.reduce<Record<string, number>>((acc, row) => { const key = row.REGION || "Nicht zugeordnet"; acc[key] = (acc[key] ?? 0) + 1; return acc; }, {})).sort((a, b) => b[1] - a[1]).slice(0, 4);
  return <div className="contacts-view"><section className="view-intro contacts-intro"><div><span className="model-badge"><ContactRound className="size-4" /> Outreach Network</span><h2>Kontakte, die <em>weiterbringen.</em></h2><p>{payload.datasets.contacts.length} verifizierte Anlaufstellen aus Tourismus, Kultur, Vereinen und Veranstaltern.</p></div><div className="contact-avatars">{payload.datasets.contacts.slice(0, 5).map((row, index) => <span key={row.CONTACT_ID} style={{ zIndex: 6 - index }}>{initials(row.ORGANISATION)}</span>)}<strong>+{payload.datasets.contacts.length - 5}</strong></div></section><section className="contact-layout"><div className="panel contact-main"><div className="contact-toolbar"><label className="table-search"><Search className="size-4" /><input value={search} onChange={(event) => setSearch(event.target.value)} placeholder="Organisation, Ort oder E-Mail suchen…" /></label><span>{contacts.length} Kontakte</span></div><div className="contact-list">{contacts.map((contact) => <button key={contact.CONTACT_ID} onClick={() => setSelected({ dataset: "contacts", row: contact })}><span className="contact-avatar">{initials(contact.ORGANISATION)}</span><span className="contact-name"><strong>{contact.ORGANISATION}</strong><small>{contact.TYP || "Organisation"}</small></span><span className="contact-place"><MapPin className="size-3.5" />{contact.ORT || contact.REGION || "—"}</span><span className="contact-channel">{contact.EMAIL_TELEFON || "Kontakt recherchieren"}</span><ArrowRight className="size-4" /></button>)}</div></div><aside className="panel region-panel"><div className="panel-heading"><div><p>Verteilung</p><h3>Top-Regionen</h3></div><MapPin className="size-5 panel-icon" /></div><div className="region-bars">{regions.map(([region, count], index) => <div key={region}><span><strong>{region}</strong><small>{count} Kontakte</small></span><div><i style={{ width: `${Math.max(18, (count / Number(regions[0][1])) * 100)}%` }} className={`region-${index}`} /></div></div>)}</div><button className="region-action" onClick={() => downloadRows(payload.datasets.contacts, "contacts")}><ArrowDownToLine className="size-4" /> Kontaktliste exportieren</button></aside></section></div>;
}

function DetailDrawer({ selected, payload, onClose }: { selected: { dataset: DatasetKey; row: DataRow }; payload: ArchivePayload; onClose: () => void }) {
  const { dataset, row } = selected;
  const eventId = row.EVENT_ID || (dataset === "events" ? row.EVENT_ID : "");
  const title = row.NAME || row.EVENT_NAME || row.ACT_NAME || row.ORGANISATION || row.PARTNER_NAME || row.WERT || "Datensatz";
  const definition = DATASETS.find((item) => item.key === dataset) ?? DATASETS[0];
  const related = eventId ? {
    dates: payload.datasets.event_dates.filter((item) => item.EVENT_ID === eventId),
    acts: payload.datasets.event_acts.filter((item) => item.EVENT_ID === eventId),
    channels: payload.datasets.event_channels.filter((item) => item.EVENT_ID === eventId),
    tags: payload.datasets.event_tags.filter((item) => item.EVENT_ID === eventId),
  } : null;
  const flyerThumb = dataset === "events" ? flyerThumbSrc(row) : null;
  return <><button className="drawer-scrim" onClick={onClose} aria-label="Detailansicht schließen" /><aside className="detail-drawer"><header><div><span><DatasetIcon dataset={dataset} /> {definition.label}</span><h2>{title}</h2><p>{row.EVENT_ID || row.CONTACT_ID || row.ACT_ID || row.LINK_ID || "SPP7 Record"}</p></div><button className="icon-button" onClick={onClose} aria-label="Schließen"><X className="size-5" /></button></header>{dataset === "events" ? <div className="drawer-body event-detail">{flyerThumb && (
    /* eslint-disable-next-line @next/next/no-img-element */
    <img className="flyer-preview" src={flyerThumb} alt={`Flyer zu ${row.NAME}`} />
  )}<div className="detail-status"><span className="source-badge">{row.QUELLE_TYP}</span>{row.PASSUNG_SPP7 && <span className="fit-badge high"><i /> Hohe Relevanz</span>}{row.BEWERBUNG && row.BEWERBUNG_STATUS && <span className={`application-status ${applicationStatusClass(row.BEWERBUNG_STATUS)}`}><i />{row.BEWERBUNG_STATUS}</span>}</div><div className="detail-location"><MapPin className="size-5" /><span><strong>{row.LOCATION || row.ORT || "Ort offen"}</strong><small>{[row.ORT, row.REGION, row.LAND].filter(Boolean).join(" · ")}</small></span></div>{row.KURZBESCHREIBUNG && <section><p>Zusammenfassung</p><h3>{row.KURZBESCHREIBUNG}</h3></section>}{row.BEWERBUNG && <div className="application-callout"><Zap className="size-5" /><span><small>Bewerbung · {row.BEWERBUNG_STATUS || "unklar"}</small><strong>{row.BEWERBUNG}</strong>{row.BEWERBUNG_STATUS_BASIS && <small className="application-status-basis">{row.BEWERBUNG_STATUS_BASIS}</small>}</span></div>}{row.NAECHSTER_SCHRITT && <section><p>Nächster Schritt</p><div className="next-step"><Check className="size-4" />{row.NAECHSTER_SCHRITT}</div></section>}<section><p>Verknüpfungen</p><div className="relation-grid"><span><CalendarDays /><strong>{related?.dates.length ?? 0}</strong><small>Termine</small></span><span><Radio /><strong>{related?.acts.length ?? 0}</strong><small>Acts</small></span><span><Link2 /><strong>{related?.channels.length ?? 0}</strong><small>Kanäle</small></span><span><Tag /><strong>{related?.tags.length ?? 0}</strong><small>Tags</small></span></div></section>{related?.acts.length ? <section><p>Line-up / Acts</p><div className="detail-list">{related.acts.slice(0, 8).map((act) => <span key={act.LINK_ID}><i>{initials(act.ACT_NAME)}</i><b>{act.ACT_NAME}</b><small>{act.ROLLE}</small></span>)}</div></section> : null}{row.LANGBESCHREIBUNG && <section><p>Research-Notiz</p><div className="long-note">{row.LANGBESCHREIBUNG}</div></section>}</div> : <div className="drawer-body generic-detail">{Object.entries(row).map(([key, value]) => value ? <section key={key}><p>{formatColumn(key)}</p><div>{value}</div></section> : null)}</div>}</aside></>;
}