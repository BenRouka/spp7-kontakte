import type { ReactNode } from "react";

export function cx(...parts: Array<string | false | null | undefined>) {
  return parts.filter(Boolean).join(" ");
}

export function Panel({
  className,
  children,
}: {
  className?: string;
  children: ReactNode;
}) {
  return (
    <div className={cx("rounded-xl border border-line bg-raised p-4 sm:p-5", className)}>
      {children}
    </div>
  );
}

type Tone = "a" | "warn" | "mute" | "line";

const TONES: Record<Tone, string> = {
  a: "border-lime/40 bg-lime/[0.07] text-lime",
  warn: "border-amber/35 bg-amber/[0.06] text-amber",
  mute: "border-line bg-raised2 text-muted",
  line: "border-line bg-transparent text-ink-soft",
};

export function Badge({
  tone = "mute",
  className,
  children,
}: {
  tone?: Tone;
  className?: string;
  children: ReactNode;
}) {
  return (
    <span
      className={cx(
        "inline-flex items-center gap-1 rounded-md border px-1.5 py-0.5 font-mono text-[10.5px] font-medium uppercase tracking-[0.08em]",
        TONES[tone],
        className
      )}
    >
      {children}
    </span>
  );
}

export function Section({
  eyebrow,
  title,
  desc,
  aside,
  className,
  children,
}: {
  eyebrow: string;
  title: string;
  desc?: ReactNode;
  aside?: ReactNode;
  className?: string;
  children: ReactNode;
}) {
  return (
    <section className={cx("mt-14 first:mt-0", className)}>
      <div className="mb-5 flex flex-wrap items-end justify-between gap-x-6 gap-y-2 border-b border-line pb-3">
        <div className="min-w-0">
          <p className="font-mono text-[10.5px] font-semibold uppercase tracking-[0.22em] text-lime">
            {eyebrow}
          </p>
          <h2 className="mt-1 text-xl font-semibold tracking-tight text-ink">
            {title}
          </h2>
          {desc ? (
            <p className="mt-1 max-w-3xl text-[13px] leading-relaxed text-muted">
              {desc}
            </p>
          ) : null}
        </div>
        {aside}
      </div>
      {children}
    </section>
  );
}

export function Stat({
  label,
  value,
  sub,
  tone = "ink",
}: {
  label: string;
  value: ReactNode;
  sub?: ReactNode;
  tone?: "ink" | "lime" | "amber";
}) {
  const color =
    tone === "lime" ? "text-lime" : tone === "amber" ? "text-amber" : "text-ink";
  return (
    <div className="rounded-xl border border-line bg-raised px-4 py-3.5">
      <p className="font-mono text-[10px] uppercase tracking-[0.18em] text-muted">
        {label}
      </p>
      <p className={cx("mt-1.5 text-[26px] font-semibold leading-none tracking-tight", color)}>
        {value}
      </p>
      {sub ? (
        <p className="mt-1.5 text-[11.5px] leading-snug text-muted">{sub}</p>
      ) : null}
    </div>
  );
}

export function FieldLabel({ children }: { children: ReactNode }) {
  return (
    <span className="font-mono text-[9.5px] uppercase tracking-[0.16em] text-muted">
      {children}
    </span>
  );
}

export function RefChip({ children }: { children: ReactNode }) {
  return (
    <span className="inline-flex items-center rounded border border-line-soft bg-raised2 px-1.5 py-0.5 font-mono text-[10px] text-amber-soft">
      {children}
    </span>
  );
}
