import Link from "next/link";
import { notFound } from "next/navigation";
import {
  ArrowLeft,
  CalendarDays,
  Euro,
  Handshake,
  Image as ImageIcon,
  Link2,
  MapPin,
  MessagesSquare,
  Music2,
  Radio,
  Sparkles,
  Tag,
} from "lucide-react";
import type { ReactNode } from "react";
import { Badge, Card, Empty, SectionHead } from "@/components/ui";
import { getAltEventDetail } from "@/lib/altbestand";

export const dynamic = "force-dynamic";

function Block({
  icon: Icon,
  titel,
  anzahl,
  children,
}: {
  icon: typeof Music2;
  titel: string;
  anzahl?: number;
  children: ReactNode;
}) {
  return (
    <Card className="p-5">
      <div className="mb-3 flex items-center gap-2">
        <Icon className="h-4 w-4 text-lime" strokeWidth={2.2} />
        <h3 className="font-mono text-[11px] font-semibold uppercase tracking-[0.16em] text-ink">
          {titel}
        </h3>
        {anzahl !== undefined ? (
          <span className="tnum font-mono text-[11px] text-muted">
            {anzahl}
          </span>
        ) : null}
      </div>
      {children}
    </Card>
  );
}

function Feld({ label, value }: { label: string; value: ReactNode }) {
  return (
    <div className="min-w-0">
      <p className="font-mono text-[10px] uppercase tracking-[0.16em] text-muted">
        {label}
      </p>
      <div className="mt-1 text-[13px] leading-snug text-ink">
        {value ?? <Empty>leer</Empty>}
      </div>
    </div>
  );
}

export default async function AltEventPage({
  params,
}: {
  params: Promise<{ eventId: string }>;
}) {
  const { eventId } = await params;
  const d = await getAltEventDetail(eventId);
  if (!d) notFound();
  const e = d.event;

  return (
    <div className="space-y-8">
      <Link
        href="/archiv"
        className="inline-flex items-center gap-1.5 font-mono text-[11px] uppercase tracking-[0.14em] text-muted transition-colors hover:text-lime"
      >
        <ArrowLeft className="h-3.5 w-3.5" /> Archiv
      </Link>

      <SectionHead
        eyebrow={`${e.eventId} · ${e.typ}`}
        title={e.name}
        right={
          <div className="flex flex-wrap justify-end gap-1.5">
            <Badge tone={e.zuordnung === "kuratiert" ? "lime" : "neutral"}>
              {e.zuordnung === "kuratiert" ? "kuratiert verknüpft" : "Rest"}
            </Badge>
            <Badge tone={e.quelleTyp.includes("KI") ? "amber" : "neutral"}>
              {e.quelleTyp}
            </Badge>
          </div>
        }
      />

      <Card className="border-amber/25 bg-amber/[0.04] px-5 py-3">
        <p className="text-[12px] leading-relaxed text-ink-soft">
          <strong className="text-amber">Vermerk:</strong> {e.vermerk}
        </p>
      </Card>

      {d.verknuepfte.length > 0 ? (
        <Block icon={Link2} titel="Kuratierter Termin (Prio 1 · führend)" anzahl={d.verknuepfte.length}>
          <div className="space-y-3">
            {d.verknuepfte.map((v) => (
              <div
                key={v.sfId}
                className="rounded-lg border border-lime/25 bg-lime/[0.05] p-3"
              >
                <div className="flex flex-wrap items-center gap-2">
                  <Badge tone="lime">{v.sfId}</Badge>
                  <span className="text-[13px] font-medium text-ink">
                    {v.name}
                  </span>
                  <span className="font-mono text-[11px] text-muted">
                    {v.datum} · {v.plzOrt}
                  </span>
                </div>
                <p className="mt-1.5 font-mono text-[10px] uppercase tracking-[0.12em] text-muted">
                  Zuordnung: {v.basis} · Score {v.score} ·{" "}
                  {v.anzahl > 1 ? `${v.anzahl} Zeitfenster` : "1 Zeitfenster"}
                </p>
                {v.hinweis ? (
                  <p className="mt-1 text-[12px] text-amber">{v.hinweis}</p>
                ) : null}
              </div>
            ))}
            <p className="text-[11px] leading-relaxed text-muted">
              Zeitfenster und Schreibweise stammen aus dem Freeze, nicht aus dem
              Altbestand (B-10 / Advent = 1 Quellzeile mit 4 Fenstern).
            </p>
          </div>
        </Block>
      ) : null}

      <div className="grid gap-5 lg:grid-cols-2">
        <Block icon={MapPin} titel="Ort & Geo">
          <div className="grid grid-cols-2 gap-4">
            <Feld label="Ort" value={e.ort} />
            <Feld label="PLZ" value={e.plz} />
            <Feld label="Location" value={e.location} />
            <Feld label="Straße" value={e.strasse} />
            <Feld label="Region" value={e.region} />
            <Feld label="Land" value={e.land} />
            <Feld
              label="Koordinaten"
              value={
                e.lat && e.lng ? (
                  <span className="tnum font-mono text-[12px]">
                    {e.lat} / {e.lng}
                  </span>
                ) : null
              }
            />
            <Feld
              label="Geo-Qualität"
              value={
                <Badge tone={e.geoQualitaet === "zentroid" ? "amber" : "neutral"}>
                  {e.geoQualitaet}
                </Badge>
              }
            />
          </div>
          {e.geoStatus ? (
            <p className="mt-3 border-t border-line pt-3 text-[11px] leading-relaxed text-muted">
              {e.geoStatus}
            </p>
          ) : null}
        </Block>

        <Block icon={Euro} titel="Bewerbung & Gage">
          <div className="grid grid-cols-2 gap-4">
            <Feld label="Bewerbung" value={e.bewerbung} />
            <Feld
              label="Status"
              value={
                e.bewerbungStatus ? (
                  <Badge tone={e.bewerbungStatus === "offen" ? "lime" : "neutral"}>
                    {e.bewerbungStatus}
                  </Badge>
                ) : null
              }
            />
            <Feld label="Gage" value={e.gage} />
            <Feld label="Gage-Status" value={e.gageStatus} />
            <Feld label="Konditionen" value={e.konditionen} />
            <Feld label="Eintritt" value={e.eintritt} />
          </div>
        </Block>
      </div>

      <div className="grid gap-5 lg:grid-cols-2">
        <Block icon={CalendarDays} titel="Termine im Altbestand" anzahl={d.dates.length}>
          {d.dates.length > 0 ? (
            <ul className="space-y-2">
              {d.dates.map((x) => (
                <li
                  key={x.dateId}
                  className="flex flex-wrap items-center gap-2 border-b border-line/60 pb-2 last:border-0 last:pb-0"
                >
                  <span className="font-mono text-[10px] text-muted">
                    {x.dateId}
                  </span>
                  <span className="tnum text-[13px] text-ink">
                    {x.von} – {x.bis}
                  </span>
                  {x.art ? <Badge>{x.art}</Badge> : null}
                  {x.kommentar ? (
                    <span className="text-[11px] text-muted">{x.kommentar}</span>
                  ) : null}
                </li>
              ))}
            </ul>
          ) : (
            <Empty>keine Datumzeilen</Empty>
          )}
        </Block>

        <Block icon={Music2} titel="Bands / Acts" anzahl={d.acts.length}>
          {d.acts.length > 0 ? (
            <ul className="space-y-2">
              {d.acts.map((a) => (
                <li
                  key={a.linkId}
                  className="flex flex-wrap items-center gap-2 border-b border-line/60 pb-2 last:border-0 last:pb-0"
                >
                  <Link
                    href={`/archiv/acts/${a.actId}`}
                    className="text-[13px] text-ink hover:text-lime"
                  >
                    {a.name}
                  </Link>
                  {a.rolle ? <Badge tone="lime">{a.rolle}</Badge> : null}
                  {a.unsicher ? <Badge tone="amber">unsicher</Badge> : null}
                  {a.notiz ? (
                    <span className="w-full text-[11px] leading-snug text-muted">
                      {a.notiz}
                    </span>
                  ) : null}
                </li>
              ))}
            </ul>
          ) : (
            <Empty>keine Bands hinterlegt</Empty>
          )}
        </Block>
      </div>

      <div className="grid gap-5 lg:grid-cols-3">
        <Block icon={Handshake} titel="Partner & Sponsoren" anzahl={d.partners.length}>
          {d.partners.length > 0 ? (
            <ul className="space-y-2">
              {d.partners.map((p) => (
                <li key={p.linkId} className="text-[13px] text-ink">
                  {p.name}
                  {p.rolle ? (
                    <span className="ml-2 font-mono text-[10px] text-muted">
                      {p.rolle}
                    </span>
                  ) : null}
                </li>
              ))}
            </ul>
          ) : (
            <Empty>keine Partner</Empty>
          )}
        </Block>

        <Block icon={Radio} titel="Kanäle" anzahl={d.channels.length}>
          {d.channels.length > 0 ? (
            <ul className="space-y-2">
              {d.channels.map((c) => (
                <li key={c.linkId} className="text-[13px] text-ink">
                  <span className="font-mono text-[10px] uppercase tracking-[0.12em] text-muted">
                    {c.kanal}
                  </span>
                  <span className="ml-2 break-all">{c.wert}</span>
                </li>
              ))}
            </ul>
          ) : (
            <Empty>keine Kanäle</Empty>
          )}
        </Block>

        <Block icon={Sparkles} titel="Features / Programm" anzahl={d.features.length + d.timetable.length}>
          {d.features.length + d.timetable.length > 0 ? (
            <ul className="space-y-1.5">
              {d.features.map((f) => (
                <li key={f.linkId} className="text-[13px] text-ink">
                  {f.feature}
                  {f.kategorie ? (
                    <span className="ml-2 font-mono text-[10px] text-muted">
                      {f.kategorie}
                    </span>
                  ) : null}
                </li>
              ))}
              {d.timetable.map((t) => (
                <li key={t.linkId} className="text-[13px] text-ink">
                  <span className="tnum font-mono text-[11px] text-lime">
                    {t.zeit}
                  </span>{" "}
                  {t.programmpunkt}
                </li>
              ))}
            </ul>
          ) : (
            <Empty>nichts hinterlegt</Empty>
          )}
        </Block>
      </div>

      {d.flyers.length > 0 ? (
        <Block icon={ImageIcon} titel="Flyer / Screens" anzahl={d.flyers.length}>
          <div className="flex flex-wrap gap-4">
            {d.flyers.map((f) => (
              <figure key={f.flyer} className="w-44">
                <a href={f.bildOriginal} target="_blank" rel="noreferrer">
                  {/* eslint-disable-next-line @next/next/no-img-element */}
                  <img
                    src={f.bildThumb}
                    alt={`Flyer ${f.flyer}`}
                    className="w-full rounded-lg border border-line object-cover transition-opacity hover:opacity-80"
                  />
                </a>
                <figcaption className="mt-1.5 space-y-1">
                  <span className="font-mono text-[10px] text-muted">
                    #{f.flyer} · {f.format}
                  </span>
                  {f.status ? <Badge>{f.status}</Badge> : null}
                  {f.ocrRohtext ? (
                    <p className="line-clamp-4 text-[11px] leading-snug text-muted">
                      {f.ocrRohtext}
                    </p>
                  ) : null}
                </figcaption>
              </figure>
            ))}
          </div>
        </Block>
      ) : null}

      <div className="grid gap-5 lg:grid-cols-2">
        <Block icon={MessagesSquare} titel="Chat-Belege" anzahl={d.chat.length}>
          {d.chat.length > 0 ? (
            <ul className="space-y-3">
              {d.chat.map((m) => (
                <li
                  key={m.msg}
                  className="border-b border-line/60 pb-3 last:border-0 last:pb-0"
                >
                  <div className="flex flex-wrap items-center gap-2">
                    <span className="font-mono text-[10px] text-muted">
                      MSG {m.msg}
                    </span>
                    {m.datum ? (
                      <span className="font-mono text-[10px] text-muted">
                        {m.datum}
                      </span>
                    ) : null}
                    {m.absender ? <Badge>{m.absender}</Badge> : null}
                  </div>
                  {m.text ? (
                    <p className="mt-1 line-clamp-5 text-[12px] leading-relaxed text-ink-soft">
                      {m.text}
                    </p>
                  ) : null}
                  {m.links ? (
                    <p className="mt-1 break-all font-mono text-[10px] text-lime">
                      {m.links}
                    </p>
                  ) : null}
                </li>
              ))}
            </ul>
          ) : (
            <Empty>keine Chat-Nachricht zugeordnet</Empty>
          )}
        </Block>

        <Block icon={Tag} titel="Einschätzung & Tags">
          <div className="space-y-4">
            <Feld label="Kurzbeschreibung" value={e.kurzbeschreibung} />
            <Feld label="Langbeschreibung" value={e.langbeschreibung} />
            <Feld label="Passung SPP7" value={e.passung} />
            <Feld label="Nächster Schritt" value={e.naechsterSchritt} />
            <Feld label="Unklar" value={e.unklar} />
            <div>
              <p className="font-mono text-[10px] uppercase tracking-[0.16em] text-muted">
                Tags
              </p>
              <div className="mt-1.5 flex flex-wrap gap-1.5">
                {d.tags.length > 0 ? (
                  d.tags.map((t) => <Badge key={t}>{t}</Badge>)
                ) : (
                  <Empty>keine Tags</Empty>
                )}
              </div>
            </div>
            {d.feed.length > 0 ? (
              <div className="border-t border-line pt-3">
                <p className="font-mono text-[10px] uppercase tracking-[0.16em] text-muted">
                  Feed-Kontext
                </p>
                {d.feed.map((f) => (
                  <p key={f.linkId} className="mt-1 text-[12px] text-ink-soft">
                    {f.account ? `@${f.account} · ` : ""}
                    {f.notiz} {f.relevanz ? <Badge>{f.relevanz}</Badge> : null}
                  </p>
                ))}
              </div>
            ) : null}
          </div>
        </Block>
      </div>
    </div>
  );
}
