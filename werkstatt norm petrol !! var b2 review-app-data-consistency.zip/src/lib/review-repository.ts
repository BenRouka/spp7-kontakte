import "server-only";
import { db } from "@/db";
import { sql } from "drizzle-orm";
import { buildCalendarReview, type ReviewData, type ReviewYear } from "@/lib/calendar-model";

// No inserts, updates, migrations or imports. This workspace is read-only.
export async function getReviewData(year: ReviewYear = 2027): Promise<ReviewData> {
  let connected = false;
  try {
    await db.execute(sql`select 1 as connection_check`);
    connected = true;
  } catch {
    // Source review remains readable even if the database is unavailable.
  }
  return { ...buildCalendarReview(year), database: { connected, readOnly: true } };
}

export function parseReviewYear(value: string | null): ReviewYear | null {
  if (value === null || value === "2027") return 2027;
  if (value === "2026") return 2026;
  return null;
}
