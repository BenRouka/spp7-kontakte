import { db } from "./index";
import { festivals, bands, locations, performances } from "./schema";

async function seed() {
  console.log("🌱 Seeding database...");

  // 1. Create Location
  const [location] = await db.insert(locations).values({
    name: "Bookwood Festival Ground",
    address: "Südharz",
    city: "Nordhausen / Umgebung",
    latitude: 51.3, // Approximate
    longitude: 10.8, // Approximate
  }).returning();

  // 2. Create Festival
  const [festival] = await db.insert(festivals).values({
    name: "BOOKWOOD",
    website: "www.mf-suedharz.de",
    locationId: location.id,
    tags: "Metal, Suedharz, Festival",
  }).returning();

  // 3. Create Bands
  const bandsData = [
    { name: "BRAINSTORM", genre: "Heavy/Power Metal", tags: "HeavyMetal, PowerMetal" },
    { name: "Lacrimas Profundere", genre: "Gothic/Doom Metal", tags: "GothicMetal, DoomMetal" },
    { name: "Zero Degree", genre: "Metal", tags: "Metal" },
    { name: "RÜCKHALT", genre: "Metal", tags: "Metal" },
    { name: "FIGHTING CHANCE", genre: "Metal", tags: "Metal" },
    { name: "VIREPTIC", genre: "Metal", tags: "Metal" },
    { name: "Buchfinken", genre: "Folk/Acoustic", tags: "Folk, Acoustic" },
    { name: "OUR MIRAGE", genre: "Metal", tags: "Metal" },
    { name: "Restrisiko", genre: "Metal", tags: "Metal" },
    { name: "MYRA", genre: "Metal", tags: "Metal" },
    { name: "Mandragora", genre: "Metal", tags: "Metal" },
    { name: "Titanith", genre: "Metal", tags: "Metal" },
    { name: "LETTERSSENT", genre: "Metal", tags: "Metal" },
    { name: "Prophecy / Rising Dead", genre: "Metal", tags: "Metal" },
    { name: "CALLING CHARISMA", genre: "Metal", tags: "Metal" },
    { name: "Endless Core", genre: "Metalcore/Deathcore", tags: "Metalcore, Deathcore" },
    { name: "MAGICAL HEART", genre: "Metal", tags: "Metal" },
    { name: "BURNING MISERY", genre: "Metal", tags: "Metal" },
  ];

  const insertedBands = await db.insert(bands).values(bandsData).returning();

  // 4. Create Performances (linking bands to festival)
  const performanceValues = insertedBands.map(band => ({
    festivalId: festival.id,
    bandId: band.id,
  }));

  await db.insert(performances).values(performanceValues);

  console.log("✅ Seeding complete!");
}

seed().catch(console.error);
