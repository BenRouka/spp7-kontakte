import { readFile } from "node:fs/promises";
import path from "node:path";
import { getAbgleichWorkspace } from "@/lib/abgleich-model";

export const dynamic = "force-dynamic";
export const runtime = "nodejs";

export async function GET(request: Request) {
  const query = new URL(request.url).searchParams;
  const format = query.get("format") || "json";
  const file = query.get("file");

  if (!["json", "md", "csv"].includes(format)) {
    return Response.json({ error: "Verfügbar: json, md, csv." }, { status: 400 });
  }

  try {
    const basePath = path.join(process.cwd(), "werkstatt", "03-berichte");
    const headers = { "Cache-Control": "no-store" };

    if (format === "json") {
      const data = await getAbgleichWorkspace();
      return Response.json(data, { headers });
    }

    if (format === "md") {
      const content = await readFile(path.join(basePath, "abgleich-bericht.md"), "utf8");
      return new Response(content, {
        headers: {
          ...headers,
          "Content-Type": "text/markdown; charset=utf-8",
          "Content-Disposition": 'attachment; filename="spp7-abgleich-stufe3-bericht.md"',
        },
      });
    }

    if (format === "csv") {
      const targetFile = file === "termine" ? "abgleich-termine.csv" : "abgleich-kontakte.csv";
      const content = await readFile(path.join(basePath, targetFile), "utf8");
      return new Response(content, {
        headers: {
          ...headers,
          "Content-Type": "text/csv; charset=utf-8",
          "Content-Disposition": `attachment; filename="${targetFile}"`,
        },
      });
    }

    return Response.json({ error: "Ungültiges Format" }, { status: 400 });
  } catch {
    return Response.json(
      { error: "Abgleich-Berichte konnten nicht gelesen werden." },
      { status: 500 },
    );
  }
}
