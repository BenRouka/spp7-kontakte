import { NextResponse } from "next/server";
import { sql } from "drizzle-orm";
import { db } from "@/db";
import { verifyFreeze } from "@/lib/freeze";

export const dynamic = "force-dynamic";

/**
 * Live-Verifikation (rein lesend):
 *  1. Freeze-Dateien gegen PRUEFSUMMEN.sha256 (byteidentisch?)
 *  2. Datenbankbestand gegen die Ground-Truth-Zahlen des Handoffs
 */
export async function GET() {
  try {
    const freeze = verifyFreeze();

    const counts = await db.execute(sql`
      select
        (select count(*) from regionen)           as regionen,
        (select count(*) from kontakte)           as kontakte,
        (select count(*) from termine)            as termine,
        (select count(*) from termin_zeitfenster)  as zeitfenster,
        (select count(*) from beschluesse)         as beschluesse
    `);
    const r = counts.rows[0] as Record<string, string | number>;
    const n = (v: string | number) => Number(v);

    const dbRows = [
      { tabelle: "regionen", erwartet: 9, ist: n(r.regionen) },
      { tabelle: "kontakte", erwartet: 35, ist: n(r.kontakte) },
      { tabelle: "termine", erwartet: 54, ist: n(r.termine) },
      { tabelle: "termin_zeitfenster", erwartet: 60, ist: n(r.zeitfenster) },
      { tabelle: "beschluesse", erwartet: 20, ist: n(r.beschluesse) },
    ].map((x) => ({ ...x, match: x.ist === x.erwartet }));

    const ok = freeze.ok && dbRows.every((x) => x.match);
    return NextResponse.json({
      ok,
      checkedAt: new Date().toISOString(),
      freeze: freeze.rows,
      db: dbRows,
    });
  } catch (e) {
    return NextResponse.json(
      { ok: false, error: e instanceof Error ? e.message : "Unbekannter Fehler" },
      { status: 500 },
    );
  }
}
