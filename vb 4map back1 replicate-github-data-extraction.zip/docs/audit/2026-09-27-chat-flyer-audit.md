# SPP7 Audit — Originalchat & 79 Bildquellen

**Datum:** 27.09.2026
**Art:** Rein lesende Prüfung. Keine Änderung an Events, Kontakten, Datenbank oder Oberfläche.
**Quellen:**
- `ChatExport_2026-09-20.zip` (GitHub, Originalchat: 121 Nachrichten, 79 Fotos)
- `replic modell extract-github-data-for-gis.zip` (GitHub, Originalmodell/Manifest)
- aktueller App-Datensatz `public/data/spp7-datasets.json`
- neue Texterkennung (OCR) über alle 79 Bilder, Engine tesseract.js (deu+eng)

---

## 1. Mengengerüst

| Kennzahl | Wert |
|---|---|
| Chat-Nachrichten gesamt | 121 |
| davon mit Foto | 79 |
| davon mit Text | 44 |
| Bilder gesamt | 79 (alle per OCR ausgewertet) |
| Events im aktuellen Datensatz | 196 |
| Kontakte im aktuellen Datensatz | 72 |
| Flyer-Quellen erfasst als Event | 71 |
| Flyer-Quellen anderem Event zugeordnet | 5 |
| Flyer-Quellen noch zu sichten | 3 |

**Bewerbungsstatus der 196 Events** (nur gesetzt, wenn Quelle eine Bewerbungsangabe enthält):
- offen: 9
- geschlossen: 31
- unklar: 3
- ohne Angabe: 153

**Gage-Status der 196 Events:**
- bestätigt (konkreter Wert aus Quelle): 33
- unklar (Hinweis ohne Betrag): 12
- keine Angabe: 151

**Im Chattext gefunden:**
- 62 unterschiedliche E-Mail-Adressen (davon stammen 61 aus einer einzigen Nachricht, dem bereits bekannten Rügen-Kontaktdump; siehe Abschnitt 3)
- 3 Telefonnummern
- 19 Web-URLs

---

## 2. Wichtigster Fund: Widerspruch bei F11

**Datensatz sagt:** F11 = „Hatikwa (hatikwa_official)“, Akustik-Konzert im Nomadenzelt.

**Tatsächliches Bild (photo_11, Nachricht 43940) zeigt:** ausschließlich einen Instagram-Post von **„Burgbrand Open Air“**:
- Location: Burgruine Brandenburg, Lauchröden, Thüringen
- Termin wurde verschoben auf **29.–31.07.2027**
- Ticket-Rückgabe möglich
- Kontakt: **shop@burgbrand.de**

Im Bildtext kommt „Hatikwa“ an keiner Stelle vor. Die Zuordnung „Hatikwa“ stammt bereits aus dem **Original-Datenmodell** (nicht aus unserer Erfassung) und wurde 1:1 übernommen.

**Einordnung:** Kein Vorwurf an unsere Arbeit, aber ein sachlicher Fehler im Ursprungsdatensatz, den wir bisher unverändert weitergeführt haben. Sollte korrigiert werden, sobald du zustimmst.

---

## 3. E-Mails — Abgleich mit dem Datensatz

- Die 62 E-Mail-Adressen aus dem Chattext stammen ganz überwiegend (61 von 62) aus **einer** Nachricht (44039) — dem bereits bekannten Rügen-Kontaktdump. Der ist bereits vollständig in den 72 Kontakten verarbeitet.
- **1 abweichende Schreibweise:** `info@westruegen.ne` — das ist der bereits dokumentierte Tippfehler zu `info@westruegen.net` bei Kontakt K19. Keine Handlung nötig, nur zur Vollständigkeit gemeldet.
- **Neu, aus einem Flyer-Bild (nicht aus Chattext):** `shop@burgbrand.de` auf Flyer 11 — hängt mit dem Fund aus Abschnitt 2 zusammen und ist noch nicht als Kontakt/Kanal erfasst.
- Die zweite auf einem Bild gefundene E-Mail (`info@maximusmet.de`, Flyer 76) ist bereits korrekt beim Michelaltermarkt-Event hinterlegt.

---

## 4. Telefonnummern — 2 von 3 unvollständig übernommen

| Nummer | Nachricht | Person/Organisation | Aktueller Stand im Datensatz |
|---|---|---|---|
| 02841/9994972 | 44035 | EGS | vollständig bei Kontakt K63 |
| +49 (0) 4127-929981 | 44014 | **Thomas Tegelhütter**, Schierenhöh 13, 25364 Brande-Hörnerkirchen | Nur Telefon + Ort bei Kontakt K64 hinterlegt. Name, Straße und 7 Webseiten/Social-Links aus derselben Nachricht fehlen. |
| 01520 9473245 | 44030 | **Wolfgang Schlegel**, Vorsitzender, Mittelstraße 16, 04435 Schkeuditz | Nur E-Mail bei Kontakt K61 hinterlegt. Name, Funktion, Adresse und Telefon fehlen. |

---

## 5. Zwei Events komplett unerfasst

Nachricht 44014 (Thomas Tegelhütter) nennt vier Termine. Zwei davon sind bereits als Event erfasst (Headbangers Open Air → K10, Hörnerfest → K09). **Zwei fehlen vollständig:**

- **Weihnachtsmarkt Barmstedt**, 27.–29.11.2026
- **MA Spektakel Barmstedt**, 29.+30.05.2027

Beide stammen vom selben Absender/Kontakt wie die bereits erfassten Termine und sind eindeutig einem Ort und Datum zuzuordnen.

---

## 6. Geldbeträge aus OCR — Abgleich mit Gage/Kosten-Feldern

10 Bilder enthalten einen erkennbaren Geldbetrag. 8 davon sind bereits korrekt in `GAGE` bzw. `KOSTEN` hinterlegt (F40, F41, F50, F52, F55, F58, F59, F72). Zwei Auffälligkeiten ohne Handlungsbedarf:

- **Flyer 10:** OCR liest „2026 €“ — das ist eine Fehllesung des Jahres „2026“ neben einem Store-Symbol, kein echter Geldbetrag.
- **Flyer 29:** OCR liest „3.000 Euro“ — stammt aus einem fremden Nachbar-Post („Bayern zahlt 3.000 Euro an alle…“), der bereits im Originalmodell als irrelevante Randnotiz vermerkt ist.

---

## 7. Bildqualität — 16 von 79 mit niedriger OCR-Konfidenz (unter 55 %)

Betroffen: Flyer 2, 5, 6, 7, 8, 14, 15, 18, 21, 25, 28, 32, 73, 74, 78, 79.

Davon:
- **21 und 74** sind bereits als „manuelle Sichtung nötig“ markiert — bekannt.
- **2, 5, 6, 7, 8, 14, 15, 18, 25, 28, 73** sind als „erfasst“ markiert — ihr Inhalt stammt **nicht** aus unserer OCR, sondern unverändert aus dem von Hand kuratierten Originalmodell. Die niedrige OCR-Konfidenz ist hier nur ein Nebenbefund, kein Qualitätsproblem unserer Erfassung.
- **32 und 79** sind als „neu erfasst“ markiert **und** stammen inhaltlich aus unserer (schwachen) OCR. Das sind die einzigen zwei Fälle, bei denen sich eine Prüfung am Originalbild wirklich lohnt.

---

## 8. Zusammenfassung — priorisierte Liste für die nächste Freigabe

1. **F11-Widerspruch klären:** Hatikwa vs. Burgbrand Open Air (Abschnitt 2)
2. **shop@burgbrand.de** als Kanal/Kontakt ergänzen (hängt an Punkt 1)
3. **Thomas Tegelhütter** (K64) um Name, Adresse, Webseiten ergänzen
4. **Wolfgang Schlegel** (K61) um Name, Funktion, Adresse, Telefon ergänzen
5. **2 neue Events** anlegen: Weihnachtsmarkt Barmstedt, MA Spektakel Barmstedt
6. **Flyer 32 und 79** am Originalbild gegenprüfen (schwache OCR, neu erfasst)

Alle übrigen geprüften Punkte (E-Mail-Dump, Geldbeträge, restliche Niedrig-Konfidenz-Bilder) erfordern **keine** Handlung — sie sind entweder bereits korrekt erfasst oder als bekannt/irrelevant dokumentiert.

---

*Dieser Bericht wurde ausschließlich lesend erstellt. Es wurden keine Dateien unter `src/`, `public/data/`, oder der Datenbank verändert.*
