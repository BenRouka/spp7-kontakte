import Link from "next/link";
import {
  Boxes,
  Image as ImageIcon,
  Link2,
  MapPin,
  MessagesSquare,
  Music2,
  Users,
} from "lucide-react";
import { Badge, Card, Empty, MonoValue, SectionHead } from "@/components/ui";
import {
  getAltEventListe,
  getAltKennzahlen,
  getGeoPruefliste,
  type AltFilter,
} from "@/lib/altbestand";

export const dynamic = "force-dynamic";

const FILTER: { key: AltFilter; label: string }[] = [
  { key: "alle", label: "Alle" },
  { key: "kuratiert", label: "Mit kuratiertem Termin" },
  { key: "rest", label: "Rest (Altbestand)" },
];

export default async function ArchivPage({
  searchParams,
}: {
  searchParams: Promise<{ f?: string; q?: string }>;
}) {
  const sp = await searchParams;
  const filter = (
    FILTER.some((x) => x.key === sp.f) ? sp.f : "alle"
  ) as AltFilter;
  const suche = sp.q ?? "";
  const [k, liste, geo] = await Promise.all([
    getAltKennzahlen(),
    getAltEventListe(filter, suche),
    getGeoPruefliste(),
  ]);

  return (
    <div className="space-y-10">
      <SectionHead
        eyebrow="Stufe 6 · Altbestand"
        title={
          <>
            Archiv — alles, was am Material hängt
            <span className="block text-[14px] font-normal leading-snug text-muted">
              Kuratierte Daten bleiben führend. Der Altbestand ergänzt als
              Prio&nbsp;2 und trägt überall seinen Herkunftsvermerk.
            </span>
          </>
        }
        right={
          <div className="flex gap-2">
            <Link
              href="/archiv/acts"
              className="inline-flex items-center gap-1.5 rounded-full border border-line px-3 py-1.5 font-mono text-[11px] uppercase tracking-[0.12em] text-muted transition-colors hover:border-lime/40 hover:text-lime"
            >
              <Music2 className="h-3.5 w-3.5" /> Bands
            </Link>
            <Link
              href="/archiv/flyer"
              className="inline-flex items-center gap-1.5 rounded-full border border-line px-3 py-1.5 font-mono text-[11px] uppercase tracking-[0.12em] text-muted transition-colors hover:border-lime/40 hover:text-lime"
            >
              <ImageIcon className="h-3.5 w-3.5" /> Flyer
            </Link>
          </div>
        }
      />

      <Card className="grid grid-cols-2 gap-6 p-6 sm:grid-cols-3 lg:grid-cols-6">
        <MonoValue label="Events" value={k.events} sub={`${k.eventsKuratiert} mit kuratiertem Termin`} />
        <MonoValue label="Termine verknüpft" value={`${k.termineVerknuepft}/54`} sub="Brücke, kein Überschreiben" />
        <MonoValue label="Bands" value={k.acts} sub={`${k.partners} Partner`} />
        <MonoValue label="Flyer" value={k.flyer} sub="mit Bild + OCR" />
        <MonoValue label="Chat" value={k.chat} sub="Nachrichten als Beleg" />
        <MonoValue label="Kontakte" value={`${k.kontakteVerknuepft}/${k.kontakte}`} sub="Kanalbezug zu KV" />
      </Card>

      <Card className="border-amber/25 bg-amber/[0.04] p-5">
        <div className="flex flex-wrap items-start gap-x-8 gap-y-3">
          <div className="flex items-start gap-2.5">
            <MapPin className="mt-0.5 h-4 w-4 shrink-0 text-amber" />
            <div>
              <p className="text-[13px] font-medium text-ink">
                Geo-Prüfliste · O-11 bleibt gesperrt
              </p>
              <p className="mt-1 max-w-2xl text-[12px] leading-relaxed text-muted">
                {k.geocodiert} von {k.events} Events haben Koordinaten — davon{" "}
                <strong className="text-amber">{k.geoZentroid} nur PLZ-Zentroid</strong>{" "}
                (1–10&nbsp;km, kein Veranstaltungsgelände). Koordinaten werden
                angezeigt, aber nicht als geprüft behandelt.
              </p>
            </div>
          </div>
          <div className="flex flex-wrap gap-1.5">
            {geo.map((g) => (
              <Badge
                key={g.qualitaet}
                tone={g.qualitaet === "zentroid" ? "amber" : "neutral"}
              >
                {g.qualitaet} {g.n}
              </Badge>
            ))}
          </div>
        </div>
      </Card>

      <div>
        <form className="mb-4 flex flex-wrap items-center gap-2" action="/archiv">
          {FILTER.map((f) => (
            <Link
              key={f.key}
              href={`/archiv?f=${f.key}${suche ? `&q=${encodeURIComponent(suche)}` : ""}`}
              className={
                filter === f.key
                  ? "rounded-full border border-lime/35 bg-lime/10 px-3 py-1.5 text-[12px] font-medium text-lime"
                  : "rounded-full border border-line px-3 py-1.5 text-[12px] font-medium text-muted transition-colors hover:text-ink"
              }
            >
              {f.label}
            </Link>
          ))}
          <input type="hidden" name="f" value={filter} />
          <input
            name="q"
            defaultValue={suche}
            placeholder="Suche Name, Ort, ID …"
            className="ml-auto w-full rounded-full border border-line bg-raised px-4 py-1.5 text-[12px] text-ink outline-none placeholder:text-muted/60 focus:border-lime/40 sm:w-64"
          />
        </form>

        <Card className="overflow-hidden">
          <div className="scrollbox overflow-x-auto">
            <table className="w-full min-w-[920px] border-collapse text-left">
              <thead>
                <tr className="border-b border-line bg-raised2/40">
                  {["ID", "Veranstaltung", "Ort", "Herkunft", "Bezug", "Material"].map(
                    (h) => (
                      <th
                        key={h}
                        className="px-4 py-2.5 font-mono text-[10px] uppercase tracking-[0.14em] text-muted"
                      >
                        {h}
                      </th>
                    ),
                  )}
                </tr>
              </thead>
              <tbody>
                {liste.map((e) => (
                  <tr
                    key={e.eventId}
                    className="border-b border-line/60 transition-colors last:border-0 hover:bg-raised2/30"
                  >
                    <td className="px-4 py-2.5">
                      <Link
                        href={`/archiv/${e.eventId}`}
                        className="font-mono text-[11px] text-lime hover:underline"
                      >
                        {e.eventId}
                      </Link>
                    </td>
                    <td className="max-w-[300px] px-4 py-2.5">
                      <Link
                        href={`/archiv/${e.eventId}`}
                        className="block truncate text-[13px] text-ink hover:text-lime"
                      >
                        {e.name}
                      </Link>
                      <span className="text-[11px] text-muted">{e.typ}</span>
                    </td>
                    <td className="px-4 py-2.5 text-[12px] text-ink-soft">
                      {e.ort ? (
                        <>
                          {e.plz ? (
                            <span className="tnum font-mono text-[11px] text-muted">
                              {e.plz}{" "}
                            </span>
                          ) : null}
                          {e.ort}
                        </>
                      ) : (
                        <Empty>ohne Ort</Empty>
                      )}
                    </td>
                    <td className="px-4 py-2.5">
                      <Badge
                        tone={
                          e.quelleTyp === "Sündenfrei"
                            ? "lime"
                            : e.quelleTyp.includes("KI")
                              ? "amber"
                              : "neutral"
                        }
                      >
                        {e.quelleTyp}
                      </Badge>
                    </td>
                    <td className="px-4 py-2.5">
                      {e.sfIds.length > 0 ? (
                        <span className="inline-flex flex-wrap gap-1">
                          {e.sfIds.map((sf) => (
                            <Badge key={sf} tone="lime">
                              <Link2 className="h-2.5 w-2.5" />
                              {sf}
                            </Badge>
                          ))}
                        </span>
                      ) : (
                        <Empty>Rest</Empty>
                      )}
                    </td>
                    <td className="px-4 py-2.5">
                      <span className="flex flex-wrap items-center gap-1.5 font-mono text-[10px] text-muted">
                        {e.actCount > 0 ? (
                          <span className="inline-flex items-center gap-1">
                            <Music2 className="h-3 w-3" />
                            {e.actCount}
                          </span>
                        ) : null}
                        {e.flyer ? (
                          <span className="inline-flex items-center gap-1">
                            <ImageIcon className="h-3 w-3" />
                            {e.flyer}
                          </span>
                        ) : null}
                        {e.bewerbungStatus ? (
                          <Badge
                            tone={
                              e.bewerbungStatus === "offen" ? "lime" : "neutral"
                            }
                          >
                            {e.bewerbungStatus}
                          </Badge>
                        ) : null}
                        {e.lat ? (
                          <span
                            className={
                              e.geoQualitaet === "zentroid"
                                ? "inline-flex items-center gap-1 text-amber"
                                : "inline-flex items-center gap-1"
                            }
                          >
                            <MapPin className="h-3 w-3" />
                            {e.geoQualitaet}
                          </span>
                        ) : null}
                      </span>
                    </td>
                  </tr>
                ))}
                {liste.length === 0 ? (
                  <tr>
                    <td colSpan={6} className="px-4 py-10 text-center">
                      <Empty>keine Treffer</Empty>
                    </td>
                  </tr>
                ) : null}
              </tbody>
            </table>
          </div>
        </Card>
        <p className="mt-3 flex items-center gap-2 font-mono text-[11px] text-muted">
          <Boxes className="h-3.5 w-3.5" />
          {liste.length} Einträge · {k.tags} Tag-Zuordnungen ·{" "}
          {k.feedVerwaist} verwaiste Feed-Referenz (F29, O-07)
          <Users className="ml-2 h-3.5 w-3.5" />
          <MessagesSquare className="h-3.5 w-3.5" />
          interner Gebrauch · B-17
        </p>
      </div>
    </div>
  );
}
