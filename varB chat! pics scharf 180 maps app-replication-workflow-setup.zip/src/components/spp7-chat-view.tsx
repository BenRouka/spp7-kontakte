"use client";

import { useMemo } from "react";
import { ArrowUpRight, Forward, Link2, MessagesSquare, Search } from "lucide-react";

export type ChatMessage = {
  MSG: string;
  TYP: string;
  DATUM: string;
  ABSENDER: string;
  WEITERGELEITET_VON: string;
  TEXT: string;
  LINKS: string;
  MEDIUM: string;
  FLYER: string;
  EVENT_ID: string;
  EVENT_NAME: string;
  AKTION: string;
};

export type ChatPayload = {
  meta: { chat: string; chatId: string; typ: string; nachrichten: number; quelle: string };
  messages: ChatMessage[];
};

const dayFormat = new Intl.DateTimeFormat("de-DE", { weekday: "long", day: "2-digit", month: "long", year: "numeric" });
const timeFormat = new Intl.DateTimeFormat("de-DE", { hour: "2-digit", minute: "2-digit" });

function initials(name: string) {
  return name
    .split(/\s+/)
    .filter(Boolean)
    .slice(0, 2)
    .map((part) => part[0]?.toUpperCase() ?? "")
    .join("");
}

export function ChatView({
  chat,
  search,
  setSearch,
  onOpenFlyer,
}: {
  chat: ChatPayload;
  search: string;
  setSearch: (value: string) => void;
  onOpenFlyer: (flyer: string) => void;
}) {
  const query = search.trim().toLocaleLowerCase("de");
  const messages = useMemo(
    () =>
      chat.messages.filter(
        (message) =>
          !query ||
          [message.TEXT, message.ABSENDER, message.EVENT_NAME, message.FLYER, message.WEITERGELEITET_VON, message.LINKS]
            .join(" ")
            .toLocaleLowerCase("de")
            .includes(query),
      ),
    [chat.messages, query],
  );

  const days = useMemo(() => {
    const groups: Array<{ day: string; items: ChatMessage[] }> = [];
    for (const message of messages) {
      const day = dayFormat.format(new Date(message.DATUM));
      const last = groups[groups.length - 1];
      if (last && last.day === day) last.items.push(message);
      else groups.push({ day, items: [message] });
    }
    return groups;
  }, [messages]);

  const withFlyer = chat.messages.filter((message) => message.FLYER).length;
  const forwarded = chat.messages.filter((message) => message.WEITERGELEITET_VON).length;

  return (
    <div className="chat-view">
      <section className="view-intro">
        <div>
          <span className="model-badge"><MessagesSquare className="size-4" /> Quell-Chat</span>
          <h2>Der Verlauf hinter den <em>Daten.</em></h2>
          <p>
            Rohnachrichten aus der Telegram-Gruppe „{chat.meta.chat}“ – unverändert, inklusive Weiterleitungen und der
            Flyer-Zuordnung zu jedem Bild.
          </p>
        </div>
        <div className="pipeline-total"><strong>{chat.meta.nachrichten}</strong><span>Nachrichten<br />im Export</span></div>
      </section>

      <section className="chat-stats">
        <div><strong>{withFlyer}</strong><small>mit Flyer</small></div>
        <div><strong>{forwarded}</strong><small>weitergeleitet</small></div>
        <div><strong>{chat.messages.filter((m) => m.LINKS).length}</strong><small>mit Links</small></div>
        <div><strong>{messages.length}</strong><small>angezeigt</small></div>
      </section>

      <div className="panel chat-panel">
        <div className="contact-toolbar">
          <label className="table-search">
            <Search className="size-4" />
            <input value={search} onChange={(event) => setSearch(event.target.value)} placeholder="Nachricht, Absender oder Event suchen…" />
          </label>
          <span>{messages.length} von {chat.meta.nachrichten}</span>
        </div>

        <div className="chat-stream">
          {days.map((group) => (
            <div className="chat-day" key={group.day}>
              <p className="chat-day-label"><span>{group.day}</span></p>
              {group.items.map((message) =>
                message.TYP === "Service" ? (
                  <div className="chat-service" key={message.MSG}>
                    {message.AKTION === "create_group" ? "Gruppe erstellt" : message.AKTION} · {message.ABSENDER}
                  </div>
                ) : (
                  <article className="chat-bubble" key={message.MSG}>
                    <span className="chat-avatar">{initials(message.ABSENDER || "?")}</span>
                    <div className="chat-body">
                      <header>
                        <strong>{message.ABSENDER}</strong>
                        <time>{timeFormat.format(new Date(message.DATUM))}</time>
                        <small>MSG {message.MSG}</small>
                      </header>
                      {message.WEITERGELEITET_VON && (
                        <p className="chat-forward"><Forward className="size-3.5" /> Weitergeleitet von {message.WEITERGELEITET_VON}</p>
                      )}
                      {message.FLYER && (
                        <button className="chat-flyer" onClick={() => onOpenFlyer(message.FLYER)}>
                          {/* eslint-disable-next-line @next/next/no-img-element */}
                          <img src={`/flyers/flyer_${message.FLYER}_thumb.jpg`} alt={`Flyer ${message.FLYER}`} loading="lazy" />
                          <span>
                            <small>Flyer {message.FLYER}{message.EVENT_ID ? ` · ${message.EVENT_ID}` : ""}</small>
                            <b>{message.EVENT_NAME || "Ohne Event-Zuordnung"}</b>
                            <em>Original öffnen <ArrowUpRight className="size-3.5" /></em>
                          </span>
                        </button>
                      )}
                      {message.MEDIUM && !message.FLYER && <p className="chat-media">Medium: {message.MEDIUM} (nicht im Export enthalten)</p>}
                      {message.TEXT && <p className="chat-text">{message.TEXT}</p>}
                      {message.LINKS && (
                        <p className="chat-links">
                          {message.LINKS.split(" ").filter(Boolean).map((href) => (
                            <a key={href} href={href} target="_blank" rel="noreferrer"><Link2 className="size-3.5" />{href.replace(/^https?:\/\//, "").slice(0, 48)}…</a>
                          ))}
                        </p>
                      )}
                    </div>
                  </article>
                ),
              )}
            </div>
          ))}
          {!messages.length && <p className="chat-empty">Keine Nachricht passt zur Suche.</p>}
        </div>
      </div>
    </div>
  );
}
