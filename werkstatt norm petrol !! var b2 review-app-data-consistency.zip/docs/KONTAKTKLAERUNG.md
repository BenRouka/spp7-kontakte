# SPP7 · Kontaktklärung nach Spaltenvorschlag v1

## Umfang und Grenze

Diese Ergänzung dokumentiert die aktuelle Nutzerklärung zu Parent/Child, Mönchgut, Baabe, fehlenden Werten und internationaler Telefonform.

Die Option-A-Oberfläche behält ihr Petrol-Layout. Änderungen sind lesend im Reiter „CSV-Aufbau“ sichtbar. Keine Datenbank-/Schemaänderung, kein Import und keine vollständige Normierung der 32 Adressblöcke oder 54 Terminzeilen. Die früheren FREEZE-Dokumente und Originalquellen bleiben unverändert; sie sind historische Prüfpunkte, nicht das neue Spaltenmodell.

## Neue Regeln

- Belegte Parent-Gruppen und Child-Standorte getrennt führen. Mehrere Außenstellen besitzen eigene IDs und Adressen.
- Mönchgut: Parent KVG01, Children KV12 (Middelhagen) und KV13 (Thiessow).
- Baabe: Parent KVG02, Children KV09 (Kurverwaltung) und KV10 (Infopavillion).
- Gleiche Telefonnummer oder E-Mail begründet weder eine Dublette noch eine Zusammenführung.
- „Kurverwaltung Mönchgut“ und „Tourist-Information Middelhagen“ stehen in der gelieferten Zuordnung beim selben Child-Standort. Zwei Namenszeilen allein sind kein Beleg für zwei Außenstellen. Bei weiteren Beziehungen: keine Hierarchie ohne Beleg festlegen.
- Bei Baabes Infopavillion ist keine E-Mail genannt. willkommen@baabe.de gehört zur Kurverwaltung und wird nicht übertragen.
- Fehlende Angaben anzeigen als `-`, intern null und Fehlstatus. Originale Felder nicht mit erfundenen Strichen füllen. `-` ist kein Kontaktwert, keine Adresse und keine wählbare Telefonnummer.
- Internationale Telefonform ist zusätzlich für diese deutsche/Rügen-Quelle freigegeben: `(0 38 38) 80 77 80` → `+49 3838 807780`, maschinenlesbar `+493838807780`.
- Die nationale führende 0 entfällt nur bei der ausdrücklich freigegebenen DE-Umrechnung. Bereits internationale Formen bleiben erhalten; andere Länder/local-only-Werte werden nicht blind in +49 umgewandelt. Die Umrechnung ist keine Erreichbarkeitsprüfung.
- Ein URL-Protokoll wurde damit nicht freigegeben: www-Adressen bleiben ohne angenommenes http/https.

## Nutzerergänzungen und Quellenstand

| Standort | Wert | MD-Original | Arbeitsebene |
|---|---|---|---|
| KV12 · Middelhagen | Internet | nicht genannt | www.ostseebad-moenchgut.de, Nutzerangabe |
| KV12 · Middelhagen | E-Mail | nicht genannt | info@ostseebad-moenchgut.de, Nutzerangabe |
| KV13 · Thiessow | Telefon | nicht genannt | +49 38308 66010, Nutzerangabe |
| KV13 · Thiessow | Fax | nicht genannt | - ausdrücklich geliefert, intern null |
| KV10 · Baabe Infopavillion | E-Mail / Internet / Fax | nicht genannt | weiterhin -, keine Vererbung |

Die als Chattext zitierten Werte sind als **Nutzerzitate** dokumentiert. Eine Original-Chat-ID oder erneute Chat-Verifikation wurde nicht geraten.

Zählungen müssen getrennt bleiben:
- Original-MD: 32 Standorte, 4 Doppel-Namensblöcke, 119 Kontaktwerte, 2 Blöcke ohne E-Mail.
- Ergänzter Stand: 3 neue Kontaktwerte → 122; noch 1 E-Mail-Lücke (Infopavillion KV Baabe).
- Die zusätzliche Telefonformatierung ist kein weiterer Kontaktweg.
- Die zwei Parent-Gruppen sind bisher ausdrücklich benannte Anzeige-/Zuordnungsgruppen, keine ungeprüfte rechtliche Organisationshierarchie.

## Aktualisierter CSV-Vorschlag

`spaltenvorschlag-v2` ergänzt eine fünfte Vorlage `kurverwaltungen-gruppen.csv`. Die vier bisherigen Vorschlagsdateien bleiben erhalten. Der gesamte Fünf-Dateien-Aufbau und die vollständige Normierung sind nicht automatisch freigegeben.

Die Parent-Datei enthält Gruppen-ID und Herkunft; Standorte erhalten `parent_id`, Zuordnungsbeleg und Hierarchiestatus. Kontaktwege erhalten MD-/Nutzerherkunft, Originalwert und zusätzliche internationale Telefonform. Die MD-/TXT-Originale und das Zeitmodell bleiben unverändert.

## Reproduzierbarkeit

- `node scripts/write-normalization-proposal.mjs`: prüft Rohzählungen, Parent/Child, Nutzerergänzungen, fehlende Werte, Telefonumrechnung und synchron erzeugte Dateien, ohne zu schreiben.
- `--write`: erzeugt nur Vorschlagsdokumente, fünf Kopfzeilen-Vorlagen und die vier Beispielstandorte mit Belegen; kein DB-Import.
- `node scripts/check-time-model.mjs`: weiterhin unveränderte A/B-Zeitmodell-Parität.
- `werkstatt/02-normiert/KONTAKTKLAERUNG.md`: lesbarer konkreter Vier-Standorte-Bericht.
- `werkstatt/02-normiert/nutzer-kontaktklaerung.json`: benannte Nutzerwerte/Zuordnungen.
- `werkstatt/02-normiert/kontaktklaerung-beispiele.json`: MD-/Nutzervergleich und Telefonableitungen.
- `/api/review/contact-hierarchy`: lesende JSON-Prüfansicht; `?format=md` als Bericht.
