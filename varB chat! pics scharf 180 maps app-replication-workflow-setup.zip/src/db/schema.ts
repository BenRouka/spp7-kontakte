import {
  doublePrecision,
  integer,
  pgTable,
  text,
  timestamp,
} from "drizzle-orm/pg-core";

export const spp7Events = pgTable("spp7_events", {
  eventId: text("event_id").primaryKey(),
  sourceType: text("source_type").notNull(),
  flyer: text("flyer"),
  message: text("message"),
  type: text("type").notNull(),
  name: text("name").notNull(),
  location: text("location"),
  street: text("street"),
  postalCode: text("postal_code"),
  city: text("city"),
  region: text("region"),
  country: text("country"),
  latitude: doublePrecision("latitude"),
  longitude: doublePrecision("longitude"),
  geoStatus: text("geo_status"),
  admission: text("admission"),
  fee: text("fee"),
  conditions: text("conditions"),
  application: text("application"),
  applicationStatus: text("application_status"),
  feeStatus: text("fee_status"),
  aiRank: integer("ai_rank"),
  tags: text("tags"),
  shortDescription: text("short_description"),
  longDescription: text("long_description"),
  fit: text("fit"),
  nextStep: text("next_step"),
  unknown: text("unknown"),
  source: text("source"),
  createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
});

export const spp7Contacts = pgTable("spp7_contacts", {
  contactId: text("contact_id").primaryKey(),
  organisation: text("organisation").notNull(),
  type: text("type"),
  channel: text("channel"),
  city: text("city"),
  region: text("region"),
  latitude: doublePrecision("latitude"),
  longitude: doublePrecision("longitude"),
  message: text("message"),
  note: text("note"),
  createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
});

export const spp7ChatMessages = pgTable("spp7_chat_messages", {
  messageId: text("message_id").primaryKey(),
  kind: text("kind").notNull(),
  sentAt: timestamp("sent_at", { withTimezone: false }).notNull(),
  author: text("author"),
  forwardedFrom: text("forwarded_from"),
  body: text("body"),
  links: text("links"),
  media: text("media"),
  flyer: text("flyer"),
  eventId: text("event_id"),
  eventName: text("event_name"),
  action: text("action"),
  createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
});

export type Spp7Event = typeof spp7Events.$inferSelect;
export type Spp7ChatMessage = typeof spp7ChatMessages.$inferSelect;
export type Spp7Contact = typeof spp7Contacts.$inferSelect;
