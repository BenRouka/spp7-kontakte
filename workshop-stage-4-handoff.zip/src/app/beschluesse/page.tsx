import type { Metadata } from "next";
import { CheckCircle2, CircleDashed, Gavel, Scale } from "lucide-react";
import { BeschlussRow, loadFreeze } from "@/lib/freeze";
import { Badge, FieldLabel, Panel, Section, cx } from "@/components/ui";

export const metadata: Metadata = {
  title: "Beschlüsse · Werkstatt Stufe 4",
};

const BEREICH_ORDER = ["Kontakte", "Termine", "Archiv", "Ablauf", "Offen"];

function StatusBadge({ status }: { status: string }) {
  const entschieden = status === "entschieden";
  return (
    <span
      className={cx(
        "inline-flex items-center gap-1.5 rounded-md border px-2 py-0.5 font-mono text-[10.5px] font-semibold uppercase tracking-[0.1em]",
        entschieden
          ? "border-lime/40 bg-lime/[0.08] text-lime"
          : "border-amber/40 bg-amber/[0.08] text-amber"
      )}
    >
      {entschieden ? (
        <CheckCircle2 className="h-3 w-3" />
      ) : (
        <CircleDashed className="h-3 w-3" />
      )}
      {status}
    </span>
  );
}

function BeschlussCard({ b }: { b: BeschlussRow }) {
  return (
    <Panel
      className={cx(
        "p-4",
        b.status !== "entschieden" && "border-amber/30 bg-amber/[0.015]"
      )}
    >
      <div className="flex flex-wrap items-center gap-2.5">
        <span className="font-mono text-[12px] font-bold text-lime">{b.id}</span>
        <h3 className="text-[14px] font-semibold text-ink">{b.titel}</h3>
        <span className="ml-auto">
          <StatusBadge status={b.status} />
        </span>
      </div>
      <div className="mt-3 grid gap-3 md:grid-cols-3">
        <div className="rounded-lg border border-line-soft bg-base/50 p-3">
          <p className="mb-1 flex items-center gap-1.5 text-lime">
            <Scale className="h-3 w-3" />
            <FieldLabel>Prio 1 · Basis</FieldLabel>
          </p>
          <p className="text-[11.5px] leading-relaxed text-ink-soft">{b.prio1}</p>
        </div>
        <div className="rounded-lg border border-line-soft bg-base/50 p-3">
          <p className="mb-1 flex items-center gap-1.5 text-amber">
            <Scale className="h-3 w-3" />
            <FieldLabel>Prio 2 · Ergänzung</FieldLabel>
          </p>
          <p className="text-[11.5px] leading-relaxed text-ink-soft">{b.prio2}</p>
        </div>
        <div className="rounded-lg border border-lime/20 bg-lime/[0.03] p-3">
          <p className="mb-1">
            <FieldLabel>Maßnahme</FieldLabel>
          </p>
          <p className="text-[11.5px] leading-relaxed text-ink">{b.massnahme}</p>
        </div>
      </div>
    </Panel>
  );
}

export default function BeschluessePage() {
  const { beschluesse } = loadFreeze();
  const entschieden = beschluesse.filter((b) => b.status === "entschieden").length;
  const provisorisch = beschluesse.filter((b) => b.status === "provisorisch").length;

  const gruppen = BEREICH_ORDER.map((bereich) => ({
    bereich,
    rows: beschluesse.filter((b) => b.bereich === bereich),
  })).filter((g) => g.rows.length > 0);

  return (
    <>
      <div className="border-b border-line pb-8">
        <p className="font-mono text-[10.5px] font-semibold uppercase tracking-[0.24em] text-amber">
          Verbindlich · beschlussverzeichnis.csv
        </p>
        <h1 className="mt-3 flex flex-wrap items-center gap-3 text-[30px] font-semibold tracking-tight text-ink sm:text-[38px]">
          <Gavel className="h-7 w-7 text-lime" />
          Beschlussverzeichnis — {beschluesse.length} Beschlüsse
        </h1>
        <p className="mt-4 max-w-3xl text-[13px] leading-relaxed text-muted">
          Jeder Beschluss mit Prio-1-Basis, Prio-2-Ergänzung, Maßnahme und Status.
          Prio 1 (MD / offizielle Website / Register) gilt immer; Prio 2 (Chat /
          App-Altbestand) ergänzt Lücken und überschreibt nie Prio 1 (B-15).
        </p>
        <div className="mt-4 flex flex-wrap gap-2">
          <Badge tone="a">{entschieden} entschieden</Badge>
          <Badge tone="warn">{provisorisch} provisorisch</Badge>
          <Badge tone="mute">B-01 … B-20 · lückenlos</Badge>
        </div>
      </div>

      {gruppen.map(({ bereich, rows }) => (
        <Section
          key={bereich}
          eyebrow={`Bereich · ${rows.length} Beschlüsse`}
          title={bereich}
        >
          <div className="space-y-3">
            {rows.map((b) => (
              <BeschlussCard key={b.id} b={b} />
            ))}
          </div>
        </Section>
      ))}
    </>
  );
}
