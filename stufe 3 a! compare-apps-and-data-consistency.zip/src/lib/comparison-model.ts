import type { ContactWorkspace, NormalizedContact } from "@/lib/contact-model";
import { NORMALIZED_MISSING_VALUE as MISSING, normalizedCsvFile } from "@/lib/normalization-csv";

export const COMPARISON_VERSION = "abgleich-01-v1";
export type ArchiveRecord = Record<string, string>;
export type ArchiveDatasets = Record<string, ArchiveRecord[]>;
export type ScheduleReference = Record<string, string>;
export type FileEvidence = { path: string; sha256: string; role: string };
export type FieldComparison = { field: string; reference: string; originalReference: string; provenance: string; inventory: string;
  result: "gleich" | "enthalten" | "abweichender_text" | "fehlt" | "nicht_strukturiert" | "quelle_offen" | "nicht_vergleichbar"; note: string };
export type ContactCandidate = { id: string; label: string; type: string; city: string; channel: string; citation: string;
  nameEvidence: string; channelEvidence: string[]; sharedWith: string[]; fields: FieldComparison[]; personal: boolean };
export type ContactComparison = { id: string; title: string; path: string; citation: string; status: "name_und_kanal" | "nur_kanal" | "nur_name" | "kein_kandidat";
  candidates: ContactCandidate[]; explanation: string; originalMissing: string; workingMissing: string; supplementary: boolean };
export type EventCandidate = { id: string; label: string; city: string; postalCode: string; sourceType: string; citation: string;
  nameEvidence: string; placeEvidence: string; postcodeEqual: boolean; completePeriodSet: boolean;
  matchedPeriods: number; dateIds: string[]; referencePeriodCount: number; sameYear: boolean;
  dates: Array<{ id: string; from: string; to: string; kind: string; citation: string }>;
  fields: FieldComparison[]; evidence: "datum_ort" | "teilzeitraum" | "ort_name" | "nur_ort" | "datum_name_ohne_ort" };
export type ScheduleComparison = { id: string; title: string; year: number; place: string; dateOriginal: string; citation: string;
  sourceStatus: string; dateOrigin: string; periods: Array<{ from: string; to: string }>;
  status: "datum_ort" | "teilzeitraum" | "andere_zeit" | "nur_anderes_jahr" | "nur_ortsbezug" | "datum_name_ohne_ort" | "kein_kandidat" | "quelle_offen";
  candidates: EventCandidate[]; explanation: string };
export type DecisionFinding = { id: string; area: "kontakte" | "termine" | "bestand"; severity: "konflikt" | "luecke" | "pruefen";
  title: string; referenceIds: string[]; inventoryIds: string[]; evidence: string; recommendation: string; question: string; decision: "offen" };
export type InventoryIssue = { id: string; kind: string; dataset: string; records: string[]; evidence: string };
export type ComparisonReport = {
  version: typeof COMPARISON_VERSION; contactModel: string; missingValue: string; scope: string; inputFiles: FileEvidence[];
  method: string[];
  summary: { contacts: { references: number; inventory: number; byStatus: Record<ContactComparison["status"], number>; sharedReferenceChannels: number; candidatePairs: number; unlinkedInventory: number };
    schedules: { references: number; year2026: number; year2027: number; byStatus: Record<ScheduleComparison["status"], number>;
      datePlaceRows: number; nameSupportedDatePlaceRows: number; noDatePlaceRows: number; openSourceRows: number; matchedPeriodCount: number; referencePeriodCount: number };
    inventory: { datasetCounts: Record<string, number>; eventCount: number; dateRows: number; contacts: number; messages: number; geocodedEvents: number;
      geocodedContacts: number; withoutDateRows: number; missingStartISO: number; noEndISO: number; dateYears: Record<string, number>; sourceTypes: Record<string, number> };
    findings: number };
  contacts: ContactComparison[]; schedules: ScheduleComparison[]; findings: DecisionFinding[];
  unmatchedContacts: Array<{ id: string; label: string; type: string; citation: string; personal: boolean }>;
  unmatchedEvents: Array<{ id: string; label: string; sourceType: string; citation: string }>;
  issues: InventoryIssue[];
};
const present = (value: string | undefined) => !!value && value !== MISSING && value !== "-" && value.trim() !== "";
const shown = (value: string | undefined) => present(value) ? value! : MISSING;
const PRIVATE_LABEL = "Personenkontakt · Name ausgeblendet";
const PRIVATE_CHANNEL = "Personenkanal · ausgeblendet";
const archiveFile = "public/data/spp7-datasets.json";
const cite = (dataset: string, index: number) => `${archiveFile}#/datasets/${dataset}/${index}`;
const fold = (value: string) => value.normalize("NFD").replace(/[\u0300-\u036f]/g, "").toLowerCase().replaceAll("ß", "ss").replace(/[^a-z0-9]+/g, " ").trim().replace(/\s+/g, " ");
const words = (value: string) => fold(value).split(" ").filter(Boolean);
const containsWords = (whole: string, part: string) => !!part && (` ${whole} `).includes(` ${part} `);
function contactNameKey(value: string) {
  return words(value).filter((word) => !["e", "v", "gmbh", "co", "kg"].includes(word))
    .map((word) => word === "info" ? "information" : word).join(" ");
}
function contactNameEvidence(reference: NormalizedContact, inventory: ArchiveRecord) {
  const keys = [reference.name_haupt_original, reference.name_zusatz_original, reference.name_zusatz_normiert, reference.name_zusatz_ergaenzung,
    ...reference.name_haupt_original.split("/")].filter(present).map((value) => ({ value, key: contactNameKey(value) }));
  const key = contactNameKey(inventory.ORGANISATION || "");
  for (const candidate of keys) if (candidate.key === key && key) return `Namenswortfolge gleich (Interpunktion/Rechtsformkürzel/Info-Schreibung vereinheitlicht): ${candidate.value}`;
  for (const candidate of keys) {
    const left = candidate.key.split(" "), right = key.split(" ");
    if (left.length >= 2 && right.length >= 2 && (containsWords(candidate.key, key) || containsWords(key, candidate.key))) {
      return `Wörtlich enthaltene Namenswortfolge: ${candidate.value} ↔ ${inventory.ORGANISATION}`;
    }
  }
  return MISSING;
}
function emailValues(text: string) { return Array.from(text.matchAll(/[a-z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-z0-9.-]+\.[a-z]{2,}/gi), (match) => match[0].toLowerCase()); }
function phoneKey(text: string) {
  if (!present(text) || text.includes("@")) return "";
  let value = text.replace(/\D+/g, "");
  if (text.includes("+49") || value.startsWith("0049")) { value = value.replace(/^(0049|49)0?/, "0"); }
  return value.length >= 6 ? value : "";
}
function referenceChannelKeys(contact: NormalizedContact) {
  return [...new Set([contact.email_1_normiert, contact.email_2_normiert].filter(present).map((v) => `email:${v.toLowerCase()}`)
    .concat(present(contact.telefon_normiert) ? [`telefon:${phoneKey(contact.telefon_normiert)}`] : []))];
}
function inventoryChannelKeys(record: ArchiveRecord) {
  const text = record.EMAIL_TELEFON || "";
  const emails = emailValues(text);
  if (emails.length) return emails.map((email) => `email:${email}`);
  const phone = phoneKey(text); return phone ? [`telefon:${phone}`] : [];
}
function contactFields(reference: NormalizedContact, record: ArchiveRecord, personal: boolean): FieldComparison[] {
  const result: FieldComparison[] = [];
  const add = (field: string, value: string, original: string, provenance: string, stored: string, structured: boolean, note = MISSING) => {
    const same = field === "Telefon" ? phoneKey(value) !== "" && phoneKey(value) === phoneKey(stored)
      : field.startsWith("E-Mail") ? value.toLowerCase() === stored.toLowerCase() : fold(value) === fold(stored);
    let status: FieldComparison["result"] = !present(value) ? "quelle_offen" : !structured ? "nicht_strukturiert" : !present(stored) ? "fehlt" : same ? "gleich" : "abweichender_text";
    if (personal && structured && field !== "Ort") status = "nicht_vergleichbar";
    result.push({ field, reference: shown(value), originalReference: shown(original), provenance: shown(provenance),
      inventory: personal && field === "Name" ? PRIVATE_LABEL : personal && ["E-Mail 1", "E-Mail 2", "Telefon"].includes(field) ? PRIVATE_CHANNEL : shown(stored), result: status, note });
  };
  const notes = record.NOTIZ || "";
  const inNote = (value: string, telephone = false) => {
    if (!present(value)) return MISSING;
    if (telephone) {
      const labeled = Array.from(notes.matchAll(/(?:Tel\.|Telefon:)\s*([()+\d\s/.-]+)/gi), (match) => match[1]);
      return phoneKey(value) !== "" && labeled.some((part) => phoneKey(part) === phoneKey(value))
        ? "Referenz-Ziffernfolge in ausdrücklich als Telefon bezeichnetem NOTIZ-Teil vorhanden; bleibt Freitext, kein strukturiertes Feld." : MISSING;
    }
    return containsWords(fold(notes), fold(value))
      ? "Referenzwert wörtlich im NOTIZ-Text vorhanden; bleibt Freitext, kein strukturiertes Feld." : MISSING;
  };
  const source = `MD-Zeilen ${reference.quellzeile}`;
  add("Name", reference.name_haupt_original + (present(reference.name_zusatz_normiert) ? ` / ${reference.name_zusatz_normiert}` : ""), reference.name_haupt_original,
    present(reference.name_zusatz_ergaenzung) ? reference.name_zusatz_herkunft : source, record.ORGANISATION, true,
    "Abweichende Schreibweise ist nicht automatisch ein Sachfehler oder Identitätsnachweis.");
  add("Ort", reference.ort_normiert, reference.plz_ort_original, source, record.ORT, true,
    present(reference.ortsteil_normiert) && fold(record.ORT || "").includes(fold(reference.ortsteil_normiert)) ? "Bestands-Ortsfeld enthält den benannten Ortsteil; keine separate Ortsteilspalte." : "Nur Textvergleich, keine geografische Korrektur.");
  add("Straße", reference.strasse_original, reference.strasse_original, source, MISSING, false, inNote(reference.strasse_original));
  add("PLZ", reference.plz_normiert, reference.plz_ort_original, source, MISSING, false, inNote(reference.plz_normiert));
  const inventoryEmails = emailValues(record.EMAIL_TELEFON || "");
  const inventoryPhone = !inventoryEmails.length && phoneKey(record.EMAIL_TELEFON || "") ? record.EMAIL_TELEFON : MISSING;
  add("Telefon", reference.telefon_normiert, reference.telefon_original, reference.telefon_herkunft, inventoryPhone, false, inNote(reference.telefon_normiert, true));
  add("Fax", reference.fax_normiert, reference.fax_original, reference.fax_herkunft, MISSING, false);
  add("Web", reference.web_normiert, reference.web_original, reference.web_herkunft, MISSING, false, inNote(reference.web_normiert));
  for (const [index, value] of [reference.email_1_normiert, reference.email_2_normiert].entries()) {
    const original = index === 0 ? reference.email_1_original : reference.email_2_original;
    const provenance = index === 0 ? reference.email_1_herkunft : source;
    const match = inventoryEmails.find((email) => email === value.toLowerCase());
    add(`E-Mail ${index + 1}`, value, original, provenance, match || inventoryEmails.join("; ") || MISSING, true,
      "Bestand hat nur EMAIL_TELEFON; keine getrennten Kanal-/Zweckspalten.");
  }
  add("Ortsteil", reference.ortsteil_normiert, reference.ortsteil_original, reference.ortsteil_herkunft, MISSING, false);
  add("Geografischer Parent", reference.parent_id, reference.ort_original, reference.hierarchie_herkunft, MISSING, false);
  add("Organisatorischer Parent", reference.organisations_parent_id, MISSING, reference.beziehungsherkunft, MISSING, false);
  return result;
}
function compareContacts(workspace: ContactWorkspace, inventory: ArchiveRecord[]) {
  const shared = new Map<string, string[]>();
  for (const ref of workspace.contacts) for (const key of referenceChannelKeys(ref)) shared.set(key, [...(shared.get(key) || []), ref.kv_id]);
  const rows = workspace.contacts.map((ref): ContactComparison => {
    const referenceKeys = referenceChannelKeys(ref);
    const candidates = inventory.flatMap((record, index): ContactCandidate[] => {
      const channelKeys = inventoryChannelKeys(record).filter((key) => referenceKeys.includes(key));
      const nameEvidence = contactNameEvidence(ref, record);
      if (!channelKeys.length && !present(nameEvidence)) return [];
      const personal = record.TYP === "Person";
      return [{ id: record.CONTACT_ID, label: personal ? PRIVATE_LABEL : record.ORGANISATION, type: record.TYP,
        city: personal ? MISSING : shown(record.ORT), channel: personal ? PRIVATE_CHANNEL : shown(record.EMAIL_TELEFON), personal,
        citation: cite("contacts", index), nameEvidence: personal && present(nameEvidence) ? "Namensvergleich intern, Personendaten ausgeblendet" : nameEvidence,
        channelEvidence: channelKeys.map((key) => personal ? `${key.split(":")[0]}-Kanal intern identisch; Personendaten ausgeblendet` : key),
        sharedWith: [...new Set(channelKeys.flatMap((key) => shared.get(key) || []).filter((id) => id !== ref.kv_id))],
        fields: contactFields(ref, record, personal) }];
    });
    const both = candidates.some((c) => present(c.nameEvidence) && c.channelEvidence.length > 0);
    const channel = candidates.some((c) => c.channelEvidence.length > 0);
    const status = both ? "name_und_kanal" : channel ? "nur_kanal" : candidates.length ? "nur_name" : "kein_kandidat";
    return { id: ref.kv_id, title: ref.name_haupt_original + (present(ref.name_zusatz_normiert) ? ` / ${ref.name_zusatz_normiert}` : ""),
      path: ref.hierarchie_pfad, citation: `Kurverwaltungen_2025.md:L${ref.quellzeile}`, status, candidates,
      explanation: status === "name_und_kanal" ? "Namensbestandteile und Kontaktkanal passen wörtlich; Zuordnung trotzdem nicht entschieden und Datenmodell unvollständig."
        : status === "nur_kanal" ? "Nur der Kontaktkanal stimmt. Gemeinsame E-Mail kann mehrere Einrichtungen bedienen; Identität nicht nachgewiesen."
        : status === "nur_name" ? "Namenshinweis, aber kein identischer Kontaktkanal. Zuordnung und abweichende Kanäle prüfen."
        : "Nach den dokumentierten Regeln kein Kandidat; das beweist nicht, dass die Einrichtung außerhalb dieses Datensatzes fehlt.",
      originalMissing: ref.felder_fehlend_quelle, workingMissing: ref.felder_fehlend_arbeitsstand,
      supplementary: present(ref.quelle_ergaenzung) };
  });
  return { rows, sharedGroups: [...shared].filter(([, ids]) => ids.length > 1) };
}
function validISO(value: string) {
  if (!/^\d{4}-\d{2}-\d{2}$/.test(value)) return false;
  const parsed = new Date(`${value}T12:00:00Z`);
  return !Number.isNaN(parsed.valueOf()) && parsed.toISOString().slice(0, 10) === value;
}
// Publication times, application periods and deadlines must never become event dates.
const nonEventDateKinds = new Set(["Post-Datum", "Bewerbungsphase", "Bewerbungsphase beendet", "Bewerbungsfrist", "Booking-Hinweis", "Feed-Kontext", "Ausgabe", "Ankündigung"]);
function nameHint(reference: string, inventory: string) {
  const ref = fold(reference.replace(/^\d+\.\s*/, ""));
  const app = fold(inventory);
  if (!ref || !app) return MISSING;
  if (ref === app) return "Namenswortfolge identisch (Großschreibung, Interpunktion, führende Ausgabennummer ausgenommen).";
  if (containsWords(ref, app) || containsWords(app, ref)) return "Namenswortfolge wörtlich im anderen Namen enthalten; kein Identitätsbeweis.";
  return MISSING;
}
function placeHint(reference: ScheduleReference, event: ArchiveRecord) {
  if (!present(reference.ort_normiert) || !present(event.ORT)) return MISSING;
  const ref = fold(reference.ort_normiert), app = fold(event.ORT);
  if (ref === app) return "Ortstext identisch.";
  if (containsWords(ref, app)) return `Bestands-Ortstext „${event.ORT}“ vollständig im Referenz-Ort/Location-Text enthalten.`;
  return MISSING;
}
function compareSchedules(references: ScheduleReference[], datasets: ArchiveDatasets) {
  const events = datasets.events;
  const dates = datasets.event_dates;
  const datesByEvent = new Map<string, Array<{ row: ArchiveRecord; index: number }>>();
  dates.forEach((row, index) => datesByEvent.set(row.EVENT_ID, [...(datesByEvent.get(row.EVENT_ID) || []), { row, index }]));
  return references.map((ref): ScheduleComparison => {
    const periods = ref.zeitfenster_iso.split(";").map((part) => { const [from, to] = part.split("/"); return { from, to }; });
    if (!periods.length || periods.some((p) => !validISO(p.from) || !validISO(p.to) || p.from > p.to)) throw new Error("Ungültige Referenzzeitfenster.");
    const open = ref.ort_offen === "ja";
    const candidates = open ? [] : events.flatMap((event, index): EventCandidate[] => {
      const associatedDates = datesByEvent.get(event.EVENT_ID) || [];
      const useful = associatedDates.filter(({ row }) => !nonEventDateKinds.has(row.ART) && validISO(row.VON_ISO) && validISO(row.BIS_ISO));
      const matched = useful.filter(({ row }) => periods.some((p) => p.from === row.VON_ISO && p.to === row.BIS_ISO));
      const matchedPeriods = periods.filter((period) => matched.some(({ row }) => row.VON_ISO === period.from && row.BIS_ISO === period.to)).length;
      const complete = matchedPeriods === periods.length;
      const nameEvidence = nameHint(ref.name_normiert, event.NAME);
      const placeEvidence = placeHint(ref, event);
      const hasPlace = present(placeEvidence), hasName = present(nameEvidence);
      if (!hasPlace && !(complete && hasName)) return [];
      const evidence = hasPlace && complete ? "datum_ort" : hasPlace && matchedPeriods ? "teilzeitraum" : hasPlace && hasName ? "ort_name" : hasPlace ? "nur_ort" : "datum_name_ohne_ort";
      const candidateDates = associatedDates.map(({ row, index }) => ({ id: row.DATE_ID, from: shown(row.VON_ISO), to: shown(row.BIS_ISO), kind: shown(row.ART), citation: cite("event_dates", index) }));
      const sameYear = useful.some(({ row }) => row.VON_ISO.startsWith(ref.jahr));
      const field = (label: string, reference: string, inventory: string, same = fold(reference) === fold(inventory)): FieldComparison => ({
        field: label, reference: shown(reference), originalReference: label === "Zeitfenster" ? ref.datum_original : ["PLZ", "Ort/Location"].includes(label) ? ref.plz_ort_original : shown(reference), provenance: `Termine_2027_suendenfrei.txt:L${ref.quellzeile}`,
        inventory: shown(inventory), result: !present(reference) ? "quelle_offen" : !present(inventory) ? "fehlt"
          : label === "Zeitfenster" && same && reference !== inventory ? "enthalten" : same ? "gleich" : "abweichender_text",
        note: label === "Zeitfenster" && same && reference !== inventory ? "Alle Referenzfenster im Bestand enthalten; Bestand hat zusätzliche oder mehrfach erfasste Zeitfenster. Keine Gleichheit der vollständigen Listen und keine Löschfreigabe."
          : "Literalvergleich; keine automatische Korrektur oder Zuordnung." });
      return [{ id: event.EVENT_ID, label: event.NAME, city: shown(event.ORT), postalCode: shown(event.PLZ), sourceType: event.QUELLE_TYP,
        citation: cite("events", index), nameEvidence, placeEvidence,
        postcodeEqual: present(ref.plz_normiert) && ref.plz_normiert === event.PLZ, completePeriodSet: complete, matchedPeriods,
        dateIds: matched.map(({ row }) => row.DATE_ID), referencePeriodCount: periods.length, sameYear, dates: candidateDates,
        fields: [field("Name", ref.name_original, event.NAME), field("Ort/Location", ref.ort_normiert, [event.ORT, event.LOCATION].filter(present).join(" / ")),
          field("PLZ", ref.plz_normiert, event.PLZ), field("Zeitfenster", ref.zeitfenster_iso,
            useful.map(({ row }) => `${row.VON_ISO}/${row.BIS_ISO}`).join(";"), complete),
          { field: "Bestätigungsstatus", reference: ref.bestaetigungsstatus, originalReference: ref.sternchen,
            provenance: `Termine_2027_suendenfrei.txt:L${ref.quellzeile}`, inventory: MISSING, result: "nicht_strukturiert",
            note: "App-Events speichern Bewerbungs-/Gagenstatus, aber keinen unabhängigen Terminbestätigungsstatus." }], evidence }];
    });
    const strict = candidates.some((c) => c.evidence === "datum_ort");
    const partial = candidates.some((c) => c.evidence === "teilzeitraum");
    const namePlace = candidates.filter((c) => c.evidence === "ort_name");
    const status: ScheduleComparison["status"] = open ? "quelle_offen" : strict ? "datum_ort" : partial ? "teilzeitraum"
      : namePlace.some((c) => c.sameYear) ? "andere_zeit" : namePlace.length ? "nur_anderes_jahr"
      : candidates.some((c) => c.evidence === "datum_name_ohne_ort") ? "datum_name_ohne_ort" : candidates.length ? "nur_ortsbezug" : "kein_kandidat";
    const explanations: Record<ScheduleComparison["status"], string> = {
      datum_ort: "Alle Referenzzeitfenster und der Ortstext sind im selben Bestands-Event belegbar. Name, PLZ, Quelltyp und Verifikation separat prüfen; kein automatischer Merge.",
      teilzeitraum: "Nur ein Teil der getrennten Referenzzeitfenster ist bei gleichem Ort gefunden. Kein durchgehender Adventszeitraum daraus bilden.",
      andere_zeit: "Ort und Namensbestandteile passen, aber nicht alle Referenzzeitfenster. Eine Terminänderung ist ohne Identitätsentscheidung nicht behauptet.",
      nur_anderes_jahr: "Ort und Namensbestandteile sind vorhanden, jedoch kein passender Referenzzeitraum. Ältere Jahresdaten niemals auf 2027 übertragen.",
      nur_ortsbezug: "Nur Ortswortfolge gefunden, kein Name-/Termin-Nachweis. Nicht als vorhandener Referenztermin zählen.",
      datum_name_ohne_ort: "Datum und Namenswortfolge passen, der Ort ist nicht belegt. Identität bleibt offen.",
      kein_kandidat: "Kein Hinweis nach den beschriebenen Regeln im App-Datensatz. Kein Nachweis, dass die Veranstaltung extern nicht existiert.",
      quelle_offen: "Referenz selbst enthält xxxx/xxxxx (Ort unbekannt); keine Zuordnung erraten.",
    };
    return { id: ref.sf_id, title: ref.name_original, year: Number(ref.jahr), place: ref.plz_ort_original, dateOriginal: ref.datum_original,
      citation: `Termine_2027_suendenfrei.txt:L${ref.quellzeile}`, sourceStatus: ref.bestaetigungsstatus, dateOrigin: ref.datumsherkunft,
      periods, status, candidates, explanation: explanations[status] };
  });
}
function inventoryAudit(datasets: ArchiveDatasets, chatMessages: ArchiveRecord[]) {
  const issues: InventoryIssue[] = [];
  const events = datasets.events, dates = datasets.event_dates, contacts = datasets.contacts;
  const eventIds = new Set(events.map((e) => e.EVENT_ID));
  const parents = { EVENT_ID: eventIds, ACT_ID: new Set(datasets.acts.map((r) => r.ACT_ID)), PARTNER_ID: new Set(datasets.partners.map((r) => r.PARTNER_ID)) };
  for (const [name, rows] of Object.entries(datasets)) {
    if (["events", "acts", "partners"].includes(name)) continue;
    for (const [field, ids] of Object.entries(parents)) {
      const unknown = rows.flatMap((r, index) => present(r[field]) && !ids.has(r[field]) ? [{ index, id: r[field] }] : []);
      if (unknown.length) issues.push({ id: `REL-${name}-${field}`, kind: "verwaister_verweis", dataset: name,
        records: unknown.map((r) => `${r.index}:${r.id}`), evidence: unknown.map((r) => `${cite(name, r.index)}.${field}=${r.id} (Ziel-ID fehlt)`).join("; ") });
    }
  }
  const dateGroups = new Map<string, ArchiveRecord[]>();
  for (const date of dates.filter((d) => validISO(d.VON_ISO) && validISO(d.BIS_ISO))) {
    const key = `${date.EVENT_ID}|${date.VON_ISO}|${date.BIS_ISO}`;
    dateGroups.set(key, [...(dateGroups.get(key) || []), date]);
  }
  for (const [key, records] of dateGroups) if (records.length > 1) issues.push({ id: `DATE-${records.map((r) => r.DATE_ID).join("-")}`,
    kind: new Set(records.map((r) => r.ART)).size > 1 ? "gleicher_zeitraum_unterschiedliche_art" : "mehrfacher_zeitraum", dataset: "event_dates",
    records: records.map((r) => r.DATE_ID), evidence: `${key}; ${records.map((r) => `${r.DATE_ID}: ${r.ART}`).join("; ")}. Unterschiedliche Arten können unterschiedliche Bedeutungen haben, nicht automatisch löschen.` });
  for (const contact of contacts) if (!inventoryChannelKeys(contact).length) issues.push({ id: `KANAL-${contact.CONTACT_ID}`, kind: "kontaktkanal_platzhalter", dataset: "contacts", records: [contact.CONTACT_ID], evidence: `${contact.CONTACT_ID}: EMAIL_TELEFON=${contact.EMAIL_TELEFON}; kein auslesbarer E-Mail-/Telefonwert.` });
  const contactNames = new Map<string, ArchiveRecord[]>();
  const contactChannels = new Map<string, ArchiveRecord[]>();
  for (const contact of contacts) {
    const key = `${contactNameKey(contact.ORGANISATION)}|${fold(contact.ORT || "")}`;
    contactNames.set(key, [...(contactNames.get(key) || []), contact]);
    for (const channel of inventoryChannelKeys(contact)) contactChannels.set(channel, [...(contactChannels.get(channel) || []), contact]);
  }
  for (const group of contactNames.values()) if (group.length > 1) issues.push({
    id: `CONTACT-NAME-${group.map((r) => r.CONTACT_ID).join("-")}`, kind: "gleicher_kontaktname_ort", dataset: "contacts",
    records: group.map((r) => r.CONTACT_ID),
    evidence: `${group.map((r) => `${r.CONTACT_ID}: ${r.TYP === "Person" ? PRIVATE_LABEL : r.ORGANISATION}`).join("; ")}. Namenswortfolge und Ortswortfolge gleich; verschiedene Kanäle können eigene Zwecke haben. Keine automatische Zusammenführung.`,
  });
  for (const group of contactChannels.values()) if (group.length > 1) issues.push({
    id: `CONTACT-CHANNEL-${group.map((r) => r.CONTACT_ID).join("-")}`, kind: "gemeinsamer_bestandskanal", dataset: "contacts",
    records: group.map((r) => r.CONTACT_ID), evidence: `${group.map((r) => r.CONTACT_ID).join(" / ")}: auslesbarer Kanal identisch. Einrichtung und Person können denselben Kanal nutzen; keine Identitätsentscheidung, persönliche Kanalwerte nicht veröffentlicht.`,
  });
  const eventNames = new Map<string, ArchiveRecord[]>();
  for (const event of events) { const key = fold(event.NAME); eventNames.set(key, [...(eventNames.get(key) || []), event]); }
  for (const rows of eventNames.values()) if (rows.length > 1) issues.push({ id: `NAME-${rows.map((r) => r.EVENT_ID).join("-")}`, kind: "gleicher_name_kein_dublettenbeweis",
    dataset: "events", records: rows.map((r) => r.EVENT_ID), evidence: rows.map((r) => `${r.EVENT_ID}: ${r.NAME} — ${shown(r.ORT)}`).join("; ") });
  const groupCount = (rows: ArchiveRecord[], field: string) => Object.fromEntries([...new Set(rows.map((r) => r[field] || "nicht angegeben"))].sort().map((key) => [key, rows.filter((r) => (r[field] || "nicht angegeben") === key).length]));
  const years = Object.fromEntries([...new Set(dates.map((r) => validISO(r.VON_ISO) ? r.VON_ISO.slice(0, 4) : "ohne ISO-Beginn"))].sort().map((year) => [year,
    dates.filter((r) => (validISO(r.VON_ISO) ? r.VON_ISO.slice(0, 4) : "ohne ISO-Beginn") === year).length]));
  return { issues, summary: { datasetCounts: Object.fromEntries(Object.entries(datasets).map(([key, rows]) => [key, rows.length])), eventCount: events.length,
    dateRows: dates.length, contacts: contacts.length, messages: chatMessages.length,
    geocodedEvents: events.filter((r) => present(r.LAT) && present(r.LNG)).length,
    geocodedContacts: contacts.filter((r) => present(r.LAT) && present(r.LNG)).length,
    withoutDateRows: events.filter((event) => !dates.some((r) => r.EVENT_ID === event.EVENT_ID)).length,
    missingStartISO: dates.filter((r) => !validISO(r.VON_ISO)).length, noEndISO: dates.filter((r) => !validISO(r.BIS_ISO)).length,
    dateYears: years, sourceTypes: groupCount(events, "QUELLE_TYP") } };
}
function counter<T extends string>(keys: T[], values: T[]): Record<T, number> {
  return Object.fromEntries(keys.map((key) => [key, values.filter((v) => v === key).length])) as Record<T, number>;
}
export function buildComparisonReport(workspace: ContactWorkspace, references: ScheduleReference[], datasets: ArchiveDatasets,
  chatMessages: ArchiveRecord[], inputs: FileEvidence[]): ComparisonReport {
  const contactResult = compareContacts(workspace, datasets.contacts);
  const contacts = contactResult.rows;
  const schedules = compareSchedules(references, datasets);
  const inventory = inventoryAudit(datasets, chatMessages);
  const candidateContactIds = new Set(contacts.flatMap((r) => r.candidates.map((c) => c.id)));
  const candidateEventIds = new Set(schedules.flatMap((r) => r.candidates.map((c) => c.id)));
  const unmatchedContacts = datasets.contacts.flatMap((c, index) => candidateContactIds.has(c.CONTACT_ID) ? [] : [{ id: c.CONTACT_ID,
    label: c.TYP === "Person" ? PRIVATE_LABEL : "Bestandskontakt außerhalb der Referenz · Name ausgeblendet", type: c.TYP, personal: c.TYP === "Person", citation: cite("contacts", index) }]);
  const unmatchedEvents = datasets.events.flatMap((e, index) => candidateEventIds.has(e.EVENT_ID) ? [] : [{ id: e.EVENT_ID, label: "Bestands-Event außerhalb der Referenz · Bezeichnung ausgeblendet",
    sourceType: e.QUELLE_TYP, citation: cite("events", index) }]);
  const findings: DecisionFinding[] = [];
  function finding(id: string, area: DecisionFinding["area"], severity: DecisionFinding["severity"], title: string, refs: string[], ids: string[],
    evidence: string, recommendation: string, question: string) {
    findings.push({ id, area, severity, title, referenceIds: refs, inventoryIds: ids, evidence, recommendation, question, decision: "offen" });
  }
  const existsContact = (ids: string[]) => ids.every((id) => datasets.contacts.some((r) => r.CONTACT_ID === id));
  if (existsContact(["K22", "K23", "K70"])) finding("K-01", "kontakte", "konflikt", "Putbus: gleiche Institution, mehrere abweichende E-Mail-Kanäle", ["KV27"], ["K22", "K23", "K70"],
    "K22/K23 heißen Kurverwaltung Putbus; K70 und MD KV27 Kurverwaltung Putbus/Stadtinformation. Drei unterschiedliche E-Mail-Werte; nur K70 enthält die Referenz-Mail. Verschiedene Kanäle sind nicht automatisch doppelte Institutionen.",
    "Institution und ihre Kanäle getrennt entscheiden; Referenz-Mail neben Altkanälen erhalten, nichts ungefragt entfernen.", "Soll später ein Institut mit getrennt belegten Alt-/Referenzkanälen geführt werden, statt drei Institutionen? Keine Entscheidung vorweggenommen.");
  if (existsContact(["K01", "K02", "K33", "K65"])) finding("K-02", "kontakte", "pruefen", "Rügen-Verband und Tourismuszentrale: Zuordnung offen", ["KV01"], ["K01", "K02", "K33", "K65"],
    "K01/K02 haben gleichen Organisationsnamen, aber verschiedene Kanäle. K33 trägt Tourismusverband Rügen (Kampagne); K65 hat den MD-Namen und die MD-Mail. Gemeinsame Domain oder Region reicht nicht zur Identität.",
    "K65 als Referenzkandidat getrennt belegen; K01/K02/K33 nicht pauschal zusammenführen.", "Welche Organisationszuordnung soll für K01/K02/K33 gegenüber KV01 gelten?" );
  if (existsContact(["K07", "K68"])) finding("K-03", "kontakte", "pruefen", "Infopoint Sellin: zwei E-Mails auf zwei Bestandszeilen", ["KV07"], ["K07", "K68"],
    "Die MD KV07 liefert zwei E-Mails in einem Adressblock; diese stehen im Bestand getrennt auf K07 und K68 (Zimmervermittlung). Beide Kanäle sind wortgleich mit der Referenz.",
    "Einrichtung und Kanalzweck getrennt führen; keine Adresse oder Mail verlieren.", "Soll der eine Referenzblock später zwei getrennt benannte Kontaktkanäle erhalten?" );
  finding("K-04", "kontakte", "pruefen", "Baabe: gemeinsamer Kanal ist kein Merge-Beweis", ["KV09", "KV10"], ["K08"],
    "KV09 Kurverwaltung und KV10 Infopavillon sind verschiedene Referenzeinrichtungen. KV10 erhält dieselbe E-Mail ausdrücklich per Nutzerangabe. Die App hat K08 Kurverwaltung; daraus ist kein eigener Pavillon-Eintrag bewiesen.",
    "Zwei Einrichtungen behalten; gemeinsamen Kanal als explizite Angabe dokumentieren.", "Soll der Infopavillon beim späteren Import als eigene Einrichtung mit diesem ausdrücklich freigegebenen Kanal ergänzt werden?" );
  finding("K-05", "kontakte", "konflikt", "Lohme: gleiche E-Mail, anderer Organisationstyp", ["KV17"], ["K53"],
    "MD KV17 bezeichnet Touristik Lohme GmbH; K53 bezeichnet Gemeinde Lohme. info@lohme.de stimmt, der Name und der Typ nicht.",
    "Keine Gleichsetzung allein wegen E-Mail; organisatorische Zuständigkeit prüfen.", "Gemeinde und Touristik getrennt lassen oder eine belegte Zuordnung liefern?" );
  finding("K-06", "kontakte", "konflikt", "Neuenkirchen: Referenz-Firma trifft auf Personenkontakt", ["KV24"], ["K57"],
    "Die Referenz KV24 nennt Zimmervermittlung Rügen in Neuenkirchen/OT Grubnow. Der wortgleiche E-Mail-Kanal steht im Bestand K57 als Person ohne Ort. Persönliche Angaben werden im Bericht nicht neu veröffentlicht.",
    "Keine stille Umbenennung; Firmenkontakt und Personenzuordnung separat entscheiden.", "Soll K57 separat erhalten bleiben und ein Unternehmenskontakt KV24 ergänzt werden?" );
  finding("K-07", "kontakte", "luecke", "Middelhagen: Platzhalter statt Kontaktkanal", ["KV12", "KV13"], ["K09", "K10"],
    "K09 Tourist-Info Middelhagen hat EMAIL_TELEFON=(nicht genannt). Referenz KV12 liefert Telefon/Fax und Nutzerergänzung Web/E-Mail. Der ergänzte Kanal stimmt auch mit K10 Thiessow überein, das beweist keine Identität von Middelhagen und Thiessow.",
    "Middelhagen und Thiessow getrennt führen; Feldherkunft bewahren.", "Soll KV12 den K09-Referenzhinweis erhalten, ohne K10/Thiessow zu verschmelzen?" );
  finding("K-08", "kontakte", "luecke", "Kontaktdatenmodell bildet die Referenz nicht vollständig ab", workspace.contacts.map((r) => r.kv_id), [],
    "App-Kontakte haben nur ORGANISATION/TYP/EMAIL_TELEFON/ORT/REGION/Koordinaten/MSG/NOTIZ. Straße, PLZ, Telefon, Fax, Web, Ortsteil und Parent sind keine getrennten Felder. Werte in NOTIZ bleiben Freitext.",
    "Vorsicht: spätere getrennte Kontakt-/Adress-/Strukturfelder verändern das Datenmodell (E4). Stufe 3 schreibt keine Datenbank.", "E4 vor einem Import klären: Welches Schema soll die belegten Einzelwerte aufnehmen?" );
  const pdfNotes = datasets.contacts.filter((r) => (r.NOTIZ || "").includes("Kurverwaltungen_2025.pdf"));
  if (pdfNotes.length) finding("K-09", "kontakte", "pruefen", "Bestandsnotizen nennen PDF statt der bereitgestellten MD", [], pdfNotes.map((r) => r.CONTACT_ID),
    "NOTIZ enthält Kurverwaltungen_2025.pdf; geprüft wurde die vorliegende Kurverwaltungen_2025.md. Das beweist keinen falschen Wert, aber der genaue ursprüngliche PDF-Nachweis fehlt hier.",
    "Herkunft auf genaue Datei/Fundstelle beziehen, alte Herkunftsangabe erhalten.", "Soll die MD als neuer belegter Nachweis neben der historischen PDF-Notiz geführt werden?" );
  for (const row of schedules) {
    if (row.status !== "datum_ort") {
      finding(`T-${row.id}`, "termine", row.status === "quelle_offen" ? "pruefen" : "luecke", `${row.id}: kein vollständiger Datum-/Ort-Nachweis`, [row.id], row.candidates.map((c) => c.id),
        `${row.dateOriginal} · ${row.title} · ${row.place}. ${row.explanation}`,
        "Originalzeile mit Herkunft, Fensterliste und Sternchenstatus erhalten; keine Jahresdaten, Orte oder Veranstaltungsnamen erfinden.",
        row.status === "quelle_offen" ? "Platzhalter offen lassen, bis eine echte Orts-/Namensquelle vorliegt?" : "Referenztermin später als eigenen, quellgebundenen Datensatz vorbereiten; Kandidatenzuordnung erst nach Einzelentscheidung?" );
    } else if (row.candidates.some((c) => c.evidence === "datum_ort" && !present(c.nameEvidence))) {
      finding(`T-${row.id}`, "termine", "konflikt", `${row.id}: Datum und Ort passen, Name weicht ab`, [row.id], row.candidates.filter((c) => c.evidence === "datum_ort").map((c) => c.id),
        `${row.dateOriginal} · ${row.title} · ${row.place}. Kandidat stimmt in Zeitraum und Ort, nicht in der Namenswortfolge.`,
        "Als Zuordnungsfrage behandeln, nicht automatisch überschreiben.", "Soll nach Quellenentscheidung der Referenzname mit dem abweichend benannten Bestands-Event verknüpft werden?" );
    }
  }
  const kiDateRefs = schedules.filter((r) => r.candidates.some((c) => c.evidence === "datum_ort" && c.sourceType.includes("KI")));
  if (kiDateRefs.length) finding("T-KI", "termine", "pruefen", "Wortgleiche Zeitdaten auf KI-Listenbasis", kiDateRefs.map((r) => r.id),
    [...new Set(kiDateRefs.flatMap((r) => r.candidates.filter((c) => c.evidence === "datum_ort" && c.sourceType.includes("KI")).map((c) => c.id)))],
    "Auch passende Zeit-/Ortswerte ändern QUELLE_TYP=Chat (KI-Liste) nicht. Herkunft und Referenzverifikation müssen unabhängig gespeichert werden.",
    "Referenznachweis gesondert hinzufügen, niemals den gesamten KI-Datensatz als verifiziert markieren.", "Soll ein separater Referenzbeleg an die später bestätigte Zuordnung angehängt werden?" );
  for (const issue of inventory.issues.filter((i) => !i.kind.includes("gleicher_name"))) finding(`B-${issue.id}`, "bestand", issue.kind === "verwaister_verweis" ? "konflikt" : "pruefen",
    issue.kind === "verwaister_verweis" ? "Verwaister Datensatzverweis" : issue.kind === "kontaktkanal_platzhalter" ? "Kontaktkanal ist kein echter Wert"
      : issue.kind === "gleicher_kontaktname_ort" ? "Gleicher Kontaktname und Ort, getrennte Bestandszeilen"
      : issue.kind === "gemeinsamer_bestandskanal" ? "Gemeinsamer Bestandskanal ohne Identitätsentscheidung"
      : "Mehrere Datumszeilen für dasselbe Event/Intervall",
    [], issue.records, issue.evidence, "Einzeln belegen; kein automatisches Löschen oder Ersetzen.", "Diesen Befund in Stufe 4 separat entscheiden?" );
  const repeatedNames = inventory.issues.filter((issue) => issue.kind === "gleicher_name_kein_dublettenbeweis");
  if (repeatedNames.length) finding("B-EVENTNAMEN", "bestand", "pruefen", "Gleichnamige Events an verschiedenen Orten sind keine bewiesenen Dubletten", [],
    [...new Set(repeatedNames.flatMap((issue) => issue.records))], repeatedNames.map((issue) => issue.evidence).join(" | "),
    "Niemals nach dem Namen allein zusammenführen. Nur mit Datum, Ort und Quellenbeleg entscheiden.",
    "Diese Namensgruppen als getrennte Veranstaltungen behalten, soweit keine individuelle Identität belegt wird?" );
  finding("B-GEO", "bestand", "pruefen", "Koordinaten vorhanden heißt nicht inhaltlich geprüft", [], [],
    `${inventory.summary.geocodedEvents} Event-Einträge und ${inventory.summary.geocodedContacts} Kontakte besitzen LAT/LNG. GEO_STATUS enthält unter anderem offene/zu verifizierende Angaben. Keine Geocodierung wurde in Stufe 3 verifiziert.`,
    "Geo-Quelle und Prüfstatus getrennt behalten.", "Vor einem späteren Mapping-Import eine gesonderte Geo-Prüfliste vorsehen?" );
  finding("B-MEDIEN", "bestand", "luecke", "Bildverweise ohne Bilddateien in der App-ZIP", [], [],
    "Die App-ZIP enthält flyer_sources mit 79 Einträgen, aber keinen public/flyers/-Ordner. Der separate Chat-Export wurde in diesem Abgleich nicht erneut geöffnet.",
    "Bildreparatur separat in Stufe 6; keine weitere Fotobewertung oder Rekonstruktion hier.", "Später nur die belegten toten Bildverweise reparieren?" );
  finding("B-SYNC", "bestand", "konflikt", "JSON-Synchronisation kann Datenbankkorrekturen überschreiben", [], [],
    "src/lib/spp7-repository.ts in der ursprünglichen App nutzt onConflictDoUpdate aus Archiv-JSON. Das Dashboard lädt JSON direkt; drei Datenbanktabellen dienen anderen Abfragen. Keine Reparatur ausgeführt.",
    "Vorsicht: Kuratierte Daten nicht ungeprüft in die synchronisierten Bestands-Tabellen schreiben. E3/E4/E5 separat klären.", "Eigene kuratierte Ebene vor Stufe 5 verbindlich festlegen?" );
  const contactStatuses: ContactComparison["status"][] = ["name_und_kanal", "nur_kanal", "nur_name", "kein_kandidat"];
  const scheduleStatuses: ScheduleComparison["status"][] = ["datum_ort", "teilzeitraum", "andere_zeit", "nur_anderes_jahr", "nur_ortsbezug", "datum_name_ohne_ort", "kein_kandidat", "quelle_offen"];
  const datePlace = schedules.filter((r) => r.status === "datum_ort");
  const report: ComparisonReport = {
    version: COMPARISON_VERSION, contactModel: workspace.version, missingValue: MISSING,
    scope: "Stufe 3: unveränderte App-ZIP ↔ normierte Quellen und ausdrückliche Nutzerangaben. Keine Live-Datenbankprüfung als Datenbestand, keine externe Verifikation, kein Import, keine Stufe-4-Entscheidung.",
    inputFiles: inputs,
    method: [
      "Kontaktkandidaten nur durch identischen E-Mail-/Telefonkanal oder gleiche/enthaltene Namenswortfolge. Info/Information, Interpunktion und Rechtsformkürzel werden nur beim Textvergleich vereinheitlicht.",
      "Gleicher Kanal ist kein Identitätsnachweis. Baabe und Mönchgut liefern ausdrücklich gemeinsam benutzte Kanäle; jede Referenzeinrichtung bleibt separat.",
      "Termin-Kriterium Datum+Ort: alle getrennten Referenzfenster müssen innerhalb desselben Bestands-Events wortgleich vorkommen, und der gesamte Bestands-Ortstext muss im Referenz-Ortstext enthalten sein. Name/PLZ werden separat geprüft.",
      "Postzeiten, Bewerbungsphasen, Fristen, Feed-Kontext, Booking-Hinweise, Ausgabe/Ankündigung werden nicht als Veranstaltungszeitfenster verglichen. Ein fehlendes BIS wird nicht zu einem Zeitraum ergänzt.",
      "Nur-Ort-, andere Jahres- und Namenshinweise sind schwache Kandidaten, keine vorhandenen Referenztermine. Keine Fuzzy-Scores, keine Geografie- oder Termininterpretation.",
      "Platzhalter xxxx/xxxxx bleiben Quelle offen. Sternchenstatus und berechnete Adventsfenster ändern sich nicht.",
      "NOTIZ wird auf wörtlich vorhandene Referenzwerte geprüft, aber nicht als strukturiertes Feld interpretiert. Bestandsfelder ohne Struktur werden ausdrücklich als nicht strukturiert ausgewiesen.",
      "Nicht zuordenbare Bestandskontakte/-events sind Überhang gegenüber diesen begrenzten Referenzen, nicht ungültig und nicht zum Löschen freigegeben.",
      "Personennamen und ihre Bestandskanäle sind ausgeblendet. Nicht zugeordneter Kontakt-/Eventbestand erscheint nur mit ID und Typ, ohne neue persönliche Namen, Kanäle oder Linkbezeichnungen. Keine privaten Chattexte oder kompletten Bestandsdatensätze über die Bericht-API.",
    ],
    summary: { contacts: { references: contacts.length, inventory: datasets.contacts.length, byStatus: counter(contactStatuses, contacts.map((r) => r.status)),
      sharedReferenceChannels: contactResult.sharedGroups.length, candidatePairs: contacts.reduce((sum, c) => sum + c.candidates.length, 0), unlinkedInventory: unmatchedContacts.length },
      schedules: { references: schedules.length, year2026: schedules.filter((r) => r.year === 2026).length, year2027: schedules.filter((r) => r.year === 2027).length,
        byStatus: counter(scheduleStatuses, schedules.map((r) => r.status)), datePlaceRows: datePlace.length,
        nameSupportedDatePlaceRows: datePlace.filter((r) => r.candidates.some((c) => c.evidence === "datum_ort" && present(c.nameEvidence))).length,
        noDatePlaceRows: schedules.length - datePlace.length, openSourceRows: schedules.filter((r) => r.status === "quelle_offen").length,
        matchedPeriodCount: schedules.reduce((sum, row) => sum + row.periods.filter((period) => row.candidates.some((c) => present(c.placeEvidence) && c.dates.some((date) => !nonEventDateKinds.has(date.kind) && date.from === period.from && date.to === period.to))).length, 0),
        referencePeriodCount: schedules.reduce((sum, r) => sum + r.periods.length, 0) }, inventory: inventory.summary, findings: findings.length },
    contacts, schedules, findings, unmatchedContacts, unmatchedEvents, issues: inventory.issues,
  };
  return report;
}
export const contactStatusLabels: Record<ContactComparison["status"], string> = {
  name_und_kanal: "Name-/Kanalhinweis", nur_kanal: "Nur gleicher Kanal", nur_name: "Nur Namenshinweis", kein_kandidat: "Kein Kandidat nach Regel",
};
export const scheduleStatusLabels: Record<ScheduleComparison["status"], string> = {
  datum_ort: "Datum + Ort", teilzeitraum: "Nur Teilzeitraum", andere_zeit: "Andere Zeitangabe", nur_anderes_jahr: "Nur andere Jahresdaten",
  nur_ortsbezug: "Nur Ortsbezug", datum_name_ohne_ort: "Datum/Name ohne Ort", kein_kandidat: "Kein Kandidat nach Regel", quelle_offen: "Referenz-Ort offen",
};
const md = (text: string) => text.replaceAll("|", "\\|").replaceAll("\n", " ").replaceAll("\r", " ");
export function comparisonMarkdown(report: ComparisonReport) {
  const s = report.summary;
  const lines = ["# SPP7 · Abgleich 01 — Stufe 3", "", `Version: ${report.version}. Kontaktmodell: ${report.contactModel}.`,
    report.scope, "", "**Keine Zuordnung, kein Merge, keine Löschung und keine Datenbankänderung ausgeführt. Alle Entscheidungspunkte sind offen.**", "",
    "## Übersicht", "",
    `- Kontakte: ${s.contacts.references} Referenzeinrichtungen ↔ ${s.contacts.inventory} Bestandszeilen. ${s.contacts.candidatePairs} Kandidatenpaare; ${s.contacts.unlinkedInventory} Bestandszeilen ohne Referenzkandidat nach diesen Regeln.`,
    ...Object.entries(s.contacts.byStatus).map(([key, value]) => `- Kontaktstatus ${contactStatusLabels[key as ContactComparison["status"]]}: ${value}.`),
    `- Termine: ${s.schedules.references} Quellzeilen (${s.schedules.year2026} aus 2026 / ${s.schedules.year2027} aus 2027), ${s.schedules.referencePeriodCount} getrennte Zeitfenster.`,
    `- ${s.schedules.datePlaceRows} Quellzeilen haben vollständige Datum-/Ort-Hinweise; davon ${s.schedules.nameSupportedDatePlaceRows} mit zusätzlichem Namenswortfolge-Hinweis. Kein automatischer Identitätsnachweis.`,
    `- ${s.schedules.noDatePlaceRows} Quellzeilen ohne vollständigen Datum-/Ort-Nachweis; darunter ${s.schedules.openSourceRows} Referenz-Ortsplatzhalter. „Fehlt“ bedeutet hier nur: nicht mit Datum+Ort im App-ZIP belegt.`,
    `- Von ${s.schedules.referencePeriodCount} Referenzzeitfenstern sind ${s.schedules.matchedPeriodCount} mit Datum-/Ort-Hinweis auffindbar. Vier Adventswochenenden zählen als vier Fenster, aber ein Quelltermin.`,
    `- ${s.findings} nummerierte Entscheidungspunkte für Stufe 4.`, "",
    "Die frühere Handoff-Aussage „46 von 54 fehlen“ wird nicht übernommen: sie verglich Eventnamen mit Terminzeilen. Dieser Bericht vergleicht jede Quellzeile und ihre Fenster einzeln.",
    "", "## Eingaben / Prüfsummen", "", "| Datei | Rolle | SHA-256 |", "|---|---|---|",
    ...report.inputFiles.map((file) => `| ${md(file.path)} | ${md(file.role)} | ${file.sha256} |`),
    "", "App-Fundstellen sind JSON-Pointer innerhalb des unveränderten App-ZIPs (public/data/spp7-datasets.json). Das ZIP liegt außerhalb public/. Berichtsfundstellen ersetzen keine Originalnachricht. Keine neue Veröffentlichung privater Chattexte.",
    "", "## Vergleichsregeln", "", ...report.method.map((rule, index) => `${index + 1}. ${rule}`),
    "", "## Alle 32 Referenzeinrichtungen", "", "| Referenz | Einrichtung | Status | Bestandskandidaten | Fundstelle |", "|---|---|---|---|---|",
    ...report.contacts.map((row) => `| ${row.id} | ${md(row.title)} | ${contactStatusLabels[row.status]} | ${row.candidates.map((c) => c.id).join(", ") || MISSING} | ${row.citation} |`),
  ];
  for (const row of report.contacts) {
    lines.push("", `### ${row.id} · ${row.title}`, "", row.explanation, `Fundstelle: ${row.citation}. Hierarchie: ${row.path}.`,
      `Fehlend im MD-Original: ${row.originalMissing}; fehlend im Arbeitsstand: ${row.workingMissing}. Nutzerergänzung: ${row.supplementary ? "ja" : "nein"}.`);
    for (const candidate of row.candidates) {
      lines.push("", `#### Kandidat ${candidate.id} · ${candidate.label}`, `Fundstelle: ${candidate.citation}.`,
        `Namenshinweis: ${candidate.nameEvidence}. Kanalhinweis: ${candidate.channelEvidence.join("; ") || MISSING}.`,
        `Gleicher Kanal auch bei Referenzen: ${candidate.sharedWith.join(", ") || MISSING}.`, "",
        "| Feld | Referenz-Arbeitswert | MD-Original | Herkunft | Bestand | Vergleich | Hinweis |", "|---|---|---|---|---|---|---|",
        ...candidate.fields.map((f) => `| ${md(f.field)} | ${md(f.reference)} | ${md(f.originalReference)} | ${md(f.provenance)} | ${md(f.inventory)} | ${f.result} | ${md(f.note)} |`));
    }
  }
  lines.push("", "## Alle 54 Referenzterminzeilen", "", "| Referenz | Jahr | Originaldatum | Veranstaltung | Ort | Status | Kandidaten |", "|---|---|---|---|---|---|---|",
    ...report.schedules.map((row) => `| ${row.id} | ${row.year} | ${md(row.dateOriginal)} | ${md(row.title)} | ${md(row.place)} | ${scheduleStatusLabels[row.status]} | ${row.candidates.map((c) => c.id).join(", ") || MISSING} |`));
  for (const row of report.schedules) {
    lines.push("", `### ${row.id} · ${row.title} · ${row.year}`, "", `Fundstelle: ${row.citation}. ${row.dateOriginal} · ${row.place}.`,
      `Zeitfenster: ${row.periods.map((p) => `${p.from}/${p.to}`).join("; ")}. Datumsherkunft: ${row.dateOrigin}; Quellstatus: ${row.sourceStatus}.`, row.explanation);
    for (const candidate of row.candidates) {
      lines.push("", `- ${candidate.id} · ${candidate.label} · ${candidate.city} · Quelle: ${candidate.sourceType}.`,
        `  - Beleg: ${candidate.citation}; Hinweisart: ${candidate.evidence}; vollständige Fenster: ${candidate.completePeriodSet}; passende Fenster ${candidate.matchedPeriods}/${candidate.referencePeriodCount}; DATE_ID: ${candidate.dateIds.join(", ") || MISSING}.`,
        `  - Name: ${candidate.nameEvidence}; Ort: ${candidate.placeEvidence}; gleiche PLZ: ${candidate.postcodeEqual}.`,
        `  - Bestands-Datumszeilen: ${candidate.dates.map((d) => `${d.id} ${d.from}/${d.to} (${d.kind}; ${d.citation})`).join("; ") || MISSING}.`,
        ...candidate.fields.map((f) => `  - ${f.field}: Referenz „${f.reference}“ ↔ Bestand „${f.inventory}“ → ${f.result}. ${f.note}`));
    }
  }
  lines.push("", "## Entscheidungsliste — alles offen", "");
  for (const finding of report.findings) lines.push(`### ${finding.id} · ${finding.title}`, "", `Bereich: ${finding.area}; Hinweisart: ${finding.severity}; Entscheidung: offen.`,
    `Referenz: ${finding.referenceIds.join(", ") || MISSING}; Bestand: ${finding.inventoryIds.join(", ") || MISSING}.`,
    `**Beleg:** ${finding.evidence}`, `**Vorschlag, nicht ausgeführt:** ${finding.recommendation}`, `**Frage:** ${finding.question}`, "");
  lines.push("## Bestand außerhalb der Referenzzuordnung", "", "Kein Löschvorschlag. Die Referenzen decken nur bestimmte Einrichtungen und Sündenfrei-Termine ab.",
    "", "| Kontakt-ID | Bestandsbezeichnung | Typ | Fundstelle |", "|---|---|---|---|",
    ...report.unmatchedContacts.map((c) => `| ${c.id} | ${md(c.label)} | ${md(c.type)} | ${c.citation} |`),
    "", "| Event-ID | Bestandsname | Quelltyp | Fundstelle |", "|---|---|---|---|",
    ...report.unmatchedEvents.map((e) => `| ${e.id} | ${md(e.label)} | ${md(e.sourceType)} | ${e.citation} |`),
    "", "## Technischer Bestand / Integrität", "", "| Dataset | Zeilen |", "|---|---|",
    ...Object.entries(s.inventory.datasetCounts).map(([key, count]) => `| ${key} | ${count} |`),
    "", `Bestands-Events ohne irgendeine Datumszeile: ${s.inventory.withoutDateRows} (kann bei Locations sinnvoll sein, kein pauschaler Fehler).`,
    `Datumszeilen ohne ISO-Beginn: ${s.inventory.missingStartISO}; ohne ISO-Ende: ${s.inventory.noEndISO} (einseitige Datums-/Post-/Fristangaben nicht als kompletten Zeitraum behandeln).`,
    `ISO-Beginnjahre: ${JSON.stringify(s.inventory.dateYears)}. Quelle-Typen: ${JSON.stringify(s.inventory.sourceTypes)}.`,
    `Geocodiert: ${s.inventory.geocodedEvents} Events / ${s.inventory.geocodedContacts} Kontakte; keine inhaltliche Geo-Prüfung. Aufbereitete Chat-Nachrichten: ${s.inventory.messages}.`,
    "", ...report.issues.map((issue) => `- ${issue.id}: ${issue.kind} (${issue.dataset}) — ${issue.evidence}`),
    "", "## Nächster Schritt", "", "Stufe 4: nummerierte Befunde einzeln entscheiden. Dieser Bericht ist keine Importfreigabe. Originale, Normierung und Datenbank wurden nicht verändert.", "");
  return lines.join("\n");
}
export function comparisonCsvReports(report: ComparisonReport) {
  return {
    "abgleich-01-kontakte.csv": normalizedCsvFile(["referenz_id", "name", "status", "kandidaten", "fundstelle", "hinweis"], report.contacts.map((r) => [r.id, r.title, contactStatusLabels[r.status], r.candidates.map((c) => c.id).join(";"), r.citation, r.explanation])),
    "abgleich-01-termine.csv": normalizedCsvFile(["referenz_id", "jahr", "datum_original", "name_original", "ort_original", "zeitfenster", "status", "kandidaten", "datumsherkunft", "quellstatus", "fundstelle", "hinweis"],
      report.schedules.map((r) => [r.id, r.year, r.dateOriginal, r.title, r.place, r.periods.map((p) => `${p.from}/${p.to}`).join(";"), scheduleStatusLabels[r.status], r.candidates.map((c) => c.id).join(";"), r.dateOrigin, r.sourceStatus, r.citation, r.explanation])),
    "abgleich-01-feldvergleich.csv": normalizedCsvFile(["bereich", "referenz_id", "kandidat_id", "feld", "referenz", "referenz_original", "herkunft", "bestand", "vergleich", "hinweis", "bestandsfundstelle"],
      [...report.contacts.flatMap((r) => r.candidates.flatMap((c) => c.fields.map((f) => ["kontakt", r.id, c.id, f.field, f.reference, f.originalReference, f.provenance, f.inventory, f.result, f.note, c.citation]))),
        ...report.schedules.flatMap((r) => r.candidates.flatMap((c) => c.fields.map((f) => ["termin", r.id, c.id, f.field, f.reference, f.originalReference, f.provenance, f.inventory, f.result, f.note, c.citation]))) ]),
    "abgleich-01-entscheidungen.csv": normalizedCsvFile(["befund_id", "bereich", "hinweisart", "titel", "referenz_ids", "bestands_ids", "beleg", "vorschlag_nicht_ausgefuehrt", "frage", "entscheidung"],
      report.findings.map((r) => [r.id, r.area, r.severity, r.title, r.referenceIds.join(";"), r.inventoryIds.join(";"), r.evidence, r.recommendation, r.question, r.decision])),
  };
}
