import "server-only";

import { readFile } from "node:fs/promises";
import path from "node:path";
import { db } from "@/db";
import { spp7Contacts, spp7Events } from "@/db/schema";
import { count, desc, getTableColumns, sql } from "drizzle-orm";

type ExportRecord = Record<string, string>;
type ArchiveData = {
  datasets: {
    events: ExportRecord[];
    contacts: ExportRecord[];
  };
};

function optional(value?: string) {
  const clean = value?.trim();
  return clean ? clean : null;
}

function coordinate(value?: string) {
  if (!value?.trim()) return null;
  const parsed = Number(value.replace(",", "."));
  return Number.isFinite(parsed) ? parsed : null;
}

function rank(value?: string) {
  if (!value?.trim()) return null;
  const match = value.match(/\d+/);
  return match ? Number(match[0]) : null;
}

async function readArchive(): Promise<ArchiveData> {
  const dataPath = path.join(process.cwd(), "public", "data", "spp7-datasets.json");
  return JSON.parse(await readFile(dataPath, "utf8")) as ArchiveData;
}

// Sync runs once per server process: new archive records are inserted and
// corrected values (e.g. application/fee status) overwrite existing rows.
let syncPromise: Promise<void> | null = null;

function seedArchive() {
  syncPromise ??= syncArchive().catch((error) => {
    syncPromise = null;
    throw error;
  });
  return syncPromise;
}

function excludedSet(columns: Record<string, { name: string }>, skip: string[]) {
  return Object.fromEntries(
    Object.entries(columns)
      .filter(([key]) => !skip.includes(key))
      .map(([key, column]) => [key, sql.raw(`excluded."${column.name}"`)]),
  );
}

async function syncArchive() {
  const archive = await readArchive();
  {
    const rows = archive.datasets.events.map((record) => ({
      eventId: record.EVENT_ID,
      sourceType: record.QUELLE_TYP || "Unbekannt",
      flyer: optional(record.FLYER),
      message: optional(record.MSG),
      type: record.TYP || "Event",
      name: record.NAME || "Ohne Namen",
      location: optional(record.LOCATION),
      street: optional(record.STRASSE),
      postalCode: optional(record.PLZ),
      city: optional(record.ORT),
      region: optional(record.REGION),
      country: optional(record.LAND),
      latitude: coordinate(record.LAT),
      longitude: coordinate(record.LNG),
      geoStatus: optional(record.GEO_STATUS),
      admission: optional(record.EINTRITT),
      fee: optional(record.GAGE),
      conditions: optional(record.KONDITIONEN),
      application: optional(record.BEWERBUNG),
      applicationStatus: optional(record.BEWERBUNG_STATUS),
      feeStatus: optional(record.GAGE_STATUS),
      aiRank: rank(record.KI_RANG),
      tags: optional(record.TAGS),
      shortDescription: optional(record.KURZBESCHREIBUNG),
      longDescription: optional(record.LANGBESCHREIBUNG),
      fit: optional(record.PASSUNG_SPP7),
      nextStep: optional(record.NAECHSTER_SCHRITT),
      unknown: optional(record.UNKLAR),
      source: optional(record.QUELLE),
    }));

    await db
      .insert(spp7Events)
      .values(rows)
      .onConflictDoUpdate({
        target: spp7Events.eventId,
        set: excludedSet(getTableColumns(spp7Events), ["eventId", "createdAt"]),
      });
  }

  {
    const rows = archive.datasets.contacts.map((record) => ({
      contactId: record.CONTACT_ID,
      organisation: record.ORGANISATION || "Ohne Organisation",
      type: optional(record.TYP),
      channel: optional(record.EMAIL_TELEFON),
      city: optional(record.ORT),
      region: optional(record.REGION),
      latitude: coordinate(record.LAT),
      longitude: coordinate(record.LNG),
      message: optional(record.MSG),
      note: optional(record.NOTIZ),
    }));

    await db
      .insert(spp7Contacts)
      .values(rows)
      .onConflictDoUpdate({
        target: spp7Contacts.contactId,
        set: excludedSet(getTableColumns(spp7Contacts), ["contactId", "createdAt"]),
      });
  }
}

export type Spp7Overview = {
  eventCount: number;
  contactCount: number;
  geocodedCount: number;
  openApplicationCount: number;
  featuredEvents: Array<{
    eventId: string;
    name: string;
    city: string | null;
    type: string;
    fit: string | null;
  }>;
};

export async function getSpp7Overview(): Promise<Spp7Overview> {
  await seedArchive();

  const [eventResult, contactResult, geoResult, applicationResult, featuredEvents] =
    await Promise.all([
      db.select({ total: count() }).from(spp7Events),
      db.select({ total: count() }).from(spp7Contacts),
      db
        .select({ total: count() })
        .from(spp7Events)
        .where(sql`${spp7Events.latitude} is not null and ${spp7Events.longitude} is not null`),
      db
        .select({ total: count() })
        .from(spp7Events)
        .where(sql`${spp7Events.applicationStatus} = 'offen'`),
      db
        .select({
          eventId: spp7Events.eventId,
          name: spp7Events.name,
          city: spp7Events.city,
          type: spp7Events.type,
          fit: spp7Events.fit,
        })
        .from(spp7Events)
        .orderBy(desc(spp7Events.aiRank), spp7Events.eventId)
        .limit(6),
    ]);

  return {
    eventCount: eventResult[0].total,
    contactCount: contactResult[0].total,
    geocodedCount: geoResult[0].total,
    openApplicationCount: applicationResult[0].total,
    featuredEvents,
  };
}