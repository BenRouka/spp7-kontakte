import { originalSchedule, sourceUrl, verifiedInventory } from "@/lib/reference-data";

export const timeModelVersion = "zeitmodell-2026-2027-v2";
export const adventCalendarRule = {
  fourthSunday: "Der 4. Advent ist der letzte Sonntag vor dem 25. Dezember (18.–24. Dezember).",
  christmasSunday: "Fällt der 25. Dezember auf einen Sonntag, ist der 4. Advent am 18. Dezember, nicht am 25. Dezember.",
  sourceUrl: "https://katholisch.de/artikel/15657-das-bedeuten-die-vier-advenssonntage",
} as const;

export type ReviewYear = 2026 | 2027;
export type SourceRow = {
  id: string;
  year: ReviewYear;
  lineNumber: number;
  dateOriginal: string;
  nameOriginal: string;
  placeOriginal: string;
  originalLine: string;
  uncertain: boolean;
  locationOpen: boolean;
};
export type Period = {
  id: string;
  ordinal: number;
  start: string;
  end: string;
};
export type ReviewedEvent = {
  source: SourceRow;
  kind: "weekends" | "continuous";
  dateOrigin: "berechnet" | "aus Quelle";
  weekdayLabel: string;
  periods: Period[];
  dayCount: number;
};
export type ReviewData = {
  year: ReviewYear;
  modelVersion: typeof timeModelVersion;
  adventRule: typeof adventCalendarRule;
  rows: SourceRow[];
  totals: { all: number; year2026: number; year2027: number; uncertain: number; openLocations: number };
  advent: ReviewedEvent;
  christmas: ReviewedEvent;
  sourceUrl: string;
  inventory: typeof verifiedInventory;
  database: { connected: boolean; readOnly: true };
};
export type CalendarReview = Omit<ReviewData, "database">;

const DAY = 86_400_000;
export function isoDate(date: Date) {
  return date.toISOString().slice(0, 10);
}
export function addDays(iso: string, days: number) {
  return isoDate(new Date(new Date(`${iso}T12:00:00Z`).getTime() + days * DAY));
}
export function dateLabel(iso: string, options?: Intl.DateTimeFormatOptions) {
  return new Intl.DateTimeFormat("de-DE", { day: "numeric", month: "long", timeZone: "UTC", ...options }).format(new Date(`${iso}T12:00:00Z`));
}
export function shortRange(period: Period) {
  const from = new Date(`${period.start}T12:00:00Z`);
  const to = new Date(`${period.end}T12:00:00Z`);
  if (from.getUTCMonth() === to.getUTCMonth()) return `${from.getUTCDate()}.–${dateLabel(period.end)}`;
  return `${dateLabel(period.start)} – ${dateLabel(period.end)}`;
}

// Church rule: Christmas Day is never counted as an Advent Sunday.
// UTC calendar arithmetic makes the result independent of the server timezone.
export function getAdventSundays(year: number): string[] {
  if (!Number.isInteger(year) || year < 1583 || year > 9998) throw new Error("Ungültiges gregorianisches Kalenderjahr.");
  const christmasDay = new Date(Date.UTC(year, 11, 25, 12));
  const fourthSunday = christmasDay.getTime() - (christmasDay.getUTCDay() || 7) * DAY;
  return Array.from({ length: 4 }, (_, index) => isoDate(new Date(fourthSunday - (3 - index) * 7 * DAY)));
}

export function readSourceRows(): SourceRow[] {
  return originalSchedule.split("\n").flatMap((originalLine, index) => {
    const parts = originalLine.split("\t");
    if (parts.length !== 3) return [];
    const [dateOriginal, nameOriginal, placeOriginal] = parts.map((part) => part.trim());
    const yearMatch = dateOriginal.match(/\b(2026|2027)\b/);
    if (!yearMatch) return [];
    const year = Number(yearMatch[1]) as ReviewYear;
    return [{
      id: `SF-${year}-L${String(index + 1).padStart(2, "0")}`,
      year,
      lineNumber: index + 1,
      dateOriginal,
      nameOriginal,
      placeOriginal,
      originalLine,
      uncertain: originalLine.includes("*"),
      locationOpen: /^x+$/.test(placeOriginal),
    }];
  });
}

export function buildCalendarReview(year: ReviewYear): CalendarReview {
  const allRows = readSourceRows();
  const rows = allRows.filter((row) => row.year === year);
  const adventRow = rows.find((row) => row.dateOriginal.includes("Advent"));
  const christmasRow = rows.find((row) => row.nameOriginal === "Mittelalter- Weihnacht");
  if (!adventRow || !christmasRow) throw new Error("Die benötigten Originalzeilen fehlen.");
  const startsThursday = adventRow.nameOriginal.includes("Do.");
  const startsFriday = adventRow.nameOriginal.includes("Fr.");
  if (startsThursday === startsFriday) throw new Error("Wochentage der Adventsquelle nicht eindeutig.");
  const periods = getAdventSundays(year).map((end, index) => ({
    id: `${adventRow.id}-P${index + 1}`, ordinal: index + 1,
    start: addDays(end, startsThursday ? -3 : -2), end,
  }));
  const match = christmasRow.dateOriginal.match(/^(\d{1,2})\.\s*(\d{1,2})\.\s*-\s*(\d{1,2})\.\s*Dezember\s+(2026|2027)\*?$/);
  if (!match || Number(match[4]) !== year) throw new Error("Weihnachtsmarkt-Datum ist nicht eindeutig lesbar.");
  const continuousPeriod: Period = {
    id: `${christmasRow.id}-P1`, ordinal: 1,
    start: isoDate(new Date(Date.UTC(year, Number(match[2]) - 1, Number(match[1]), 12))),
    end: isoDate(new Date(Date.UTC(year, 11, Number(match[3]), 12))),
  };
  return {
    year,
    modelVersion: timeModelVersion,
    adventRule: adventCalendarRule,
    rows,
    totals: {
      all: allRows.length,
      year2026: allRows.filter((r) => r.year === 2026).length,
      year2027: allRows.filter((r) => r.year === 2027).length,
      uncertain: allRows.filter((r) => r.uncertain).length,
      openLocations: allRows.filter((r) => r.locationOpen).length,
    },
    advent: { source: adventRow, kind: "weekends", dateOrigin: "berechnet", weekdayLabel: startsThursday ? "Do.–So." : "Fr.–So.", periods, dayCount: periods.length * (startsThursday ? 4 : 3) },
    christmas: { source: christmasRow, kind: "continuous", dateOrigin: "aus Quelle", weekdayLabel: "", periods: [continuousPeriod], dayCount: Math.round((new Date(continuousPeriod.end).getTime() - new Date(continuousPeriod.start).getTime()) / DAY) + 1 },
    sourceUrl,
    inventory: verifiedInventory,
  };
}
