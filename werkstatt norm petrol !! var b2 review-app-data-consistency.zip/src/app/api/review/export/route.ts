import { getReviewData, parseReviewYear } from "@/lib/review-repository";
import { calendarReport, csvReport, markdownReport } from "@/lib/review-report";

export const dynamic = "force-dynamic";
export async function GET(request: Request) {
  const query = new URL(request.url).searchParams;
  const year = parseReviewYear(query.get("year"));
  if (!year) return Response.json({ error: "Ungültiges Quelljahr." }, { status: 400 });
  const format = query.get("format") || "md";
  if (!["md", "csv", "ics"].includes(format)) return Response.json({ error: "Verfügbar: md, csv, ics." }, { status: 400 });
  const originals = query.get("kind") === "originals";
  if (originals && format !== "csv") return Response.json({ error: "Originalzeilen werden ausschließlich als CSV exportiert." }, { status: 400 });
  try {
    const data = await getReviewData(year);
    const content = format === "md" ? markdownReport(data) : format === "csv" ? csvReport(data, originals) : calendarReport(data);
    const mime = format === "md" ? "text/markdown" : format === "csv" ? "text/csv" : "text/calendar";
    return new Response(content, { headers: {
      "Content-Type": `${mime}; charset=utf-8`,
      "Content-Disposition": `attachment; filename="spp7-${originals ? "quelltermine" : "zeitmodell"}-${year}.${format}"`,
      "Cache-Control": "no-store",
      "X-SPP7-Model-Version": data.modelVersion,
    } });
  } catch {
    return Response.json({ error: "Der Prüfbericht konnte nicht erstellt werden." }, { status: 500 });
  }
}
