# Befundbericht A — Abgleich Werkstatt ↔ Alt-App ↔ Mockup

**Stand:** 2026-10-04
**Art:** rein lesende Analyse. Keine Schemaänderung, kein Import, keine Änderung an Freeze-Dateien, Alt-App oder Mockup.
**Auftrag:** Fünf offene Punkte mit belegten Zahlen klären (mindestens eindeutige Identifikation der Alt-App, Mockup-Inhalt, Flyer-Zahl, Kontakt-Overlap, Termin-Overlap, Prüfsperren O-01/O-04/O-07/O-08).
**Datenschutz:** B-17 — intern only. Enthält IDs und Orte, keine vollständigen Kanalwerte.

**Quellen (alle nur gelesen):**

| Quelle | Datei | Zweck |
|---|---|---|
| Werkstatt | `public/export/FREEZE/*.csv` + DB | Kuratierter Soll-Bestand (35/54) |
| Alt-App | `varB chat! pics scharf 180 maps app-replication-workflow-setup.zip` → `public/data/spp7-datasets.json` | Altbestand, Zustand A |
| Mockup | `spp7-mockup.zip` → `data.js` (`window.SPP7_DATASETS`) | Altbestand, Zustand M (neuer) |
| Chat-Export | `ChatExport_2026-09-20.zip` | 200 Bilddateien + `result.json` (Telegram) |

**Methodik:** Nur exakte String-Vergleiche (E-Mail-Exakt, Name normalisiert: klein/trim/whitespace-kollabiert). Abweichungen werden als Befund benannt, nicht geraten. „Gefüllt" = Feld nicht leer (auch Platzhalterwerte wie „keine Angabe" zählen als gefüllt und werden zusätzlich in ihrer Verteilung ausgewiesen).

---

## 1. Zentraler Befund: Das Mockup enthält den neuesten Datenstand

Die `data.js` des Mockups ist **keine Kopie** der Alt-App-JSON, sondern ein **neuerer Zustand**:

| Datensatz | Alt-App JSON | Mockup data.js | Differenz |
|---|---:|---:|---|
| events | 206 | 240 | +34 (S07–S40) |
| event_dates | 203 | 240 | +37 |
| ART = „Sündenfrei 2027" | 2 | **45** | +43 |
| VON_ISO-Jahr 2027 | 12 | 49 | +37 |
| Geocodiert (LAT+LNG) | 180/206 | **212/240** | — |
| contacts | 74 | 74 | identisch |
| acts/tags/partner/feed/chat/flyer | wie Mockup | wie Alt-App | identisch |

**Belegt:** Das Mockup enthält den vollständigen Sündenfrei-2027-Import (45 Termine, Stand 29.09.2026 laut README) — dieselbe Quelle (`Termine 2027 Veranstalter suendenfrei.txt`), aus der die Werkstatt ihre 45 Termine 2027 kuratiert hat. Event-ID-Präfixe Mockup: F 71 · M 47 · S 40 · K 38 · C 30 · T 9 · R 5.

**Konsequenz (Vorschlag, keine Entscheidung):** Für jede künftige Übernahme ist das Mockup (`data.js`) die maßgebliche Alt-Datenquelle, nicht die ältere Alt-App-JSON. Die Alt-App-JSON bleibt Beleg für Zustand A.

---

## 2. Prüfsperren — aufgelöst durch Originalbefund

### O-04 · D196/D197 Stolpen — JAHRESFRAGE GELÖST
D-IDs sind **Datumssätze** (`event_dates.DATE_ID`), keine Events. Beide gehören zum Event **S06**:

| DATE_ID | EVENT | NAME | ZEitraum | ART | KOMMENTAR |
|---|---|---|---|---|---|
| D196 | S06 | Drachen und Ritter Stolpen | 08.–09.08.**2026** | Festivaltermin 2026 | — |
| D197 | S06 | Drachen und Ritter Stolpen | 14.–15.08.**2027** | Sündenfrei 2027 (Mock) / Festivaltermin 2027 (Alt) | nach Juli-Ostsee-Fenster |

**Befund:** D196 ist eine **eigenständige, korrekte 2026-Zeile** — kein Schreibfehler von D197. Die Jahresabweichung ist keine Abweichung: zwei verschiedene Festivals desselben Veranstaltungsstandorts. **Keine Löschung erforderlich; die Sperre ist damit gegenstandslos.** Hinweis: D197 trägt derzeit den Namen „Drachen und Ritter Stolpen"; der im Gespräch bestätigte offizielle Name („Fantasy- und Mittelalterfest", 01833 Stolpen/Burg) ist eine Werkstatt-Kuratierung und wurde nirgendwo eingetragen.

### O-08 · D113/D198 — IDENTITÄT BESTÄTIGT
Beide gehören zum Event **M21 „Ritterturnier"**, identischer Zeitraum:

| DATE_ID | EVENT | ZEitraum | ART | KOMMENTAR |
|---|---|---|---|---|
| D113 | M21 | 01.–03.05.2026 | Festivaltermin (KI-Liste) | — |
| D198 | M21 | 01.–03.05.2026 | Sündenfrei 2026 | Ritterturnier Freyburg/Neuenburg |

**Befund:** Gleicher Event, gleicher Zeitraum — die im Gespräch bestätigte Bereinigung (offiziellen D198 behalten, KI-D113 entfernen) ist damit **faktisch abgesichert**. Nicht ausgeführt; bedarf der Freigabe im Zuge der Migration.

### O-07 · F29 — AUFGEKLÄRT
**F29 existiert nicht als Event** (in keinem der beiden Zustände). Es existiert nur `feed_context[20]`:

```json
{"LINK_ID": "FC21", "EVENT_ID": "F29", "EVENT_NAME": "F29",
 "ACCOUNT": "faktglaublich", "NOTIZ": "\"Bayern zahlt 3.000 Euro an alle…\"",
 "RELEVANZ": "irrelevant"}
```

**Befund:** F29 ist eine **tote Referenz** — ein Feed-Kontext-Link auf ein nicht vorhandenes Event (EVENT_NAME = ID ist das Indiz). Kein Datenverlust; die Zeile kann bei der Migration als verwaiste Referenz behandelt werden.

### O-01 · K53/KV17 Lohme — BELEGT
K53 matcht per E-Mail-Exakt auf KV17 (Touristik Lohme GmbH) — bestätigt den Befund: gleicher Kanal, anderer Organisationstyp. Keine Aktion (Regel steht).

### O-10 · Gleichnamige Events — BELEGT
SF38 „Burgfest" matcht namentlich **drei verschiedene Orte**: M14 Falkenstein (Harz) · M19 Creuzburg · M22 Orlamünde. SF23 „Mittelaltermarkt" matcht **fünf**: M04 Weißenfels · M06 Hohenmölsen · M24 Breitungen · M27 Vacha · M47 Osnabrück. → **Name allein ist kein Identitätsbeweis**; Identität = Name + Ort + Datum (Regel O-10 bestätigt sich in den Daten).

---

## 3. Kontakt-Abgleich: 74 (Alt) ↔ 35 (Werkstatt)

| Kennzahl | Wert |
|---|---:|
| E-Mail-Exakt-Matches | **37** Alt-Kontakte → 19 verschiedene KV-IDs |
| Name-Exakt-Matches | 12 (alle zusätzlich auch E-Mail-Match) |
| Alt-Kontakte mit Match gesamt | **37/74** |
| Werkstatt-KV mit Match | **33/35** |
| Werkstatt-KV **ohne** Alt-Match | **KV10, KV13** |
| Alt-Kontakte ohne Match | **37** (K09, K24, K26–K28, K30, K34–K52, K54–K56, K58–K63, K64, K73, K74) |

**E-Mail-Match-Paare (KV ↔ K):**
KV01←K01,K02 · KV01.1←K65 · KV01.2←K33 · KV02←K03 · KV03←K04 · KV04←K66 · KV05←K05 · KV06←K06 · KV07←K07,K68 · KV08←K67 · KV09←K08 · KV11←K69 · KV12←K10 · KV14←K11 · KV15←K12 · KV16←K13 · KV17←**K53** · KV18←K14 · KV19←K15 · KV20←K16 · KV21←K17 · KV22←K18 · KV23←K19 · KV24←K57 · KV25←K20 · KV26←K21 · KV27←K22,K23,K70 · KV28←K71 · KV29←K29 · KV30←K31 · KV31←K32 · KV32←K72 · STADT-PUTBUS←K25

**Interpretation (als solche gekennzeichnet):** Mehrere K-IDs je KV-IDs = Kanaltrennung (O-09-Struktur der Werkstatt deckt sich mit dem Altbestand). Die 37 unmatched Alt-Kontakte sind überwiegend Portale/Mitarbeiter-Kanäle und Chat-Kontakte (u. a. K64, K73 — Kanalfälle aus O-09) sowie K53 (bekannt). KV10/KV13 haben keine Entsprechung im Altbestand — kuratierte Neuaufnahmen der Werkstatt.

---

## 4. Termin-Abgleich: 240/206 (Alt) ↔ 54 (Werkstatt)

| Kennzahl | Wert |
|---|---:|
| Exakte Namens-Matches Mockup-Events ↔ Freeze-Termine | **19** |
| davon 2027/Sündenfrei (S07–S40) | 8 (SF12, SF22, SF25, SF26, SF31, SF43, SF44, SF46) |
| davon Alt-App-Zustand (206 Events) | 11 |

**Namens-Matches (Event ↔ SF):** M04↔SF23 · M06↔SF23 · M14↔SF38 · M17↔SF21 · M19↔SF38 · M22↔SF38 · M24↔SF23 · M27↔SF23 · M28↔SF40 · M33↔SF40 · M47↔SF23 · S07↔SF12 · S15↔SF22 · S17↔SF25 · S18↔SF26 · S22↔SF31 · S31↔SF43 · S32↔SF44 · S34↔SF01

**Wichtiger Befund — Namens-Abweichung trotz gleicher Quelle:** Beispiel SF02 „**373.** Zwiebelmarkt" (99423 Weimar) vs. S35 „**374.** Zwiebelmarkt** Weimar**" (PLZ 99423) — gleiche Veranstaltung, andere Jahreszählung und Namenszusatz. Nur 8 der 45 Freeze-2027-Termine matchen exakt namentlich, obwohl beide aus `suendenfrei.txt` stammen. → **Eine Migration braucht ein mehrstufiges Matching (Name normalisiert → PLZ/Ort → Zeitfenster), kein bloßer Namensvergleich.** Das ist der eigentliche Abgleichsaufwand, quantitativ: 240 Events × 54 Termine, davon 19 vorab exakt.

---

## 5. Material-Inventar (Flyer · Screens · Bewerbungen/Gagen · Chat)

*Gemäß Arbeitsregel: „Flyer" schließt Screenshots und Bewerbungen mit Gagen etc. ein.*

### 5.1 Flyer-Bilder (Mockup, physische Dateien)
| Position | Zahl | Beleg |
|---|---:|---|
| Flyer-Nummern | **79** (1–79, keine Lücken) | Dateiliste `flyers/` |
| Originale `flyer_NN.jpg` | 79 | `find`-Zählung |
| Thumbnails `flyer_NN_thumb.jpg` | 79 | `find`-Zählung |
| `flyers/QUELLE.txt` | 1 | Zuordnung FLYER → MSG → Originaldateiname |
| davon Screenshots (572×1280) | 35 | README (Mockup) |
| davon Handyfotos | 44 | README (Mockup) |

Die frühere Zählunsicherheit („80 Vollbilder") ist aufgeklärt: die 80. Nicht-Thumb-Datei ist `QUELLE.txt`. **meta.flyers=79 · flyersCaptured=71 · flyer_sources=79** — die Differenz 79/71 schlägt sich in den STATUS-Werten nieder (unten).

### 5.2 flyer_sources (Daten, 79 Zeilen)
| STATUS | Zeilen |
|---|---:|
| neu erfasst | 42 |
| erfasst | 29 |
| Manuelle Sichtung nötig | 3 |
| Duplikat | 2 |
| Zusatzquelle | 2 |
| Zusatzquelle (unsicher) | 1 |

76 der 79 Zeilen haben eine EVENT_ID (3 ohne).

### 5.3 Bewerbungen & Gagen (Events, n=240 im Mockup / 206 Alt — Werte identisch)
| Feld | gefüllt | Verteilung |
|---|---:|---|
| BEWERBUNG | 43 | — |
| BEWERBUNG_STATUS | 43 | 31 geschlossen · **9 offen** · 3 unklar |
| GAGE | 36 | — |
| GAGE_STATUS | 206/206 | 33 bestätigt · 12 unklar · 161 „keine Angabe" |
| KONDITIONEN | 41 | — |
| EINTRITT | 13 | — |
| FLYER-Referenz am Event | 71 | — |

### 5.4 Chat-Quellenmaterial
| Quelle | Umfang |
|---|---|
| `ChatExport_2026-09-20.zip` | 209 Dateien: **158 jpg + 42 png (= 200 Bilder)** + `result.json` + html/css/js (Telegram-Export) |
| chat_items (Daten) | 149: 91 E-Mail · 20 URL · 16 Text · 16 URL (Text-Link) · 2 Foto-Caption · 2 Hashtag · 2 Telefon |
| feed_context (Daten) | 22 Zeilen (F06–F33, inkl. tote Referenz F29) |
| Mockup-App-Screenshots | 6 PNG (Views) |
| timetable (Daten) | 15 Programmzeilen |

---

## 6. Geo / Map-Panel (Mockup)

- **Keine** externe Map-Bibliothek (kein Leaflet/Mapbox/OSM). Das Karten-Panel ist ein **eigenes SVG („Event-Radar")** mit 2 `<svg>`-Elementen.
- Koordinaten liegen als Stringfelder `LAT`/`LNG` an Events **und** Kontakten (Dezimalgrad, z. B. S06: 51.04923).
- Geocodiert: **212/240 Events** (Mockup) bzw. 180/206 (Alt). 28 Events ohne Koordinaten, u. a. S11 „Offener Termin April" und S26 „Burgfest August" (beide ohne Ort in der Quelle — deckt sich mit README: 41 von 43 Sündenfrei-Orten mit Koordinaten).
- ⚠️ B-GEO/O-11 bleibt gesperrt: Koordinaten werden **nicht** automatisch übernommen; Quelle/Genauigkeit/Status ist je Datensatz zu prüfen, bevor irgendein Kartenimport passiert.

---

## 7. Fazit und vorgeschlagene nächste Schritte

1. **O-04, O-07, O-08 sind faktisch aufgeklärt** — die Sperren können mit diesem Bericht als Unterlage fallengelassen bzw. in gezielte Einzelentscheidungen überführt werden (D113-Entfernung erst im Migrationskontext, F29 als verwaiste Referenz dokumentiert).
2. **Das Mockup ist der aktuelle Alt-Datenstand** (240/240/212) und enthält das vollständige Sündenfrei-2027-Set — es ist der Zulieferer, nicht die Alt-App-JSON.
3. **Der Abgleich ist das Kernstück:** Nur 19 exakte Namens-Matches; Identität erfordert mehrstufiges Matching (Name → PLZ/Ort → Zeitfenster). Kontakte: 33/35 gedeckt, 37 Alt-Kontakte und KV10/KV13 separat zu behandeln.
4. **Nichts wurde verändert.** Keine Schemaänderung, kein Import, kein Schreiben in irgendeine Quelle.

**Vorgeschlagene Reihenfolge der nächsten Mini-Schritte (jeweils einzeln zu bestätigen):**
- **A1:** Abgleichsmatrix Termine erstellen (rein lesend): alle 240 Events × 54 Termine mit Match-Stufen (Name exakt / Name+PLZ / PLZ+Ort+Zeitfenster) als CSV-Befund.
- **A2:** Abgleichsmatrix Kontakte (rein lesend): 74 Alt-Kontakte mit Vorschlag je Zeile (kanal-zuordnen / neu / ignorieren) — **nur Vorschlag, keine Zuordnung ohne ja.**
- **A3:** Danach erst: Schema-Erweiterungen einzeln besprechen (Material/Anlagen inkl. Bewerbung+Gage → Geo → Herkunft Prio-1/Prio-2). Reihenfolge vorgeschlagen, nicht entschieden.

**Ende Befundbericht A.**
