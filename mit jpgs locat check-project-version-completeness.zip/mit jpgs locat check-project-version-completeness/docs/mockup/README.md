# SPP7 Mockup

Statische HTML-Nachbildung von `spp7-dashboard.tsx` — **ohne** Node, React, Next.js oder PostgreSQL.
Doppelklick auf `index.html` genügt.

## Dateien

| Datei | Herkunft |
|---|---|
| `index.html` | Markup + Vanilla-JS, 1:1 portiert aus `src/components/spp7-dashboard.tsx` und `spp7-chat-view.tsx` |
| `globals.css` | Unverändert aus `src/app/globals.css` (nur die Zeile `@import "tailwindcss";` entfernt, da kein PostCSS-Build läuft) |
| `data.js` | Inlinet `public/data/spp7-datasets.json` + `spp7-chat.json` als `window.SPP7_DATASETS` / `window.SPP7_CHAT` |
| `spp7-logo.png` | Logo 256×258 (RGBA), 74 KB - Kopie aus `C:\Users\User\Music\1_spp\website\pics\logo spp 256.png`, identisch mit `app-replication-workflow-setup/public/spp7-logo.png` |
| `flyers/flyer_NN_thumb.jpg` | Flyer-Thumbnails aus dem Telegram-Export, 2,06 MB — für Tabellen und Chat |
| `flyers/flyer_NN.jpg` | dieselben Flyer in Originalauflösung, 7,25 MB — für die Lightbox |
| `flyers/QUELLE.txt` | Zuordnung FLYER → MSG → Originaldateiname, belegt aus `result.json` |
| `media/notes.js` | lokale Textergänzungen pro Chat-Nachricht |
| `media/LIESMICH.txt` | Ablage-Konvention für fehlende Medien |

Die Daten liegen als `data.js` statt `.json`, weil `fetch()` auf `file://` von Chrome blockiert wird.

## Views

Übersicht · Events/Termine (14 Tabellen) · Opportunities · Kontakte · Chat-Verlauf — alle klickbar,
inkl. Detail-Drawer, Volltextsuche, CSV-Export und Paginierung.

## Flyer

Ein Klick auf ein Thumbnail (Event-Tabelle, Flyer-Quellen oder Chat) öffnet eine Lightbox mit dem
Originalbild. Navigation über die Pfeiltasten oder `←`/`→`, Schließen mit `Esc` oder Klick auf den
Hintergrund. Zähler oben rechts zeigt die Position unter allen 79 Flyern.

Die Tabelle lädt bewusst nur die Thumbnails, die Lightbox die Originale — dadurch bleibt die Tabelle
schnell und die Vergrößerung bleibt scharf. Fehlt ein Original, greift automatisch das Thumbnail als
Rückfallebene.

Die Bilder sind uneinheitlich, weil sie aus dem Chat stammen: 35 der 79 sind Screenshots im Format
572×1280, die übrigen 44 Handyfotos mit wechselnden Abmessungen (kleinste Originale 633×763,
größte 1000×750). Die Thumbnails hat Telegram auf eine Kantenlänge von 520 px skaliert, sie sind
deshalb 232×520 oder 520×n und nicht einheitlich.

Dateinamen folgen der Konvention der echten App (`spp7-dashboard.tsx`, `flyerThumbSrc` /
`flyerOriginalSrc`): `flyers/flyer_NN_thumb.jpg` und `flyers/flyer_NN.jpg`. Die 158 Dateien liegen
bereits auch in `app-replication-workflow-setup/public/flyers/`, wo die App sie erwartet.

## Lokale Ergänzungen

Ohne Änderung an den Daten lassen sich fehlende Medien und Texte nachtragen:

- **Video MSG 43965** — Telegram hat die Datei nicht mitgeliefert. Ablage als
  `media/msg_43965.mp4` genügt; die Blase zeigt solange einen Platzhalter mit dem Dateinamen.
  Gleiches gilt für Bilder mit `media/msg_<N>.jpg`.
- **Texte** — in `media/notes.js` eine MSG-Nummer auf Text abbilden. Der Text erscheint unter dem
  vorhandenen, mit Markierung „ergänzt", und ist über die Chat-Suche auffindbar.

Dateien in `media/` sind lokale Ergänzungen und gehören nicht in den Datenbestand.

## Abweichungen vom Original

| Punkt | Grund |
|---|---|
| Daten aus JSON statt PostgreSQL | Postgres liefert nur die 5 KPI-Zahlen; identische Werte werden zur Laufzeit berechnet |
| Flyer-Bilder lokal unter `flyers/` | `public/flyers/*.jpg` ist im Export nicht enthalten, die Bilder stammen aus dem Telegram-Chat-Export |
| Icons als selbst gezeichnete SVGs | `lucide-react` benötigt den npm-Paketbuild |
| Kein `⌘ K`-Shortcut | Im Original ohnehin nur dekorativ (kein Handler) |

## Datenzahlen (aus dem Export)

- 242 Events · 240 Termine · 221 Acts · 74 Kontakte · 2.238 Records in 14 Tabellen
- 214 von 242 Events geocodiert
- 45 Termine mit `ART = "Sündenfrei 2027"` (Import aus `Termine 2027 suendenfrei.txt`, Stand 29.09.2026)
- 43 Sündenfrei-2027-Terminorte, davon 41 mit Koordinaten (`S11`/`S26` ohne Anschrift in der Quelle); im Event-Radar orange markiert
- Zeitspanne der 45 Termine: 02.01.–30.12.2027 (im Karten-Badge direkt am Sündenfrei-Zähler)
- Die Tooltips im Event-Radar zeigen den Veranstaltungstermin: 181 der 213 sichtbaren Punkte haben
  ein Datum, alle 41 Sündenfrei-Punkte. Bevorzugt werden Veranstaltungstermine, Metatermine
  (`Post-Datum`, `Bewerbungsfrist`, `Feed-Kontext`) bleiben hinten. Gibt es die Veranstaltung für
  2026 und 2027, erscheint das Jahr mit dem höheren Rang zuerst, der Rest desselben Jahres folgt
  chronologisch — sonst stünde bei Kranichfeld und Freyburg der 2026er Termin vorn.
- 9 offene Bewerbungen
- 79 Flyer (71 erfasst) · 120 Chat-Nachrichten
- Zeichenkodierung: UTF-8 ohne BOM, LF. In `spp7-datasets.json` lagen vier als Windows-1252
  missverstandene Umlaute (alle in `T11`: `ÃŸ` statt `ß`, `Ã¤` statt `ä`), dort sind sie einzeln
  korrigiert. Der eingebettete Chat in `data.js` war vollständig so missverstanden (211 Stellen,
  `Ãœberschneidung` statt `Überschneidung`, `CafÃ©` statt `Café`) und wurde durch eine Neuablesung
  aus `spp7-chat.json` ersetzt — `data.js` ist damit byteidentisch mit `spp7-datasets.json` +
  `spp7-chat.json`.

## Tourkorridor 2027

Der Kasten unter dem Event-Radar listet sechs Stationen — vier Ostsee-Stopps und zwei Berliner
Vormerkungen. Die Liste steckt in `routeStops` (`index.html` bzw. `spp7-dashboard.tsx`):

| EVENT_ID | Station | Anzeige |
|---|---|---|
| `S04` | Insel Poel | 16.–18.07.2027 |
| `S03` | Stralsund | 22.–25.07.2027 |
| `T04` | Rügenhof | Datum noch offen |
| `T09` | Schaprode | Datum noch offen |
| `T11` | Wagendorf Karow | Termin offen · ab Mitte Juli |
| `T12` | Arcanoa | Termin offen · ab Mitte Juli |

`T11` und `T12` sind reine Vormerkungen (`QUELLE_TYP = "Nutzer / Tourplanung"`,
`TYP = "Tour-Stopp (Vormerkung 2027)"`) ohne Eintrag in `event_dates`. Fehlt der Termin, greift
das Feld `hint` statt des starren Texts „Datum noch offen". Weil zwei der sechs Stationen in Berlin
liegen, heißt die Überschrift neutral „TOURKORRIDOR · 2027"; die Zeile darunter zählt veröffentlichte
Termine und Vormerkungen dynamisch aus `routeStops` (aktuell 2 + 4).

Auf der Karte tragen alle sechs Stationen einen grünen Ring. Das Berliner Clustering bleibt sichtbar:
`T11` (52,6170 / 13,4540) und `T12` (52,4880 / 13,3868) liegen nur 4,4 px auseinander und
überlagern mehrere weitere Berliner Punkte — die Projektion `x = 105 + ((lng − 5) / 11) · 250`,
`y = 300 − ((lat − 47) / 8,5) · 270` ist zu grob, um Stadtteile aufzulösen.
