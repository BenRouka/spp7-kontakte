/* ------------------------------------------------------------------ */
/* Stufe 5 — Import des Freeze-Pakets in die Datenbank.                */
/* Ablauf (verbindlich):                                               */
/*   1. Integritäts-Gate: sha256 jeder Freeze-Datei wird neu berechnet */
/*      und mit PRUEFSUMMEN.sha256 abgeglichen. Abweichung = Abbruch,  */
/*      es wird nichts geschrieben.                                    */
/*   2. Transaktionaler Import: alte Stände der Zieltabellen werden    */
/*      verworfen, das Paket komplett neu eingespielt (idempotent).    */
/*   3. Protokoll: je Datei eine Zeile in import_protokoll.            */
/* Ausführung:  npx tsx src/db/seed.ts                                 */
/* ------------------------------------------------------------------ */

import { randomUUID } from "node:crypto";
import { sql } from "drizzle-orm";
import { db, pool } from "./index";
import {
  beschluesse,
  importProtokoll,
  kontakte,
  regionen,
  terminZeitfenster,
  termine,
} from "./schema";
import {
  hatMdBlock,
  kontaktStats,
  loadFreeze,
  parsePruefsummen,
  readFreeze,
  REGION_ORDER,
  sha256OfFile,
  terminStats,
} from "../lib/freeze";

async function main() {
  console.log("— Stufe 5 · Import des Freeze-Pakets —");

  /* 1 · Integritäts-Gate ------------------------------------------- */
  const manifest = parsePruefsummen(readFreeze("PRUEFSUMMEN.sha256"));
  const checks = manifest.map(({ file, hash }) => {
    const actual = sha256OfFile(file);
    return { file, expected: hash, actual, match: actual === hash };
  });
  for (const c of checks) {
    console.log(
      `  sha256 ${c.match ? "OK  " : "FAIL"}  ${c.file}  ${c.actual.slice(0, 16)}…`,
    );
  }
  const failed = checks.filter((c) => !c.match);
  if (failed.length > 0) {
    console.error(
      `\nABBRUCH: ${failed.length} Datei(en) weichen vom Manifest ab. Es wurde nichts geschrieben.`,
    );
    process.exit(1);
  }

  /* 2 · Freeze lesen ------------------------------------------------ */
  const freeze = loadFreeze();
  const kStats = kontaktStats(freeze.kontakte);
  const t26 = terminStats(freeze.termine, "2026");
  const t27 = terminStats(freeze.termine, "2027");
  const regionIds = new Map<string, number>(
    REGION_ORDER.map((r, i) => [r, i + 1]),
  );

  // Plausibilität gegen die Ground-Truth-Zahlen des Handoffs
  const erw = [
    [freeze.kontakte.length, 35, "Kontakt-Datensätze"],
    [freeze.termine.length, 54, "Termin-Quellzeilen"],
    [t26.zeitfenster + t27.zeitfenster, 60, "Zeitfenster gesamt"],
    [t26.quellzeilen, 9, "Quellzeilen 2026"],
    [t26.zeitfenster, 12, "Zeitfenster 2026"],
    [t27.quellzeilen, 45, "Quellzeilen 2027"],
    [t27.zeitfenster, 48, "Zeitfenster 2027"],
    [freeze.beschluesse.length, 20, "Beschlüsse"],
    [kStats.regionen, 9, "Regionen"],
  ] as const;
  for (const [ist, soll, label] of erw) {
    if (ist !== soll) {
      console.error(
        `\nABBRUCH: Plausibilitätsprüfung fehlgeschlagen — ${label}: erwartet ${soll}, gelesen ${ist}.`,
      );
      process.exit(1);
    }
  }
  console.log("  Plausibilität OK (54/60, 9/12, 45/48, 35, 20, 9 Regionen)");

  /* 3 · Transaktionaler Import -------------------------------------- */
  const laufId = randomUUID();
  const entschieden = freeze.beschluesse.filter(
    (b) => b.status === "entschieden",
  ).length;

  await db.transaction(async (tx) => {
    await tx.delete(terminZeitfenster);
    await tx.delete(termine);
    await tx.delete(kontakte);
    await tx.delete(regionen);
    await tx.delete(beschluesse);
    await tx.delete(importProtokoll);

    await tx.insert(regionen).values(
      REGION_ORDER.map((name, i) => ({ id: i + 1, name })),
    );

    await tx.insert(kontakte).values(
      freeze.kontakte.map((r, i) => ({
        kvId: r.kvId,
        regionId: regionIds.get(r.region)!,
        ort: r.ort,
        name: r.name,
        anschrift: r.anschrift || null,
        telefon: r.telefon || null,
        fax: r.fax || null,
        email1: r.email1 || null,
        email2: r.email2 || null,
        email3: r.email3 || null,
        web: r.web || null,
        typ: r.typ,
        prio2ChatHinweis: r.hinweis || null,
        hatMdBlock: hatMdBlock(r),
        sortierung: i,
      })),
    );

    await tx.insert(termine).values(
      freeze.termine.map((r, i) => ({
        sfId: r.sfId,
        jahr: Number.parseInt(r.jahr, 10),
        datumOriginal: r.datumOriginal,
        nameOriginal: r.name,
        plzOrtOriginal: r.plzOrt,
        zeitfensterAnzahl: r.anzahl,
        sternchen: r.sternchen || "kein",
        hinweis: r.hinweis || null,
        sortierung: i,
      })),
    );

    await tx.insert(terminZeitfenster).values(
      freeze.termine.flatMap((r) =>
        r.fenster.map((f) => ({
          terminSfId: r.sfId,
          nr: f.nr,
          von: f.von,
          bis: f.bis,
          raw: f.raw,
        })),
      ),
    );

    await tx.insert(beschluesse).values(
      freeze.beschluesse.map((b, i) => ({
        id: b.id,
        bereich: b.bereich,
        titel: b.titel,
        prio1Basis: b.prio1,
        prio2Ergaenzung: b.prio2,
        massnahme: b.massnahme,
        status: b.status,
        sortierung: i,
      })),
    );

    await tx.insert(importProtokoll).values([
      {
        laufId,
        datei: "arbeitsstand-kontakte.csv",
        sha256: checks.find((c) => c.file === "arbeitsstand-kontakte.csv")!
          .actual,
        datensaetze: freeze.kontakte.length,
        detail: `${kStats.kvGekennzeichnet} KV-nummerierte Einrichtungen + ${kStats.sonderdatensaetze} Sonderdatensatz (STADT-PUTBUS) · ${kStats.regionen} Regionen · ${kStats.orte} Orte · E-Mail-Spalten email_1 ${kStats.email1}× / email_2 ${kStats.email2}× / email_3 ${kStats.email3}×`,
        pruefsummeOk: true,
      },
      {
        laufId,
        datei: "arbeitsstand-termine.csv",
        sha256: checks.find((c) => c.file === "arbeitsstand-termine.csv")!
          .actual,
        datensaetze: freeze.termine.length,
        detail: `54 Quellzeilen → ${t26.zeitfenster + t27.zeitfenster} Zeitfenster · 2026: ${t26.quellzeilen}/${t26.zeitfenster} · 2027: ${t27.quellzeilen}/${t27.zeitfenster} · Herne-Advent je 1 Quellzeile mit 4 Fenstern (B-10)`,
        pruefsummeOk: true,
      },
      {
        laufId,
        datei: "beschlussverzeichnis.csv",
        sha256: checks.find((c) => c.file === "beschlussverzeichnis.csv")!
          .actual,
        datensaetze: freeze.beschluesse.length,
        detail: `${entschieden} entschieden · ${freeze.beschluesse.length - entschieden} provisorisch · Bereiche Kontakte/Termine/Archiv/Ablauf/Offen`,
        pruefsummeOk: true,
      },
    ]);
  });

  /* 4 · Kontrolle ---------------------------------------------------- */
  const counts = await db.execute(sql`
    select
      (select count(*) from regionen)          as regionen,
      (select count(*) from kontakte)          as kontakte,
      (select count(*) from termine)           as termine,
      (select count(*) from termin_zeitfenster) as zeitfenster,
      (select count(*) from beschluesse)       as beschluesse
  `);
  const row = counts.rows[0] as Record<string, string>;
  console.log("\nImport abgeschlossen · Lauf", laufId);
  console.log(
    `  regionen ${row.regionen} · kontakte ${row.kontakte} · termine ${row.termine} · zeitfenster ${row.zeitfenster} · beschluesse ${row.beschluesse}`,
  );
}

main()
  .catch((e) => {
    console.error("Import fehlgeschlagen:", e);
    process.exitCode = 1;
  })
  .finally(() => pool.end());
