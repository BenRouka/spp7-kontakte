"""Read-only extraction of structured signals from OCR text of all 79 flyer images."""
import json, re

OCR = '/tmp/ocr/audit_result.json'
OUT = '/tmp/audit/ocr_signals.json'

EMAIL_RE = re.compile(r'[a-zA-Z0-9._%+\-]+@[a-zA-Z0-9.\-]+\.[a-zA-Z]{2,}')
PHONE_RE = re.compile(r'(?:\+49|0)[\d\s()\-/]{6,}\d')
URL_RE = re.compile(r'(?:https?://|www\.)[^\s)\]}>"\']+')
MONEY_RE = re.compile(r'\d{1,4}[.,]?\d{0,3}\s?(?:€|EUR|Euro)', re.I)
GAGE_RE = re.compile(r'gage[^.\n]{0,40}', re.I)
BEWERBER_RE = re.compile(r'(\d{1,4})\s*bewerber', re.I)
DATE_RE = re.compile(r'\b\d{1,2}\.\d{1,2}\.\d{2,4}\b')

ocr = json.load(open(OCR, encoding='utf-8'))
rows = []
for n_str, info in ocr.items():
    n = int(n_str)
    text = info['text']
    flat = ' '.join(text.split())
    rows.append({
        'n': n,
        'confidence': info['confidence'],
        'emails': sorted(set(EMAIL_RE.findall(flat))),
        'phones': sorted(set(PHONE_RE.findall(flat))),
        'urls': sorted(set(URL_RE.findall(flat))),
        'money_mentions': sorted(set(MONEY_RE.findall(flat))),
        'gage_phrases': [m.strip() for m in GAGE_RE.findall(flat)][:3],
        'bewerber_counts': BEWERBER_RE.findall(flat),
        'dates_found': sorted(set(DATE_RE.findall(flat))),
        'text_len': len(flat),
        'raw_excerpt': flat[:300],
    })
rows.sort(key=lambda r: r['n'])
json.dump({'flyers': rows}, open(OUT, 'w', encoding='utf-8'), ensure_ascii=False, indent=1)

low_conf = [r['n'] for r in rows if r['confidence'] < 55]
with_money = [r['n'] for r in rows if r['money_mentions']]
with_email = [r['n'] for r in rows if r['emails']]
with_url = [r['n'] for r in rows if r['urls']]
print('flyers analyzed:', len(rows))
print('low confidence (<55%):', low_conf)
print('flyers with money mentions:', with_money)
print('flyers with emails:', with_email)
print('flyers with urls:', len(with_url))
