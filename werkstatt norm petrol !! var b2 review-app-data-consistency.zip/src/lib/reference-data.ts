export const repositoryUrl = "https://github.com/BenRouka/spp7-kontakte/blob/main/";
export const sourceUrl = `${repositoryUrl}Termine%202027%20Veranstalter%20suendenfrei.txt`;

// Read-only display snapshot of the public reference, not a normalized import.
// Original spelling, markers and line contents are retained in this snapshot.
export const originalSchedule = `Veranstalter Sündenfrei Mittelalteragentur 
Termine 2026 
3. - 4. Oktober 2026 \tThüringer Ritterturnier \t99448 Kranichfeld
9. - 11. Oktober 2026 \t373. Zwiebelmarkt \t99423 Weimar
10. - 11. Oktober 2026* \t29. Burgfest \t06543 Burg Falkenstein / Harz
17. - 18. Oktober 2026 \t5. Mittelalter- Markttage \t44575 Castrop- Rauxel
1. - 4. Advent 2026 \tMittelalter- Advent (Do. - So.) \t44629 Herne/ Schloss Strünkede
25. 11. - 23. Dezember 2026* \tMittelalter- Weihnacht \t01067 Dresden / Stallhof
26. 11. - 30. Dezember 2026* \tFelsenkeller- Weihnachtsmarkt \t04229 Leipzig / Plagwitz
27. 11. - 23. Dezember 2026** \tKloster- Weihnacht \t09111 Chemnitz
27. - 30. Dezember 2026 \tRauhnächte \t01067 Dresden / Stallhof


Termine 2027 (Stand 22. September 2026)
Mittelaltermärkte gibt es seit über 1000 Jahren!
2.- 6. Januar 2027 \tRauhnächte \t01067 Dresden /Stallhof
6. - 7. März 2027 \t18. Leipziger Umschlag \t04107 Leipzig / agra Messepark Halle 1
13. - 14. März 2027 \tMittelalterfest Burgfrühling \t97877 Wertheim/ Burg
20. - 21. März 2027 \tRitterturnier und Mittelaltermarkt \t01683 Altzella / Nossen
27. - 29. März 2027 \tOster- Ritterturnier \t56346 Loreley/ St. Goarshausen
27. - 29. März 2027 \tRitter und Drachen- Spektakel \t99448 Kranichfeld/ Niederburg
27. - 29. März 2027 \tOster- Ritterturnier \t44286 Dorsten/ Schloss Lembeck
3.- 4. April 2027 \tnoch offen \txxxxx
10. - 11. April 2027 \tDie Wikinger kommen! \t07929 Saalburg/ Bleilochtalsperre
10. - 11. April 2027 \tTurnierspiele \t96178 Schloss Weissenstein/ Pommersfelden
17.- 18. April 2027 \tMittealterspektakel \t04519 Rackwitz, Schladitzer Bucht
17. - 18. April 2027 \tMittelalterspektakel \t41844 Wegberg/ Schloss Tüschenbroich
24. - 25. April 2027 \tMittelalterfest Löwenburg \t34131 Kassel
24. - 25. April 2027 \tMittelaltermarkt \t90513 Zirndorf b. Nürnberg
30. April - 2. Mai 2027 \tRitterturnier & Walpurgisnacht \t06632 Freyburg/ Neuenburg
1. - 2. Mai 2027 \tRitterturnier Schloss Lauersfort \t47447 Moers
6. - 9. Mai 2027 \t23. Siegfriedspektakel \t46509 Xanten
6. - 9. Mai 2027 \tMittealter- Burgfest \t06543 Burg Falkenstein/ Harz
15. - 17. Mai 2027 \tWikingerfest \t99885 Weißensee/Thür.
15. - 17. Mai 2027 \tRitterturnier & Mittelalterspektakel \t85399 Hallbergmoos
22. - 23. Mai 2027 \tMittelalterspektakel \t58455 Witten /Kemnader See
27.- 30. Mai 2027* \tGaudium Schloss Horst* \t45899 Gelsenkirchen*
29. - 30. Mai 2027 \tMittelalterspektakel \t02829 Königshain
5. - 6. Juni 2027 \tMittelalterspektakel \t34346 Hann. Münden
11. - 13. Juni 2027 \tAnnamarkt und Stadtfest \t52349 Düren
16. - 18. Juli 2027 \tMittelalterspektakel \t23999 Insel Poel
22. - 25. Juli 2027 \tWallensteintage \t18439 Stralsund /Alter Markt
14. - 15. August 2027 \tFantasy- und Mittelalterfest \t01833 Stolpen (Burg)
28. - 29. August 2027 \tBurgfest* \txxxx
3. - 5. September 2027 \t20. Mittelalterspektakel \t44629 Herne / Schloss Strünkede
11. - 12. September 2027 \tMittelalterfest* \t99707 Kyffhäuser*
18. - 19. September 2027 \tDie Wikinger kommen! \t46509 Xanten
18. - 19. September 2027 \tRitterturnier und Mittelalterspektakel \t93186 Adlersberg/ Pettendorf
24. - 26. September 2027* \tZwiebelmarkt Apolda \t99510 Apolda
25. - 26. September 2027 \t56. Heidelberger Herbst \t69120 Heidelberg
2. - 3. Oktober 2027 \tMittelalter & Fantasytage mit Drachen \t56346 Loreley/ St. Goarshausen
2. - 3. Oktober 2027 \tThüringer Ritterturnier \t99448 Kranichfeld
8. - 10. Oktober 2027 \t374. Zwiebelmarkt \t99423 Weimar
9.- 10. Oktober 2027* \t30. Burgfest \t06543 Burg Falkenstein/ Harz
16. - 17. Oktober 2027* \t6. Mittelalter- Markttage \t44575 Castrop- Rauxel
1. - 4. Advent 2027* \tMittelalter- Advent (Fr.- So.) \t44629 Herne/ Schloss Strünkede
24.11. - 23. Dezember 2027* \tMittelalter- Weihnacht \t01067 Dresden / Stallhof
25.11. - 30. Dezember 2027* \tFelsenkeller- Weihnachtsmarkt \t04229 Leipzig / Plagwitz
26.11. - 23. Dezember 2027** \tKloster- Weihnacht \t09111 Chemnitz
27. - 30. Dezember 2027 \tRauhnächte \t01067 Dresden / Stallhof 

*Sternchen: \tTermin oder Ort wahrscheinlich, jedoch noch unbestätigt 
`;

export const sourceFiles = [
  { id: "termine", name: "Termine 2027 Veranstalter suendenfrei.txt", label: "Sündenfrei · Termine", type: "TXT", size: "4,1 KB", detail: "54 Quellzeilen · 2026 und 2027", file: "Termine%202027%20Veranstalter%20suendenfrei.txt", role: "Referenzquelle" },
  { id: "kur", name: "Kurverwaltungen_2025.md", label: "Kurverwaltungen auf Rügen", type: "MD", size: "7,1 KB", detail: "32 Adressblöcke · Stand 2025, ohne Gewähr", file: "Kurverwaltungen_2025.md", role: "Referenzquelle" },
  { id: "app", name: "varB chat! pics scharf 180 maps app-replication-workflow-setup.zip", label: "SPP7 · bestehende App", type: "ZIP", size: "977 KB", detail: "206 Events · 74 Kontakte · 14 Datensätze", file: "varB%20chat!%20pics%20scharf%20180%20maps%20app-replication-workflow-setup.zip", role: "Bestandsdaten" },
  { id: "chat", name: "ChatExport_2026-09-20.zip", label: "Original-Chat", type: "ZIP", size: "9,4 MB", detail: "121 Nachrichten · 79 Originalbilder + 79 Thumbnails", file: "ChatExport_2026-09-20.zip", role: "Originalarchiv" },
  { id: "logo", name: "logo-spp.pdf", label: "Original-Logo", type: "PDF", size: "1,3 MB", detail: "Originaldatei · keine Umwandlung vorgenommen", file: "logo-spp.pdf", role: "Originalarchiv" },
];

export const verifiedInventory = {
  events: 206,
  geocodedEvents: 180,
  uniqueEventCoordinates: 149,
  contacts: 74,
  geocodedContacts: 68,
  originalImages: 79,
  thumbnailImages: 79,
  originalScheduleSha256: "2ed2f631b158a8e3eaffc1f85d67d01abfdf8672c9f794f293e4ded263161cc7",
};
