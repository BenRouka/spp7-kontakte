# SPP7 · Abgleich-Bericht (Stufe 3)

**Stand:** Stufe 3 abgeschlossen · **Rein lesender Bericht — keine Datenbankänderung, kein Import.**
**Gegenüberstellung:** Saubere Normierte Quellen (`werkstatt/02-normiert/`) ↔ Bestandsdaten der App (`varB...zip`).

---

## 0. Executive Summary

| Prüfbereich | Saubere Referenzquelle | Bestands-App (`varB`) | Kernbefund |
|---|---|---|---|
| **Kurverwaltungen / Kontakte** | **32 Adressblöcke** (119 Kontaktwerte) | **74 Kontakte** (1 Feld `channel`) | 34 App-Kontakte beziehen sich auf die 32 Kurverwaltungen mit massiven Dubletten (Putbus 9×, ruegen.de 7×). 40 Kontakte sind andere Chat-Kontakte (Bands, Agenturen, Veranstalter). Adressen und Telefone wurden mangels Spalten in Notiz-Freitext gequetscht. |
| **Sündenfrei-Termine** | **54 Termine** (2026: 9, 2027: 45) | **6 Events** (`S01`–`S06`) + 2 Chat-Events | **40 von 54 Terminen fehlen** in der App vollständig als eigenständige Events. Das gesamte Jahr 2027 ist im App-Bestand fast unberührt (nur 12 Datumszeilen im Gesamtbestand). |
| **Flyer & Bilder** | **158 JPGs** im Chat-Export | **79 Bildquellen** referenziert | Im App-ZIP fehlen die Bilddateien komplett (**tote Bildlinks**). Rekonstruktion aus Chat-Export zu 100 % möglich (79 Originale + 79 Thumbnails). |

---

## 1. Abgleich: Kurverwaltungen (32 saubere Blöcke ↔ 74 App-Kontakte)

### 1.1 Dubletten-Cluster in der Bestands-App

In der Bestands-App wurden Kontakte aus dem Chat unkoordiniert erfasst. Weil das Datenmodell nur **ein einziges Feld** `channel` für E-Mail *oder* Telefon kannte, wurden für denselben Träger mehrere Einzelkontakte angelegt oder Adressen in das Freitext-Feld `NOTIZ` ausgelagert.

#### Cluster [D1] — Stadt & Kurverwaltung Putbus (9 Einträge in App vs. 2 saubere Blöcke)

| ID in App | Name in App | Typ in App | Kanal in App | Notiz in App | Saubere Referenz |
|---|---|---|---|---|---|
| `K22` | Kurverwaltung Putbus | Kurverwaltung | `service@ruegen-putbus.de` | — | `KV27` (Kurverwaltung Putbus) |
| `K23` | Kurverwaltung Putbus | Kurverwaltung | `kurverwaltung@ruegen-putbus.de` | — | `KV27` (Kurverwaltung Putbus) |
| `K24` | Stadt Putbus – Marketing | Stadt | `marketing@ruegen-putbus.de` | — | `KV27` (Kurverwaltung Putbus) |
| `K25` | Stadt Putbus – Rathaus | Stadt | `rathaus@putbus.de` | — | `KV27` (Kurverwaltung Putbus) |
| `K26` | Stadt Putbus – Person Röder | Person | `roeder@ruegen-putbus.de` | — | `KV27` (Kurverwaltung Putbus) |
| `K27` | Stadt Putbus – Person B. Schädlich | Person | `b.schaedlich@ruegen-putbus.de` | — | `KV27` (Kurverwaltung Putbus) |
| `K28` | Stadt Putbus – Person Titze | Person | `titze@ruegen-putbus.de` | — | `KV27` (Kurverwaltung Putbus) |
| `K70` | Kurverwaltung Putbus/Stadtinformation | Kurverwaltung | `info.putbus@putbus.de` | *Alleestraße 2, 18581 Putbus · Tel. (03 83 01) 6 09 64* | `KV27` (Kurverwaltung Putbus) |
| `K71` | Tourismus- und Gewerbeverein Putbus e. V. | Verein | `tgv-putbus@gmx.de` | *Pappelweg 7, 18581 Lauterbach · Tel. (03 83 01) 6 04 67* | `KV28` (TGV Putbus) |

> 💡 **Empfehlung für Stufe 4:** `KV27` und `KV28` als saubere Stammdaten übernehmen. Die 7 personengebundenen Zusatzadressen (`K24`–`K28`) können optional als Ansprechpartner verknüpft werden, dürfen aber die Stammdaten nicht aufblähen.

#### Cluster [D2] — Tourismusverband Rügen / ruegen.de (7 Einträge in App vs. 1 sauberer Block)

| ID in App | Name in App | Typ in App | Kanal in App | Saubere Referenz |
|---|---|---|---|---|
| `K01` | Tourismuszentrale Rügen (ruegen.de) | Tourismus | `info@ruegen.de` | `KV01` (Baltic Project / TV Rügen) |
| `K02` | Tourismuszentrale Rügen (ruegen.de) | Tourismus | `inselexperten@ruegen.de` | `KV01` (Baltic Project / TV Rügen) |
| `K35` | ruegen.de – Person Hegen | Person | `hegen@ruegen.de` | `KV01` (Baltic Project / TV Rügen) |
| `K36` | ruegen.de – Person Szymanski | Person | `szymanski@ruegen.de` | `KV01` (Baltic Project / TV Rügen) |
| `K37` | ruegen.de – Person Günther | Person | `guenther@ruegen.de` | `KV01` (Baltic Project / TV Rügen) |
| `K38` | ruegen.de – Person Schmitz | Person | `schmitz@ruegen.de` | `KV01` (Baltic Project / TV Rügen) |
| `K39` | ruegen.de – Person Wolff | Person | `wolff@ruegen.de` | `KV01` (Baltic Project / TV Rügen) |

#### Cluster [D3] — S. Schönke (privat) vs. Zimmervermittlung Rügen (`KV24`)

- **In App (`K57`):** Name `S. Schönke (privat)`, Ort `(leer)`, Region `Mecklenburg-Vorpommern (Rügen)`, Kanal `sschoenke@t-online.de`.
- **In sauberer Quelle (`KV24`):** Name `Zimmervermittlung Rügen`, Adresse `OT Grubnow 1, 18569 Neuenkirchen`, Tel `+49 38309 88001`, Fax `+49 38309 88002`, Web `www.zv-ruegen.de`, Mail `sschoenke@t-online.de`.
- **Befund:** `K57` ist kein separater Privatkontakt, sondern die Inhaberin/Mailadresse der gewerblichen Zimmervermittlung Grubnow.

#### Cluster [D4] — Middelhagen Lücke in App (`K09`)

- **In App (`K09`):** Name `Tourist-Info Middelhagen`, Kanal `(nicht genannt)`.
- **In sauberer Quelle (`KV12`):** Tel `+49 38308 66010`, Fax `+49 38308 660110`, Web `www.ostseebad-moenchgut.de`, Mail `info@ostseebad-moenchgut.de`.

### 1.2 Die 40 sonstigen App-Kontakte (kein Kurverwaltungs-Bezug)

Die Bestands-App enthält 40 Kontakte, die aus anderen Chat-Kontexten stammen (Bands, Veranstalter, Kulturvereine, private Dienstleister):
- Veranstalter/Agenturen: `K59 Extratours`, `K60 Basic Events`, `K63 EGS GmbH`
- Kultur/Locations: `K55 La Grange e.V.`, `K61 Biedermeierstrand`, `K62 SKF Harburg`, `K64 Headbangers Open Air`
- Gemeinden/Ämter ohne Kurstatus: `K40 Amt West-Rügen`, `K48 Hansestadt Stralsund`, `K49 Stadt Garz`, `K50 Ralswiek`, `K51 Patzig`, `K52 Poseritz`
- Personen: `K58 Dirk Schröder (Transport)`, `K73 Thomas Tegelhütter`, `K74 Wolfgang Schlegel`

> 🔒 **Empfehlung:** Diese 40 Kontakte dürfen **nicht gelöscht** werden, gehören aber in eine eigene Kontaktkategorie („Veranstalter & Partner“), getrennt von den amtlichen Kurverwaltungen Rügens.

---

## 2. Abgleich: Sündenfrei-Termine (54 saubere Zeilen ↔ 206 App-Events)

### 2.1 Fehlmengen-Statistik

- **Saubere Termine gesamt:** 54 Zeilen (9× 2026 ab Okt., 45× 2027)
- **In Bestands-App als Sündenfrei-Events erfasst:** nur **6 Events** (`S01`–`S06`) plus **2 Chat-KI-Events** (`M21`, `M44`).
- **Komplett fehlend in App:** **40 von 54 Terminen (74.1 %)**!

### 2.2 Das „Generischer Name“-Problem in der Bestands-App

In der Bestands-App wurden Veranstaltungen nach generischen Namen wie „Mittelalterspektakel“ oder „Ritterturnier“ zusammengefasst:
- `S04 Insel Poel – Mittelalterspektakel` wurde in der App als Container für viele Termine genutzt, wodurch unterschiedliche Orte (Wegberg, Witten, Hann. Münden, Königshain, Rackwitz) fälschlich denselben Event-Eintrag überschrieben haben.
- `M21 Ritterturnier` (Freyburg) wurde für Termine in Loreley, Altzella, Dorsten, Moers und Hallbergmoos herangezogen.

> ⚠️ **Empfehlung für Stufe 4/5:** Jeder der 54 Sündenfrei-Termine muss als **eigenständiger Termin** (`ST01`–`ST54`) mit eigenem Ort, PLZ und Zeitfenstern geführt werden. Keine blinde Deduplizierung nach Name!

---

## 3. Abgleich: Flyer & Medien (79 Quellen ↔ 158 Bilder)

| Element | Bestand in App | Bestand im Chat-Export | Status |
|---|---|---|---|
| Flyer-Quellen (`flyer_sources`) | 79 Zeilen (`F01`–`F79`) | — | Vorhanden |
| Bilddateien im App-ZIP | **0 Dateien** (Verzeichnis `/flyers/` fehlt) | — | ❌ **Tote Bildlinks** |
| Bilddateien im Chat-Export | — | **158 JPGs** (`photo_X.jpg` + `_thumb.jpg`) | ✅ **100 % vorhanden** |

> 🛠️ **Rekonstruktions-Plan für Stufe 6:** Die 79 Flyer-Quellen können per Bild-Index 1:1 mit den 158 JPGs aus `ChatExport_2026-09-20/photos/` verknüpft werden.

---

## 4. Bereitgestellte Dateien in `werkstatt/03-berichte/`

1. `abgleich-bericht.md` (dieser Bericht)
2. `abgleich-kontakte.csv` (32 saubere Blöcke mit detaillierter Gegenüberstellung aller 74 App-Kontakte)
3. `abgleich-termine.csv` (54 Sündenfrei-Termine mit Status in der Bestands-App)
4. `abgleich-zusammenfassung.json` (maschinenlesbare Kennzahlen)
