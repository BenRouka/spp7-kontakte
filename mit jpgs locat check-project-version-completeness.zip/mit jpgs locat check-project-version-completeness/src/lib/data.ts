import "server-only";
import { asc, count, desc, eq, sql } from "drizzle-orm";
import { db } from "@/db";
import {
  beschluesse,
  importProtokoll,
  kontakte,
  regionen,
  terminZeitfenster,
  termine,
  type Termin,
  type TerminZeitfenster,
} from "@/db/schema";
import {
  fmtDatum,
  fmtMonat,
  fmtTag,
  monatKey,
  tageZwischen,
} from "@/lib/freeze";

/* ------------------------------------------------------------------ */
/* Übersicht / Stufe 5                                                  */
/* ------------------------------------------------------------------ */

export async function getDbCounts() {
  const rows = await db.execute(sql`
    select
      (select count(*) from regionen)           as regionen,
      (select count(*) from kontakte)           as kontakte,
      (select count(*) from termine)            as termine,
      (select count(*) from termin_zeitfenster)  as zeitfenster,
      (select count(*) from beschluesse)         as beschluesse,
      (select count(*) from import_protokoll)    as protokoll
  `);
  const r = rows.rows[0] as Record<string, string | number>;
  const n = (v: string | number) => Number(v);
  return {
    regionen: n(r.regionen),
    kontakte: n(r.kontakte),
    termine: n(r.termine),
    zeitfenster: n(r.zeitfenster),
    beschluesse: n(r.beschluesse),
    protokoll: n(r.protokoll),
  };
}

export async function getLetzterImportLauf() {
  const eintraege = await db
    .select()
    .from(importProtokoll)
    .orderBy(desc(importProtokoll.importiertAm));
  if (eintraege.length === 0)
    return null as null | {
      laufId: string;
      importiertAm: string;
      eintraege: typeof eintraege;
    };
  const laufId = eintraege[0].laufId;
  return {
    laufId,
    importiertAm: eintraege[0].importiertAm,
    eintraege: eintraege.filter((e) => e.laufId === laufId),
  };
}

/* ------------------------------------------------------------------ */
/* Kontakte — Hierarchie Region → Ort → Einrichtung                     */
/* ------------------------------------------------------------------ */

export async function getKontakteHierarchie() {
  const regs = await db.select().from(regionen).orderBy(asc(regionen.id));
  const rows = await db.query.kontakte.findMany({
    orderBy: [asc(kontakte.regionId), asc(kontakte.sortierung)],
  });
  return regs
    .map((region) => {
      const regionRows = rows.filter((r) => r.regionId === region.id);
      const orte: { ort: string; einrichtungen: typeof regionRows }[] = [];
      for (const r of regionRows) {
        const last = orte[orte.length - 1];
        if (last && last.ort === r.ort) last.einrichtungen.push(r);
        else orte.push({ ort: r.ort, einrichtungen: [r] });
      }
      return { region, orte, anzahl: regionRows.length };
    })
    .filter((g) => g.anzahl > 0);
}

export type KontaktHierarchie = Awaited<
  ReturnType<typeof getKontakteHierarchie>
>;
export type KontaktRecord = KontaktHierarchie[number]["orte"][number]["einrichtungen"][number];

export async function getRegionChips() {
  const rows = await db
    .select({
      id: regionen.id,
      name: regionen.name,
      anzahl: count(kontakte.kvId),
    })
    .from(regionen)
    .leftJoin(kontakte, eq(kontakte.regionId, regionen.id))
    .groupBy(regionen.id)
    .orderBy(asc(regionen.id));
  return rows;
}

/* ------------------------------------------------------------------ */
/* Termine — Quellzeilen mit Zeitfenstern, formatiert für die Anzeige   */
/* ------------------------------------------------------------------ */

export interface TerminAnzeige {
  sfId: string;
  jahr: number;
  datumOriginal: string;
  name: string;
  plzOrt: string;
  anzahl: number;
  sternchen: string;
  hinweis: string | null;
  monatKey: string;
  monatLabel: string;
  fenster: {
    nr: number;
    von: string;
    bis: string;
    label: string; // "Do 26.11.26 – So 29.11.26"
    tage: number;
  }[];
}

function toAnzeige(t: Termin, fenster: TerminZeitfenster[]): TerminAnzeige {
  const sorted = [...fenster].sort((a, b) => a.nr - b.nr);
  const first = sorted[0];
  return {
    sfId: t.sfId,
    jahr: t.jahr,
    datumOriginal: t.datumOriginal,
    name: t.nameOriginal,
    plzOrt: t.plzOrtOriginal,
    anzahl: t.zeitfensterAnzahl,
    sternchen: t.sternchen,
    hinweis: t.hinweis,
    monatKey: monatKey(first.von),
    monatLabel: fmtMonat(first.von),
    fenster: sorted.map((f) => ({
      nr: f.nr,
      von: f.von,
      bis: f.bis,
      label: `${fmtTag(f.von)} – ${fmtTag(f.bis)}`,
      tage: tageZwischen(f.von, f.bis),
    })),
  };
}

export async function getTermineAnzeige(jahr: number) {
  const rows = await db.query.termine.findMany({
    where: eq(termine.jahr, jahr),
    orderBy: [asc(termine.sortierung)],
    with: { zeitfenster: true },
  });
  const anzeigen = rows.map((t) => toAnzeige(t, t.zeitfenster));
  // Gruppieren nach Monat des ersten Fensters, Einträge intern nach Datum
  const monate = new Map<string, { label: string; termine: TerminAnzeige[] }>();
  for (const t of anzeigen) {
    const g = monate.get(t.monatKey) ?? { label: t.monatLabel, termine: [] };
    g.termine.push(t);
    monate.set(t.monatKey, g);
  }
  for (const g of monate.values()) {
    g.termine.sort((a, b) => a.fenster[0].von.localeCompare(b.fenster[0].von));
  }
  const gruppen = [...monate.entries()]
    .sort(([a], [b]) => a.localeCompare(b))
    .map(([key, g]) => ({ key, label: g.label, termine: g.termine }));
  return { gruppen, alle: anzeigen };
}

export async function getTerminJahresStats() {
  const rows = await db
    .select({
      jahr: termine.jahr,
      quellzeilen: count(termine.sfId),
    })
    .from(termine)
    .groupBy(termine.jahr)
    .orderBy(asc(termine.jahr));
  const fenster = await db
    .select({
      jahr: termine.jahr,
      anzahl: count(terminZeitfenster.id),
    })
    .from(terminZeitfenster)
    .innerJoin(termine, eq(terminZeitfenster.terminSfId, termine.sfId))
    .groupBy(termine.jahr);
  const fMap = new Map(fenster.map((f) => [f.jahr, Number(f.anzahl)]));
  return rows.map((r) => ({
    jahr: r.jahr,
    quellzeilen: Number(r.quellzeilen),
    zeitfenster: fMap.get(r.jahr) ?? 0,
  }));
}

/* ------------------------------------------------------------------ */
/* Beschlüsse                                                           */
/* ------------------------------------------------------------------ */

export async function getBeschluesseGruppiert() {
  const rows = await db
    .select()
    .from(beschluesse)
    .orderBy(asc(beschluesse.sortierung));
  const order = ["Kontakte", "Termine", "Archiv", "Ablauf", "Offen"];
  return order
    .map((bereich) => ({
      bereich,
      beschluesse: rows.filter((r) => r.bereich === bereich),
    }))
    .filter((g) => g.beschluesse.length > 0);
}

export async function getBeschlussStats() {
  const rows = await db.select().from(beschluesse);
  return {
    gesamt: rows.length,
    entschieden: rows.filter((r) => r.status === "entschieden").length,
    provisorisch: rows.filter((r) => r.status === "provisorisch").length,
  };
}

/** Formatiert "2026-10-04 11:20:13.922+00" → "04.10.2026, 13:20 Uhr" */
export function fmtZeitstempel(iso: string): string {
  const d = new Date(iso);
  if (Number.isNaN(d.getTime())) return iso;
  const p = (n: number) => String(n).padStart(2, "0");
  return `${p(d.getUTCDate())}.${p(d.getUTCMonth() + 1)}.${d.getUTCFullYear()}, ${p(d.getUTCHours())}:${p(d.getUTCMinutes())} UTC`;
}

export { fmtDatum };
