import assert from "node:assert/strict";
import { createRequire } from "node:module";
import { existsSync, readFileSync } from "node:fs";
import { mkdir, readFile, writeFile } from "node:fs/promises";
import path from "node:path";
import ts from "typescript";

const require = createRequire(import.meta.url);
function sourceLoader(readSource = (file) => readFileSync(file, "utf8")) {
  const cache = new Map();
  function load(file) {
    const resolved = file.startsWith("@/") ? `src/${file.slice(2)}.ts` : file;
    if (cache.has(resolved)) return cache.get(resolved).exports;
    const module = { exports: {} };
    cache.set(resolved, module);
    const code = ts.transpileModule(readSource(resolved), {
      compilerOptions: { module: ts.ModuleKind.CommonJS, target: ts.ScriptTarget.ES2022, esModuleInterop: true },
    }).outputText;
    const localRequire = (specifier) => specifier === "server-only" ? {} : specifier.startsWith("@/") ? load(specifier) : require(specifier);
    new Function("require", "module", "exports", code)(localRequire, module, module.exports);
    return module.exports;
  }
  return load;
}
const load = sourceLoader();
const calendar = load("src/lib/calendar-model.ts");
const reports = load("src/lib/review-report.ts");
const a2026 = calendar.buildCalendarReview(2026);
const a2027 = calendar.buildCalendarReview(2027);
assert.deepEqual(a2026.advent.periods.map((p) => [p.start, p.end]), [
  ["2026-11-26", "2026-11-29"], ["2026-12-03", "2026-12-06"],
  ["2026-12-10", "2026-12-13"], ["2026-12-17", "2026-12-20"],
]);
assert.deepEqual(a2027.advent.periods.map((p) => [p.start, p.end]), [
  ["2027-11-26", "2027-11-28"], ["2027-12-03", "2027-12-05"],
  ["2027-12-10", "2027-12-12"], ["2027-12-17", "2027-12-19"],
]);
assert.equal(a2026.advent.weekdayLabel, "Do.–So.");
assert.equal(a2027.advent.weekdayLabel, "Fr.–So.");
assert.equal(a2026.advent.source.uncertain, false);
assert.equal(a2027.advent.source.uncertain, true);
assert.equal(a2027.advent.periods.some((p) => p.start === "2027-11-25"), false);
assert.equal(a2026.christmas.periods[0].start, "2026-11-25");
assert.equal(a2027.christmas.periods[0].start, "2027-11-24");
assert.equal(a2027.christmas.periods[0].end, "2027-12-23");
assert.equal(a2027.christmas.dateOrigin, "aus Quelle");
assert.equal(a2027.christmas.source.uncertain, true);
assert.equal(a2027.advent.dateOrigin, "berechnet");
assert.equal(a2026.christmas.dayCount, 29);
assert.equal(a2027.christmas.dayCount, 30);
assert.deepEqual(a2027.totals, { all: 54, year2026: 9, year2027: 45, uncertain: 14, openLocations: 2 });
assert.equal(calendar.getAdventSundays(2022)[3], "2022-12-18");
assert.equal(calendar.getAdventSundays(2023)[3], "2023-12-24");
for (let year = 2000; year <= 2100; year++) {
  const sundays = calendar.getAdventSundays(year);
  assert.equal(sundays.length, 4);
  for (const sunday of sundays) assert.equal(new Date(`${sunday}T12:00:00Z`).getUTCDay(), 0);
  assert.ok(sundays[3] >= `${year}-12-18` && sundays[3] <= `${year}-12-24`);
}
for (const review of [a2026, a2027]) {
  assert.equal(review.advent.periods.length, 4);
  assert.equal(review.christmas.periods.length, 1);
  assert.equal(new Set(review.advent.periods.map((p) => p.id)).size, 4);
  assert.equal(new Set(review.advent.periods.map((p) => p.id.replace(/-P\d+$/, ""))).size, 1);
  assert.equal(reports.csvReport(review).split("\r\n").length, 6);
  const ics = reports.calendarReport(review, new Date("1980-01-01T00:00:00Z"));
  assert.equal((ics.match(/BEGIN:VEVENT/g) || []).length, 5);
  for (const line of ics.split("\r\n")) assert.ok(Buffer.byteLength(line, "utf8") <= 75);
  assert.ok(ics.includes(`DTEND;VALUE=DATE:${review.year}1224`));
}

const snapshotPath = "werkstatt/03-berichte/zeitmodell-stand.json";
if (process.argv.includes("--write-option-b")) {
  const artifact = load("src/lib/option-b-alignment.ts");
  const result = await artifact.createOptionBArtifact();
  for (const [file, content] of Object.entries(result.documents)) {
    if (/\/01-roh\/(Kurverwaltungen_2025\.md|Termine_2027_suendenfrei\.txt)$/.test(file) && existsSync(file)) {
      assert.deepEqual(await readFile(file), Buffer.from(content), `Rohquelle darf nicht überschrieben werden: ${file}`);
      continue;
    }
    await mkdir(path.dirname(file), { recursive: true });
    await writeFile(file, content);
  }
  await mkdir(path.dirname(artifact.updatedOptionBPath), { recursive: true });
  await writeFile(artifact.updatedOptionBPath, result.zip);
  console.log("Updated Option-B copy and derived read-only workshop reports written. Original ZIP / raw source bytes unchanged.");
}
if (existsSync(snapshotPath)) {
  const snapshot = JSON.parse(readFileSync(snapshotPath, "utf8"));
  assert.equal(snapshot.modelVersion, calendar.timeModelVersion);
  assert.deepEqual(snapshot.reviews, [a2026, a2027]);
}
if (existsSync("werkstatt/04-austausch/option-b-zeitmodell-v2.zip")) {
  const { unzipSync, strFromU8 } = require("fflate");
  const artifact = load("src/lib/option-b-alignment.ts");
  const result = await artifact.readOptionBArtifact();
  assert.equal(result.summary.aligned, true);
  assert.equal(result.summary.checks.length, 4);
  assert.equal(result.summary.originalSourcesPreserved, true);
  assert.equal(result.summary.remoteArenaChanged, false);
  assert.equal(result.summary.databaseChanged, false);
  const bFiles = unzipSync(result.zip);
  const bLoad = sourceLoader((file) => {
    assert.ok(bFiles[file], `Missing file in Option B: ${file}`);
    return strFromU8(bFiles[file]);
  });
  const bCalendar = bLoad("src/lib/calendar-model.ts");
  for (const year of [2026, 2027]) assert.deepEqual(bCalendar.buildCalendarReview(year), calendar.buildCalendarReview(year));
  const oldFiles = unzipSync(await readFile(artifact.originalOptionBPath));
  for (const file of ["src/app/page.tsx", "src/app/globals.css", "src/app/layout.tsx", "src/db/schema.ts", "package.json"]) {
    assert.deepEqual(bFiles[file], oldFiles[file], `Option-B screen / schema / dependency file must remain unchanged: ${file}`);
  }
  for (const file of Object.keys(bFiles)) assert.equal(/(^|\/)\.env|ChatExport.*\.zip|(^|\/)node_modules\/|(^|\/)\.next\//.test(file), false, `Private / generated file in artifact: ${file}`);
  console.log("Option A / packaged Option B: identical calculated data and shared source modules; unchanged Option-B screen, schema and raw sources.");
}
console.log("All regression checks passed: eight Advent windows, independent Dresden dates, 54 original rows, source markers, 101 Gregorian years and Christmas-on-Sunday exception.");
