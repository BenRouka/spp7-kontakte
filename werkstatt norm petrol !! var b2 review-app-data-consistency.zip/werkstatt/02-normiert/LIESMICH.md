# 02 — Normiert

**Status: Spaltenvorschlag v2 und vier Beispielstandorte geklärt — keine vollständigen CSV-Datenzeilen.**

Die MD-/TXT-Originale in ../01-roh/ sind unverändert. Die Kontaktklärung übernimmt ausdrücklich gelieferte Nutzerwerte mit eigener Herkunft, ohne das MD-Original nachträglich zu füllen.

Vorgeschlagene Dateien:

- kurverwaltungen-gruppen.csv: bisher zwei ausdrücklich zugeordnete Parents (Mönchgut, Baabe).
- kurverwaltungen.csv: 32 ursprüngliche Standorte mit parent_id; unbekannte Beziehungen bleiben offen.
- kurverwaltungen-kontaktwege.csv: 119 MD-Werte plus drei Nutzerergänzungen = 122; keine Kontaktvererbung.
- suendenfrei-termine.csv: 54 Quelltermine.
- suendenfrei-zeitfenster.csv: 60 Zeitfenster.

Die fünfte Gruppen-Datei ergänzt den vorherigen Vier-Dateien-Vorschlag. Der vollständige Aufbau ist noch nicht als Import freigegeben.
Unter vorlagen/ liegen ausschließlich fünf Kopfzeilen, eindeutig mit vorschlag- benannt. Die echten Ergebnis-CSV-Dateien sind noch nicht vorhanden.

KONTAKTKLAERUNG.md und kontaktklaerung-beispiele.json dokumentieren nur zwei Parents/four Children (vier Beispielstandorte), Original-/Nutzerbelege und +49-Ableitungen. Das ist keine vollständige Normierung.
nutzer-kontaktklaerung.json bewahrt die ausdrücklich benannten Ergänzungen und die als Nutzerzitate gekennzeichneten Chattexte. Keine Original-Chat-ID wurde daraus geraten.

Fehlende Angaben: Anzeige und spätere normierte CSV-Zellen -; intern null plus Status. Kein Strich als tatsächliche Telefonnummer, E-Mail oder erfundener MD-Wert.
Telefon: +49 ist zusätzlich für diese deutsche Quelle freigegeben, Original bleibt erhalten. URL-Protokolle werden nicht angenommen.

Details: SPALTENVORSCHLAG.md und schema-vorschlag.json. Keine Datenbankänderung.
