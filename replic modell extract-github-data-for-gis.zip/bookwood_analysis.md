# Festival Analyse: BOOKWOOD

## 📌 Basisinformationen
- **Name:** BOOKWOOD
- **Website:** [www.mf-suedharz.de](http://www.mf-suedharz.de)
- **Instagram:** @metal.foundation.suedharz
- **Kategorie:** Metal / Rock Festival
- **Tags:** #Metal #Suedharz #Festival #LiveMusic #Bookwood

## 🏢 Sponsoren & Partner
| Name | Typ | Beschreibung |
| :--- | :--- | :--- |
| **Köstritzer** | Getränkepartner | Brauerei / Bier |
| **Kreissparkasse Nordhausen** | Finanzpartner | Regionale Bank |
| **KNAUF** | Industriepartner | Baustoffe / Sponsoring |

## 🎸 Line-Up

### Freitag
- **BRAINSTORM** (Headliner)
  - *Kurzbeschreibung:* Heavy/Power Metal.
  - *Tags:* #HeavyMetal #PowerMetal
- **Lacrimas Profundere**
  - *Kurzbeschreibung:* Gothic/Doom Metal.
  - *Tags:* #GothicMetal #DoomMetal
- **Zero Degree**
  - *Tags:* #Metal
- **RÜCKHALT**
  - *Tags:* #Metal
- **FIGHTING CHANCE**
  - *Tags:* #Metal
- **VIREPTIC**
  - *Tags:* #Metal
- **Buchfinken**
  - *Kurzbeschreibung:* Akustik/Folk-Elemente (vermutlich).
  - *Tags:* #Folk #Acoustic

### Samstag
- **OUR MIRAGE**
  - *Tags:* #Metal
- **Restrisiko**
  - *Tags:* #Metal
- **MYRA**
  - *Tags:* #Metal
- **Mandragora**
  - *Tags:* #Metal
- **Titanith**
  - *Tags:* #Metal
- **LETTERSSENT**
  - *Tags:* #Metal
- **Prophecy / Rising Dead**
  - *Tags:* #Metal
- **CALLING CHARISMA**
  - *Tags:* #Metal
- **Endless Core**
  - *Tags:* #Metalcore #Deathcore
- **MAGICAL HEART**
  - *Tags:* #Metal
- **BURNING MISERY**
  - *Tags:* #Metal

---

## 🗺️ GIS-Vorbereitung (Konzept)
Um diese Daten in QGIS/3D-Modelle zu überführen, wird folgende Struktur implementiert:

1. **Entität "Festival":**
   - `id`: UUID
   - `name`: "Bookwood"
   - `location_name`: "Südharz" (Präzisierung via PDF-Adressen nötig)
   - `geom`: Point(lon lat) $\rightarrow$ für GPKG/QGIS
   - `website`: "www.mf-suedharz.de"

2. **Entität "Band":**
   - `id`: UUID
   - `name`: "Brainstorm", "Myra", etc.
   - `genre`: Tags aus MD-Datei

3. **Relation "Performance":**
   - `festival_id` $\leftrightarrow$ `band_id` $\leftrightarrow$ `datum`
   - Ermöglicht Abfrage: *"Zeige mir alle Festivals, auf denen Band X gespielt hat"* $\rightarrow$ Visualisierung als Liniennetzwerk in QGIS.
