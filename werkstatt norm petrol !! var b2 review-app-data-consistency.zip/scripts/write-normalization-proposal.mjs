import assert from "node:assert/strict";
import { createRequire } from "node:module";
import { readFileSync } from "node:fs";
import { mkdir, readFile, writeFile } from "node:fs/promises";
import { createHash } from "node:crypto";
import path from "node:path";
import ts from "typescript";

const require = createRequire(import.meta.url);
const modules = new Map();
function load(file) {
  const resolved = file.startsWith("@/") ? `src/${file.slice(2)}.ts` : file;
  if (modules.has(resolved)) return modules.get(resolved).exports;
  const module = { exports: {} };
  modules.set(resolved, module);
  const code = ts.transpileModule(readFileSync(resolved, "utf8"), {
    compilerOptions: { module: ts.ModuleKind.CommonJS, target: ts.ScriptTarget.ES2022, esModuleInterop: true },
  }).outputText;
  new Function("require", "module", "exports", code)(
    (specifier) => specifier.startsWith("@/") ? load(specifier) : require(specifier), module, module.exports,
  );
  return module.exports;
}
const schema = load("src/lib/normalization-schema.ts");
const contact = load("src/lib/contact-hierarchy.ts");
const addressBytes = await readFile("werkstatt/01-roh/Kurverwaltungen_2025.md");
const originalSha256 = createHash("sha256").update(addressBytes).digest("hex");
assert.equal(originalSha256, "28512c72423ac270d4c423007b29dc85266e6938441d830bf0ec8a3239c1bfa1", "Original-MD verändert");
const blocks = contact.readAddressBlocks(addressBytes.toString("utf8"));
const contactReview = contact.buildContactReview(addressBytes.toString("utf8"), originalSha256);

const outputRoot = "werkstatt/02-normiert";
const intro = [
  "# 02 — Normiert", "",
  "**Status: Spaltenvorschlag v2 und vier Beispielstandorte geklärt — keine vollständigen CSV-Datenzeilen.**", "",
  "Die MD-/TXT-Originale in ../01-roh/ sind unverändert. Die Kontaktklärung übernimmt ausdrücklich gelieferte Nutzerwerte mit eigener Herkunft, ohne das MD-Original nachträglich zu füllen.", "",
  "Vorgeschlagene Dateien:", "",
  "- kurverwaltungen-gruppen.csv: bisher zwei ausdrücklich zugeordnete Parents (Mönchgut, Baabe).",
  "- kurverwaltungen.csv: 32 ursprüngliche Standorte mit parent_id; unbekannte Beziehungen bleiben offen.",
  "- kurverwaltungen-kontaktwege.csv: 119 MD-Werte plus drei Nutzerergänzungen = 122; keine Kontaktvererbung.",
  "- suendenfrei-termine.csv: 54 Quelltermine.",
  "- suendenfrei-zeitfenster.csv: 60 Zeitfenster.", "",
  "Die fünfte Gruppen-Datei ergänzt den vorherigen Vier-Dateien-Vorschlag. Der vollständige Aufbau ist noch nicht als Import freigegeben.",
  "Unter vorlagen/ liegen ausschließlich fünf Kopfzeilen, eindeutig mit vorschlag- benannt. Die echten Ergebnis-CSV-Dateien sind noch nicht vorhanden.", "",
  "KONTAKTKLAERUNG.md und kontaktklaerung-beispiele.json dokumentieren nur zwei Parents/four Children (vier Beispielstandorte), Original-/Nutzerbelege und +49-Ableitungen. Das ist keine vollständige Normierung.",
  "nutzer-kontaktklaerung.json bewahrt die ausdrücklich benannten Ergänzungen und die als Nutzerzitate gekennzeichneten Chattexte. Keine Original-Chat-ID wurde daraus geraten.", "",
  "Fehlende Angaben: Anzeige und spätere normierte CSV-Zellen -; intern null plus Status. Kein Strich als tatsächliche Telefonnummer, E-Mail oder erfundener MD-Wert.",
  "Telefon: +49 ist zusätzlich für diese deutsche Quelle freigegeben, Original bleibt erhalten. URL-Protokolle werden nicht angenommen.", "",
  "Details: SPALTENVORSCHLAG.md und schema-vorschlag.json. Keine Datenbankänderung.", "",
].join("\n");
const artifacts = new Map([
  [`${outputRoot}/LIESMICH.md`, intro],
  [`${outputRoot}/SPALTENVORSCHLAG.md`, schema.normalizationMarkdown() + "\n"],
  [`${outputRoot}/schema-vorschlag.json`, JSON.stringify(schema.normalizationProposal, null, 2) + "\n"],
  [`${outputRoot}/KONTAKTKLAERUNG.md`, contact.contactReviewMarkdown(contactReview) + "\n"],
  [`${outputRoot}/kontaktklaerung-beispiele.json`, JSON.stringify(contactReview, null, 2) + "\n"],
  [`${outputRoot}/nutzer-kontaktklaerung.json`, JSON.stringify(contact.contactClarifications, null, 2) + "\n"],
]);
for (const file of schema.normalizationFiles) artifacts.set(`${outputRoot}/vorlagen/vorschlag-${file.filename}`, schema.normalizationHeaderCsv(file));

async function validateProposal() {
  const proposal = schema.normalizationProposal;
  assert.equal(proposal.version, "spaltenvorschlag-v2");
  assert.equal(proposal.stage2Started, false);
  assert.equal(proposal.databaseChanged, false);
  assert.equal(proposal.originalSourcesChanged, false);
  assert.deepEqual(proposal.coreRows, { gruppen: 2, kurverwaltungen: 32, termine: 54 });
  assert.deepEqual(proposal.relationRows, { kontaktwege: 122, zeitfenster: 60 });
  assert.equal(proposal.files.length, 5);
  assert.deepEqual(proposal.files.map((file) => file.id), ["gruppen", "kurverwaltungen", "kontaktwege", "termine", "zeitfenster"]);
  assert.equal(blocks.length, proposal.sourceAudit.addressBlocks);
  assert.equal(blocks.reduce((sum, block) => sum + block.names.length, 0), proposal.sourceAudit.boldNameLines);
  assert.equal(blocks.filter((block) => block.names.length === 2).length, proposal.sourceAudit.twoNameBlocks);
  const counts = Object.fromEntries(["telefon", "fax", "internet", "email"].map((type) => [type, blocks.flatMap((block) => block.channels).filter((value) => value.type === type).length]));
  counts.total = Object.values(counts).reduce((sum, n) => sum + n, 0);
  assert.deepEqual(counts, proposal.sourceAudit.contactChannels);
  assert.deepEqual(blocks.filter((block) => !block.channels.some((value) => value.type === "email")).map((block) => block.names.join(" / ")), proposal.sourceAudit.missingEmailBlocks);
  const schedule = await readFile("werkstatt/01-roh/Termine_2027_suendenfrei.txt", "utf8");
  const rows = schedule.split(/\r?\n/).filter((line) => line.split("\t").length === 3 && /\b20(?:26|27)\b/.test(line.split("\t")[0]));
  const adventCount = rows.filter((line) => line.split("\t")[0].includes("Advent")).length;
  assert.equal(rows.length, 54);
  assert.equal(adventCount, 2);
  assert.equal(rows.length - adventCount + adventCount * 4, proposal.relationRows.zeitfenster);
  for (const file of proposal.files) {
    assert.equal(new Set(file.fields.map((item) => item.name)).size, file.fields.length, "Doppelte Spalte");
    assert.ok(file.fields.some((item) => item.role === "schluessel"));
    const csv = schema.normalizationHeaderCsv(file);
    assert.equal(csv.split("\r\n").filter(Boolean).length, 1, "CSV-Vorlage enthält Datenzeilen");
    assert.equal((csv.match(/;/g) ?? []).length, file.fields.length - 1);
  }
  const find = (id) => new Set(proposal.files.find((file) => file.id === id).fields.map((item) => item.name));
  assert.ok(find("gruppen").has("gruppe_id") && find("kurverwaltungen").has("parent_id"));
  assert.ok(find("kontaktwege").has("telefon_international"));
  assert.ok(find("termine").has("termin_id") && find("zeitfenster").has("termin_id"));
}

function validateContactClarification() {
  assert.deepEqual(contactReview.counts, { originalLocations: 32, originalContactValues: 119, supplementedContactValues: 122, addedContactValues: 3, originalMissingEmails: 2, remainingMissingEmails: 1, parentGroups: 2, exampleLocations: 4 });
  const children = contactReview.groups.flatMap((group) => group.children);
  assert.deepEqual(contactReview.groups.map((group) => group.children.map((child) => child.id)), [["KV12", "KV13"], ["KV09", "KV10"]]);
  const value = (id, type) => children.find((item) => item.id === id).channels.find((item) => item.type === type);
  assert.equal(value("KV12", "email").value, "info@ostseebad-moenchgut.de");
  assert.equal(value("KV12", "email").mdValue, null);
  assert.equal(value("KV12", "email").origin, "nutzer");
  assert.equal(value("KV12", "internet").origin, "nutzer");
  assert.equal(value("KV13", "telefon").value, "+49 38308 66010");
  assert.equal(value("KV13", "telefon").mdValue, null);
  assert.equal(value("KV13", "fax").value, null);
  assert.equal(value("KV13", "fax").status, "fehlt_laut_nutzer");
  assert.equal(value("KV12", "telefon").phone.international, value("KV13", "telefon").phone.international);
  assert.notEqual(children.find((item) => item.id === "KV12").street, children.find((item) => item.id === "KV13").street);
  for (const type of ["email", "internet", "fax"]) assert.equal(value("KV10", type).value, null, "Keine Vererbung nach Baabe-Infopavillion");
  assert.equal(value("KV10", "telefon").value, "(03 83 03) 1 42 41");
  assert.equal(value("KV09", "email").value, "willkommen@baabe.de");
  assert.equal(children.find((item) => item.id === "KV13").subtitle, null);
  assert.equal(contact.internationalGermanPhone("(0 38 38) 80 77 80").international, "+493838807780");
  assert.equal(contact.internationalGermanPhone("(0 38 38) 80 77 80").display, "+49 3838 807780");
  assert.equal(contact.internationalGermanPhone("+49 38308 66010").international, "+493830866010");
  for (const input of [null, "", "-"]) { const result = contact.internationalGermanPhone(input); assert.equal(result.international, null); assert.equal(result.status, "fehlt"); }
  for (const input of ["+43 123456789", "+49 (0) 38308 66010", "807780", "unbekannt"]) assert.equal(contact.internationalGermanPhone(input).status, "pruefen", input);
  assert.equal(contactReview.rules.inheritance, "keine");
  assert.equal(contactReview.stage2Started, false);
}

await validateProposal();
validateContactClarification();
if (process.argv.includes("--write")) {
  for (const [filename, content] of artifacts) {
    await mkdir(path.dirname(filename), { recursive: true });
    await writeFile(filename, content);
  }
  console.log(`Vorschlag und vier Beispielstandorte geschrieben: ${artifacts.size} Dateien; CSV-Vorlagen nur Kopfzeilen.`);
}
for (const [filename, expected] of artifacts) assert.equal(await readFile(filename, "utf8"), expected, `${filename}: nicht synchron`);
console.log("Geprüft: MD 32 Standorte / 119 Kontaktwerte; mit Nutzerwerten 122; zwei Parents / vier Children; keine Vererbung; +49-Ableitung; fünf Kopfzeilen-only Vorlagen.");
