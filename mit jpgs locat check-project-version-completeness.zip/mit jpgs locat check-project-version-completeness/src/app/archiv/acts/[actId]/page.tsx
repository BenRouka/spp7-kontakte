import Link from "next/link";
import { notFound } from "next/navigation";
import { ArrowLeft, CalendarDays, MessagesSquare } from "lucide-react";
import { Badge, Card, Empty, SectionHead } from "@/components/ui";
import { getActDetail } from "@/lib/altbestand";

export const dynamic = "force-dynamic";

export default async function ActDetailPage({
  params,
}: {
  params: Promise<{ actId: string }>;
}) {
  const { actId } = await params;
  const d = await getActDetail(actId);
  if (!d) notFound();

  return (
    <div className="space-y-8">
      <Link
        href="/archiv/acts"
        className="inline-flex items-center gap-1.5 font-mono text-[11px] uppercase tracking-[0.14em] text-muted transition-colors hover:text-lime"
      >
        <ArrowLeft className="h-3.5 w-3.5" /> Bands
      </Link>

      <SectionHead
        eyebrow={`${d.act.actId} · Act`}
        title={d.act.name}
        right={<Badge tone="lime">{d.events.length} Festivals</Badge>}
      />

      {d.act.namensvarianten && d.act.namensvarianten !== d.act.name ? (
        <Card className="px-5 py-3">
          <p className="text-[12px] text-muted">
            <strong className="text-ink-soft">Namensvarianten:</strong>{" "}
            {d.act.namensvarianten}
          </p>
        </Card>
      ) : null}

      <Card className="overflow-hidden">
        <div className="flex items-center gap-2 border-b border-line bg-raised2/40 px-4 py-2.5">
          <CalendarDays className="h-4 w-4 text-lime" />
          <h3 className="font-mono text-[11px] font-semibold uppercase tracking-[0.16em] text-ink">
            Festivals
          </h3>
        </div>
        <div className="scrollbox overflow-x-auto">
          <table className="w-full min-w-[720px] border-collapse text-left">
            <thead>
              <tr className="border-b border-line">
                {["ID", "Veranstaltung", "Ort", "Rolle", "Herkunft"].map((h) => (
                  <th
                    key={h}
                    className="px-4 py-2 font-mono text-[10px] uppercase tracking-[0.14em] text-muted"
                  >
                    {h}
                  </th>
                ))}
              </tr>
            </thead>
            <tbody>
              {d.events.map((e) => (
                <tr
                  key={e.eventId}
                  className="border-b border-line/60 transition-colors last:border-0 hover:bg-raised2/30"
                >
                  <td className="px-4 py-2.5">
                    <Link
                      href={`/archiv/${e.eventId}`}
                      className="font-mono text-[11px] text-lime hover:underline"
                    >
                      {e.eventId}
                    </Link>
                  </td>
                  <td className="px-4 py-2.5 text-[13px] text-ink">
                    {e.name}
                    <span className="ml-2 font-mono text-[10px] text-muted">
                      {e.typ}
                    </span>
                  </td>
                  <td className="px-4 py-2.5 text-[12px] text-ink-soft">
                    {e.plz ? (
                      <span className="tnum font-mono text-[11px] text-muted">
                        {e.plz}{" "}
                      </span>
                    ) : null}
                    {e.ort ?? <Empty>ohne Ort</Empty>}
                  </td>
                  <td className="px-4 py-2.5">
                    {e.rolle ? <Badge tone="lime">{e.rolle}</Badge> : null}
                    {e.unsicher ? <Badge tone="amber">unsicher</Badge> : null}
                  </td>
                  <td className="px-4 py-2.5">
                    <Badge tone={e.quelleTyp.includes("KI") ? "amber" : "neutral"}>
                      {e.quelleTyp}
                    </Badge>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </Card>

      <Card className="p-5">
        <div className="mb-3 flex items-center gap-2">
          <MessagesSquare className="h-4 w-4 text-lime" />
          <h3 className="font-mono text-[11px] font-semibold uppercase tracking-[0.16em] text-ink">
            Chat-Belege zu diesen Festivals
          </h3>
          <span className="tnum font-mono text-[11px] text-muted">
            {d.chat.length}
          </span>
        </div>
        {d.chat.length > 0 ? (
          <ul className="space-y-3">
            {d.chat.map((m) => (
              <li
                key={m.msg}
                className="border-b border-line/60 pb-3 last:border-0 last:pb-0"
              >
                <div className="flex flex-wrap items-center gap-2">
                  <span className="font-mono text-[10px] text-muted">
                    MSG {m.msg}
                  </span>
                  {m.datum ? (
                    <span className="font-mono text-[10px] text-muted">
                      {m.datum}
                    </span>
                  ) : null}
                  {m.eventName ? <Badge>{m.eventName}</Badge> : null}
                </div>
                {m.text ? (
                  <p className="mt-1 line-clamp-4 text-[12px] leading-relaxed text-ink-soft">
                    {m.text}
                  </p>
                ) : null}
              </li>
            ))}
          </ul>
        ) : (
          <Empty>keine Chat-Nachricht zugeordnet</Empty>
        )}
      </Card>
    </div>
  );
}
