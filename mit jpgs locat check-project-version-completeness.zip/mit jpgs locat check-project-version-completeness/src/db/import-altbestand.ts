/* ------------------------------------------------------------------ */
/* Stufe 6 — Import des Altbestands (Alt-App / Mockup-Export).         */
/*                                                                     */
/* Verbindliche Regeln:                                                */
/*  1. Die kuratierten Tabellen (regionen, kontakte, termine,          */
/*     termin_zeitfenster, beschluesse) werden NICHT angefasst.        */
/*  2. Zuordnung geschieht ausschließlich über Brückentabellen.        */
/*  3. Jeder Altdatensatz bekommt einen Herkunfts-/Prüfvermerk.        */
/*  4. Nicht zuordenbares bleibt erhalten ("rest") — nichts wird       */
/*     gelöscht, zusammengeführt oder geraten.                         */
/*  5. Integritäts-Gate: sha256 der Quelldateien gegen Manifest.       */
/*                                                                     */
/* Ausführung:  npx tsx src/db/import-altbestand.ts                    */
/* ------------------------------------------------------------------ */

import { createHash } from "node:crypto";
import { readFileSync } from "node:fs";
import path from "node:path";
import { db, pool } from "./index";
import {
  altActs,
  altChatItems,
  altChatMessages,
  altContacts,
  altEventActs,
  altEventChannels,
  altEventDates,
  altEventFeatures,
  altEventPartners,
  altEventTags,
  altEvents,
  altFeedContext,
  altFlyerSources,
  altPartners,
  altTimetable,
  terminAltEvent,
} from "./schema";
import { loadFreeze } from "../lib/freeze";

type Rec = Record<string, string>;
const DATA_DIR = path.join(process.cwd(), "public", "data");
const opt = (v?: string) => {
  const s = (v ?? "").trim();
  return s.length > 0 ? s : null;
};
const ns = (v?: string) => (v ?? "").replace(/\s+/g, "").toLowerCase();

/* --- Integritäts-Gate ---------------------------------------------- */
function verifyQuellen() {
  const manifest = readFileSync(
    path.join(DATA_DIR, "PRUEFSUMMEN.sha256"),
    "utf8",
  )
    .trimEnd()
    .split(/\r?\n/)
    .filter(Boolean)
    .map((l) => {
      const m = l.match(/^([0-9a-f]{64})\s+(.+)$/);
      return { hash: m?.[1] ?? "", file: m?.[2] ?? l };
    });
  let ok = true;
  for (const { hash, file } of manifest) {
    const actual = createHash("sha256")
      .update(readFileSync(path.join(DATA_DIR, file)))
      .digest("hex");
    const match = actual === hash;
    if (!match) ok = false;
    console.log(`  sha256 ${match ? "OK  " : "FAIL"}  ${file}`);
  }
  if (!ok) {
    console.error("ABBRUCH: Quelldateien weichen vom Manifest ab.");
    process.exit(1);
  }
}

/* --- Geo-Qualität klassifizieren (O-11 / B-GEO) --------------------- */
function geoQualitaet(status?: string): string {
  const s = status ?? "";
  if (!s.trim()) return "unbekannt";
  if (s.includes("Zentroid")) return "zentroid";
  if (s.includes("Nominatim") || s.includes("OSM")) return "osm";
  if (s.trim() === "offen" || s.startsWith("offen")) return "offen";
  return "sonstige";
}

function geoVermerk(e: Rec): string {
  const q = geoQualitaet(e.GEO_STATUS);
  if (!opt(e.LAT) || !opt(e.LNG)) return "ohne Koordinaten";
  if (q === "zentroid")
    return "Koordinate = PLZ-Zentroid (1–10 km, kein Veranstaltungsgelände) — O-11: vor Kartennutzung prüfen";
  if (q === "osm") return "Koordinate via OSM/Nominatim — O-11: Genauigkeit prüfen";
  if (q === "offen") return "Geo offen — O-11";
  return "Koordinate ungeprüft — O-11";
}

function herkunftVermerk(e: Rec): string {
  const qt = e.QUELLE_TYP ?? "";
  if (qt.includes("KI")) return "Prio 2 · KI-/Chat-Liste — nie pauschal verifizieren (O-6)";
  if (qt === "Sündenfrei") return "Prio 1 (Sündenfrei-Terminliste), Alt-App-Fassung";
  if (qt === "Flyer") return "Prio 2 · Flyer/Chat-Beleg";
  if (qt === "Chat") return "Prio 2 · Chat-Herkunft (O-6)";
  return `Prio 2 · ${qt || "Herkunft unbekannt"}`;
}

/* --- Zuordnung Termine (identisch zur Abgleichmatrix) --------------- */
/** Dokumentierte Fehlzuordnungen: reine Datumstreffer ohne Name/PLZ. */
const AUSGESCHLOSSEN = new Set(["SF02|M14", "SF04|F66", "SF05|K33"]);

function ordneTermineZu(
  events: Rec[],
  dates: Rec[],
  freezeTermine: {
    sfId: string;
    jahr: number;
    name: string;
    plzOrt: string;
    fenster: { von: string; bis: string }[];
  }[],
) {
  const datesByEvent = new Map<string, Rec[]>();
  for (const d of dates) {
    const k = d.EVENT_ID;
    if (!k) continue;
    datesByEvent.set(k, [...(datesByEvent.get(k) ?? []), d]);
  }
  const treffer: {
    sfId: string;
    eventId: string;
    basis: string;
    score: number;
    hinweis: string | null;
  }[] = [];

  for (const t of freezeTermine) {
    const tn = ns(t.name);
    const plz = t.plzOrt.match(/^(\d{5})/)?.[1] ?? "";
    let best: { score: number; eventId: string; basis: string[] } | null = null;

    for (const e of events) {
      const en = ns(e.NAME);
      const ep = (e.PLZ ?? "").trim();
      let score = 0;
      const basis: string[] = [];
      if (plz && ep === plz) {
        score += 3;
        basis.push("PLZ");
      }
      if (tn && en && (en.includes(tn) || tn.includes(en))) {
        score += 3;
        basis.push("Name");
      }
      if (t.fenster.length > 0) {
        for (const d of datesByEvent.get(e.EVENT_ID) ?? []) {
          const von = d.VON_ISO ?? "";
          const bis = d.BIS_ISO ?? "";
          if (
            von.slice(0, 4) === String(t.jahr) &&
            von <= t.fenster[t.fenster.length - 1].bis &&
            bis >= t.fenster[0].von
          ) {
            score += 3;
            basis.push("Datum");
            break;
          }
        }
      }
      if (score >= 3 && (best === null || score > best.score)) {
        best = { score, eventId: e.EVENT_ID, basis };
      }
    }

    if (!best) continue;
    const key = `${t.sfId}|${best.eventId}`;
    if (AUSGESCHLOSSEN.has(key)) continue;
    // Nur Datumstreffer allein ist zu schwach für eine Zuordnung.
    if (best.basis.length === 1 && best.basis[0] === "Datum") continue;
    const ev = events.find((x) => x.EVENT_ID === best!.eventId)!;
    const hinweise: string[] = [];
    if (ns(ev.NAME) !== tn) hinweise.push(`Altname: ${ev.NAME}`);
    if (plz && (ev.PLZ ?? "").trim() !== plz)
      hinweise.push(`Alt-PLZ: ${ev.PLZ || "—"}`);
    treffer.push({
      sfId: t.sfId,
      eventId: best.eventId,
      basis: [...new Set(best.basis)].sort().join("+"),
      score: best.score,
      hinweis: hinweise.length > 0 ? hinweise.join("; ") : null,
    });
  }
  return treffer;
}

async function main() {
  console.log("— Stufe 6 · Import des Altbestands —");
  verifyQuellen();

  const archive = JSON.parse(
    readFileSync(path.join(DATA_DIR, "spp7-altbestand.json"), "utf8"),
  ) as { datasets: Record<string, Rec[]> };
  const chat = JSON.parse(
    readFileSync(path.join(DATA_DIR, "spp7-altchat.json"), "utf8"),
  ) as { messages: Rec[] };
  const D = archive.datasets;

  const freeze = loadFreeze();
  const freezeTermine = freeze.termine.map((t) => ({
    sfId: t.sfId,
    jahr: Number(t.jahr),
    name: t.name,
    plzOrt: t.plzOrt,
    fenster: t.fenster.map((f) => ({ von: f.von, bis: f.bis })),
  }));

  const eventIds = new Set(D.events.map((e) => e.EVENT_ID));
  const treffer = ordneTermineZu(D.events, D.event_dates, freezeTermine);
  const kuratierteEvents = new Set(treffer.map((t) => t.eventId));

  /* --- Kontakte zuordnen (E-Mail-Exakt, O-09-konform) --------------- */
  const mailToKv = new Map<string, string>();
  for (const k of freeze.kontakte) {
    for (const m of [k.email1, k.email2, k.email3]) {
      const v = (m ?? "").trim().toLowerCase();
      if (v) mailToKv.set(v, k.kvId);
    }
  }

  await db.transaction(async (tx) => {
    // Nur Altbestands-Tabellen leeren — kuratierte bleiben unberührt.
    await tx.execute(
      `truncate table
        alt_chat_messages, alt_chat_items, alt_contacts, alt_flyer_sources,
        alt_feed_context, alt_timetable, alt_event_tags, alt_event_channels,
        alt_event_features, alt_event_partners, alt_partners, alt_event_acts,
        alt_acts, alt_event_dates, termin_alt_event, alt_events
       restart identity cascade` as unknown as never,
    );

    await tx.insert(altEvents).values(
      D.events.map((e) => ({
        eventId: e.EVENT_ID,
        quelleTyp: e.QUELLE_TYP || "Unbekannt",
        quelle: opt(e.QUELLE),
        typ: e.TYP || "Event",
        name: e.NAME || "Ohne Namen",
        location: opt(e.LOCATION),
        strasse: opt(e.STRASSE),
        plz: opt(e.PLZ),
        ort: opt(e.ORT),
        region: opt(e.REGION),
        land: opt(e.LAND),
        lat: opt(e.LAT),
        lng: opt(e.LNG),
        geoStatus: opt(e.GEO_STATUS),
        geoQualitaet: geoQualitaet(e.GEO_STATUS),
        eintritt: opt(e.EINTRITT),
        gage: opt(e.GAGE),
        gageStatus: opt(e.GAGE_STATUS),
        konditionen: opt(e.KONDITIONEN),
        bewerbung: opt(e.BEWERBUNG),
        bewerbungStatus: opt(e.BEWERBUNG_STATUS),
        kiRang: opt(e.KI_RANG),
        tags: opt(e.TAGS),
        kurzbeschreibung: opt(e.KURZBESCHREIBUNG),
        langbeschreibung: opt(e.LANGBESCHREIBUNG),
        passung: opt(e.PASSUNG_SPP7),
        naechsterSchritt: opt(e.NAECHSTER_SCHRITT),
        unklar: opt(e.UNKLAR),
        flyer: opt(e.FLYER),
        msg: opt(e.MSG),
        zuordnung: kuratierteEvents.has(e.EVENT_ID) ? "kuratiert" : "rest",
        vermerk: `${herkunftVermerk(e)} · ${geoVermerk(e)}`,
      })),
    );

    if (treffer.length > 0)
      await tx.insert(terminAltEvent).values(
        treffer.map((t) => ({
          terminSfId: t.sfId,
          altEventId: t.eventId,
          basis: t.basis,
          score: t.score,
          hinweis: t.hinweis,
        })),
      );

    await tx.insert(altEventDates).values(
      D.event_dates
        .filter((d) => eventIds.has(d.EVENT_ID))
        .map((d) => ({
          dateId: d.DATE_ID,
          altEventId: d.EVENT_ID,
          von: opt(d.VON),
          bis: opt(d.BIS),
          vonIso: opt(d.VON_ISO),
          bisIso: opt(d.BIS_ISO),
          art: opt(d.ART),
          kommentar: opt(d.KOMMENTAR),
        })),
    );

    await tx.insert(altActs).values(
      D.acts.map((a) => ({
        actId: a.ACT_ID,
        name: a.ACT_NAME || "Ohne Namen",
        namensvarianten: opt(a.NAMENSVARIANTEN),
        anzahlEvents: Number(a.ANZAHL_EVENTS || 0) || 0,
        events: opt(a.EVENTS),
        rollen: opt(a.ROLLEN),
      })),
    );
    const actIds = new Set(D.acts.map((a) => a.ACT_ID));
    await tx.insert(altEventActs).values(
      D.event_acts
        .filter((r) => eventIds.has(r.EVENT_ID) && actIds.has(r.ACT_ID))
        .map((r) => ({
          linkId: r.LINK_ID,
          altEventId: r.EVENT_ID,
          actId: r.ACT_ID,
          rolle: opt(r.ROLLE),
          slotTag: opt(r.SLOT_TAG),
          unsicher: (r.UNSICHER ?? "0").trim() === "1",
          notiz: opt(r.NOTIZ),
        })),
    );

    await tx.insert(altPartners).values(
      D.partners.map((p) => ({
        partnerId: p.PARTNER_ID,
        name: p.PARTNER_NAME || "Ohne Namen",
        anzahlEvents: Number(p.ANZAHL_EVENTS || 0) || 0,
        events: opt(p.EVENTS),
        rollen: opt(p.ROLLEN),
      })),
    );
    const partnerIds = new Set(D.partners.map((p) => p.PARTNER_ID));
    await tx.insert(altEventPartners).values(
      D.event_partners
        .filter((r) => eventIds.has(r.EVENT_ID) && partnerIds.has(r.PARTNER_ID))
        .map((r) => ({
          linkId: r.LINK_ID,
          altEventId: r.EVENT_ID,
          partnerId: r.PARTNER_ID,
          rolle: opt(r.ROLLE),
          unsicher: (r.UNSICHER ?? "0").trim() === "1",
        })),
    );

    await tx.insert(altEventFeatures).values(
      D.event_features
        .filter((r) => eventIds.has(r.EVENT_ID))
        .map((r) => ({
          linkId: r.LINK_ID,
          altEventId: r.EVENT_ID,
          feature: r.FEATURE,
          kategorie: opt(r.KATEGORIE),
        })),
    );

    await tx.insert(altEventChannels).values(
      D.event_channels
        .filter((r) => eventIds.has(r.EVENT_ID))
        .map((r) => ({
          linkId: r.LINK_ID,
          altEventId: r.EVENT_ID,
          kanal: r.KANAL,
          wert: r.WERT,
        })),
    );

    await tx.insert(altEventTags).values(
      D.event_tags
        .filter((r) => eventIds.has(r.EVENT_ID) && (r.TAG ?? "").trim())
        .map((r) => ({ altEventId: r.EVENT_ID, tag: r.TAG.trim() })),
    );

    await tx.insert(altTimetable).values(
      D.timetable
        .filter((r) => eventIds.has(r.EVENT_ID))
        .map((r) => ({
          linkId: r.LINK_ID,
          altEventId: r.EVENT_ID,
          zeit: opt(r.ZEIT),
          programmpunkt: r.PROGRAMMPUNKT || "—",
        })),
    );

    // Feed-Kontext inkl. verwaister Referenzen (O-07 / F29).
    await tx.insert(altFeedContext).values(
      D.feed_context.map((r) => ({
        linkId: r.LINK_ID,
        altEventId: eventIds.has(r.EVENT_ID) ? r.EVENT_ID : null,
        eventRef: opt(r.EVENT_ID),
        account: opt(r.ACCOUNT),
        notiz: opt(r.NOTIZ),
        relevanz: opt(r.RELEVANZ),
        verwaist: !eventIds.has(r.EVENT_ID),
      })),
    );

    await tx.insert(altFlyerSources).values(
      D.flyer_sources.map((f) => ({
        flyer: f.FLYER,
        altEventId: eventIds.has(f.EVENT_ID) ? f.EVENT_ID : null,
        msg: opt(f.MSG),
        datum: opt(f.DATUM),
        montage: opt(f.MONTAGE),
        format: opt(f.FORMAT),
        status: opt(f.STATUS),
        ocrKonfidenz: opt(f.OCR_KONFIDENZ),
        ocrRohtext: opt(f.OCR_ROHTEXT),
        hinweis: opt(f.HINWEIS),
        bildOriginal: `/flyers/flyer_${f.FLYER}.jpg`,
        bildThumb: `/flyers/flyer_${f.FLYER}_thumb.jpg`,
      })),
    );

    await tx.insert(altContacts).values(
      D.contacts.map((c) => {
        const kanal = (c.EMAIL_TELEFON ?? "").toLowerCase();
        let kv: string | null = null;
        for (const token of kanal.split(/[;,|/\s]+/)) {
          const hit = mailToKv.get(token);
          if (hit) {
            kv = hit;
            break;
          }
        }
        return {
          contactId: c.CONTACT_ID,
          organisation: c.ORGANISATION || "Ohne Organisation",
          typ: opt(c.TYP),
          kanal: opt(c.EMAIL_TELEFON),
          ort: opt(c.ORT),
          region: opt(c.REGION),
          lat: opt(c.LAT),
          lng: opt(c.LNG),
          msg: opt(c.MSG),
          notiz: opt(c.NOTIZ),
          kuratiertKvId: kv,
          zuordnungBasis: kv ? "E-Mail exakt" : null,
          zuordnung: kv ? "kuratiert" : "rest",
          vermerk: kv
            ? `Kanalbezug zu ${kv} · gemeinsamer Kanal ist kein Identitätsbeweis (O-09)`
            : "Prio 2 · kein kuratierter Gegenpart — Altbestand, nicht geprüft",
        };
      }),
    );

    await tx.insert(altChatItems).values(
      D.chat_items.map((r) => ({
        msg: opt(r.MSG),
        datum: opt(r.DATUM),
        typ: opt(r.TYP),
        wert: opt(r.WERT),
        foto: opt(r.FOTO),
        kontext: opt(r.KONTEXT),
        zugeordnet: opt(r.ZUGEORDNET),
      })),
    );

    const seen = new Set<string>();
    const msgs = chat.messages.filter((m) => {
      const id = (m.MSG ?? "").trim();
      if (!id || seen.has(id)) return false;
      seen.add(id);
      return true;
    });
    await tx.insert(altChatMessages).values(
      msgs.map((m) => ({
        msg: m.MSG.trim(),
        datum: opt(m.DATUM),
        typ: opt(m.TYP),
        absender: opt(m.ABSENDER),
        weitergeleitetVon: opt(m.WEITERGELEITET_VON),
        text: opt(m.TEXT),
        links: opt(m.LINKS),
        medium: opt(m.MEDIUM),
        flyer: opt(m.FLYER),
        altEventId: eventIds.has((m.EVENT_ID ?? "").trim())
          ? m.EVENT_ID.trim()
          : null,
        eventName: opt(m.EVENT_NAME),
        aktion: opt(m.AKTION),
      })),
    );
  });

  const kuratierteKontakte = D.contacts.filter((c) => {
    const kanal = (c.EMAIL_TELEFON ?? "").toLowerCase();
    return kanal.split(/[;,|/\s]+/).some((t) => mailToKv.has(t));
  }).length;

  console.log("\nImport abgeschlossen:");
  console.log(
    `  alt_events ${D.events.length} (kuratiert verknüpft ${kuratierteEvents.size} · rest ${D.events.length - kuratierteEvents.size})`,
  );
  console.log(`  termin_alt_event ${treffer.length} Verknüpfungen`);
  console.log(
    `  acts ${D.acts.length}/${D.event_acts.length} · partners ${D.partners.length}/${D.event_partners.length} · tags ${D.event_tags.length}`,
  );
  console.log(
    `  flyer ${D.flyer_sources.length} · chat ${chat.messages.length} · kontakte ${D.contacts.length} (zugeordnet ${kuratierteKontakte})`,
  );
  await pool.end();
}

main().catch(async (e) => {
  console.error(e);
  await pool.end();
  process.exit(1);
});
