import { pgTable, text, varchar, timestamp, uuid, doublePrecision, primaryKey } from "drizzle-orm/pg-core";

export const locations = pgTable("locations", {
  id: uuid("id").primaryKey().defaultRandom(),
  name: varchar("name", { length: 255 }).notNull(),
  address: text("address"),
  city: varchar("city", { length: 255 }),
  country: varchar("country", { length: 100 }).default("Germany"),
  latitude: doublePrecision("latitude"),
  longitude: doublePrecision("longitude"),
  altitude: doublePrecision("altitude"), // Für das 3D-Datenmodell
  createdAt: timestamp("created_at").defaultNow(),
});

export const festivals = pgTable("festivals", {
  id: uuid("id").primaryKey().defaultRandom(),
  name: varchar("name", { length: 255 }).notNull(),
  website: varchar("website", { length: 255 }),
  locationId: uuid("location_id").references(() => locations.id),
  description: text("description"),
  tags: text("tags"), // JSON-like string or comma separated
  createdAt: timestamp("created_at").defaultNow(),
});

export const bands = pgTable("bands", {
  id: uuid("id").primaryKey().defaultRandom(),
  name: varchar("name", { length: 255 }).notNull(),
  genre: varchar("genre", { length: 255 }),
  description: text("description"),
  tags: text("tags"),
  createdAt: timestamp("created_at").defaultNow(),
});

export const performances = pgTable("performances", {
  id: uuid("id").primaryKey().defaultRandom(),
  festivalId: uuid("festival_id").references(() => festivals.id),
  bandId: uuid("band_id").references(() => bands.id),
  performanceDate: timestamp("performance_date"),
  stage: varchar("stage", { length: 100 }),
});

// Overriding performances to have a proper ID for easier handling in some ORM versions
// but let's stick to a dedicated table for the relation.

export const contacts = pgTable("contacts", {
  id: uuid("id").primaryKey().defaultRandom(),
  firstName: varchar("first_name", { length: 100 }),
  lastName: varchar("last_name", { length: 100 }),
  email: varchar("email", { length: 255 }),
  phone: varchar("phone", { length: 50 }),
  role: varchar("role", { length: 100 }), // e.g., "Booking", "Technical"
  createdAt: timestamp("created_at").defaultNow(),
});

export const contactRelations = pgTable("contact_relations", {
  id: uuid("id").primaryKey().defaultRandom(),
  contactId: uuid("contact_id").references(() => contacts.id),
  festivalId: uuid("festival_id").references(() => festivals.id),
  bandId: uuid("band_id").references(() => bands.id),
  relationType: varchar("relation_type", { length: 100 }), // e.g., "Organizer", "Manager"
});
