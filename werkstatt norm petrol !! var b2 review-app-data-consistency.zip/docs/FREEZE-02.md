# SPP7 · FREEZE-02 — Stilklärungen beantwortet

**Status: eingefroren (Pause)** · Aktualisiert: 2026-10-01 UTC
**Dieses Dokument ist der aktuelle Einstieg bei der Wiederaufnahme.** Es ergänzt `FREEZE-01`; dessen Dateien und Prüfsummen bleiben als historischer Prüfpunkt unangetastet.

> Bis zur Wiederaufnahme: keine Code-, Layout-, Daten- oder Schemaänderung.
> Weiter erst nach ausdrücklicher Freigabe.

Begleitdateien:
- `docs/FREEZE-02-pruefprotokoll.txt` — automatische Regression, Laufzeit und Build-Ergebnisse
- `docs/FREEZE-02.sha256` — Prüfsummen des aktuellen eingefrorenen Arbeitsstands

---

## 1. L1–L3 — vom Auftraggeber geklärt und umgesetzt

### L1 · „Ablage noch offen“ als Maßstab

- Die Schriftart und Größe von „Ablage noch offen“ bleiben unverändert: **Inter, 12 px**, gedecktes Petrol-/Blaugrau.
- Dieselbe Schriftart und Größe verwenden jetzt auch die Metrik-Unterzeilen, z. B. „9 aus 2026 · 45 aus 2027“.
- Große Zähler bleiben technische Zahlen in Roboto Mono/Lime. Technische Dateinamen, Koordinaten, ISO-Daten und Prüfsummen bleiben Roboto Mono/Lime.

### L2 · A/B-Dialog bereinigt

- Alte Inline-Schriftgrößen (9/10/11 px) und Farben des alten Hell-Schemas entfernt.
- Der Dialog folgt nun dem Petrol-Dunkelschema und den definierten Schriftstufen.
- Technische Versions- und Zeitfensterangaben folgen Roboto Mono/Lime. Der Dialoginhalt und die Prüfung sind unverändert.

### L3 · Quellkarten wie im PNG

- Überschrift: **20 px Inter**, hell.
- Unterzeile: **16 px Inter**, helles Blaugrau.
- Technische Dateiangabe: **14 px Roboto Mono**, Lime.
- Die vorhandenen breiteren Quellspalten und die größere 54-Quellzeilen-Karte bleiben erhalten.

**Gemessene Werte** auf Desktop: Kennzahl-Unterzeile und „Ablage noch offen“ stimmen überein (12 px Inter, gleiche Farbe); Quellkarten 20/16/14 px; A/B-Dialog ohne Inline-Stile und ohne die alten Farben. Auf 390 px Mobilbreite kein horizontaler Überlauf.

Diese Änderungen betreffen ausschließlich die Option-A-Oberfläche. **Option B, ihre Startseite, Rohquellen, Zeitmodell, Datenbank und Pipeline-Stufe 2 sind unverändert.**

---

## 2. Gesamtstand — nicht geändert

- Ausgewählte Oberfläche: **Option A „Datenwerkstatt“**, Petrol-Dunkelschema.
- Zeitmodell: `zeitmodell-2026-2027-v2`, identisch in Option A und im aktualisierten Option-B-Paket.
- Herne 2026: vier getrennte Do.–So.-Wochenenden; Datumsherkunft „berechnet“.
- Herne 2027: vier getrennte Fr.–So.-Wochenenden; „berechnet“ und Sternchenstatus „unbestätigt“ bleiben getrennt.
- Dresden 2026/2027: je ein eigener, durchgehender Zeitraum aus der Quelle; nicht Advent.
- F1: vergangene Termine Januar–September 2026 werden nicht nacherfasst.
- F2: 180 von 206 Events mit Koordinaten; 149 verschiedene Koordinatenpaare. Keine Aussage zur inhaltlichen Richtigkeit.
- Rohquellen MD/TXT bytegleich. Das ursprüngliche Option-B-Werkstatt-ZIP und das daraus abgeleitete Option-B-ZIP unverändert.
- Datenbankschema unverändert und ohne Tabellen; keine Imports oder Schreibzugriffe.
- Stufe 2 (vollständige Normierung) **nicht begonnen**.

Detaillierte Beschlüsse, F1–F3, E3–E5 und vollständige Pipeline: `docs/FREEZE-01.md` (historischer Basisstand). L1–L3 sind mit diesem FREEZE-02 beantwortet und gelten nicht mehr als offene Punkte.

---

## 3. Sicherheitsgrenze

Die lokale Prüfansicht wurde ausschließlich lesend gegen die bestehende Datenbank geprüft. Das Option-B-Paket enthält keine `.env`, keine Datenbankexporte und keinen privaten Chat-Export. Eine separate Arena-Instanz und GitHub wurden nicht direkt geändert.

---

## 4. Prüfumfang

- Regressionstest: 8 Adventsfenster, 4 Sündenfrei-Quellzeilen, 2026/2027, Sternchenstatus, Kirchenkalender über 101 Jahre.
- A/B-Parität: 7 gemeinsame Code-Dateien bytegleich, 4/4 Zeitmodellfälle identisch, Rohquellen bytegleich.
- Production: Next.js-Typegenerierung, TypeScript ohne Meldungen, `npm run build`, Vorschau/Healthcheck.
- Browser: Kennzahl-/Pipeline-Typografie, Quellkarten-Hierarchie, A/B-Dialog, mobile Navigation und 390-px-Überlaufprüfung.
- Rohquellen-Prüfsummen, Original- und abgeleitetes Option-B-Paket sowie unveränderte Datenbankschema-Datei.

Vollständige Prüfausgabe und Paketprüfsummen: `docs/FREEZE-02-pruefprotokoll.txt`.

---

## 5. Wiederaufnahme

1. Diesen aktuellen FREEZE-02 lesen.
2. Aktuellen Stand prüfen: `sha256sum -c docs/FREEZE-02.sha256`.
3. Zeitmodell und A/B-Gleichstand prüfen: `node scripts/check-time-model.mjs`.
4. Rohquellen prüfen: `cd werkstatt/01-roh && sha256sum -c PRUEFSUMMEN.sha256`.
5. Eine nächste Änderung vor dem Start ausdrücklich abstimmen. Stufe 2 bleibt bis zu ihrer Freigabe unberührt.

`docs/FREEZE-01.sha256` ist der historische Vergleichspunkt vor diesen Stilklärungen. Erwartete Änderungen seit FREEZE-01: nur `src/app/globals.css` und `src/components/alignment-details.tsx`.
