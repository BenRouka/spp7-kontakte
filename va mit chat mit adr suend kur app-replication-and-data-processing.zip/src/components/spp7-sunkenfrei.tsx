"use client";

import { CalendarCheck2, MapPin, Search, X } from "lucide-react";
import { useMemo, useState } from "react";

type DataRow = Record<string, string>;

const MONTHS = ["Januar", "Februar", "März", "April", "Mai", "Juni", "Juli", "August", "September", "Oktober", "November", "Dezember"];
const MONTH_SHORT = ["JAN", "FEB", "MÄR", "APR", "MAI", "JUN", "JUL", "AUG", "SEP", "OKT", "NOV", "DEZ"];

function statusTone(value: string) {
  const v = value.toLowerCase();
  if (v === "bestätigt") return "ok";
  if (v === "wahrscheinlich") return "warn";
  return "neutral";
}

function monthOf(row: DataRow) {
  const iso = row.VON_ISO;
  if (iso) return Number(iso.slice(5, 7)) - 1;
  if (row.MONAT) return Number(row.MONAT) - 1;
  return 11;
}

export function SunkenfreiView({
  rows,
  search,
  setSearch,
  setSelected,
}: {
  rows: DataRow[];
  search: string;
  setSearch: (value: string) => void;
  setSelected: (value: { dataset: "sunkenfrei_2027"; row: DataRow }) => void;
}) {
  const [month, setMonth] = useState<number | null>(null);
  const [status, setStatus] = useState("Alle");

  const counts = useMemo(() => {
    const acc = Array.from({ length: 12 }, () => 0);
    rows.forEach((row) => {
      const m = monthOf(row);
      if (m >= 0 && m < 12) acc[m] += 1;
    });
    return acc;
  }, [rows]);

  const filtered = useMemo(() => {
    const query = search.trim().toLocaleLowerCase("de");
    return rows
      .filter((row) => {
        const matchesQuery = !query || Object.values(row).some((value) => value.toLocaleLowerCase("de").includes(query));
        const matchesMonth = month === null || monthOf(row) === month;
        const matchesStatus = status === "Alle" || row.STATUS === status;
        return matchesQuery && matchesMonth && matchesStatus;
      })
      .sort((a, b) => {
        const ma = monthOf(a) * 10000 + (a.VON_ISO ? Number(a.VON_ISO.slice(8, 10)) : 0);
        const mb = monthOf(b) * 10000 + (b.VON_ISO ? Number(b.VON_ISO.slice(8, 10)) : 0);
        return ma - mb || a.BEZEICHNUNG.localeCompare(b.BEZEICHNUNG, "de");
      });
  }, [rows, search, month, status]);

  const confirmed = rows.filter((row) => row.STATUS === "bestätigt").length;
  const likely = rows.filter((row) => row.STATUS === "wahrscheinlich").length;
  const open = rows.filter((row) => row.STATUS === "offen").length;
  const monthsWithData = counts.map((count, index) => ({ index, count })).filter((entry) => entry.count > 0);

  return (
    <div className="sf-view">
      <section className="view-intro">
        <div>
          <span className="model-badge"><CalendarCheck2 className="size-4" /> Veranstalter-Termine</span>
          <h2>
            Sündenfrei <em>2027.</em>
          </h2>
          <p>Jahresprogramm des Veranstalters Sündenfrei — {rows.length} Termine von Januar bis Dezember, mit Sternchen-System zur Bestätigung.</p>
        </div>
        <div className="pipeline-total">
          <strong>{rows.length}</strong>
          <span>Termine · {confirmed} bestätigt<br />{likely} wahrscheinlich · {open} offen</span>
        </div>
      </section>

      <div className="sf-legend">
        <span className="status-badge status-ok"><i />bestätigt</span>
        <span className="status-badge status-warn"><i />wahrscheinlich <small>· Sternchen in der Quelle</small></span>
        <span className="status-badge status-neutral"><i />offen <small>· noch unbenannt / Ort unbekannt</small></span>
      </div>

      <div className="sf-month-strip" aria-label="Monat filtern">
        <button type="button" className={month === null ? "selected" : ""} onClick={() => setMonth(null)}>
          <strong>Alle</strong><small>{rows.length}</small>
        </button>
        {monthsWithData.map(({ index, count }) => (
          <button key={index} type="button" className={month === index ? "selected" : ""} onClick={() => setMonth(month === index ? null : index)}>
            <strong>{MONTH_SHORT[index]}</strong><small>{count}</small>
          </button>
        ))}
      </div>

      <div className="sf-toolbar">
        <label className="table-search">
          <Search className="size-4" />
          <input value={search} onChange={(event) => setSearch(event.target.value)} placeholder="Termin, Ort oder PLZ suchen…" />
          {search && <button onClick={() => setSearch("")} aria-label="Suche löschen"><X className="size-3.5" /></button>}
        </label>
        <div className="sf-status-filter" aria-label="Status filtern">
          {["Alle", "bestätigt", "wahrscheinlich", "offen"].map((item) => (
            <button key={item} type="button" className={status === item ? "selected" : ""} onClick={() => setStatus(item)} aria-pressed={status === item}>{item}</button>
          ))}
        </div>
        <span>{filtered.length} von {rows.length}</span>
      </div>

      <section className="panel sf-table-panel">
        <div className="table-scroll">
          <table className="data-table">
            <thead>
              <tr>
                <th className="thumb-column">Monat</th>
                <th>Termin</th>
                <th>Termin (Original)</th>
                <th>PLZ</th>
                <th>Ort</th>
                <th>Status</th>
                <th>Anmerkung</th>
                <th className="action-column" />
              </tr>
            </thead>
            <tbody>
              {filtered.length ? filtered.map((row) => {
                const m = monthOf(row);
                const day = row.VON_ISO ? Number(row.VON_ISO.slice(8, 10)) : null;
                return (
                  <tr key={row.TERM_ID} onClick={() => setSelected({ dataset: "sunkenfrei_2027", row })}>
                    <td className="thumb-column">
                      <span className="date-tile"><strong>{day ?? "–"}</strong><small>{MONTH_SHORT[m]}</small></span>
                    </td>
                    <td><strong>{row.BEZEICHNUNG}</strong></td>
                    <td>{row.VON_TEXT}</td>
                    <td className="id-cell">{row.PLZ || "—"}</td>
                    <td>{row.ORT ? <span className="sf-place"><MapPin className="size-3" />{row.ORT}</span> : <span className="empty-value">noch offen</span>}</td>
                    <td><span className={`status-badge status-${statusTone(row.STATUS)}`}><i />{row.STATUS}</span></td>
                    <td>{row.ANMERKUNG ? <span title={row.ANMERKUNG} className="clamped-cell">{row.ANMERKUNG}</span> : <span className="empty-value">—</span>}</td>
                    <td className="action-column" />
                  </tr>
                );
              }) : (
                <tr><td colSpan={8} className="empty-row"><Search className="size-5" /> Keine passenden Termine gefunden.</td></tr>
              )}
            </tbody>
          </table>
        </div>
        <div className="sf-footnote">
          <span className="sf-star">*</span> Sternchen: Termin oder Ort wahrscheinlich, jedoch noch unbestätigt.
          {month !== null && <em>Ansicht: {MONTHS[month]} 2027</em>}
        </div>
      </section>
    </div>
  );
}
