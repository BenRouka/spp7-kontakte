# Stufe 6 — Altbestand integriert · Handoff

**Stand:** 2026-10-04 · **Datenschutz:** B-17, nur intern
**Grundsatz:** Werkstatt = Referenz. Altbestand = Prio-2-Zulieferer mit Herkunftsvermerk. Nichts wurde geraten, zusammengeführt oder gelöscht.

---

## 1. Was ausgeführt wurde

| Schritt | Ergebnis |
|---|---|
| Quellmaterial ins Projekt | `public/data/spp7-altbestand.json` (240 Events), `spp7-altchat.json` (121 Nachrichten), `suendenfrei-26-27.txt` (korrigierte Prio-1-Quelle), 159 Flyer-Dateien nach `public/flyers/` |
| Prüfsummen | `public/data/PRUEFSUMMEN.sha256` — Integritäts-Gate im Import, Abbruch bei Abweichung |
| Schema erweitert | 17 neue `alt_*`-Tabellen + Brücke `termin_alt_event` |
| Import | `src/db/import-altbestand.ts`, transaktional, idempotent |
| GUI | `/archiv`, `/archiv/[eventId]`, `/archiv/acts`, `/archiv/acts/[actId]`, `/archiv/flyer` |

**Die kuratierten Tabellen wurden nicht angefasst:** `regionen` 9 · `kontakte` 35 · `termine` 54 · `termin_zeitfenster` 60 · `beschluesse` 20 — unverändert, `/api/import/verify` bleibt `ok: true`.

## 2. Importierte Mengen

| Tabelle | Zeilen | | Tabelle | Zeilen |
|---|---:|---|---|---:|
| alt_events | 240 | | alt_event_tags | 711 |
| alt_event_dates | 240 | | alt_event_channels | 80 |
| alt_acts | 221 | | alt_event_features | 47 |
| alt_event_acts | 270 | | alt_timetable | 15 |
| alt_partners | 42 | | alt_feed_context | 22 |
| alt_event_partners | 46 | | alt_flyer_sources | 79 |
| alt_contacts | 74 | | alt_chat_messages | 121 |
| **termin_alt_event** | **50** | | alt_chat_items | 149 |

## 3. Zuordnung — was verknüpft ist und was bewusst nicht

### Termine: 50 von 54 verknüpft
Report: `docs/Zuordnung-Termine-Altbestand.csv`

**Nicht verknüpft (4) — bewusst offen gelassen statt geraten:**

| SF | Grund |
|---|---|
| SF02 · 373. Zwiebelmarkt 2026 | kein 2026er-Event im Altbestand (nur 374. von 2027) |
| SF04 · 5. Mittelalter-Markttage 2026 | kein 2026er-Event |
| SF05 · Mittelalter-Advent 2026 | kein 2026er-Advent-Event |
| SF17 · „noch offen" / `xxxxx` | Platzhalter ohne Ort — reiner Datumstreffer reicht als Beleg nicht |

**Zuordnungsregel im Code:** Score aus PLZ (+3), Name-Containment (+3), Datumsüberschneidung im selben Jahr (+3); Schwelle ≥ 3. **Ein reiner Datumstreffer wird verworfen.** Die drei dokumentierten Fehlzuordnungen aus Befundbericht C (SF02→M14, SF04→F66, SF05→K33) sind als Ausschlussliste im Import hinterlegt.

**Serien-Events:** Ein Alt-Event kann mehrere Quellzeilen decken (S02 Rauhnächte → SF09/SF10/SF54; M14 Burgfest → SF03/SF27/SF48). Die Brücke ist deshalb n:m.

### Kontakte: 37 von 74 verknüpft
Report: `docs/Zuordnung-Kontakte-Altbestand.csv` · Basis: E-Mail-Exakt · 33 der 35 KV-IDs gedeckt (ohne: KV10, KV13).
Jede Verknüpfung trägt den Vermerk: *„gemeinsamer Kanal ist kein Identitätsbeweis (O-09)"*.

## 4. Vermerke — jeder Altdatensatz trägt seine Herkunft

Kombination aus Herkunft + Geo-Qualität, z. B.:
- `Prio 1 (Sündenfrei-Terminliste), Alt-App-Fassung · Koordinate = PLZ-Zentroid (1–10 km, kein Veranstaltungsgelände) — O-11: vor Kartennutzung prüfen`
- `Prio 2 · KI-/Chat-Liste — nie pauschal verifizieren (O-6) · ohne Koordinaten`

**Geo-Qualität klassifiziert (O-11 bleibt gesperrt):** zentroid · osm · offen · sonstige · unbekannt. In der GUI sind Zentroid-Koordinaten durchgehend bernsteinfarben markiert.

## 5. GUI — die gewünschten Formularansichten

| Route | Inhalt |
|---|---|
| `/archiv` | Kennzahlen, Geo-Prüfliste, filterbare Eventliste (Alle / Mit kuratiertem Termin / Rest), Suche |
| `/archiv/[eventId]` | **Festival-Formular:** kuratierter Termin (führend) · Ort & Geo · Bewerbung & Gage · Termine · Bands · Partner · Kanäle · Features/Programm · Flyer mit OCR · Chat-Belege · Einschätzung & Tags · Feed-Kontext |
| `/archiv/acts` | Band-Liste mit Anzahl Festivals |
| `/archiv/acts/[actId]` | **Band-Formular:** Namensvarianten · alle Festivals mit Rolle · Chat-Belege dieser Festivals |
| `/archiv/flyer` | Bildraster aller 79 Flyer, Klick öffnet Original |

## 6. Prüfstatus

- Next.js Typegen: bestanden
- TypeScript `tsc --noEmit`: 0 Fehler
- Production Build: bestanden (13 Routen)
- Import-Gate: alle 3 Quelldateien sha256 OK
- Kuratierte Bestände unverändert

## 7. Weiterhin offen (keine Entscheidung getroffen)

1. **SF20/SF27 Schreibweise** — Option 1 (überliefert belassen) / Option 2 (Prio-1-Korrektur übernehmen). Unverändert.
2. **O-11 Geo** — Koordinaten sind sichtbar und klassifiziert, aber nicht als geprüft markiert. Kartenimport weiterhin gesperrt.
3. **Map-Panel** — SVG-Radar aus dem Mockup noch nicht nachgebaut.
4. **9 Rügen-Events im Rest** (S05, T04, T05, T06, T09, T10, C29, C30, C31) — fachlich noch nicht bewertet.
5. **KV10/KV13** ohne Altbestands-Gegenpart.
6. **D113/D198** — als identisch belegt; Bereinigung im Altbestand nicht ausgeführt (beide Datumzeilen bleiben sichtbar).
7. **F29** — verwaiste Feed-Referenz, als `verwaist = true` gekennzeichnet statt gelöscht.

**Ende Stufe-6-Handoff.**
