"""Read-only cross-check: compares chat/OCR signals against the current app dataset.
Writes only to /tmp/audit — never touches public/data or the database."""
import json

DATASET = 'public/data/spp7-datasets.json'
CHAT = '/tmp/audit/chat_signals.json'
OCR = '/tmp/audit/ocr_signals.json'
OUT = '/tmp/audit/cross_check.json'

data = json.load(open(DATASET, encoding='utf-8'))
ds = data['datasets']
chat = json.load(open(CHAT, encoding='utf-8'))
ocr = json.load(open(OCR, encoding='utf-8'))['flyers']
ocr_by_n = {r['n']: r for r in ocr}

events = ds['events']
contacts = ds['contacts']
flyer_sources = ds.get('flyer_sources', [])
fs_by_n = {int(r['FLYER']): r for r in flyer_sources}

known_contact_emails = {c['EMAIL_TELEFON'].lower() for c in contacts if '@' in (c['EMAIL_TELEFON'] or '')}
known_channel_emails = {r['WERT'].lower() for r in ds['event_channels'] if '@' in (r.get('WERT') or '')}
known_event_emails = set()
for e in events:
    for field in ('QUELLE', 'KURZBESCHREIBUNG', 'LANGBESCHREIBUNG', 'UNKLAR', 'ANBIETER'):
        pass  # emails aren't usually embedded in these; captured separately below
known_emails_all = known_contact_emails | known_channel_emails

flyer_money = {int(r['EVENT_ID'][1:]): r for r in events if r['EVENT_ID'].startswith('F') and r['EVENT_ID'][1:].isdigit()}

money_review = []
for r in ocr:
    n = r['n']
    if not r['money_mentions']:
        continue
    ev = flyer_money.get(n)
    gage = ev['GAGE'] if ev else ''
    kosten = ev['KOSTEN'] if ev else ''
    money_review.append({
        'flyer': n, 'ocr_money': r['money_mentions'], 'ocr_confidence': r['confidence'],
        'event_id': ev['EVENT_ID'] if ev else None, 'captured_gage': gage, 'captured_kosten': kosten,
        'status': 'captured' if (gage or kosten) else 'CHECK: money seen in OCR but no gage/kosten value stored',
    })

email_review = []
for r in ocr:
    if not r['emails']:
        continue
    for e in r['emails']:
        email_review.append({
            'flyer': r['n'], 'email': e,
            'in_contacts_or_channels': e.lower() in known_emails_all,
        })

chat_email_review = []
for e in chat['unique_emails']:
    chat_email_review.append({
        'email': e,
        'in_contacts_or_channels': e in known_emails_all,
    })
new_chat_emails = [r for r in chat_email_review if not r['in_contacts_or_channels']]

low_conf_status = []
for n in range(1, 80):
    r = ocr_by_n.get(n)
    fs = fs_by_n.get(n)
    if r and r['confidence'] < 55:
        low_conf_status.append({
            'flyer': n, 'confidence': r['confidence'], 'current_status': fs['STATUS'] if fs else 'unknown',
            'event_id': fs['EVENT_ID'] if fs else '', 'excerpt': r['raw_excerpt'][:180],
        })

bewerbung_status_counts = {}
for e in events:
    st = e.get('BEWERBUNG_STATUS', '')
    if st:
        bewerbung_status_counts[st] = bewerbung_status_counts.get(st, 0) + 1

gage_status_counts = {}
for e in events:
    st = e.get('GAGE_STATUS', '')
    gage_status_counts[st] = gage_status_counts.get(st, 0) + 1

flyer_status_counts = {}
for r in flyer_sources:
    flyer_status_counts[r['STATUS']] = flyer_status_counts.get(r['STATUS'], 0) + 1

out = {
    'totals': {
        'events_in_dataset': len(events),
        'contacts_in_dataset': len(contacts),
        'flyer_sources_in_dataset': len(flyer_sources),
        'flyer_status_counts': flyer_status_counts,
        'bewerbung_status_counts': bewerbung_status_counts,
        'gage_status_counts': gage_status_counts,
    },
    'chat_signal_totals': {
        'messages_total': chat['messages_total'],
        'messages_with_text': chat['messages_with_text'],
        'messages_with_photo': chat['messages_with_photo'],
        'unique_emails_in_chat_text': len(chat['unique_emails']),
        'unique_phones_in_chat_text': len(chat['unique_phones']),
        'unique_urls_in_chat_text': len(chat['unique_urls']),
    },
    'money_mentions_review': money_review,
    'flyer_ocr_email_review': email_review,
    'chat_text_email_review_new_only': new_chat_emails,
    'chat_text_email_review_total': len(chat_email_review),
    'low_confidence_flyers': low_conf_status,
}
json.dump(out, open(OUT, 'w', encoding='utf-8'), ensure_ascii=False, indent=1)

print('Flyer status counts:', flyer_status_counts)
print('Bewerbung status counts:', bewerbung_status_counts)
print('Gage status counts:', gage_status_counts)
print()
print('Money mentions to review:', len(money_review))
for m in money_review:
    print(' ', m)
print()
print('Chat emails NOT yet in contacts/channels:', len(new_chat_emails))
for r in new_chat_emails:
    print(' ', r['email'])
print()
print('OCR emails found on flyers:', email_review)
print()
print('Low-confidence flyers:', len(low_conf_status))
for r in low_conf_status:
    print(' ', r['flyer'], r['confidence'], '%', '| status:', r['current_status'], '| event:', r['event_id'])
