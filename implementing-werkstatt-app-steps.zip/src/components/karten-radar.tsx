"use client";

/* ------------------------------------------------------------------ */
/* Event-Radar (Schritt C2). Geometrie, Deutschland-Pfad und Gitter    */
/* 1:1 aus dem Alt-System (Formel 105+(LNG−5)/11×250 · 300−(LAT−47)   */
/* /8,5×270, viewBox 460×330). Farb- und Schriftsprache: Werkstatt.    */
/* Drei Punktklassen wie im Vorbild:                                   */
/*   Sündenfrei 2027 (kuratiert)        = amber, r 4.2, Glow           */
/*   Tourstation 2027 (Korridor)        = lime-Ring (+3.2), r 5.5      */
/*   Rest (Altbestand, ungeprüft)       = matt, r 2.2 — Vergleich,     */
/*                                        Zentroide ausgeblendet       */
/* ------------------------------------------------------------------ */

import { useState } from "react";
import Link from "next/link";
import {
  CalendarDays,
  CircleCheck,
  Eye,
  EyeOff,
  MapPin,
  ShieldAlert,
} from "lucide-react";
import type { KarteDaten } from "@/lib/data";
import { DEUTSCHLAND_PFAD, GITTER_H, GITTER_V } from "@/lib/geo";

const LABEL_OFFSET: Record<string, { dx: number; dy: number; anchor: "start" | "end" }> = {
  S04: { dx: 11, dy: 4, anchor: "start" },
  S03: { dx: 11, dy: 14, anchor: "start" },
  T04: { dx: -11, dy: -7, anchor: "end" },
  T09: { dx: -11, dy: 13, anchor: "end" },
};

export function KarteRadar({ daten }: { daten: KarteDaten }) {
  const [zeigAlt, setZeigAlt] = useState(true);
  const { kuratiert, alt, korridor, stats } = daten;

  const korridorWeg = korridor
    .filter((h) => h.x > 0 || h.y > 0)
    .map((h) => `${h.x.toFixed(1)},${h.y.toFixed(1)}`)
    .join(" ");

  const korridorIds = new Set(korridor.map((h) => h.sfId).filter(Boolean));

  return (
    <div>
      {/* Kopf ------------------------------------------------------ */}
      <div className="flex flex-wrap items-center justify-between gap-3 border-b border-line px-5 py-4">
        <div>
          <p className="font-mono text-[11px] font-semibold uppercase tracking-[0.22em] text-muted">
            Geografische Abdeckung · Schritt C2
          </p>
          <h3 className="font-display mt-1 text-xl font-medium tracking-tight text-ink">
            Event-Radar
          </h3>
        </div>
        <div className="flex items-center gap-2">
          <span className="inline-flex items-center gap-1.5 rounded-full border border-amber/35 bg-amber/10 px-3 py-1.5 font-mono text-[11px] text-amber">
            <span className="h-1.5 w-1.5 rounded-full bg-amber" />
            {stats.sf2027Anzahl} · Sündenfrei 2027
            {stats.sf2027Spanne ? (
              <span className="text-amber/70"> {stats.sf2027Spanne}</span>
            ) : null}
          </span>
          <button
            type="button"
            onClick={() => setZeigAlt((v) => !v)}
            aria-pressed={zeigAlt}
            className={
              zeigAlt
                ? "inline-flex items-center gap-1.5 rounded-full border border-line bg-raised2/70 px-3 py-1.5 font-mono text-[11px] text-ink-soft transition-colors hover:text-ink"
                : "inline-flex items-center gap-1.5 rounded-full border border-transparent px-3 py-1.5 font-mono text-[11px] text-muted transition-colors hover:border-line hover:text-ink"
            }
          >
            {zeigAlt ? <Eye className="h-3.5 w-3.5" /> : <EyeOff className="h-3.5 w-3.5" />}
            Altbestand ungeprüft {zeigAlt ? `(${stats.altAngezeigt})` : "aus"}
          </button>
        </div>
      </div>

      {/* Karte ------------------------------------------------------ */}
      <div className="relative">
        <svg
          viewBox="0 0 460 330"
          role="img"
          aria-label="Event-Radar: kuratierte Sündenfrei-Orte und Tour-Korridor in Deutschland"
          className="block h-auto w-full"
        >
          <defs>
            <filter id="kr-glow" x="-60%" y="-60%" width="220%" height="220%">
              <feGaussianBlur stdDeviation="4" result="blur" />
              <feMerge>
                <feMergeNode in="blur" />
                <feMergeNode in="SourceGraphic" />
              </feMerge>
            </filter>
          </defs>

          {/* Gitter + Silhouette (1:1 Alt-Geometrie) */}
          <g fill="none" stroke="var(--color-line-soft)" strokeWidth="1">
            <path d={GITTER_H} />
            <path d={GITTER_V} />
          </g>
          <path
            d={DEUTSCHLAND_PFAD}
            fill="var(--color-raised)"
            stroke="var(--color-line)"
            strokeWidth="1.2"
          />

          {/* Tour-Korridor-Linie (Ostsee 2027) */}
          {korridorWeg ? (
            <polyline
              points={korridorWeg}
              fill="none"
              stroke="var(--color-lime)"
              strokeWidth="1"
              strokeDasharray="1 5"
              strokeLinecap="round"
              opacity="0.55"
            />
          ) : null}

          {/* Altbestand-Vergleichslayer (ungeprüft, ohne Zentroide) */}
          {zeigAlt
            ? alt.map((p) => (
                <g
                  key={p.eventId}
                  transform={`translate(${p.x.toFixed(1)} ${p.y.toFixed(1)})`}
                  opacity="0.4"
                >
                  <circle r="2.2" fill="var(--color-muted)" />
                  <title>{`${p.name} · ${p.ort} · Altbestand (ungeprüft, Prio 2 · Qualität ${p.qualitaet})`}</title>
                </g>
              ))
            : null}

          {/* Kuratierte Terminorte (frisch geocodierte geo_orte) */}
          {kuratiert.map((p) => {
            const sf2027 = p.jahr === 2027;
            const istKorridor = korridorIds.has(p.sfId);
            if (istKorridor) return null; // wird unten als Tourstation gezeichnet
            return (
              <g
                key={p.sfId}
                transform={`translate(${p.x.toFixed(1)} ${p.y.toFixed(1)})`}
              >
                <circle
                  r={sf2027 ? 4.2 : 3}
                  fill={sf2027 ? "var(--color-amber)" : "var(--color-ink-soft)"}
                  stroke={sf2027 ? "var(--color-amber-soft)" : "var(--color-base)"}
                  strokeWidth={sf2027 ? 1 : 0.75}
                  opacity={sf2027 ? 1 : 0.85}
                  filter={sf2027 ? "url(#kr-glow)" : undefined}
                />
                <title>{`${p.name} · ${p.plzOrt}${sf2027 ? " · Sündenfrei 2027" : " · Sündenfrei 2026"}`}</title>
              </g>
            );
          })}

          {/* Tourstationen (Ring), beschriftet */}
          {korridor.map((h) => {
            const off = LABEL_OFFSET[h.altEventId] ?? { dx: 11, dy: 4, anchor: "start" as const };
            const kur = h.zustand === "kuratiert";
            return (
              <g key={h.altEventId} transform={`translate(${h.x.toFixed(1)} ${h.y.toFixed(1)})`}>
                <circle
                  r="8.7"
                  fill="none"
                  stroke="var(--color-lime)"
                  strokeWidth="1.3"
                  opacity="0.95"
                />
                <circle
                  r="5.5"
                  fill={kur ? "var(--color-amber)" : "var(--color-lime)"}
                  stroke={kur ? "var(--color-amber-soft)" : "var(--color-lime-soft)"}
                  strokeWidth="1"
                  filter="url(#kr-glow)"
                />
                <text
                  x={off.dx}
                  y={off.dy}
                  textAnchor={off.anchor}
                  className="fill-ink"
                  fontSize="9"
                  fontFamily="var(--font-mono)"
                  letterSpacing="0.08em"
                >
                  {h.label.toUpperCase()}
                </text>
                <title>{`${h.label} · ${h.untertitel} · ${kur ? `kuratierter Termin ${h.sfId} · ${h.datumLabel ?? ""}` : "vorgemerkt (Prio 2)"}`}</title>
              </g>
            );
          })}
        </svg>

        {/* Zähler-Kachel */}
        <div className="absolute right-3 top-3 rounded-lg border border-line bg-base/80 px-3 py-2 text-right backdrop-blur-sm">
          <p className="font-mono text-[10px] uppercase tracking-[0.18em] text-muted">
            kuratiert geocodiert
          </p>
          <p className="font-display text-2xl font-medium leading-tight text-ink">
            {stats.kuratiertGeocodiert}
          </p>
          <p className="font-mono text-[10px] text-muted">
            von {kuratiert.length + stats.kuratiertOhneZuordnung} Terminzeilen
          </p>
        </div>
      </div>

      {/* Legende ----------------------------------------------------- */}
      <div className="flex flex-wrap items-center gap-x-5 gap-y-2 border-t border-line px-5 py-3.5">
        <LegendSwatch kind="sf">Sündenfrei 2027 (kuratiert)</LegendSwatch>
        <LegendSwatch kind="tour">Tourstation 2027</LegendSwatch>
        <LegendSwatch kind="sf26">Sündenfrei 2026</LegendSwatch>
        <LegendSwatch kind="alt">Altbestand · ungeprüft</LegendSwatch>
        <span className="ml-auto inline-flex items-center gap-1.5 font-mono text-[10.5px] text-muted">
          <ShieldAlert className="h-3.5 w-3.5 text-amber" />
          {stats.altZentroidAusgeblendet} Zentroide + {stats.altOhneKoordinate} ohne Koordinate
          bewusst nicht als Punkt (O-11)
        </span>
      </div>

      {/* Tour-Korridor-Leiste ----------------------------------------- */}
      <div className="border-t border-line px-5 py-4">
        <p className="font-mono text-[11px] font-semibold uppercase tracking-[0.22em] text-muted">
          Ostsee · Sommer 2027
        </p>
        <div className="mt-3 grid gap-2 sm:grid-cols-2 lg:grid-cols-4">
          {korridor.map((h) => {
            const kur = h.zustand === "kuratiert";
            const inner = (
              <>
                <span
                  className={
                    kur
                      ? "mt-0.5 inline-flex h-6 w-6 shrink-0 items-center justify-center rounded-full border border-amber/40 bg-amber/10 text-amber"
                      : "mt-0.5 inline-flex h-6 w-6 shrink-0 items-center justify-center rounded-full border border-lime/40 bg-lime/10 text-lime"
                  }
                >
                  <MapPin className="h-3.5 w-3.5" />
                </span>
                <span className="min-w-0">
                  <span className="block truncate text-[13px] font-medium text-ink">
                    {h.label}
                    <span className="ml-1.5 text-[11px] font-normal text-muted">
                      {h.untertitel}
                    </span>
                  </span>
                  <span className="mt-0.5 flex items-center gap-1.5 font-mono text-[10.5px] text-muted">
                    {kur ? (
                      <>
                        <CalendarDays className="h-3 w-3 text-amber/80" />
                        {h.datumLabel ?? "Termin kuratiert"} · {h.sfId}
                      </>
                    ) : (
                      <>
                        <CircleCheck className="h-3 w-3 text-lime/70" />
                        vorgemerkt · Alt-Brücke {h.altEventId}
                      </>
                    )}
                  </span>
                </span>
              </>
            );
            return kur ? (
              <Link
                key={h.altEventId}
                href="/termine"
                className="flex items-start gap-2.5 rounded-lg border border-line bg-raised2/50 px-3 py-2.5 transition-colors hover:border-amber/40"
              >
                {inner}
              </Link>
            ) : (
              <Link
                key={h.altEventId}
                href={`/archiv/${h.altEventId}`}
                className="flex items-start gap-2.5 rounded-lg border border-line bg-raised2/50 px-3 py-2.5 transition-colors hover:border-lime/40"
              >
                {inner}
              </Link>
            );
          })}
        </div>
        <p className="mt-3 font-mono text-[10.5px] leading-relaxed text-muted">
          Korridor 1:1 aus dem Alt-System (S04 · S03 · T04 · T09). Geo-Positionen aus der
          frisch geocodierten geo_orte-Tabelle — nicht aus Alt-Koordinaten.
        </p>
      </div>
    </div>
  );
}

function LegendSwatch({
  kind,
  children,
}: {
  kind: "sf" | "tour" | "sf26" | "alt";
  children: React.ReactNode;
}) {
  const swatch =
    kind === "sf"
      ? "h-2.5 w-2.5 rounded-full bg-amber shadow-[0_0_0_3px_rgba(238,176,52,0.18)]"
      : kind === "tour"
        ? "h-2.5 w-2.5 rounded-full border-[1.5px] border-lime"
        : kind === "sf26"
          ? "h-2 w-2 rounded-full bg-ink-soft"
          : "h-2 w-2 rounded-full bg-muted opacity-60";
  return (
    <span className="inline-flex items-center gap-2 font-mono text-[11px] text-ink-soft">
      <span className={swatch} />
      {children}
    </span>
  );
}
