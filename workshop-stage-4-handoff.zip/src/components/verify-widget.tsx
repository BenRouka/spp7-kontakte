"use client";

import { useEffect, useState } from "react";
import { AlertTriangle, FileCheck2, Loader2, ShieldCheck } from "lucide-react";

interface VerifyRow {
  file: string;
  expected: string;
  actual: string;
  match: boolean;
}

interface VerifyResponse {
  ok: boolean;
  checkedAt?: string;
  rows?: VerifyRow[];
  error?: string;
}

export function VerifyWidget() {
  const [state, setState] = useState<"loading" | "ready" | "error">("loading");
  const [data, setData] = useState<VerifyResponse | null>(null);

  useEffect(() => {
    let alive = true;
    fetch("/api/freeze/verify", { cache: "no-store" })
      .then((r) => r.json())
      .then((j: VerifyResponse) => {
        if (!alive) return;
        setData(j);
        setState(j.ok ? "ready" : "error");
      })
      .catch(() => {
        if (!alive) return;
        setState("error");
      });
    return () => {
      alive = false;
    };
  }, []);

  return (
    <div className="rounded-lg border border-line bg-base/60 p-3.5">
      <div className="mb-2.5 flex items-center justify-between gap-3">
        <p className="flex items-center gap-1.5 font-mono text-[10px] font-semibold uppercase tracking-[0.18em] text-muted">
          <ShieldCheck className="h-3.5 w-3.5 text-lime" />
          Live-Verifikation · sha256
        </p>
        {state === "ready" && data?.ok ? (
          <span className="font-mono text-[10px] uppercase tracking-[0.14em] text-lime">
            4/4 OK
          </span>
        ) : null}
        {state === "error" ? (
          <span className="font-mono text-[10px] uppercase tracking-[0.14em] text-amber">
            Abweichung
          </span>
        ) : null}
      </div>

      {state === "loading" ? (
        <p className="flex items-center gap-2 py-2 text-[12px] text-muted">
          <Loader2 className="h-3.5 w-3.5 animate-spin" />
          Prüfsummen werden neu berechnet …
        </p>
      ) : null}

      {state !== "loading" && data?.rows ? (
        <ul className="space-y-1.5">
          {data.rows.map((r) => (
            <li
              key={r.file}
              className="flex items-center justify-between gap-3 rounded border border-line-soft bg-raised2/60 px-2.5 py-1.5"
            >
              <span className="flex min-w-0 items-center gap-2">
                {r.match ? (
                  <FileCheck2 className="h-3.5 w-3.5 shrink-0 text-lime" />
                ) : (
                  <AlertTriangle className="h-3.5 w-3.5 shrink-0 text-amber" />
                )}
                <span className="truncate font-mono text-[11.5px] text-ink-soft">
                  {r.file}
                </span>
              </span>
              <span className="flex items-center gap-2">
                <span className="hidden font-mono text-[10px] text-muted sm:inline">
                  {r.actual.slice(0, 12) || "—"}…
                </span>
                <span
                  className={
                    r.match
                      ? "font-mono text-[10px] font-semibold uppercase text-lime"
                      : "font-mono text-[10px] font-semibold uppercase text-amber"
                  }
                >
                  {r.match ? "OK" : "FAIL"}
                </span>
              </span>
            </li>
          ))}
        </ul>
      ) : null}

      {state === "error" && !data?.rows ? (
        <p className="py-1 text-[12px] text-amber">
          Verifikation nicht erreichbar — Dateien bleiben unverändert im Paket.
        </p>
      ) : null}
    </div>
  );
}
