// Einmal-Skript: erweitert public/data/spp7-datasets.json um die sauber
// verarbeiteten Datensätze "sunkenfrei_2027" und "kurverwaltungen".
// Status: bestätigt = ohne Sternchen, wahrscheinlich = mit Sternchen (*),
// offen = noch unbenannt/unbekannt in der Quelle.

import { readFileSync, writeFileSync } from "node:fs";

const file = new URL("../public/data/spp7-datasets.json", import.meta.url);
const data = JSON.parse(readFileSync(file, "utf8"));

// ---------- Sündenfrei 2027 (Veranstalter-Termine, Original-Liste) ----------
// [name, vonText, vonIso, bisIso, plz, ort, status, anmerkung, monat]
const S = [
  ["Rauhnächte", "2.- 6. Januar 2027", "2027-01-02", "2027-01-06", "01067", "Dresden / Stallhof", "bestätigt", "", 1],
  ["18. Leipziger Umschlag", "6. - 7. März 2027", "2027-03-06", "2027-03-07", "04107", "Leipzig / Agra Messepark Halle 1", "bestätigt", "", 3],
  ["Mittelalterfest Burgfrühling", "13. - 14. März 2027", "2027-03-13", "2027-03-14", "97877", "Wertheim/Burg", "bestätigt", "", 3],
  ["Ritterturnier und Mittelaltermarkt", "20. - 21. März 2027", "2027-03-20", "2027-03-21", "01683", "Altzella / Nossen", "bestätigt", "", 3],
  ["Oster-Ritterturnier", "27. - 29. März 2027", "2027-03-27", "2027-03-29", "56346", "Loreley/ St. Goarshausen", "bestätigt", "", 3],
  ["Ritter und Drachen- Spektakel", "27. - 29. März 2027", "2027-03-27", "2027-03-29", "99448", "Kranichfeld/ Niederburg", "bestätigt", "", 3],
  ["Oster-Ritterturnier", "27. - 29. März 2027", "2027-03-27", "2027-03-29", "44286", "Dorsten/ Schloss Lembeck", "bestätigt", "", 3],
  ["noch offen", "3.- 4. April 2027", "2027-04-03", "2027-04-04", "", "", "offen", "Bezeichnung und Ort noch offen (Quelle: xxxxx)", 4],
  ["Die Wikinger kommen!", "10. - 11. April 2027", "2027-04-10", "2027-04-11", "07929", "Saalburg/ Bleilochtalsperre", "bestätigt", "", 4],
  ["Turnierspiele", "10. - 11. April 2027", "2027-04-10", "2027-04-11", "96178", "Schloss Weissenstein/ Pommersfelden", "bestätigt", "", 4],
  ["Mittealterspektakel", "17.- 18. April 2027", "2027-04-17", "2027-04-18", "04519", "Rackwitz, Schladitzer Bucht", "bestätigt", "", 4],
  ["Mittelalterspektakel", "17. - 18. April 2027", "2027-04-17", "2027-04-18", "41844", "Wegberg/ Schloss Tüschenbroich", "bestätigt", "", 4],
  ["Mittelalterfest Löwenburg", "24. - 25. April 2027", "2027-04-24", "2027-04-25", "34131", "Kassel", "bestätigt", "", 4],
  ["Mittelaltermarkt", "24. - 25. April 2027", "2027-04-24", "2027-04-25", "90513", "Zirndorf b. Nürnberg", "bestätigt", "", 4],
  ["Ritterturnier & Walpurgisnacht", "30. April - 2. Mai 2027", "2027-04-30", "2027-05-02", "06632", "Freyburg/ Neuenburg", "bestätigt", "", 4],
  ["Ritterturnier Schloss Lauersfort", "1. - 2. Mai 2027", "2027-05-01", "2027-05-02", "47447", "Moers", "bestätigt", "", 5],
  ["23. Siegfriedspektakel", "6. - 9. Mai 2027", "2027-05-06", "2027-05-09", "46509", "Xanten", "bestätigt", "", 5],
  ["Mittealter- Burgfest", "6. - 9. Mai 2027", "2027-05-06", "2027-05-09", "06543", "Burg Falkenstein/ Harz", "bestätigt", "", 5],
  ["Wikingerfest", "15. - 17. Mai 2027", "2027-05-15", "2027-05-17", "99885", "Weißensee/Thür.", "bestätigt", "", 5],
  ["Ritterturnier & Mittelalterspektakel", "15. - 17. Mai 2027", "2027-05-15", "2027-05-17", "85399", "Hallbergmoos", "bestätigt", "", 5],
  ["Mittelalterspektakel", "22. - 23. Mai 2027", "2027-05-22", "2027-05-23", "58455", "Witten /Kemnader See", "bestätigt", "", 5],
  ["Gaudium Schloss Horst", "27.- 30. Mai 2027*", "2027-05-27", "2027-05-30", "45899", "Gelsenkirchen", "wahrscheinlich", "Sternchen in Quelle: Termin/Ort wahrscheinlich, noch unbestätigt", 5],
  ["Mittelalterspektakel", "29. - 30. Mai 2027", "2027-05-29", "2027-05-30", "02829", "Königshain", "bestätigt", "", 5],
  ["Mittelalterspektakel", "5. - 6. Juni 2027", "2027-06-05", "2027-06-06", "34346", "Hann. Münden", "bestätigt", "", 6],
  ["Annamarkt und Stadtfest", "11. - 13. Juni 2027", "2027-06-11", "2027-06-13", "52349", "Düren", "bestätigt", "", 6],
  ["Mittelalterspektakel", "16. - 18. Juli 2027", "2027-07-16", "2027-07-18", "23999", "Insel Poel", "bestätigt", "", 7],
  ["Wallensteintage", "22. - 25. Juli 2027", "2027-07-22", "2027-07-25", "18439", "Stralsund /Alter Markt", "bestätigt", "", 7],
  ["Fantasy- und Mittelalterfest", "14. - 15. August 2027", "2027-08-14", "2027-08-15", "01833", "Stolpen (Burg)", "bestätigt", "", 8],
  ["Burgfest", "28. - 29. August 2027*", "2027-08-28", "2027-08-29", "", "", "wahrscheinlich", "Ort noch offen (Quelle: xxxx) · Sternchen: noch unbestätigt", 8],
  ["20. Mittelalterspektakel", "3. - 5. September 2027", "2027-09-03", "2027-09-05", "44629", "Herne / Schloss Strünkede", "bestätigt", "", 9],
  ["Mittelalterfest", "11. - 12. September 2027*", "2027-09-11", "2027-09-12", "99707", "Kyffhäuser", "wahrscheinlich", "Sternchen in Quelle: noch unbestätigt", 9],
  ["Die Wikinger kommen!", "18. - 19. September 2027", "2027-09-18", "2027-09-19", "46509", "Xanten", "bestätigt", "", 9],
  ["Ritterturnier und Mittelalterspektakel", "18. - 19. September 2027", "2027-09-18", "2027-09-19", "93186", "Adlersberg/ Pettendorf", "bestätigt", "", 9],
  ["Zwiebelmarkt Apolda", "24. - 26. September 2027*", "2027-09-24", "2027-09-26", "99510", "Apolda", "wahrscheinlich", "Sternchen in Quelle: noch unbestätigt", 9],
  ["56. Heidelberger Herbst", "25. - 26. September 2027", "2027-09-25", "2027-09-26", "69120", "Heidelberg", "bestätigt", "", 9],
  ["Mittelalter & Fantasytage mit Drachen", "2. - 3. Oktober 2027", "2027-10-02", "2027-10-03", "56346", "Loreley/ St. Goarshausen", "bestätigt", "", 10],
  ["Thüringer Ritterturnier", "2. - 3. Oktober 2027", "2027-10-02", "2027-10-03", "99448", "Kranichfeld", "bestätigt", "", 10],
  ["374. Zwiebelmarkt", "8. - 10. Oktober 2027", "2027-10-08", "2027-10-10", "99423", "Weimar", "bestätigt", "", 10],
  ["30. Burgfest", "9.- 10. Oktober 2027*", "2027-10-09", "2027-10-10", "06543", "Burg Falkenstein/ Harz", "wahrscheinlich", "Sternchen in Quelle: noch unbestätigt", 10],
  ["6. Mittelalter- Markttage", "16. - 17. Oktober 2027*", "2027-10-16", "2027-10-17", "44575", "Castrop- Rauxel", "wahrscheinlich", "Sternchen in Quelle: noch unbestätigt", 10],
  ["Mittelalter- Advent (Fr.- So.)", "1. - 4. Advent 2027*", "", "", "44629", "Herne/ Schloss Strünkede", "wahrscheinlich", "Wöchentlicher Fr.–So.-Rhythmus über die Adventssonntage · 1. Advent 2027: So. 28.11. · 4. Advent: So. 19.12.", 11],
  ["Mittelalter- Weihnacht", "24. 11. - 23. Dezember 2027*", "2027-11-24", "2027-12-23", "01067", "Dresden / Stallhof", "wahrscheinlich", "Sternchen in Quelle: noch unbestätigt", 11],
  ["Felsenkeller- Weihnachtsmarkt", "25. 11. - 30. Dezember 2027*", "2027-11-25", "2027-12-30", "04229", "Leipzig / Plagwitz", "wahrscheinlich", "Sternchen in Quelle: noch unbestätigt", 11],
  ["Kloster- Weihnacht", "26. 11. - 23. Dezember 2027**", "2027-11-26", "2027-12-23", "09111", "Chemnitz", "wahrscheinlich", "Quelle mit Doppelsternchen (**) – wie Sternchen einzuordnen (vermutlich Tippfehler)", 11],
  ["Rauhnächte", "27. - 30. Dezember 2027", "2027-12-27", "2027-12-30", "01067", "Dresden / Stallhof", "bestätigt", "", 12],
];

data.datasets.sunkenfrei_2027 = S.map((row, i) => ({
  TERM_ID: `S${String(i + 1).padStart(2, "0")}`,
  BEZEICHNUNG: row[0],
  VON_TEXT: row[1],
  VON_ISO: row[2],
  BIS_ISO: row[3],
  PLZ: row[4],
  ORT: row[5],
  STATUS: row[6],
  ANMERKUNG: row[7],
  MONAT: String(row[8]),
  QUELLE: "Terminliste des Veranstalters Sündenfrei (Stand Chat 09/2026)",
}));

// ---------- Kurverwaltungen / Infostellen Rügen (Stand 2025) ----------
// [name, gruppe, untergruppe, strasse, plz, ort, telefon, fax, notiz]
const K = [
  ["RügenINFO", "Übergreifend", "Übergreifend", "", "", "", "", "", "Informationsportal „Aktuelle Informationen über die Urlaubsinsel Rügen“ – Seitenkopf der Quelle, kein direkter Ansprechpartner"],
  ["Baltic Project GmbH / Tourismusverband Rügen e. V.", "Übergreifend", "Übergreifend", "Markt 25", "18528", "Bergen auf Rügen", "(03838) 807780", "(03838) 807781", "Tourismusverband"],
  ["Kurverwaltung Binz", "Rund um die Granitz", "Ostseebad Binz", "Heinrich-Heine-Straße 7", "18609", "Ostseebad Binz", "(038393) 148148", "(038393) 148145", "Haus des Gastes"],
  ["Fremdenverkehrsverein Binz/Rügen e. V.", "Rund um die Granitz", "Ostseebad Binz", "Wylichstraße 11", "18609", "Ostseebad Binz", "(038393) 665740", "(038393) 665750", ""],
  ["Rujana Immobilien GmbH", "Rund um die Granitz", "Ostseebad Binz", "Wylichstraße 11", "18609", "Ostseebad Binz", "(038393) 66640", "(038393) 666414", "Zimmervermittlung"],
  ["Tourist-Info Lancken-Granitz", "Rund um die Granitz", "Lancken-Granitz", "Dorfstraße 8", "18586", "Lancken-Granitz", "(038303) 95678", "", ""],
  ["Kurverwaltung Sellin", "Rund um die Granitz", "Ostseebad Sellin", "Warmbadstraße 4", "18586", "Ostseebad Sellin", "(038303) 160", "(038303) 16100", "Haus des Gastes"],
  ["Infopoint Sellin", "Rund um die Granitz", "Ostseebad Sellin", "Seeparkpromenade 1", "18586", "Ostseebad Sellin", "(038303) 16222", "(038303) 16200", ""],
  ["Ostseeappartements Rügen Vermarktungs-GmbH & Co. KG", "Rund um die Granitz", "Ostseebad Sellin", "Granitzer Straße 8", "18586", "Ostseebad Sellin", "(038303) 90940", "(038303) 90944", "Zimmervermittlung"],
  ["Kurverwaltung Baabe", "Halbinsel Mönchgut", "Ostseebad Baabe", "Am Kurpark 9", "18586", "Ostseebad Baabe", "(038303) 1420", "(038303) 14299", "Haus des Gastes"],
  ["Infopavillon KV Baabe", "Halbinsel Mönchgut", "Ostseebad Baabe", "Strandstraße", "18586", "Ostseebad Baabe", "(038303) 14241", "", "außer Winter"],
  ["Mönchguter Zimmervermittlung", "Halbinsel Mönchgut", "Ostseebad Baabe", "Göhrener Chaussee 22", "18586", "Ostseebad Baabe", "(038303) 9560500", "(038303) 909932", "Zimmervermittlung"],
  ["Kurverwaltung Mönchgut / Tourist-Information Middelhagen", "Halbinsel Mönchgut", "Ostseebad Mönchgut", "Dorfstraße 4", "18586", "Ostseebad Mönchgut OT Middelhagen", "(038308) 66010", "(038308) 660110", ""],
  ["Tourist-Information Thiessow", "Halbinsel Mönchgut", "Ostseebad Mönchgut", "Hauptstraße 36", "18586", "Ostseebad Mönchgut OT Thiessow", "", "", "Außenstelle"],
  ["Kurverwaltung Göhren", "Halbinsel Mönchgut", "Ostseebad Göhren", "Poststraße 9", "18586", "Ostseebad Göhren", "(038308) 66790", "(038308) 667932", "im Haus des Gastes"],
  ["Fremdenverkehrs- und Gewerbeverein Göhren e. V.", "Halbinsel Mönchgut", "Ostseebad Göhren", "Poststraße 6", "18586", "Ostseebad Göhren", "(038308) 25940", "(038308) 25930", ""],
  ["Tourist-Infostelle / Gemeinde Glowe", "Halbinsel Jasmund", "Glowe", "Boddenmarkt 1", "18551", "Glowe", "(038302) 5221", "(038302) 5252", ""],
  ["Touristik Lohme GmbH", "Halbinsel Jasmund", "Lohme", "Arkonastr. 31", "18551", "Lohme", "(038302) 88855", "(038302) 88857", "Haus Linde"],
  ["Tourist-Service der Stadt Sassnitz", "Halbinsel Jasmund", "Sassnitz", "Strandpromenade 12", "18546", "Sassnitz", "(038392) 6490", "(038392) 64920", ""],
  ["Fremdenverkehrsamt Dranske", "Halbinsel Wittow", "Dranske", "Schulstraße 19", "18556", "Dranske", "(038391) 89007", "(038391) 89424", ""],
  ["Informationsamt Seebad Breege-Juliusruh", "Halbinsel Wittow", "Juliusruh", "Wittower Straße 5", "18556", "Seebad Juliusruh", "(038391) 311", "(038391) 13235", ""],
  ["Tourismusgesellschaft mbH Kap Arkona", "Halbinsel Wittow", "Putgarten/Kap Arkona", "Am Parkplatz 1", "18556", "Putgarten", "(038391) 13037", "(038391) 41917", ""],
  ["Tourismusinformation Wiek", "Halbinsel Wittow", "Wiek", "Am Markt 5", "18556", "Wiek", "(038391) 76870", "(038391) 76871", ""],
  ["Tourismusverein West-Rügen e. V. / Info-Stube Gingst", "Nord-West-Rügen", "Gingst", "Karl-Marx-Straße 19", "18569", "Gingst", "(038305) 535862", "(038305) 535862", "Telefon und Fax identisch laut Quelle"],
  ["Zimmervermittlung Rügen", "Nord-West-Rügen", "Neuenkirchen", "OT Grubnow 1", "18569", "Neuenkirchen", "(038309) 88001", "(038309) 88002", "Zimmervermittlung"],
  ["Ummanz-Information", "Nord-West-Rügen", "Ummanz", "Neue Straße 63 a", "18569", "Waase/Ummanz", "(038305) 53481", "(038305) 53483", ""],
  ["Gemeinde Seebad Altefähr / Eigenbetrieb Hafen- und Tourismuswirtschaft", "Süd-Rügen", "Altefähr", "Am Fährberg 9", "18573", "Altefähr", "(038306) 75037", "(038306) 75056", ""],
  ["Kurverwaltung Putbus / Stadtinformation", "Süd-Rügen", "Putbus", "Alleestraße 2", "18581", "Putbus", "(038301) 60964", "(038301) 60963", ""],
  ["Tourismus- und Gewerbeverein Putbus e. V.", "Süd-Rügen", "Lauterbach (Putbus)", "Pappelweg 7", "18581", "Lauterbach", "(038301) 60467", "(038301) 60377", "keine Zimmervermittlung"],
  ["Stadtinformation Bergen auf Rügen / Bergen Touristik Service UG", "Zentralrügen", "Bergen auf Rügen", "Markt 23", "18528", "Bergen auf Rügen", "(03838) 3152838", "(03838) 3152839", ""],
  ["Insel Information Hiddensee", "Seebad Insel Hiddensee", "Vitte", "Achtern Diek 18a", "18565", "Vitte", "(038300) 608685", "(038300) 608689", ""],
  ["Tourist Information im Hafencenter Kloster", "Seebad Insel Hiddensee", "Kloster", "Hafenweg 15", "18565", "Kloster", "(038300) 60654", "(038300) 60791", ""],
  ["HTS", "Seebad Insel Hiddensee", "Vitte", "Wiesenweg 21a", "18565", "Vitte", "(038300) 60497", "(038300) 60498", ""],
];

data.datasets.kurverwaltungen = K.map((row, i) => ({
  KV_ID: `KV${String(i + 1).padStart(2, "0")}`,
  NAME: row[0],
  GRUPPE: row[1],
  ORTSBEREICH: row[2],
  STRASSE: row[3],
  PLZ: row[4],
  ORT: row[5],
  TELEFON: row[6],
  FAX: row[7],
  NOTIZ: row[8],
  INTERNET: "",
  EMAIL: "",
  STAND: "2025",
}));

data.meta.sunkenfreiTerms = data.datasets.sunkenfrei_2027.length;
data.meta.kurverwaltungen = data.datasets.kurverwaltungen.length;
data.meta.generatedFrom += " + Sündenfrei 2027 + Kurverwaltungen Rügen";

writeFileSync(file, JSON.stringify(data, null, 1));
console.log(
  "sunkenfrei_2027:",
  data.datasets.sunkenfrei_2027.length,
  "| kurverwaltungen:",
  data.datasets.kurverwaltungen.length,
  "| datasets total:",
  Object.keys(data.datasets).length,
);
