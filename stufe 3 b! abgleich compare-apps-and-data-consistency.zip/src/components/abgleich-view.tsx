"use client";

import { useEffect, useMemo, useState } from "react";
import { Icon } from "@/components/icons";
import type { AbgleichWorkspace } from "@/lib/abgleich-model";

type SubTab = "kontakte" | "termine" | "dubletten";

export function AbgleichView() {
  const [data, setData] = useState<AbgleichWorkspace | null>(null);
  const [error, setError] = useState("");
  const [subTab, setSubTab] = useState<SubTab>("kontakte");
  const [filter, setFilter] = useState("all");
  const [search, setSearch] = useState("");

  useEffect(() => {
    async function load() {
      try {
        const res = await fetch("/api/review/abgleich", { cache: "no-store" });
        if (!res.ok) throw new Error("Fehler beim Laden des Abgleichs");
        const json = (await res.json()) as AbgleichWorkspace;
        setData(json);
      } catch {
        setError("Abgleich-Daten konnten nicht geladen werden.");
      }
    }
    load();
  }, []);

  const filteredContacts = useMemo(() => {
    if (!data) return [];
    return data.contactsComparison.filter((c) => {
      const matchSearch = `${c.name_haupt_sauber} ${c.ort_sauber} ${c.app_organisationen} ${c.kv_id}`
        .toLowerCase()
        .includes(search.toLowerCase());
      if (filter === "dubletten") return matchSearch && c.status_abgleich.startsWith("Dublette");
      if (filter === "matched") return matchSearch && c.status_abgleich === "1:1 Match";
      return matchSearch;
    });
  }, [data, filter, search]);

  const filteredTermine = useMemo(() => {
    if (!data) return [];
    return data.termineComparison.filter((t) => {
      const matchSearch = `${t.name_original} ${t.plz_ort_original} ${t.sf_id} ${t.app_event_namen}`
        .toLowerCase()
        .includes(search.toLowerCase());
      if (filter === "missing") return matchSearch && t.status_abgleich === "Fehlt in App";
      if (filter === "matched") return matchSearch && t.status_abgleich !== "Fehlt in App";
      return matchSearch;
    });
  }, [data, filter, search]);

  if (error) {
    return (
      <div className="error-notice" role="alert">
        <Icon name="info" size={18} />
        <span>{error}</span>
      </div>
    );
  }

  if (!data) {
    return (
      <div className="contact-loading" role="status">
        <Icon name="compare" size={20} />
        <span>Abgleich-Ergebnisse der Stufe 3 werden geladen …</span>
      </div>
    );
  }

  const { statistik } = data.summary;

  return (
    <section className="abgleich-workspace" aria-label="Abgleich Stufe 3">
      {/* Header */}
      <div className="section-heading">
        <div>
          <h2>Abgleich: Saubere Quellen ↔ Bestands-App</h2>
          <p>
            Stufe 3: Gegenüberstellung aller 32 Kurverwaltungen und 54 Termine mit den 74 Kontakten und 206 Events der App.
          </p>
        </div>
        <div className="schema-head-actions">
          <span className="badge badge-green">
            <Icon name="check" size={12} /> Stufe 3 Abgleich bereit
          </span>
          <a className="secondary-button" href="/api/review/abgleich?format=md">
            <Icon name="download" size={14} /> Vollständiger Report (.md)
          </a>
        </div>
      </div>

      {/* KPI Cards */}
      <div className="metric-grid">
        <article className="metric-card">
          <div className="metric-label">
            Kurverwaltungen Dubletten <Icon name="layers" size={17} />
          </div>
          <strong>
            {statistik.kurverwaltungen.dubletten_cluster_in_app.length}
            <span>Cluster in App</span>
          </strong>
          <p>Putbus 9×, ruegen.de 7×, Amt Nord 5×</p>
        </article>

        <article className="metric-card">
          <div className="metric-label">
            Sündenfrei Fehlmenge <Icon name="calendar" size={17} />
          </div>
          <strong>
            {statistik.suendenfrei_termine.fehlend_in_app}
            <span>von 54 fehlen in App</span>
          </strong>
          <p>{statistik.suendenfrei_termine.fehlend_prozent}% der Termine fehlen</p>
        </article>

        <article className="metric-card">
          <div className="metric-label">
            Sonstige App-Kontakte <Icon name="file" size={17} />
          </div>
          <strong>
            {statistik.kurverwaltungen.app_kontakte_andere_chat_kontakte}
            <span>von 74 Kontakten</span>
          </strong>
          <p>Veranstalter, Bands, Ämter aus Chat</p>
        </article>

        <article className="metric-card">
          <div className="metric-label">
            Flyer & Bildlinks <Icon name="folder" size={17} />
          </div>
          <strong>
            158
            <span>JPGs im Chat-Export</span>
          </strong>
          <p>79 tote Bildlinks in App reparierbar</p>
        </article>
      </div>

      {/* Sub Tabs */}
      <div className="tab-toolbar">
        <div className="tabs">
          <button
            className={subTab === "kontakte" ? "selected" : ""}
            onClick={() => {
              setSubTab("kontakte");
              setFilter("all");
              setSearch("");
            }}
          >
            <Icon name="layers" size={15} /> Kurverwaltungen ({data.contactsComparison.length})
          </button>
          <button
            className={subTab === "termine" ? "selected" : ""}
            onClick={() => {
              setSubTab("termine");
              setFilter("all");
              setSearch("");
            }}
          >
            <Icon name="calendar" size={15} /> Sündenfrei Termine ({data.termineComparison.length})
          </button>
          <button
            className={subTab === "dubletten" ? "selected" : ""}
            onClick={() => {
              setSubTab("dubletten");
              setFilter("all");
              setSearch("");
            }}
          >
            <Icon name="compare" size={15} /> Dubletten-Cluster im Detail
          </button>
        </div>

        {subTab !== "dubletten" && (
          <div className="toolbar-controls">
            <label className="search-input">
              <Icon name="search" size={14} />
              <input
                placeholder={subTab === "kontakte" ? "Kontakt suchen…" : "Termin / Ort suchen…"}
                value={search}
                onChange={(e) => setSearch(e.target.value)}
              />
              {search && (
                <button onClick={() => setSearch("")}>
                  <Icon name="close" size={12} />
                </button>
              )}
            </label>
            <a
              className="secondary-button"
              href={`/api/review/abgleich?format=csv&file=${subTab === "kontakte" ? "kontakte" : "termine"}`}
            >
              <Icon name="download" size={14} /> CSV
            </a>
          </div>
        )}
      </div>

      {/* TAB 1: KONTAKTE */}
      {subTab === "kontakte" && (
        <div className="originals-panel">
          <div className="table-heading">
            <div>
              <h3>Gegenüberstellung: 32 saubere Adressblöcke ↔ 74 App-Kontakte</h3>
              <p>Zeigt, wie die sauberen Stammdaten im Bestandsdatensatz abgebildet oder aufgesplittet sind.</p>
            </div>
            <div className="filter-bar">
              <select value={filter} onChange={(e) => setFilter(e.target.value)}>
                <option value="all">Alle anzeigen ({data.contactsComparison.length})</option>
                <option value="dubletten">Nur Dubletten in App</option>
                <option value="matched">Nur 1:1 Matches</option>
              </select>
            </div>
          </div>
          <div className="table-scroll">
            <table>
              <thead>
                <tr>
                  <th>ID</th>
                  <th>Saubere Quelle (MD)</th>
                  <th>Ort / Ortsteil</th>
                  <th>Saubere Kanäle</th>
                  <th>Status in App</th>
                  <th>App-IDs & Befund</th>
                </tr>
              </thead>
              <tbody>
                {filteredContacts.map((c) => (
                  <tr key={c.kv_id}>
                    <td>
                      <code>{c.kv_id}</code>
                    </td>
                    <td>
                      <strong>{c.name_haupt_sauber}</strong>
                      {c.name_zusatz_sauber !== " - " && <small>{c.name_zusatz_sauber}</small>}
                    </td>
                    <td>
                      {c.ort_sauber}
                      {c.ortsteil_sauber !== " - " && <small>OT {c.ortsteil_sauber}</small>}
                    </td>
                    <td>
                      <small className="tech">{c.email_sauber}</small>
                      <small className="tech">{c.telefon_sauber}</small>
                    </td>
                    <td>
                      <span
                        className={`badge ${
                          c.status_abgleich.startsWith("Dublette")
                            ? "badge-amber"
                            : "badge-green"
                        }`}
                      >
                        {c.status_abgleich}
                      </span>
                    </td>
                    <td>
                      <small><strong>App-IDs:</strong> {c.app_contact_ids}</small>
                      <small>{c.befund_details}</small>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* TAB 2: TERMINE */}
      {subTab === "termine" && (
        <div className="originals-panel">
          <div className="table-heading">
            <div>
              <h3>Gegenüberstellung: 54 Sündenfrei-Termine ↔ 206 Bestands-Events</h3>
              <p>40 von 54 Terminen fehlen als eigenständige Events im App-Bestand.</p>
            </div>
            <div className="filter-bar">
              <select value={filter} onChange={(e) => setFilter(e.target.value)}>
                <option value="all">Alle Termine ({data.termineComparison.length})</option>
                <option value="missing">Nur fehlende Termine (40)</option>
                <option value="matched">Nur in App vorhandene (14)</option>
              </select>
            </div>
          </div>
          <div className="table-scroll">
            <table>
              <thead>
                <tr>
                  <th>ID</th>
                  <th>Jahr</th>
                  <th>Datum · Original</th>
                  <th>Veranstaltung (sauber)</th>
                  <th>PLZ / Ort (sauber)</th>
                  <th>Status in App</th>
                  <th>App-Zuordnung & Befund</th>
                </tr>
              </thead>
              <tbody>
                {filteredTermine.map((t) => (
                  <tr key={t.sf_id}>
                    <td>
                      <code>{t.sf_id}</code>
                    </td>
                    <td>
                      <code>{t.jahr}</code>
                    </td>
                    <td className="tech">{t.datum_original}</td>
                    <td>
                      <strong>{t.name_original}</strong>
                      {t.sternchen !== "kein" && <small>Sternchen: {t.sternchen}</small>}
                    </td>
                    <td>{t.plz_ort_original}</td>
                    <td>
                      <span
                        className={`badge ${
                          t.status_abgleich === "Fehlt in App" ? "badge-amber" : "badge-green"
                        }`}
                      >
                        {t.status_abgleich}
                      </span>
                    </td>
                    <td>
                      {t.app_event_ids !== " - " && (
                        <small><strong>App-Events:</strong> {t.app_event_ids}</small>
                      )}
                      <small>{t.befund_details}</small>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* TAB 3: DUBLETTEN CLUSTER DETAIL */}
      {subTab === "dubletten" && (
        <div className="decisions-grid">
          <article className="decision-card">
            <span className="decision-icon">
              <Icon name="layers" size={20} />
            </span>
            <div>
              <div className="decision-heading">
                <h3>Cluster [D1] · Putbus: 9 Einträge für 2 Blöcke</h3>
                <span className="badge badge-amber">9 Einträge in App</span>
              </div>
              <p>
                In der App liegen 9 Kontakte (<code>K22</code>, <code>K23</code>, <code>K24</code>, <code>K25</code>, <code>K26</code>, <code>K27</code>, <code>K28</code>, <code>K70</code>, <code>K71</code>).
                Die saubere MD-Quelle hat exakt 2 Träger: <code>KV27</code> (Kurverwaltung) und <code>KV28</code> (Tourismusverein Lauterbach).
                <code>K70</code> und <code>K71</code> haben Adressen in die Notiz gequetscht.
              </p>
              <div className="dialog-info" style={{ marginTop: 12 }}>
                <Icon name="info" size={16} />
                <span><strong>Empfehlung Stufe 4:</strong> KV27 und KV28 als saubere Stammdaten übernehmen. Personenbezogene Mails optional als Ansprechpartner verknüpfen.</span>
              </div>
            </div>
          </article>

          <article className="decision-card">
            <span className="decision-icon">
              <Icon name="layers" size={20} />
            </span>
            <div>
              <div className="decision-heading">
                <h3>Cluster [D2] · Tourismusverband / ruegen.de: 7 Einträge</h3>
                <span className="badge badge-amber">7 Einträge in App</span>
              </div>
              <p>
                In der App existieren <code>K01</code>, <code>K02</code> (Tourismuszentrale) sowie <code>K35</code>–<code>K39</code> (Mitarbeiter Hegen, Szymanski, Günther, Schmitz, Wolff).
                Die saubere Quelle <code>KV01</code> bündelt die Organisation mit <code>info@ruegen.de</code> und <code>inselexperten@ruegen.de</code>.
              </p>
              <div className="dialog-info" style={{ marginTop: 12 }}>
                <Icon name="info" size={16} />
                <span><strong>Empfehlung Stufe 4:</strong> KV01 als Dachverband führen, Mitarbeiter nicht als eigenständige Organisationen duplizieren.</span>
              </div>
            </div>
          </article>

          <article className="decision-card">
            <span className="decision-icon">
              <Icon name="layers" size={20} />
            </span>
            <div>
              <div className="decision-heading">
                <h3>Cluster [D3] · S. Schönke (privat) vs. Zimmervermittlung</h3>
                <span className="badge badge-amber">Identische Mail</span>
              </div>
              <p>
                In der App ist <code>K57</code> als „S. Schönke (privat)“ erfasst (ohne Ort).
                Die saubere Quelle <code>KV24</code> belegt: Es handelt sich um die „Zimmervermittlung Rügen, OT Grubnow 1, Neuenkirchen“ mit identischer Mailadresse <code>sschoenke@t-online.de</code>.
              </p>
              <div className="dialog-info" style={{ marginTop: 12 }}>
                <Icon name="info" size={16} />
                <span><strong>Empfehlung Stufe 4:</strong> K57 zu KV24 konsolidieren.</span>
              </div>
            </div>
          </article>

          <article className="decision-card">
            <span className="decision-icon">
              <Icon name="layers" size={20} />
            </span>
            <div>
              <div className="decision-heading">
                <h3>Cluster [D4] · Middelhagen Lücke behoben</h3>
                <span className="badge badge-green">Gelöst</span>
              </div>
              <p>
                In der App hatte <code>K09</code> den Kanal <code>(nicht genannt)</code>.
                Die saubere Quelle <code>KV12</code> liefert Telefon, Fax und mit deiner Bestätigung Website & E-Mail (<code>info@ostseebad-moenchgut.de</code>).
              </p>
            </div>
          </article>
        </div>
      )}
    </section>
  );
}
