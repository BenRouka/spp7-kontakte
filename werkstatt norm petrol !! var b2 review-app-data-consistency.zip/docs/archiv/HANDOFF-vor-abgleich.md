# SPP7 · Tour Intelligence — Übergabe- & Entscheidungsprotokoll

**Status: Stufe 1 abgeschlossen** — Stand 2026-10-01
**Am Projektcode wurde weiterhin NICHTS geändert.** Die Sandbox enthält das nackte Starter-Template.
Neu hinzugekommen sind ausschließlich **Dateien zum Lesen**: `werkstatt/` (Originale + Erklärtexte) und dieses Dokument.

> 📌 **Aktueller Punkt der Pipeline:** Stufe 1 ✅ erledigt → **Stufe 2 (Normieren) wartet auf Freigabe.**

---

## 0. Arbeitsroutinen (vom Auftraggeber vorgegeben — gelten fortlaufend)

- Niemals raten oder interpretieren. Bei ungenauen, komplexen oder widersprüchlichen Angaben: selbst kritisch prüfen und Rückfragen stellen.
- Bei Eingriffen ins Datenmodell ausdrücklich warnen (z. B. „Vorsicht, das verändert das Datenmodell").
- Nichts ändern ohne ausdrückliches `ja` / `ok`. `ok leg los` = Code starten.
- In kleinen Schritten arbeiten, jeweils mit ja/nein abstimmen, bis Einigkeit besteht.

---

## 1. Quellen

| Inhalt | URL (GitHub, Repo `BenRouka/spp7-kontakte`) | Größe |
|---|---|---|
| App-Setup | `varB chat! pics scharf 180 maps app-replication-workflow-setup.zip` | 977.096 B · 29 Dateien |
| Original-Chat | `ChatExport_2026-09-20.zip` | 9.437.194 B · 209 Dateien |
| Logo | `logo-spp.pdf` | 1.329.579 B · 1 Seite |
| **Sauber:** Kurverwaltungen | `Kurverwaltungen_2025.md` | 32 Adressblöcke |
| **Sauber:** Termine | `Termine 2027 Veranstalter suendenfrei.txt` | 54 Termine |

### Wiederherstellungs-Befehle (wichtig!)

> ⚠️ **`/tmp` ist in der Sandbox flüchtig** — wurde zwischen zwei Turns bereits geleert.
> Alles außer diesem Dokument muss ggf. neu geladen werden:

```bash
mkdir -p /tmp/spp && cd /tmp/spp
curl -sL -o workflow.zip  "https://raw.githubusercontent.com/BenRouka/spp7-kontakte/main/varB%20chat!%20pics%20scharf%20180%20maps%20app-replication-workflow-setup.zip"
curl -sL -o chatexport.zip "https://raw.githubusercontent.com/BenRouka/spp7-kontakte/main/ChatExport_2026-09-20.zip"
curl -sL -o logo-spp.pdf  "https://raw.githubusercontent.com/BenRouka/spp7-kontakte/main/logo-spp.pdf"
mkdir -p wf chat && unzip -qo workflow.zip -d wf && unzip -qo chatexport.zip -d chat
# Saubere Quellen (Markdown/TXT) direkt aus dem Repo, via raw-URL:
#   https://raw.githubusercontent.com/BenRouka/spp7-kontakte/main/Kurverwaltungen_2025.md
#   https://raw.githubusercontent.com/BenRouka/spp7-kontakte/main/Termine%202027%20Veranstalter%20suendenfrei.txt
```

---

## 2. Inventar App (workflow.zip)

**Stack:** Next.js 16.2.6 · React 19.2.6 · Drizzle ORM 0.45.2 · pg 8.20.0 · Tailwind 4.1.17 · lucide-react ^1.48.0

**Dateien:** `package.json`, `drizzle.config.json`, `next.config.ts`, `eslint.config.mjs`, `postcss.config.mjs`, `tsconfig.json`,
`src/app/{page,layout,globals.css,api/health/route}`, `src/components/{spp7-dashboard.tsx (51 KB), spp7-chat-view.tsx}`,
`src/db/{schema.ts,index.ts}`, `src/lib/spp7-repository.ts`, `scripts/build-chat-data.mjs`,
`public/data/{spp7-datasets.json (775 KB), spp7-chat.json (65 KB), flyer-mapping.csv (13 KB)}`

**UI:** Dashboard „SPP7 · Tour Intelligence", Ansichten Overview / Model (14 Datasets als Tabellen) / Chat-Verlauf, SVG-Karte „Event-Radar", CSV-Export, Suche, Flyer-Thumbnails.

### 2.1 `spp7-datasets.json` — 14 Datasets

| Dataset | Zeilen | Dataset | Zeilen |
|---|---|---|---|
| events | **206** | event_channels | 80 |
| event_dates | 203 | event_tags | 711 |
| event_acts | 270 | timetable | 15 |
| acts | 221 | feed_context | 22 |
| event_partners | 46 | contacts | **74** |
| partners | 42 | chat_items | 149 |
| event_features | 47 | flyer_sources | **79** |

### 2.2 DB-Schema (3 Tabellen)

- `spp7_events` — 29 Spalten (eventId PK, Quelle, Adresse, Geo, Eintritt/Gage, Bewerbung, KI-Rank, Texte, Status)
- `spp7_contacts` — 11 Spalten (contactId PK, Organisation, Typ, **`channel` = EIN einziges Feld für E-Mail *oder* Telefon**, Ort, Region, Lat/Lng, Message, Note)
- `spp7_chat_messages` — 13 Spalten (messageId PK, Art, Zeit, Absender, Text, Links, Medium, Flyer, Event-Bezug)

### 2.3 Chat

- Telegram-Export „Locations zum abtippen", chatId 5349594086, `private_group`, **121 Nachrichten**, alle von **„Hanna Mvb"**
- `ChatExport_2026-09-20/` enthält: `result.json` (142 KB), `messages.html` (111 KB), css/js/images, **158 JPGs** in `photos/`

---

## 3. Check-Ergebnis: vollständig / unvollständig

### ✅ Vollständig & reproduzierbar

- App-Code komplett (package.json → Components → CSS → Schema)
- Chat-Transkript: 121 Nachrichten + `result.json` + Build-Skript `scripts/build-chat-data.mjs`
- 14 Datasets strukturiert vorhanden
- Kontakte: **0 ohne Kontaktkanal**

### ❌ Fehlend / kaputt

| Punkt | Befund |
|---|---|
| **Flyer-/Bild-Dateien** | `flyer-mapping.csv` und UI verweisen auf `/flyers/flyer_XX.jpg` + `_thumb.jpg` — **im workflow.zip NICHT enthalten** → tote Bildlinks |
| ↳ Rekonstruktion | **möglich**: 158 JPGs im ChatExport = exakt **79 × (Original + Thumb)**; Zuordnung per MSG-ID aus `flyer_sources` |
| **Sündenfrei-Termine** | Quelldatei hat **54 Termine** (2026: nur **9**, ab 3. Okt.; 2027: **45**, Stand 22.09.2026). In der App existieren nur **6** (`S01`–`S06`) plus **2** weitere als „Chat (KI-Liste), unverifiziert" ohne PLZ (`M21` Freyburg, `M44` Kranichfeld) → **46 von 54 fehlen** |
| Jahr 2027 generell | nur **12 von 203** Datumszeilen im gesamten Datensatz |
| **Termine 2026 Jan–Sept.** | in der TXT-Quelle **komplekt absent** — Absicht oder Lücke? (offene Frage Q1) |
| Karten-Screenshots | Zip-Name nennt „180 maps", vorhanden sind nur 158 JPGs → evtl. fehlen ~22 Kartenbilder (offene Frage Q5) |
| Saison-Infopavillon Baabe | in `Kurverwaltungen_2025.md`, nicht in contacts |

### ⚠️ Inkonsistenzen & Qualität

**Kurverwaltungen (MD „Stand 2025, ohne Gewähr") — 32 Blöcke vs. 74 contacts**

- ~31/32 namentlich abgedeckt; **aber**: Straße, PLZ, Telefon, Fax, Web passen **nicht ins Datenmodell** (`channel` = 1 Feld) ⚠️ *verändert das Datenmodell*
- Dubletten: Kurverwaltung Putbus **×3** (`K22`, `K23`, `K70`) · ruegen.de/Verband **×4** (`K01`, `K02`, `K33`, `K65`)
- `K09` Middelhagen: Kanal „(nicht genannt)" — MD liefert Telefonnummer
- `K57` „S. Schönke (privat)" = MD „Zimmervermittlung Rügen, Neuenkirchen" (identische Mail `sschoenke@t-online.de`)
- **6 Kontakte ohne Koordinaten**

**Geo/Verifikation**

- `GEO_STATUS`: 24 × „offen", 10 × „Allgemeinwissen – verifizieren", 46 × „Bundesland aus Ortsname – verifizieren", 1 dokumentierter KI-Fehler („Ort aus Quelle (44045); KI-Text sagt fälschlich 'Saarland'")
- **44 Events ohne Datumseintrag**; 8 Datumszeilen nicht parsebar
- Namens-Dubletten (**generische Namen → nicht blind deduplizieren!**): `M04+M06+M24+M27+M47` „Mittelaltermarkt" · `M11+M13` „Ritterfest" · `M14+M19+M22` „Burgfest" · `M16+M29+M41` „Fantasy- & Mittelaltermarkt" · `M28+M33` „Mittelalterfest" · `M42+M43` „Phantastisches Zauberdorf"
- `QUELLE_TYP`: Flyer 71 · Chat 80 · Chat (KI-Liste) 47 · Sündenfrei 6 · Nutzer/Tourplanung 2

**Bilder sind NICHT nur Flyer** *(vom Auftraggeber korrigiert, per OCR verifiziert ✅)*

| Typ | Erkennungsmerkmal | Umfang |
|---|---|---|
| Echte Veranstaltungsflyer | sauberes Layout, OCR lesbar | ~F01–F19, 10 × „OCR ohne Auffälligkeiten" |
| **Gig-Anzeigen-Screenshots** (backstagepro-Muster: „Performance / Anbieter / PLZ / Datum") | Muster im OCR-Rohtext | **F39–F72** (Hauptblock) |
| Instagram-/Post-Screenshots | „Gefällt … und weiteren Personen" | u. a. F20 |
| Zeitungsartikel-Screenshot | otz.de (Marcus Cislak) | 1 |
| **Prüfbedarf** | „Anbieter unleserlich" 10 ×, „bitte prüfen" (Jahr als 2016 gelesen?, Schreibweisen, PLZ unleserlich) | ~15 Bilder |

Zusätzlich liegen Gagen-/Bewerbungsinfos auch in **Text** vor: `chat_items` = 91 × E-Mail, 20 × URL, 16 × URL-Textlink, 16 × Text, 2 × Telefon, 2 × Hashtag, 2 × Foto-Caption (nur 4 mit FOTO-Feld).

**Logo**

- `logo-spp.pdf` enthält **keine Vektoren**, sondern ein eingebettetes FlateDecode-Rasterbild
- **Verlustfrei extrahiert: 1080 × 1090 px, RGB, dominanter Ton `#f8f8f8` (weißer Grund)** → PNG möglich ✅
- ASCII-Preview zeigt eine detaillierte Illustration (Figur/Emblem), kein flaches Typo-Logo → **Auto-Tracing zu SVG = Qualitätsverlust + Riesendatei. Empfehlung: PNG, nicht SVG.**
- Werkzeug-Lage: ImageMagick-PDF durch Security-Policy **gesperrt**; `sharp` ist nur **innerhalb des Projektverzeichnisses** verfügbar (in `/tmp` nicht auflösbar)

---

## 4. Technisches Risiko (blockierend für jeden Import)

> 🔴 `src/lib/spp7-repository.ts` spiegelt `events`, `contacts`, `chat` **bei jedem Serverstart** per `onConflictDoUpdate` aus dem JSON in die DB — **überschreibt dabei vorhandene Werte**.

**Konsequenz:** Manuelle Korrekturen in diesen 3 Tabellen wären beim nächsten Neustart verloren. Kuratierte Daten **müssen in eigene Tabellen**.
Zusätzlich zweigleisig: das Dashboard lädt `/data/spp7-datasets.json` und `/data/spp7-chat.json` **clientseitig direkt** — die DB liefert nur die Zähler im Kopf des Dashboards.

---

## 5. Entschieden ✅

| # | Thema | Entscheidung |
|---|---|---|
| 1 | Vorgehen in Einzelschritten mit ja/nein | ✅ vereinbart |
| 2 | Bilder = Flyer **und** Screenshots **und** Bewerbungen mit Gagen-Infos | ✅ bestätigt (vom Auftraggeber, per OCR verifiziert) |
| 3 | Logo als **PNG**, nicht SVG (PDF enthält nur ein Rasterbild) | ✅ bestätigt |
| 4 | Trennung **Original-Archiv** (unantastbar) ↔ **kuratierte Arbeitsebene** (DB) | ✅ bestätigt |
| 5 | Arbeitsordner heißt **`werkstatt/`** und liegt dauerhaft im Projekt (**nicht** `/tmp`, nicht `public/`) | ✅ bestätigt |
| 6 | Ablauf: **erst Abgleich → dann Entscheidung → dann Datenbank** | ✅ bestätigt |
| 7 | `**` in der Termin-Datei bedeutet **dasselbe wie `*`** = unbestätigt | ✅ vom Auftraggeber geklärt |
| 8 | „1.–4. Advent" wird **nach Kirchenregel in echte Daten umgerechnet** | ✅ entschieden (Werte siehe `werkstatt/01-roh/QUELLEN.md`) |
| 9 | Adressblöcke mit zwei Namen → **eine** Zeile mit Hauptname + Zusatzname | ✅ entschieden |
| 10 | **Normierungs-Grundsatz:** Originalschreibweise bleibt in eigener Spalte erhalten, normiert wird nur zusätzlich | ✅ entschieden |

## 6. Offen — **auf Antwort wartend, nichts umgesetzt**

| # | Frage | Warum wichtig | Blockiert |
|---|---|---|---|
| **E3** | Sündenfrei-Termine als **eigene Tabelle** (statt Merge in die 206 Bestands-Events), mit Zuordnung zu `M21`/`M44` — ja/nein? | Verhindert Vermischung geprüfter mit KI-recherchierten Daten | Stufe 5 |
| **E4** | **Kontakte-Datenmodell erweitern**: Straße, PLZ, Telefon, Fax, Web als eigene Felder statt **einem** Sammelfeld `channel` — ja/nein? | ⚠️ *verändert das Datenmodell*; ohne das passt die MD-Quelle nicht hinein | Stufe 5 |
| **E5** | Rohdaten später aus dem **öffentlichen** `public/`-Ordner herausziehen (Datenschutz) — ja/nein? | 91 E-Mails, Telefonnummern, Klarnamen sind derzeit über das Internet abrufbar | Stufe 6 |
| **F1** | Termine **2026 Jan–Sept.** fehlen in der TXT — Absicht (Restliste ab Stand 22.09.) oder kommt eine vollständige Liste? | Bestimmt, ob 2026 als Lücke markiert oder ergänzt wird | Stufe 2 |
| **F2** | Zip-Name nennt **„180 maps"**, gefunden wurden 158 Bilder — fehlen Karten-Screenshots? | Ggf. weitere tote Bildlinks | Stufe 4 |
| **F3** | Dubletten-Entscheidungen (`K22/K23/K70`, `K01/K02/K33/K65`, `K57`) | Kein Auto-Merge vereinbart | kommt **automatisch** als Liste in Stufe 4 |

> **E3/E4 blockieren Stufe 2 NICHT** — die Normierung in CSV-Dateien funktioniert unabhängig davon.
> Beide Fragen müssen erst vor dem Datenbank-Import (Stufe 5) beantwortet sein.

### Kernargument zum Ablauf (nicht vergessen)

**„Erst importieren, wenn alles sauber ist" funktioniert bei diesen Quellen nicht** — die guten Quellen sind *bewusst* unvollständig:
14 Zeilen mit `*`/`**` („wahrscheinlich, jedoch noch unbestätigt"), 2 echte Platzhalter (`xxxxx`, „noch offen"), MD mit „alle Angaben ohne Gewähr", Bestandsdaten mit 10 × „Allgemeinwissen – verifizieren".
→ Deshalb **Status-/Herkunftsfeld statt Warten**: auch Unvollständiges darf hinein, aber **immer erkennbar markiert** — und **niemals erfunden**.

---

## 7. Pipeline — 6 Stufen

| Stufe | Inhalt | Datenbank? | Status |
|---|---|---|---|
| **1 — Quellen sichern** | `werkstatt/` anlegen · alle 5 Originale unverändert ablegen · Prüfsummen · Herkunftsprotokoll | ❌ nein | ✅ **erledigt** (2026-10-01) |
| **2 — Normieren** | MD → `kurverwaltungen.csv` (32 Zeilen) · TXT → `suendenfrei-termine.csv` (54 Zeilen) · Datum als ISO, E-Mail klein, Original bleibt erhalten | ❌ nein | ⏳ **wartet auf Freigabe** |
| **3 — Abgleich** | saubere Quellen ↔ App-Daten vergleichen: Dubletten, Widersprüche, Lücken, Überhang → lesbarer Bericht | ❌ nein | ⏳ |
| **4 — Entscheidungen** | Auftraggeber geht den Bericht Punkt für Punkt durch (nummeriert, einfaches ja/nein) | ❌ nein | ⏳ |
| **5 — Import** | **erst jetzt** in die Datenbank — in **neue, eigene Tabellen**, jede Zeile mit Herkunft + Status | ✅ ja | ⏳ E3/E4 |
| **6 — App** | Baseline einspielen · 79 Bilder verkabeln · Logo-PNG · Kennzeichen „verifiziert/unbestätigt/offen" · Datenschutz (E5) | ✅ liest DB | ⏳ |

**Grundregel Stufe 6 (Bilder):** nur tote Links reparieren — **keine Umbenennung, keine Neubewertung, keine Kuration**.

---

## 8. Wiederaufnahme

1. Dieses Dokument lesen (es ist die einzige Wahrheit über den Fortschritt).
2. **Quellen sind gesichert** — kein Neu-Download nötig. Prüfen mit:
   `cd werkstatt/01-roh && sha256sum -c PRUEFSUMMEN.sha256` → muss 5 × „OK" ergeben.
3. Offene Punkte aus §6 klären (**E3, E4, E5, F1, F2** — F3 kommt automatisch in Stufe 4).
4. Freigabe für **Stufe 2** einholen, dann normieren.

*Bis zur jeweiligen Freigabe gilt: keine Code-, Schema- oder Datenänderung.*
