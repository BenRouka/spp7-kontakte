/* ------------------------------------------------------------------ */
/* C2 — Event-Radar. Geometrie 1:1 aus dem Alt-System (viewBox 460×330,*/
/* Gitter, Projektionsformel), Farb-/Schriftsprache nativ Werkstatt.   */
/* Deutschland-Umriss: reale OSM-Geometrie (src/lib/germany-path.ts),  */
/* NICHT mehr die 26-Punkte-Stylisierung des Alt-Systems.              */
/* Altbestand-Punkte werden nicht mehr dargestellt (nicht benötigt).   */
/* ------------------------------------------------------------------ */

import { GERMANY_PATH } from "@/lib/germany-path";

export interface RadarDot {
  id: number;
  x: number;
  y: number;
  klasse: "sf2027" | "rest" | "korridor";
  korridorStatus?: "datiert" | "vorgemerkt";
  titel: string;
}

export interface RadarLabel {
  x: number;
  y: number;
  text: string;
  anchor: "start" | "end";
}

/* Gitter exakt wie im Alt-System. */
const GRID_H = [55, 110, 165, 220, 275];
const GRID_V = [77, 154, 231, 308, 385];

export function KarteRadar({
  dots,
  korridorLinie,
  labels,
}: {
  dots: RadarDot[];
  korridorLinie: Array<{ x: number; y: number }>;
  labels: RadarLabel[];
}) {
  return (
    <svg
      viewBox="0 0 460 330"
      role="img"
      aria-label="Karte der Terminorte in Deutschland"
      className="block h-auto w-full"
    >
      <defs>
        <filter id="radar-glow" x="-80%" y="-80%" width="260%" height="260%">
          <feGaussianBlur stdDeviation="3.6" result="blur" />
          <feMerge>
            <feMergeNode in="blur" />
            <feMergeNode in="SourceGraphic" />
          </feMerge>
        </filter>
        <filter id="umriss-sheen" x="-20%" y="-20%" width="140%" height="140%">
          <feGaussianBlur stdDeviation="5" />
        </filter>
        <radialGradient id="land-fill" cx="50%" cy="30%" r="90%">
          <stop offset="0%" stopColor="#161d12" />
          <stop offset="100%" stopColor="#0f130c" />
        </radialGradient>
      </defs>

      {/* Gitter — Alt-Maße */}
      <g stroke="var(--color-line-soft)" strokeWidth="0.6">
        {GRID_H.map((y) => (
          <line key={`h${y}`} x1="0" y1={y} x2="460" y2={y} />
        ))}
        {GRID_V.map((x) => (
          <line key={`v${x}`} x1={x} y1="0" x2={x} y2="330" />
        ))}
      </g>

      {/* Deutschland — reale Geometrie, dreilagig gerendert */}
      <path d={GERMANY_PATH} fill="url(#land-fill)" />
      <path
        d={GERMANY_PATH}
        fill="none"
        stroke="rgba(185, 227, 60, 0.16)"
        strokeWidth="6"
        filter="url(#umriss-sheen)"
      />
      <path
        d={GERMANY_PATH}
        fill="none"
        stroke="var(--color-line)"
        strokeWidth="1.1"
        strokeLinejoin="round"
      />
      <path
        d={GERMANY_PATH}
        fill="none"
        stroke="rgba(196, 207, 179, 0.28)"
        strokeWidth="0.45"
        strokeLinejoin="round"
      />

      {/* Tour-Korridor — Alt-System hatte keine Linie, nur Ringe;        */}
      {/* die Linie hier ist eine neue, dezente Ergänzung der Werkstatt.  */}
      {korridorLinie.length > 1 ? (
        <polyline
          points={korridorLinie.map((p) => `${p.x},${p.y}`).join(" ")}
          fill="none"
          stroke="var(--color-lime)"
          strokeOpacity="0.4"
          strokeWidth="1.1"
          strokeDasharray="2 5"
          strokeLinecap="round"
        />
      ) : null}

      {/* Punkte */}
      {dots.map((d) => {
        if (d.klasse === "rest") {
          return (
            <g key={d.id}>
              <circle
                cx={d.x}
                cy={d.y}
                r="2.6"
                fill="var(--color-muted)"
                opacity="0.75"
              />
              <title>{d.titel}</title>
            </g>
          );
        }
        const vorgemerkt = d.korridorStatus === "vorgemerkt";
        return (
          <g key={d.id}>
            {d.klasse === "korridor" ? (
              <circle
                cx={d.x}
                cy={d.y}
                r="8.6"
                fill="none"
                stroke="var(--color-lime)"
                strokeWidth="1.1"
                strokeDasharray={vorgemerkt ? "2.5 3" : undefined}
                opacity={vorgemerkt ? 0.75 : 1}
              />
            ) : null}
            <circle
              cx={d.x}
              cy={d.y}
              r={d.klasse === "korridor" ? 5.2 : 4}
              fill={
                d.klasse === "korridor" && vorgemerkt
                  ? "var(--color-raised2)"
                  : "var(--color-amber)"
              }
              stroke={
                d.klasse === "korridor" && vorgemerkt
                  ? "var(--color-lime)"
                  : undefined
              }
              strokeWidth={
                d.klasse === "korridor" && vorgemerkt ? 1.2 : undefined
              }
              filter="url(#radar-glow)"
            />
            <title>{d.titel}</title>
          </g>
        );
      })}

      {/* Stations-Labels */}
      {labels.map((l) => (
        <text
          key={l.text}
          x={l.x}
          y={l.y}
          textAnchor={l.anchor}
          className="radar-label"
        >
          {l.text}
        </text>
      ))}
    </svg>
  );
}
