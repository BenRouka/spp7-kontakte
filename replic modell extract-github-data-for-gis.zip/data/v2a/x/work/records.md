# SPP7 – Rohextrakt Flyer (Telegram-Export „Locations zum abtippen", 2026-09-14)
Quelle pro Datensatz: Chat-Export, Foto-Nr. n = `photo_n@14-09-2026…jpg` (Original, Thumb verworfen).
Hinweis: Instagram-/Facebook-Overlays überdecken teils Text – solche Stellen sind mit `?` markiert.

---

## flyer_01
- **Typ:** Festival (Meta-Festival: Nerdrock/Metal + Gaming-Convention)
- **Name:** NEXUS Festival
- **Veranstalter/Account:** Instagram `nerdrockfestival`
- **DATUM1:** 18.–20.09.2026 | **Kommentar:** Haupttermin, 3 Tage
- **DATUM2:** – | **Kommentar:** „NEXUS IS BACK!!" → Vorjahr/Vorauflage existierte, Re-Start
- **Location:** Agra Messepark Leipzig
- **Ort:** Leipzig (Sachsen)
- **Website:** (nicht lesbar, nur IG-Account)
- **Social:** IG @nerdrockfestival
- **Headliner:** Stand Atlantic – „First Leipzig Festival Show Ever – Live from Australia"
- **Special Guest:** Coldmirror
- **Bands:** Stand Atlantic; Smash Into Pieces; Dead by April; As December Falls; Within Destruction; Our Mirage; Elwood Stray; MittelAltA; Grainknights; Enemy Inside; Kontrollverlust; Coldmirror; ?10s Evolves; ?Axlrose; ?Anthrax?; ?Dying Victim?; ?Gang; Impulse; Flore; Vogelsang; ?Rollanz?; Dekas Tanz?; Agabe; Infield Masters; Simon will us UBUHI?; The New Asura; Cosplay Champions; Quest Live Band
- **Konzept-Zonen:** Nerdgaming Convention, Gaming & Indie Area, Artist Area, Mittelalter Markt, Merch Area, Cosplay Area, Food Area, Workshops, Wasteland Area, Karaoke, Creator & Streamer
- **Tags:** #Metal #Nerdrock #Gaming #Cosplay #MittelalterMarkt #Indie #OpenAir+Halle
- **Kurzbeschreibung:** NEXUS Festival – dreitägiges Nerdrock-/Metal-Festival plus Gaming- & Nerd-Convention auf der Agra Messepark Leipzig (18.–20.09.2026), Headliner Stand Atlantic.
- **Langbeschreibung:** Bewirbt sich als „das weltweit erste" Nerd-Rock-Festival. Kombination aus Konzert-Line-Up (Metal/Post-Hardcore/Indie bis Mittelalter-Rock) und Convention-Programm mit Gaming-, Indie-, Cosplay-, Creator- und Mittelalter-Markt-Flächen sowie Wasteland-Area, Workshops und Karaoke. Als Facebook-Anzeige gesichtet (399 Kommentare, 57 Shares), Reichweite also vorhanden. Für SPP7 interessant wegen Mittelalter-Markt-Fläche und Indie-/Nerd-Schiene – zwei sehr unterschiedliche Bühnen/ Publikumsschichten.
- **Passung SPP7:** mittel–hoch (Mittelalter-/Markt-Bühne + offene Indie-Fläche)
- **Unklar:** Line-Up-Teile durch IG-Overlay verdeckt; Ticketpreise, Bühnenzahl, Kontaktdaten, Bewerbungsschluss fehlen im Screenshot.
