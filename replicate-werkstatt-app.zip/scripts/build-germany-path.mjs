/* ------------------------------------------------------------------ */
/* Generator — präziser Deutschland-Umriss für den Event-Radar.        */
/*                                                                    */
/* Hintergrund: Der Alt-Radar nutzte eine 26-Punkte-Stylisierung.      */
/* Dieser Generator baut den Umriss aus realer OSM-Geometrie          */
/* (isellsoap/deutschlandGeoJSON, „hoch"), vereinfacht ihn per        */
/* Douglas-Peucker und projiziert mit EXAKT der Alt-Formel, damit      */
/* Umriss und Punkte im selben Koordinatensystem liegen:              */
/*   x = 105 + (LNG - 5) / 11 * 250                                   */
/*   y = 300 - (LAT - 47) / 8.5 * 270   (viewBox 460 × 330)           */
/* Ausgabe: src/lib/germany-path.ts (eingefroren, im Repo).            */
/* Ausführung: node scripts/build-germany-path.mjs [epsilonGrad]       */
/* ------------------------------------------------------------------ */

import { writeFileSync } from "node:fs";

const EPSILON = Number(process.argv[2] ?? 0.012); // Grad, ~1 km Richtwert
const SOURCES = [
  "https://raw.githubusercontent.com/isellsoap/deutschlandGeoJSON/main/1_deutschland/2_hoch.geo.json",
  "https://raw.githubusercontent.com/isellsoap/deutschlandGeoJSON/main/1_deutschland/3_mittel.geo.json",
];

const projX = (lng) => 105 + ((lng - 5) / 11) * 250;
const projY = (lat) => 300 - ((lat - 47) / 8.5) * 270;

function distToSegment(p, a, b) {
  const dx = b[0] - a[0];
  const dy = b[1] - a[1];
  const len2 = dx * dx + dy * dy;
  if (len2 === 0) return Math.hypot(p[0] - a[0], p[1] - a[1]);
  let t = ((p[0] - a[0]) * dx + (p[1] - a[1]) * dy) / len2;
  t = Math.max(0, Math.min(1, t));
  return Math.hypot(p[0] - (a[0] + t * dx), p[1] - (a[1] + t * dy));
}

function douglasPeucker(points, epsilon) {
  if (points.length < 3) return points;
  const first = points[0];
  const last = points[points.length - 1];
  let maxDist = 0;
  let index = 0;
  for (let i = 1; i < points.length - 1; i++) {
    const d = distToSegment(points[i], first, last);
    if (d > maxDist) {
      maxDist = d;
      index = i;
    }
  }
  if (maxDist <= epsilon) return [first, last];
  const left = douglasPeucker(points.slice(0, index + 1), epsilon);
  const right = douglasPeucker(points.slice(index), epsilon);
  return left.slice(0, -1).concat(right);
}

const fmt = (n) => {
  const v = Math.round(n * 10) / 10;
  return Number.isInteger(v) ? String(v) : v.toFixed(1);
};

async function loadGeoJson() {
  const errors = [];
  for (const url of SOURCES) {
    try {
      const res = await fetch(url, {
        headers: { "user-agent": "spp7-werkstatt-path-generator/1.0" },
      });
      if (!res.ok) throw new Error(`HTTP ${res.status}`);
      console.log(`Quelle: ${url}`);
      return { json: await res.json(), url };
    } catch (err) {
      errors.push(`${url}: ${err.message}`);
    }
  }
  throw new Error("Keine Quelle erreichbar:\n" + errors.join("\n"));
}

const { json: geo, url } = await loadGeoJson();
const feature =
  geo.type === "FeatureCollection" ? geo.features[0] : geo;

const polygons =
  feature.geometry.type === "Polygon"
    ? [feature.geometry.coordinates]
    : feature.geometry.coordinates; // MultiPolygon

let pointCountIn = 0;
let pointCountOut = 0;
const parts = [];

for (const polygon of polygons) {
  const outer = polygon[0].map(([lng, lat]) => [lng, lat]);
  pointCountIn += outer.length;
  const simplified = douglasPeucker(outer, EPSILON);
  pointCountOut += simplified.length;
  const d = simplified
    .map(([lng, lat], i) => `${i === 0 ? "M" : "L"}${fmt(projX(lng))} ${fmt(projY(lat))}`)
    .join("");
  parts.push(d + "Z");
}

const pathData = parts.join("");

const out = `/* ------------------------------------------------------------------ */
/* GENERIERT — nicht von Hand editieren.                               */
/* Quelle: ${url}        */
/* OSM-Geometrie, Douglas-Peucker ε=${EPSILON}°, Punkte ${pointCountIn} → ${pointCountOut}. */
/* Projektion = Alt-Formel: x=105+(LNG-5)/11*250 · y=300-(LAT-47)/8.5*270 */
/* Erzeugt: ${new Date().toISOString()} via scripts/build-germany-path.mjs */
/* ------------------------------------------------------------------ */
export const GERMANY_PATH = "${pathData}";
`;

writeFileSync(new URL("../src/lib/germany-path.ts", import.meta.url), out);
console.log(
  `Punkte: ${pointCountIn} → ${pointCountOut} (ε=${EPSILON}°) · Pfadlänge: ${pathData.length} Zeichen`,
);
console.log("geschrieben → src/lib/germany-path.ts");
