# SPP7 · FREEZE-06 — Region / Ort / Einrichtung / Ortsteil

**Aktueller Einstieg bei Wiederaufnahme.** Die Arbeitsebene ist nach der Strukturpräzisierung eingefroren. FREEZE-01…05 bleiben unverändert als historische Dokumente erhalten.

## Freigegebener Umfang

- Geografische Gliederung wie im aktuellen Nutzerbeispiel: Region → Ort → Einrichtung.
- „Kurverwaltung Mönchgut / Tourist-Information Middelhagen“ bleibt ein vollständiger Adressblock unter Ostseebad Mönchgut; Thiessow ein eigener Geschwistereintrag.
- Vorherige zusätzliche KV33-Adresse aufgehoben: aktuell 32 Einrichtungen aus 32 MD-Blöcken.
- Regions-/Ortsknoten separat: 9 Regions-/Gruppenüberschriften und 24 Ortsüberschriften; Strukturdatei zusammen mit Einrichtungen 65 Knoten.
- Ortsteil-Spalte aus explizitem „OT“: Middelhagen, Thiessow, Grubnow. Andere Ortsteile werden nicht vermutet.
- Aktuelles Nutzerbeispiel ergänzt ausdrücklich Website/E-Mail für den Baabe-Infopavillon. Roh-MD-Felder bleiben fehlend; Ergänzung und Herkunft stehen daneben. Kein automatisches Kopieren vom Parent.
- Frühere Ergänzungen für Middelhagen und Thiessow bleiben erhalten, soweit nicht ausdrücklich widerrufen.
- Fehlwerte exakt `" - "` einschließlich je eines Leerzeichens; durch CSV-Schreiben, API und Anzeige erhalten.

## Modellgrenze

`parent_id` der Einrichtungszeile bezeichnet den **geografischen Ortsknoten**. Die organisatorische Außenstellen-Zuordnung ist ein separates `organisations_parent_id`; bei Thiessow: KV12. Gliederungsnummern folgen der Reihenfolge der MD, keine amtlichen Kennziffern.

Das ist eine Änderung des CSV-/Prüfmodells, **keine** Datenbank-Schemaänderung. Rohdateien, Zeitmodell und Option-B-Paket bleiben unverändert; kein Import. Der A/B-Gleichstand betrifft weiterhin das Zeitmodell, nicht die neue Kontakt-Prüfansicht.

## Neue/aktualisierte Dateien

- `src/lib/contact-model.ts`: reine, testbare Gliederungs-/Kontaktnormierung.
- `src/lib/normalization-csv.ts`: Fehlmarker mit Leerzeichen und CSV-Schreiben.
- `scripts/normalize-sources.mjs`: reproduzierbare Erzeugung; `--verify` ist lesend.
- `scripts/check-contact-structure.mjs`: unabhängiger Test von Baum, Ortsteilen, CSV-Roundtrip und fehlender automatischer Vererbung.
- `werkstatt/02-normiert/`: CSVs, `kontakte-struktur.json`, `kontaktstruktur.md`, explizite `nutzer-ergaenzungen.json`, `LIESMICH.md`, Prüfsummen.
- Option A: lesender Reiter **Normierung → Kontaktstruktur** mit Filter, Suche, Quellanzeige und Downloads.
- `GET /api/review/contacts`: allowlist-basierte Prüfung/Ausgabe, keine DB-Schreibfunktion.

## Historie / offene Fragen

FREEZE-05 enthält den früheren 33-Zeilen-Entwurf und die frühere fehlende Pavillon-E-Mail. Diese Aussagen sind nach dem neuen Nutzerbeispiel überholt; sie bleiben historisch erhalten und sind **nicht** der aktuelle CSV-Vertrag.

Weiter offen: P4 (Schreibweisen in Namen), P7 (erste MD-Gliederung), F3 (Dubletten), E3/E4 (späteres Datenbankschema), E5 (Datenschutz). Stufe 3 und Import nicht begonnen. Ortsteil aus Ortsnamen oder Schrägstrich abzuleiten ist nicht freigegeben.

## Wiederaufnahme

1. Dieses Dokument und `werkstatt/02-normiert/LIESMICH.md` lesen.
2. Aktuellen Zustand prüfen: `sha256sum -c docs/FREEZE-06.sha256`.
3. `node scripts/normalize-sources.mjs --verify` und `node scripts/check-contact-structure.mjs`.
4. `node scripts/check-time-model.mjs` sowie Rohquellen-Prüfsummen.
5. Nächsten Schritt abstimmen. Bis dahin keine weiteren CSV-, Daten-, Layout- oder Schemaänderungen.

Prüfergebnisse: `docs/FREEZE-06-pruefprotokoll.txt`. `.env` und Build-Artefakte werden nicht in die Freeze-Prüfsummenliste aufgenommen.
