"""Read-only extraction of structured signals from the original chat export.
Does not touch the app database, public dataset, or UI. Output only."""
import json, re, unicodedata
from collections import Counter

CHAT = '/tmp/spp7-extra/export/ChatExport_2026-09-20/result.json'
OUT = '/tmp/audit/chat_signals.json'

def text_of(m):
    t = m.get('text')
    if isinstance(t, str):
        return t
    if isinstance(t, list):
        return ''.join(p if isinstance(p, str) else p.get('text', '') for p in t)
    return ''

EMAIL_RE = re.compile(r'[a-zA-Z0-9._%+\-]+@[a-zA-Z0-9.\-]+\.[a-zA-Z]{2,}')
PHONE_RE = re.compile(r'(?:\+49|0)[\d\s()\-/]{6,}\d')
URL_RE = re.compile(r'https?://[^\s)\]}>]+')
MONEY_RE = re.compile(r'\d{1,4}\s?(?:€|EUR|Euro)|(?:€|EUR)\s?\d{1,4}', re.I)
KEYWORDS = {
    'gage': re.compile(r'gage|honorar', re.I),
    'kosten': re.compile(r'kostenbeitrag|buy-?in|fixbetrag|teilnahmegeb', re.I),
    'bewerbung': re.compile(r'bewerb', re.I),
    'slots': re.compile(r'freie slots|slot', re.I),
    'frist': re.compile(r'frist|deadline|bis (?:zum |einschl)', re.I),
}

data = json.load(open(CHAT, encoding='utf-8'))
messages = data['messages']

rows = []
for m in messages:
    if m.get('type') != 'message':
        continue
    tx = text_of(m).strip()
    emails = EMAIL_RE.findall(tx)
    phones = PHONE_RE.findall(tx)
    urls = URL_RE.findall(tx)
    money = MONEY_RE.findall(tx)
    kw = {k: bool(p.search(tx)) for k, p in KEYWORDS.items()}
    if tx or m.get('photo'):
        rows.append({
            'msg': m['id'],
            'date': m.get('date', ''),
            'from': m.get('from', ''),
            'has_photo': bool(m.get('photo')),
            'photo': m.get('photo', ''),
            'text': tx,
            'emails': emails,
            'phones': phones,
            'urls': urls,
            'money_mentions': money,
            'keywords': kw,
        })

all_emails = sorted({e.lower() for r in rows for e in r['emails']})
all_phones = sorted({re.sub(r'\s+', ' ', p).strip() for r in rows for p in r['phones']})
all_urls = sorted({u.rstrip('.,)') for r in rows for u in r['urls']})
kw_counts = Counter()
for r in rows:
    for k, v in r['keywords'].items():
        if v:
            kw_counts[k] += 1

report = {
    'messages_total': len(messages),
    'messages_with_text': sum(1 for r in rows if r['text']),
    'messages_with_photo': sum(1 for r in rows if r['has_photo']),
    'unique_emails': all_emails,
    'unique_phones': all_phones,
    'unique_urls': all_urls,
    'keyword_message_counts': dict(kw_counts),
    'rows': rows,
}
import os
os.makedirs('/tmp/audit', exist_ok=True)
json.dump(report, open(OUT, 'w', encoding='utf-8'), ensure_ascii=False, indent=1)
print('messages_total', report['messages_total'])
print('messages_with_text', report['messages_with_text'])
print('messages_with_photo', report['messages_with_photo'])
print('unique_emails', len(all_emails))
print('unique_phones', len(all_phones))
print('unique_urls', len(all_urls))
print('keyword_message_counts', dict(kw_counts))
