import { getTermineAnzeige, getTerminJahresStats } from "@/lib/data";
import {
  TermineBrowser,
  type TerminJahrDto,
} from "@/components/termine-browser";
import { Badge, Eyebrow } from "@/components/ui";

export const dynamic = "force-dynamic";

export default async function TerminePage() {
  const stats = await getTerminJahresStats();
  const jahre: TerminJahrDto[] = [];
  for (const s of stats) {
    const { gruppen } = await getTermineAnzeige(s.jahr);
    jahre.push({ ...s, gruppen });
  }

  const gesamtFenster = jahre.reduce((s, j) => s + j.zeitfenster, 0);
  const gesamtZeilen = jahre.reduce((s, j) => s + j.quellzeilen, 0);

  return (
    <div className="space-y-8">
      <section className="rise pt-4">
        <Eyebrow>Termine · Sündenfrei 2026 / 2027 · aus der Datenbank</Eyebrow>
        <div className="mt-4 flex flex-wrap items-end justify-between gap-6">
          <h1 className="font-display max-w-3xl text-[clamp(2.2rem,5vw,3.8rem)] font-medium leading-[1.02] tracking-tight text-ink">
            {gesamtZeilen} Quellzeilen,{" "}
            <span className="text-lime">{gesamtFenster} Zeitfenster</span> —
            vollständig übernommen.
          </h1>
          <div className="flex flex-wrap gap-2 pb-1">
            <Badge tone="lime">B-09 · Vollständige Übernahme</Badge>
            <Badge tone="amber">* / ** = unbestätigt (B-11)</Badge>
          </div>
        </div>
        <p className="mt-4 max-w-2xl text-[14px] leading-relaxed text-ink-soft">
          Die offizielle Liste wird 1:1 geführt: Quellzeilen und Zeitfenster
          werden immer als getrennte Zahlen ausgewiesen (B-12). Der
          Herne-Advent bleibt eine Quellzeile mit vier Fenstern (B-10) — die
          Unterzeilen sind sichtbar, verändern aber das Datenmodell nicht.
          Der Altbestand der App kannte nur 14 dieser 54 Termine; das ist ein
          Befund über den Altbestand, keine Lücke in dieser Liste.
        </p>
      </section>

      <TermineBrowser jahre={jahre} />
    </div>
  );
}
