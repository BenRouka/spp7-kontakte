// The spaces are part of the missing-value marker, never trim this value.
export const NORMALIZED_MISSING_VALUE = " - ";

export function normalizedCsvCell(value: string | number | null | undefined): string {
  const text = value == null || value === "" || value === "-" ? NORMALIZED_MISSING_VALUE : String(value);
  const telephone = /^\+49 \d+ \d+$/.test(text);
  const missing = text === NORMALIZED_MISSING_VALUE;
  // Preserve generated +49 numbers and the exact spaced marker. Protect other formula-like text.
  const safe = !telephone && !missing && /^[=+@-]/.test(text.trimStart()) ? `'${text}` : text;
  return `"${safe.replaceAll('"', '""')}"`;
}

export function normalizedCsvFile(headers: readonly string[], rows: ReadonlyArray<ReadonlyArray<string | number>>): string {
  for (const row of rows) {
    if (row.length !== headers.length || row.some((cell) => cell == null)) {
      throw new Error("CSV-Spaltenzahl oder Feldbelegung stimmt nicht.");
    }
  }
  return "\uFEFF" + [headers, ...rows].map((row) => row.map(normalizedCsvCell).join(";")).join("\r\n") + "\r\n";
}
