import { Workshop } from "@/components/workshop";
import { getReviewData } from "@/lib/review-repository";

export const dynamic = "force-dynamic";
export default async function ComparisonPage() {
  const data = await getReviewData(2027);
  return <Workshop initialData={data} initialView="comparison" />;
}
