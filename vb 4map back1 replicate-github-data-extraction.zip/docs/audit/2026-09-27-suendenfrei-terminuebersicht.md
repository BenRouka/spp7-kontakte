# SPP7 Audit-Zusatz — Sündenfrei Terminübersicht

**Datum:** 27.09.2026  
**Art:** Rein lesend. Keine Events, Kontakte oder UI geändert.  
**Quelle:** https://www.suendenfrei.tv/terminuebersicht  
**Rohdaten:** `docs/audit/suendenfrei_2026_2027.json`

## Korrektur zum vorherigen Abruf

Der erste Seitenabruf hat nur die Blöcke ab 2025 geliefert. In der Roh-HTML stehen zusätzlich:

- **Termine 2027 (Stand 22. September 2026)** — 46 Termine, davon 11 mit `*`
- **Termine 2026 (Stand 23. Juni 2026)** — 43 Termine, davon 5 mit `*`

`*` laut Quelle: „Termin oder Ort wahrscheinlich, jedoch noch unbestätigt“.  
Zwei 2027-Zeilen haben statt eines Orts nur `xxxxx` / `xxxx` (3.–4. April „noch offen“; 28.–29. August „Burgfest*“).

Dein Screenshot (Rauhnächte, 18. Leipziger Umschlag, Burgfrühling Wertheim) stimmt mit den ersten drei 2027-Zeilen der Roh-HTML überein.

## 2027 — vollständige Liste (Quelle, nicht unser Datensatz)

| Datum | Name | Ort |
|---|---|---|
| 2.–6. Januar 2027 | Rauhnächte | 01067 Dresden / Stallhof |
| 6.–7. März 2027 | 18. Leipziger Umschlag | 04107 Leipzig / agra Messepark Halle 1 |
| 13.–14. März 2027 | Mittelalterfest Burgfrühling | 97877 Wertheim / Burg |
| 20.–21. März 2027 | Ritterturnier und Mittelaltermarkt | 01683 Altzella / Nossen |
| 27.–29. März 2027 | Oster-Ritterturnier | 56346 Loreley / St. Goarshausen |
| 27.–29. März 2027 | Ritter und Drachen-Spektakel | 99448 Kranichfeld / Niederburg |
| 27.–29. März 2027 | Oster-Ritterturnier | 44286 Dorsten / Schloss Lembeck |
| 3.–4. April 2027 | noch offen | xxxxx |
| 10.–11. April 2027 | Die Wikinger kommen! | 07929 Saalburg / Bleilochtalsperre |
| 10.–11. April 2027 | Turnierspiele | 96178 Schloss Weissenstein / Pommersfelden |
| 17.–18. April 2027 | Mittelalterspektakel | 04519 Rackwitz, Schladitzer Bucht |
| 17.–18. April 2027 | Mittelalterspektakel | 41844 Wegberg / Schloss Tüschenbroich |
| 24.–25. April 2027 | Mittelalterfest Löwenburg | 34131 Kassel |
| 24.–25. April 2027 | Mittelaltermarkt | 90513 Zirndorf b. Nürnberg |
| 30. April – 2. Mai 2027 | Ritterturnier & Walpurgisnacht | 06632 Freyburg / Neuenburg |
| 1.–2. Mai 2027 | Ritterturnier Schloss Lauersfort | 47447 Moers |
| 6.–9. Mai 2027 | 23. Siegfriedspektakel | 46509 Xanten |
| 6.–9. Mai 2027 | Mittelalter-Burgfest | 06543 Burg Falkenstein / Harz |
| 15.–17. Mai 2027 | Wikingerfest | 99885 Weißensee / Thür. |
| 15.–17. Mai 2027 | Ritterturnier & Mittelalterspektakel | 85399 Hallbergmoos |
| 22.–23. Mai 2027 | Mittelalterspektakel | 58455 Witten / Kemnader See |
| 27.–30. Mai 2027* | Gaudium Schloss Horst* | 45899 Gelsenkirchen* |
| 29.–30. Mai 2027 | Mittelalterspektakel | 02829 Königshain |
| 5.–6. Juni 2027 | Mittelalterspektakel | 34346 Hann. Münden |
| 11.–13. Juni 2027 | Annamarkt und Stadtfest | 52349 Düren |
| 2.–4. Juli 2027* | Kiliani-Altstadtfest | 91438 Bad Windsheim |
| 16.–18. Juli 2027 | Mittelalterspektakel | 23999 Insel Poel |
| 22.–25. Juli 2027 | Wallensteintage | 18439 Stralsund / Alter Markt |
| 14.–15. August 2027 | Fantasy- und Mittelalterfest | 01833 Stolpen (Burg) |
| 28.–29. August 2027 | Burgfest* | xxxx |
| 3.–5. September 2027 | 20. Mittelalterspektakel | 44629 Herne / Schloss Strünkede |
| 11.–12. September 2027 | Mittelalterfest* | 99707 Kyffhäuser* |
| 18.–19. September 2027 | Die Wikinger kommen! | 46509 Xanten |
| 18.–19. September 2027 | Ritterturnier und Mittelalterspektakel | 93186 Adlersberg / Pettendorf |
| 24.–26. September 2027* | Zwiebelmarkt Apolda | 99510 Apolda |
| 25.–26. September 2027 | 56. Heidelberger Herbst | 69120 Heidelberg |
| 2.–3. Oktober 2027 | Mittelalter & Fantasytage mit Drachen | 56346 Loreley / St. Goarshausen |
| 2.–3. Oktober 2027 | Thüringer Ritterturnier | 99448 Kranichfeld |
| 8.–10. Oktober 2027 | 374. Zwiebelmarkt | 99423 Weimar |
| 9.–10. Oktober 2027* | 30. Burgfest | 06543 Burg Falkenstein / Harz |
| 16.–17. Oktober 2027* | 6. Mittelalter-Markttage | 44575 Castrop-Rauxel |
| 1.–4. Advent 2027* | Mittelalter-Advent (Fr.–So.) | 44629 Herne / Schloss Strünkede |
| 24.11.–23.12.2027* | Mittelalter-Weihnacht | 01067 Dresden / Stallhof |
| 25.11.–30.12.2027* | Felsenkeller-Weihnachtsmarkt | 04229 Leipzig / Plagwitz |
| 26.11.–23.12.2027** | Kloster-Weihnacht | 09111 Chemnitz |
| 27.–30. Dezember 2027 | Rauhnächte | 01067 Dresden / Stallhof |

## Abgleich mit dem Live-Datensatz (nur gelesen)

Bereits als Event vorhanden (Name+Ort, andere Quelle):

- Kranichfeld „Ritter und Drachen-Spektakel“ → M44 (KI-Liste)
- Freyburg Ritterturnier → M21 (KI-Liste)
- Göhren existiert als T06 **Neptunfest**, nicht als Strandkorbsilvester (2026-Liste)

Nicht als eigenes Event gefunden, obwohl in 2026/2027 genannt: Rauhnächte Dresden, Leipziger Umschlag, Wallensteintage Stralsund, Siegfriedspektakel Xanten, Loreley, Herne/Strünkede, Altzella, Wertheim.

Sündenfrei ist im Datensatz **keine** bisherige Quelle.

## Was das für die nächste Übernahme heißt

- Quelle ist eine **öffentliche Veranstalter-Tourliste**, keine Bewerbungsplattform. Es gibt darin keine Gage, keine Slots, keine E-Mail.
- 2026-Stand ist älter (23.06.2026) als 2027-Stand (22.09.2026).
- Übernahme später nur als Staging-Kandidaten: Quelle = `suendenfrei.tv`, Jahr getrennt, `*` als unbestätigt, leere Orte nicht raten.
- Nicht mit den 79 Chat-Bildern vermischen.

Live-Daten, Datenbank und UI wurden in diesem Schritt nicht verändert.
