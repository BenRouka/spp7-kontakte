"use client";

/* ------------------------------------------------------------------ */
/* C3 — Geo-Herkunftsnachweis mit Prüf-Workflow (O-11).                 */
/* Jede Koordinate zeigt Quelle, Genauigkeit und Status; „geprüft“     */
/* kann je Eintrag gesetzt und zurückgenommen werden. Optimistic UI,   */
/* Server ist führend (Rollback + Refresh bei Fehler).                  */
/* ------------------------------------------------------------------ */

import { useState } from "react";
import { useRouter } from "next/navigation";
import clsx from "clsx";
import { Check, Loader2, ShieldCheck, Undo2 } from "lucide-react";
import type { Pruefstatus } from "@/lib/geo";
import { PRUEFSTATUS_LABEL } from "@/lib/geo";

export interface NachweisZeile {
  id: number;
  plz: string | null;
  ort: string;
  label: string;
  art: string;
  lat: number | null;
  lng: number | null;
  quelle: string;
  genauigkeit: string | null;
  pruefstatus: Pruefstatus;
  geocodiertAm: string;
  geprueftAm: string | null;
}

function fmtZeit(iso: string | null): string {
  if (!iso) return "—";
  const d = new Date(iso);
  return `${d.toLocaleDateString("de-DE")} ${String(d.getHours()).padStart(2, "0")}:${String(d.getMinutes()).padStart(2, "0")}`;
}

function StatusPill({ status }: { status: Pruefstatus }) {
  const stile: Record<Pruefstatus, string> = {
    geprueft: "border-lime/40 bg-lime/10 text-lime",
    ungeprueft: "border-line bg-raised2/70 text-ink-soft",
    pruefen: "border-amber/45 bg-amber/10 text-amber",
  };
  return (
    <span
      className={clsx(
        "inline-flex items-center gap-1 rounded-full border px-2 py-0.5 font-mono text-[10px] font-medium uppercase tracking-[0.1em]",
        stile[status],
      )}
    >
      {status === "geprueft" ? <Check className="h-3 w-3" /> : null}
      {PRUEFSTATUS_LABEL[status]}
    </span>
  );
}

function ToggleButton({
  zeile,
  onToggle,
  pending,
}: {
  zeile: NachweisZeile;
  onToggle: (z: NachweisZeile) => void;
  pending: boolean;
}) {
  const geprueft = zeile.pruefstatus === "geprueft";
  return (
    <button
      type="button"
      onClick={() => onToggle(zeile)}
      disabled={pending}
      aria-pressed={geprueft}
      className={clsx(
        "inline-flex items-center gap-1.5 rounded-full border px-2.5 py-1 font-mono text-[10px] font-medium uppercase tracking-[0.08em] transition-colors disabled:cursor-wait disabled:opacity-60",
        geprueft
          ? "border-line text-muted hover:border-red/50 hover:text-red"
          : "border-lime/35 bg-lime/10 text-lime hover:bg-lime/20",
      )}
    >
      {pending ? (
        <Loader2 className="h-3 w-3 animate-spin" />
      ) : geprueft ? (
        <Undo2 className="h-3 w-3" />
      ) : (
        <ShieldCheck className="h-3 w-3" />
      )}
      {geprueft ? "Prüfung aufheben" : "Als geprüft markieren"}
    </button>
  );
}

export function GeoNachweis({ zeilen }: { zeilen: NachweisZeile[] }) {
  const router = useRouter();
  const [pendingId, setPendingId] = useState<number | null>(null);
  const [fehler, setFehler] = useState<string | null>(null);

  async function toggle(zeile: NachweisZeile) {
    setPendingId(zeile.id);
    setFehler(null);
    const ziel =
      zeile.pruefstatus === "geprueft" ? "ungeprueft" : "geprueft";
    try {
      const res = await fetch(`/api/geo/${zeile.id}/status`, {
        method: "POST",
        headers: { "content-type": "application/json" },
        body: JSON.stringify({ status: ziel }),
      });
      if (!res.ok) {
        const j = (await res.json().catch(() => null)) as {
          error?: string;
        } | null;
        throw new Error(j?.error ?? `HTTP ${res.status}`);
      }
      router.refresh();
    } catch (err) {
      setFehler(
        `Konnte Status für „${zeile.label}“ nicht schreiben: ${String(err instanceof Error ? err.message : err)}`,
      );
    } finally {
      setPendingId(null);
    }
  }

  return (
    <div>
      {fehler ? (
        <p className="mb-3 rounded-lg border border-red/40 bg-red/10 px-3 py-2 text-[12px] text-red">
          {fehler}
        </p>
      ) : null}
      <div className="overflow-x-auto">
        <table className="w-full min-w-[760px] border-collapse text-left">
          <thead>
            <tr className="border-b border-line font-mono text-[10px] uppercase tracking-[0.14em] text-muted">
              <th className="py-2 pr-3 font-medium">Ort</th>
              <th className="py-2 pr-3 font-medium">PLZ</th>
              <th className="py-2 pr-3 font-medium">Koordinaten</th>
              <th className="py-2 pr-3 font-medium">Quelle</th>
              <th className="py-2 pr-3 font-medium">Genauigkeit</th>
              <th className="py-2 pr-3 font-medium">Geocodiert</th>
              <th className="py-2 pr-3 font-medium">Status</th>
              <th className="py-2 font-medium">Aktion</th>
            </tr>
          </thead>
          <tbody>
            {zeilen.map((z) => (
              <tr
                key={z.id}
                className="border-b border-line-soft align-middle last:border-0"
              >
                <td className="py-2.5 pr-3">
                  <span className="text-[13px] font-medium text-ink">
                    {z.label}
                  </span>
                  {z.art === "korridor-vormerkung" ? (
                    <span className="ml-2 font-mono text-[9px] uppercase tracking-[0.1em] text-lime/80">
                      Korridor
                    </span>
                  ) : null}
                </td>
                <td className="tnum py-2.5 pr-3 font-mono text-[12px] text-ink-soft">
                  {z.plz ?? "—"}
                </td>
                <td className="tnum py-2.5 pr-3 font-mono text-[11.5px] text-muted">
                  {z.lat !== null && z.lng !== null
                    ? `${z.lat.toFixed(4)}, ${z.lng.toFixed(4)}`
                    : "—"}
                </td>
                <td className="py-2.5 pr-3 font-mono text-[11px] uppercase text-muted">
                  {z.quelle}
                </td>
                <td className="py-2.5 pr-3">
                  <span
                    className={clsx(
                      "font-mono text-[11px]",
                      z.genauigkeit === "postcode"
                        ? "text-amber"
                        : "text-ink-soft",
                    )}
                  >
                    {z.genauigkeit ?? "—"}
                  </span>
                </td>
                <td className="tnum py-2.5 pr-3 font-mono text-[11px] text-muted">
                  {fmtZeit(z.geocodiertAm)}
                </td>
                <td className="py-2.5 pr-3">
                  <StatusPill status={z.pruefstatus} />
                  {z.pruefstatus === "geprueft" && z.geprueftAm ? (
                    <span className="tnum mt-1 block font-mono text-[10px] text-muted">
                      {fmtZeit(z.geprueftAm)}
                    </span>
                  ) : null}
                </td>
                <td className="py-2.5">
                  <ToggleButton
                    zeile={z}
                    onToggle={toggle}
                    pending={pendingId === z.id}
                  />
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
