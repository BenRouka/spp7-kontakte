import Link from "next/link";
import { ArrowLeft } from "lucide-react";
import { Badge, Card, Empty, SectionHead } from "@/components/ui";
import { getFlyerListe } from "@/lib/altbestand";

export const dynamic = "force-dynamic";

export default async function FlyerPage() {
  const flyer = await getFlyerListe();
  const mitEvent = flyer.filter((f) => f.eventId).length;
  const mitOcr = flyer.filter((f) => f.ocr).length;

  return (
    <div className="space-y-8">
      <Link
        href="/archiv"
        className="inline-flex items-center gap-1.5 font-mono text-[11px] uppercase tracking-[0.14em] text-muted transition-colors hover:text-lime"
      >
        <ArrowLeft className="h-3.5 w-3.5" /> Archiv
      </Link>

      <SectionHead
        eyebrow="Altbestand · Bildquellen"
        title={
          <>
            Flyer, Screens & Bewerbungsmaterial
            <span className="block text-[14px] font-normal leading-snug text-muted">
              {flyer.length} Bildquellen · {mitEvent} einem Event zugeordnet ·{" "}
              {mitOcr} mit OCR-Text. Original per Klick. B-17: nur intern.
            </span>
          </>
        }
      />

      <div className="grid grid-cols-2 gap-4 sm:grid-cols-3 lg:grid-cols-5">
        {flyer.map((f) => (
          <Card key={f.flyer} className="overflow-hidden p-0">
            <a href={f.original} target="_blank" rel="noreferrer">
              {/* eslint-disable-next-line @next/next/no-img-element */}
              <img
                src={f.thumb}
                alt={`Flyer ${f.flyer}`}
                className="aspect-[3/4] w-full object-cover transition-opacity hover:opacity-80"
              />
            </a>
            <div className="space-y-1.5 p-3">
              <div className="flex items-center justify-between gap-2">
                <span className="font-mono text-[10px] text-muted">
                  #{f.flyer}
                </span>
                {f.status ? <Badge>{f.status}</Badge> : null}
              </div>
              {f.eventId ? (
                <Link
                  href={`/archiv/${f.eventId}`}
                  className="block truncate text-[12px] text-ink hover:text-lime"
                >
                  {f.eventName}
                </Link>
              ) : (
                <Empty>ohne Event</Empty>
              )}
            </div>
          </Card>
        ))}
      </div>
    </div>
  );
}
