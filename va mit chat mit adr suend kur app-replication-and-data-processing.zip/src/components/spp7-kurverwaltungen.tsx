"use client";

import { Building2, Globe, Mail, MapPin, Phone, Printer, Search, X } from "lucide-react";
import { useMemo } from "react";

type DataRow = Record<string, string>;

const GROUP_ORDER = [
  "Übergreifend",
  "Rund um die Granitz",
  "Halbinsel Mönchgut",
  "Halbinsel Jasmund",
  "Halbinsel Wittow",
  "Nord-West-Rügen",
  "Süd-Rügen",
  "Zentralrügen",
  "Seebad Insel Hiddensee",
];

export function KurverwaltungenView({
  rows,
  search,
  setSearch,
  setSelected,
}: {
  rows: DataRow[];
  search: string;
  setSearch: (value: string) => void;
  setSelected: (value: { dataset: "kurverwaltungen"; row: DataRow }) => void;
}) {
  const query = search.trim().toLocaleLowerCase("de");
  const filtered = useMemo(
    () => rows.filter((row) => !query || Object.values(row).some((value) => value.toLocaleLowerCase("de").includes(query))),
    [rows, query],
  );

  const groups = GROUP_ORDER.map((name) => ({
    name,
    rows: filtered.filter((row) => row.GRUPPE === name),
  })).filter((group) => group.rows.length > 0);

  const withPhone = rows.filter((row) => row.TELEFON).length;

  return (
    <div className="kv-view">
      <section className="view-intro">
        <div>
          <span className="model-badge"><Building2 className="size-4" /> Infostellen · Urlaubsinsel Rügen</span>
          <h2>
            Kurverwaltungen <em>auf Rügen.</em>
          </h2>
          <p>
            {rows.length} Kurverwaltungen, Fremdenverkehrsvereine, Tourismusinformationen und Zimmervermittlungen — regional geordnet, mit Telefon, Fax und Anschrift.
          </p>
        </div>
        <div className="pipeline-total">
          <strong>{rows.length}</strong>
          <span>Einträge · {withPhone} mit<br />Telefonnummer</span>
        </div>
      </section>

      <div className="kv-group-strip" aria-label="Regionen">
        {GROUP_ORDER.map((name) => {
          const count = rows.filter((row) => row.GRUPPE === name).length;
          return count ? <span key={name}><i />{name}<strong>{count}</strong></span> : null;
        })}
      </div>

      <div className="sf-toolbar">
        <label className="table-search">
          <Search className="size-4" />
          <input value={search} onChange={(event) => setSearch(event.target.value)} placeholder="Einrichtung, Ort oder Telefonnummer suchen…" />
          {search && <button onClick={() => setSearch("")} aria-label="Suche löschen"><X className="size-3.5" /></button>}
        </label>
        <span>{filtered.length} von {rows.length}</span>
      </div>

      <div className="kv-groups">
        {groups.map((group) => (
          <section className="kv-group" key={group.name}>
            <header>
              <h3>{group.name}</h3>
              <span>{group.rows.length} {group.rows.length === 1 ? "Eintrag" : "Einträge"}</span>
            </header>
            <div className="kv-grid">
              {group.rows.map((row) => (
                <button key={row.KV_ID} type="button" className="kv-card" onClick={() => setSelected({ dataset: "kurverwaltungen", row })}>
                  <div className="kv-card-head">
                    <strong>{row.NAME}</strong>
                    {row.ORTSBEREICH && row.ORTSBEREICH !== row.GRUPPE && <small>{row.ORTSBEREICH}</small>}
                  </div>
                  {(row.STRASSE || row.ORT) && (
                    <p className="kv-line kv-address"><MapPin className="size-3.5" />{[row.STRASSE, `${row.PLZ} ${row.ORT}`.trim()].filter(Boolean).join(" · ")}</p>
                  )}
                  <p className={`kv-line ${row.TELEFON ? "" : "kv-muted"}`}><Phone className="size-3.5" />{row.TELEFON || "Telefon nicht in der Quelle"}</p>
                  <p className={`kv-line ${row.FAX ? "" : "kv-muted"}`}><Printer className="size-3.5" />Fax: {row.FAX || "—"}</p>
                  <p className={`kv-line ${row.INTERNET ? "" : "kv-muted"}`}><Globe className="size-3.5" />Internet: {row.INTERNET || "nicht in der Quelle angegeben"}</p>
                  <p className={`kv-line ${row.EMAIL ? "" : "kv-muted"}`}><Mail className="size-3.5" />E-Mail: {row.EMAIL || "nicht in der Quelle angegeben"}</p>
                  {row.NOTIZ && <p className="kv-note">{row.NOTIZ}</p>}
                </button>
              ))}
            </div>
          </section>
        ))}
        {!filtered.length && <p className="chat-empty">Kein Eintrag passt zur Suche.</p>}
      </div>

      <p className="kv-footnote">Stand {rows[0]?.STAND || "2025"} · Alle Angaben ohne Gewähr · Internet- und E-Mail-Adressen in der Quelle nicht ausgeschrieben.</p>
    </div>
  );
}
