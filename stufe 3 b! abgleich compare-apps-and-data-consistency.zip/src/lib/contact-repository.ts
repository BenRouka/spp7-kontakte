import "server-only";
import { createHash } from "node:crypto";
import { readFile } from "node:fs/promises";
import path from "node:path";
import { buildContactStructure, CONTACT_MODEL_VERSION, type ContactWorkspace, type ContactSupplements } from "@/lib/contact-model";

const basePath = () => path.join(process.cwd(), "werkstatt", "02-normiert");
export const contactDownloadFiles = [
  "kurverwaltungen.csv", "suendenfrei-termine.csv", "kontaktstruktur.csv", "kontakte-struktur.json",
  "kontaktstruktur.md", "nutzer-ergaenzungen.json", "LIESMICH.md", "PRUEFSUMMEN.sha256",
] as const;
const checkedFiles = ["kurverwaltungen.csv", "suendenfrei-termine.csv", "kontaktstruktur.csv", "kontakte-struktur.json", "kontaktstruktur.md", "nutzer-ergaenzungen.json"];
const sha = (value: Uint8Array) => createHash("sha256").update(value).digest("hex");

// Read only, fixed allowlist: never imports contacts, changes tables, or exposes private chat archives.
export async function getContactWorkspace() {
  const entries = await Promise.all(contactDownloadFiles.map(async (name) => [name, await readFile(path.join(basePath(), name))] as const));
  const files = Object.fromEntries(entries) as Record<typeof contactDownloadFiles[number], Buffer>;
  const checksums = files["PRUEFSUMMEN.sha256"].toString("utf8").trim().split("\n");
  if (checksums.length !== checkedFiles.length) throw new Error("Unvollständige Normierungs-Prüfsummenliste.");
  const found = new Set<string>();
  for (const line of checksums) {
    const match = line.match(/^([a-f0-9]{64})  ([a-z0-9_.-]+)$/);
    if (!match || !checkedFiles.includes(match[2]) || found.has(match[2])) throw new Error("Nicht erlaubter Eintrag in der Prüfsummenliste.");
    const name = match[2] as typeof contactDownloadFiles[number]; found.add(name);
    if (sha(files[name]) !== match[1]) throw new Error("Eine Normierungsdatei entspricht nicht ihrer Prüfsumme.");
  }
  const data = JSON.parse(files["kontakte-struktur.json"].toString("utf8")) as ContactWorkspace;
  const original = await readFile(path.join(process.cwd(), "werkstatt", "01-roh", "Kurverwaltungen_2025.md"));
  const supplements = files["nutzer-ergaenzungen.json"];
  if (data.version !== CONTACT_MODEL_VERSION || sha(original) !== data.source.sha256 || sha(supplements) !== data.source.supplementSha256) {
    throw new Error("Die Strukturdatei gehört nicht zum aktuellen Quellstand.");
  }
  const expected = buildContactStructure(original.toString("utf8"), JSON.parse(supplements.toString("utf8")) as ContactSupplements);
  const { source, ...actual } = data;
  if (JSON.stringify(expected) !== JSON.stringify(actual) || !source.file) throw new Error("Die Kontaktstruktur weicht von der reproduzierbaren Normierung ab.");
  return { data, files };
}
