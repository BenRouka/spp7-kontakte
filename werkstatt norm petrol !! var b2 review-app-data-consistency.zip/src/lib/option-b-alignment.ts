import "server-only";
import { createHash } from "node:crypto";
import { readFile } from "node:fs/promises";
import path from "node:path";
import { strFromU8, strToU8, unzipSync, zipSync } from "fflate";
import { adventCalendarRule, buildCalendarReview, shortRange, timeModelVersion, type CalendarReview, type ReviewedEvent } from "@/lib/calendar-model";
import { calendarReport, confirmation, csvReport, markdownReport } from "@/lib/review-report";
import { originalSchedule } from "@/lib/reference-data";
import type { AlignmentValue, OptionBAlignment } from "@/lib/option-b-contract";

export const originalOptionBPath = "werkstatt/01-roh/option-b-original.zip";
export const updatedOptionBPath = "werkstatt/04-austausch/option-b-zeitmodell-v2.zip";
export const originalOptionBSha256 = "2cc04683a638ba264ff1932ce4ac4f4cba147506da0faacf2242f9dc11c696bd";
export const sharedOptionBFiles = [
  "src/lib/reference-data.ts",
  "src/lib/calendar-model.ts",
  "src/lib/review-report.ts",
  "src/lib/review-repository.ts",
  "src/app/api/review/route.ts",
  "src/app/api/review/export/route.ts",
  "scripts/check-time-model.mjs",
] as const;
const snapshotPath = "werkstatt/03-berichte/zeitmodell-stand.json";
const manifestPath = "werkstatt/03-berichte/option-b-manifest.json";
const reportPath = "werkstatt/03-berichte/zeitmodell-a-b.md";
const originalSourceFiles = [
  "werkstatt/01-roh/Kurverwaltungen_2025.md",
  "werkstatt/01-roh/Termine_2027_suendenfrei.txt",
] as const;
function localFile(file: string) {
  // Statically scoped filesystem roots avoid tracing unrelated project files.
  if (file.split("/").includes("..")) throw new Error("Nicht erlaubter Dateipfad.");
  if (file.startsWith("werkstatt/")) return path.join(process.cwd(), "werkstatt", file.slice(10));
  if (file.startsWith("scripts/")) return path.join(process.cwd(), "scripts", file.slice(8));
  if (file.startsWith("src/lib/")) return path.join(process.cwd(), "src", "lib", file.slice(8));
  if (file.startsWith("src/app/api/")) return path.join(process.cwd(), "src", "app", "api", file.slice(12));
  throw new Error("Datei außerhalb der freigegebenen Abgleichsordner.");
}
export function sha256(data: Uint8Array | string) {
  return createHash("sha256").update(data).digest("hex");
}
function replaceRequired(text: string, search: string, replacement: string) {
  if (!text.includes(search)) throw new Error("Der erwartete historische Dokumentstand ist nicht vorhanden.");
  return text.replace(search, replacement);
}
function alignmentValue(event: ReviewedEvent): AlignmentValue {
  return {
    kind: event.kind, dateOrigin: event.dateOrigin, uncertain: event.source.uncertain,
    weekdayLabel: event.weekdayLabel, originalLine: event.source.originalLine,
    periods: event.periods,
  };
}
export function alignmentMarkdown(reviews = [buildCalendarReview(2026), buildCalendarReview(2027)]) {
  return [
    "# SPP7 · Zeitmodell-Abgleich Option A / Option B", "",
    `Gemeinsamer Stand: **${timeModelVersion}**.`,
    "Freigegebener Umfang: Zeitmodelle und überholte Werkstatt-Angaben angleichen. Option A bleibt die gewählte Arena-Oberfläche.",
    "Das aktualisierte Option-B-Paket ist eine lokale Ableitung des verlinkten Werkstatt-ZIPs. Eine andere Arena-Instanz und GitHub wurden nicht verändert.",
    "", "## Ergebnis", "",
    "| Quelle | Art | Datumsherkunft | Quellstatus |",
    "|---|---|---|---|",
    ...reviews.flatMap((r) => [r.advent, r.christmas].map((event) => `| ${event.source.originalLine.replaceAll("\t", " · ").trim()} | ${event.kind === "weekends" ? "vier getrennte Wochenenden" : "durchgehend; eigenes Datum, nicht Advent"} | ${event.dateOrigin} | ${confirmation(event)} |`)),
    "", "Jeder Herne-Quelltermin bleibt ein Event mit vier zugeordneten Zeitfenstern. Keine Veranstaltungstage zwischen den Wochenenden und keine vier neuen Events.",
    "", ...reviews.flatMap((r) => [
      `## Herne ${r.year} · ${r.advent.weekdayLabel}`, "",
      "| Advent | Beginn ISO | Ende ISO |", "|---|---|---|",
      ...r.advent.periods.map((p) => `| ${p.ordinal}. Advent | ${p.start} | ${p.end} |`),
      "", `Dresden ${r.year}: **${shortRange(r.christmas.periods[0])} ${r.year}**. Ein durchgehender Zeitraum aus der eigenen Quellzeile; keine Adventsberechnung.`, "",
    ]),
    "## Überholte Angaben", "",
    "- Die frühere Zusammenfassung 26.11.–20.12.2026 ist kein durchgehender Herne-Termin.",
    "- Der frühere Herne-Beginn 25.11.2027 ist falsch: Dieser Tag ist Donnerstag. Die Quelle 2027 nennt Fr.–So.; das erste Fenster beginnt am 26.11.2027.",
    "- Die alten Handoff- und QUELLEN-Texte liegen unverändert unter docs/archiv/. Sie sind historisch, nicht maßgeblich für neue Berechnungen.",
    "", "## Kirchenregel – Präzisierung", "",
    adventCalendarRule.fourthSunday, adventCalendarRule.christmasSunday,
    "Der Zusatz „oder der 25.12., wenn er Sonntag ist“ wird deshalb nicht als Kirchenregel übernommen. Für 2026 (Weihnachten Freitag) und 2027 (Weihnachten Samstag) bleiben alle bestätigten Wochenenden gleich.",
    `Beleg: ${adventCalendarRule.sourceUrl}`, "",
    "## Weitere geklärte Regeln", "",
    "- F1: Januar–September 2026 werden nicht nacherfasst; Originalzeilen bleiben erhalten.",
    "- F2: 180 von 206 Events haben LAT und LNG, verteilt auf 149 unterschiedliche Koordinatenpaare. Die Zahl bezeichnet keine Bilder. Vorhanden bedeutet nicht inhaltlich verifiziert.",
    "- * und ** kennzeichnen gleichermaßen unbestätigte Termine oder Orte.",
    "- Originalschreibweisen bleiben erhalten. Eine spätere Normierung wird zusätzlich geführt.",
    "- Ein Adressblock mit zwei Namen bleibt eine Zeile mit Haupt- und Zusatzname.",
    "", "## Grenzen dieser Angleichung", "",
    "- Keine vollständige Normierung der 32 Adressblöcke oder 54 Terminzeilen; Stufe 2 ist nicht abgeschlossen.",
    "- Kein vollständiger Quellen↔App-Abgleich; keine Dublettenentscheidungen.",
    "- Keine Schemaänderung, kein Import, keine Datenbankschreibzugriffe.",
    "- Option B behält seinen bisherigen Starter-Bildschirm. Ergänzt sind ausschließlich die gemeinsame lesende Kalender-/Berichtslogik, API-Endpunkte und korrigierte Werkstatt-Unterlagen.",
    "- Die zwei im ursprünglichen Werkstatt-ZIP vorhandenen MD-/TXT-Quellen bleiben bytegleich. Die drei dort fehlenden Originale (App-ZIP, Chat-ZIP, Logo) wurden nicht stillschweigend ergänzt.",
    "- Das Paket enthält keine .env-Datei, keinen privaten Chat-Export und keine Datenbankexporte.",
    "", "Vorsicht: Beim späteren Import muss ein Quelltermin mehrere Zeitfenster besitzen können. Diese Zuordnung betrifft das Datenmodell und ist hier nicht implementiert.",
    "", `Terminquelle: ${reviews[0].sourceUrl}`, "",
  ].join("\n");
}
function handoffMarkdown() {
  return [
    "# SPP7 · Aktueller Handoff für den Zeitmodell-Abgleich A/B", "",
    `**Maßgeblicher Zeitmodell-Stand: ${timeModelVersion}.**`,
    "Option A bleibt die gewählte Arena-Oberfläche. Die freigegebenen Zeitmodell-Änderungen sind in der lokalen aktualisierten Option-B-Kopie nachgezogen.",
    "GitHub und eine separate Arena-Instanz wurden nicht direkt bearbeitet.", "",
    "## Arbeitsroutinen", "",
    "- Nicht raten, schätzen oder Angaben stillschweigend interpretieren.",
    "- Originaldateien nie verändern. Zusätzlich berechnete oder normierte Angaben gesondert kennzeichnen.",
    "- Keine Schemaänderung oder Datenbankimporte ohne gesonderte Freigabe.",
    "- Nächste Stufen nicht automatisch starten.", "",
    "## Jetzt gültig", "",
    "1. Herne 2026: vier getrennte Do.–So.-Wochenenden; Datum berechnet; in Quelle ohne Sternchen. Ohne Sternchen bedeutet nicht bestätigt.",
    "2. Herne 2027: vier getrennte Fr.–So.-Wochenenden; Datum berechnet; unbestätigt (*).",
    "3. Dresden/Stallhof 2027: durchgehend 24.11.–23.12.2027; eigenes Datum aus Quelle; unbestätigt (*), nicht Advent.",
    "4. Dresden 2026 bleibt unverändert als durchgehender Quellzeitraum 25.11.–23.12.2026 erhalten.",
    "5. Datumsherkunft und Bestätigungsstatus sind unabhängig. Kein automatischer Wechsel auf „verifiziert“.",
    "6. F1 ist geklärt: vergangene Termine Januar–September 2026 nicht nacherfassen.",
    "7. F2 ist geklärt: 180 Event-Einträge mit Koordinaten; 149 verschiedene Koordinatenpaare. Nicht die Bildzahl.",
    "8. * und ** bedeuten unbestätigt. Zwei Namen im Adressblock werden als Haupt-/Zusatzname geführt. Originalschreibweisen bleiben erhalten.", "",
    "## Kirchenregel", "", adventCalendarRule.fourthSunday, adventCalendarRule.christmasSunday,
    `Beleg: ${adventCalendarRule.sourceUrl}`, "",
    "## Dateien und Reproduzierbarkeit", "",
    "- werkstatt/03-berichte/zeitmodell-a-b.md: lesbarer Abgleich samt Korrektur der alten Angaben.",
    "- werkstatt/03-berichte/zeitmodell-stand.json: vier geprüfte Quelltermine mit insgesamt zehn Zeitfenstern; berechnete Herne-Termine getrennt von Dresden.",
    "- werkstatt/03-berichte/zeitfenster-pruefung.csv: die zehn Zeitfenster; kein vollständiger Stufe-2-Import.",
    "- werkstatt/03-berichte/option-b-manifest.json: Änderungen, Dateiprüfsummen und unverändert übernommene Quellen.",
    "- docs/archiv/: unveränderte historische Notizen, ausdrücklich nicht die aktive Berechnungsgrundlage.",
    "- scripts/check-time-model.mjs: Regressionstest für die acht Adventsfenster, Dresden, Quellstatus und Weihnachten am Sonntag.",
    "- /api/review?year=2026 bzw. 2027: gemeinsame lesende Prüfdaten.",
    "- /api/review/export?year=2027&format=md bzw. csv oder ics: gemeinsame Berichtserzeugung.", "",
    "## Tatsächlicher Pipeline-Stand", "",
    "| Stufe | Stand |", "|---|---|",
    "| 1 · Quellen sichern | Im ursprünglichen Option-B-ZIP sind nur zwei der fünf benannten Originale enthalten. Drei weitere sind extern referenziert. Vollständige Ablage nicht nachgewiesen. |",
    "| 2 · Normieren | Zeitmodell geklärt und als Prüfdaten abgebildet; vollständige Normierung der 32 Adressblöcke / 54 Quellzeilen noch nicht durchgeführt. |",
    "| 3 · Abgleich | Nur der A/B-Zeitmodell-Abgleich durchgeführt; vollständiger Quellen↔App-Abgleich steht aus. |",
    "| 4 · Entscheidungen | Zeitmodell, F1/F2 und Erhalt der Originale geklärt; Konflikt-/Dublettenentscheidungen stehen aus. |",
    "| 5 · Import | Nicht begonnen. Kein neues Schema und keine DB-Schreibzugriffe. |",
    "| 6 · App | Option A als Prüfansicht beibehalten; kein Umbau der ursprünglichen Bestands-App. |", "",
    "## Weiterhin offen", "",
    "- E3: Tabellen-/Zuordnungskonzept vor dem späteren Import entscheiden.",
    "- E4: Kontakte-Felder für Straße, PLZ, Telefon, Fax, Website und mehrere Kontaktkanäle entscheiden. Vorsicht: verändert das Datenmodell.",
    "- E5: Datenschutz und Umgang mit den bereits öffentlich liegenden Bestandsdaten entscheiden.",
    "- F3: Kontakt-Dubletten nicht automatisch zusammenführen.", "",
    "werkstatt/ liegt außerhalb von public/ und wird nicht automatisch als statische Datei ausgeliefert. Das ist keine allgemeine Zugriffskontrolle. Das Downloadpaket enthält nur die bereits bereitgestellte Werkstatt und den eng begrenzten Zeitmodell-Abgleich, keinen privaten Chat.", "",
  ].join("\n");
}
function correctedSources(original: string) {
  let text = replaceRequired(original,
    "**Gesichert am:** 2026-10-01 · **Stufe 1 der Pipeline** · Status: abgeschlossen",
    "**Historisches Abrufdatum laut altem Protokoll:** 2026-10-01. Im vorliegenden Option-B-ZIP sind nur MD und TXT enthalten; die vollständige Ablage aller fünf Originale ist nicht belegt.\n\n**Zeitmodell-Nachtrag:** " + timeModelVersion + ". Original-MD/TXT bleiben bytegleich; dieser erklärende Metatext wurde aktualisiert. Der frühere Text ist in docs/archiv/QUELLEN-vor-abgleich.md erhalten.");
  const begin = text.indexOf("### Adventsberechnung (Entscheidung des Auftraggebers)");
  const end = text.indexOf("\n---\n\n## 3.", begin);
  if (begin < 0 || end < begin) throw new Error("Historischer Adventsabschnitt nicht eindeutig gefunden.");
  const reviews = [buildCalendarReview(2026), buildCalendarReview(2027)];
  const replacement = [
    "### Adventsberechnung – korrigierter gemeinsamer Stand A/B", "",
    adventCalendarRule.fourthSunday, adventCalendarRule.christmasSunday,
    `Beleg: ${adventCalendarRule.sourceUrl}`, "",
    "**Je Quelltermin vier getrennte Wochenenden. Kein durchgehender Zeitraum.**", "",
    "| Jahr | Abschnitt | Beginn | Ende | Wochentage | Quellstatus |", "|---|---|---|---|---|---|",
    ...reviews.flatMap((r) => r.advent.periods.map((p) => `| ${r.year} | ${p.ordinal}. Advent | ${p.start} | ${p.end} | ${r.advent.weekdayLabel} | ${confirmation(r.advent)} |`)),
    "", "Datumsherkunft: berechnet. Bestätigungsstatus bleibt unabhängig. Originaltext bleibt vollständig erhalten.",
    "Dresden/Stallhof 2027 ist ein eigener, durchgehender Termin aus der Quelle: 24.11.–23.12.2027*, keine Adventsberechnung.",
    "Die frühere durchgehende Herne-Zusammenfassung sowie der Beginn 25.11.2027 sind überholt. 25.11.2027 ist Donnerstag, nicht Freitag.",
    "", "### F1 – geklärt", "",
    "Für 2026 enthält die Datei neun Termine ab dem 3. Oktober. Januar–September 2026 werden nach Klarstellung des Auftraggebers nicht nacherfasst. Keine Änderung der Originaldatei.", "",
  ].join("\n");
  text = text.slice(0, begin) + replacement + text.slice(end);
  text = replaceRequired(text,
    '- ❓ Der Dateiname nennt **„180 maps"**; im Chat-Export liegen aber nur 158 Bilder → offene Faktenfrage **F2**',
    '- **F2 geklärt:** „180 maps“ entspricht 180 von 206 Event-Einträgen mit LAT und LNG, verteilt auf 149 unterschiedliche Koordinatenpaare. Es ist keine Bilderzahl; die Koordinatenrichtigkeit ist damit nicht bestätigt.');
  text = replaceRequired(text,
    '`werkstatt/` liegt **außerhalb von `public/`** und ist damit **nicht über das Internet abrufbar**. ✅',
    '`werkstatt/` liegt außerhalb von `public/` und wird nicht automatisch als statische Datei ausgeliefert. Das ist keine allgemeine Zugriffskontrolle. Das aktualisierte Paket enthält keinen privaten Chat-Export, keine Zugangsdaten und keine DB-Exporte.');
  text = replaceRequired(text,
    '**Erneut prüfen** (muss „OK" für alle 5 ergeben):',
    '**Im vorliegenden Paket prüfen:** Die aktive PRUEFSUMMEN.sha256 enthält nur die zwei tatsächlich vorhandenen Rohquellen. Die frühere Liste aller fünf externen Referenzen bleibt als PRUEFSUMMEN-referenzen.sha256 erhalten. Drei Originale wurden nicht automatisch ergänzt.');
  return text;
}

export async function createOptionBArtifact() {
  const raw = await readFile(localFile(originalOptionBPath));
  if (sha256(raw) !== originalOptionBSha256) throw new Error("Die Original-Option-B-Prüfsumme stimmt nicht.");
  const original = unzipSync(raw);
  for (const file of Object.keys(original)) {
    if (file.startsWith("/") || file.split("/").includes("..")) throw new Error("Unsicherer Pfad im ursprünglichen Archiv.");
  }
  const entries: Record<string, Uint8Array> = { ...original };
  const rawSchedule = original[originalSourceFiles[1]];
  if (!rawSchedule || strFromU8(rawSchedule).replaceAll("\r\n", "\n") !== originalSchedule) {
    throw new Error("Die A/B-Originalzeilen stimmen nicht vollständig überein.");
  }
  const documents: Record<string, Uint8Array> = {};
  function put(file: string, text: string | Uint8Array) {
    entries[file] = typeof text === "string" ? strToU8(text) : text;
    documents[file] = entries[file];
  }
  for (const file of sharedOptionBFiles) entries[file] = await readFile(localFile(file));
  put("docs/archiv/HANDOFF-vor-abgleich.md", original["docs/HANDOFF.md"]);
  put("docs/archiv/QUELLEN-vor-abgleich.md", original["werkstatt/01-roh/QUELLEN.md"]);
  put("docs/HANDOFF.md", handoffMarkdown());
  put("werkstatt/01-roh/QUELLEN.md", correctedSources(strFromU8(original["werkstatt/01-roh/QUELLEN.md"])));
  put("werkstatt/01-roh/PRUEFSUMMEN-referenzen.sha256", original["werkstatt/01-roh/PRUEFSUMMEN.sha256"]);
  put("werkstatt/01-roh/PRUEFSUMMEN.sha256", originalSourceFiles.map((file) => `${sha256(entries[file])}  ${path.basename(file)}\n`).join(""));
  const reviews = [buildCalendarReview(2026), buildCalendarReview(2027)];
  put(reportPath, alignmentMarkdown(reviews));
  put(snapshotPath, JSON.stringify({ modelVersion: timeModelVersion, scope: "time-model-only", reviews }, null, 2) + "\n");
  const csvs = reviews.map((r) => csvReport(r).replace(/^\uFEFF/, "").split("\r\n"));
  put("werkstatt/03-berichte/zeitfenster-pruefung.csv", "\uFEFF" + [csvs[0][0], ...csvs.flatMap((rows) => rows.slice(1))].join("\r\n") + "\r\n");
  for (const review of reviews) {
    put(`werkstatt/03-berichte/zeitmodell-${review.year}.md`, markdownReport(review));
    // A fixed timestamp keeps the artifact reproducible; it is not an approval date.
    put(`werkstatt/03-berichte/kalendervorschau-${review.year}.ics`, calendarReport(review, new Date("1980-01-01T00:00:00Z")));
  }
  for (const file of originalSourceFiles) documents[file] = entries[file];
  const manifest = {
    modelVersion: timeModelVersion, scope: "time-model-only",
    optionAInterfacePreserved: true, remoteArenaChanged: false, databaseChanged: false,
    originalArchiveSha256: originalOptionBSha256,
    originalSources: originalSourceFiles.map((file) => ({ path: file, sha256: sha256(original[file]), unchanged: sha256(original[file]) === sha256(entries[file]) })),
    sharedFiles: sharedOptionBFiles.map((file) => ({ path: file, sha256: sha256(entries[file]) })),
    files: Object.keys(entries).filter((file) => !file.endsWith("/")).sort().map((file) => ({
      path: file, sha256: sha256(entries[file]),
      change: !original[file] ? "added" : sha256(original[file]) === sha256(entries[file]) ? "unchanged" : "updated",
    })),
  };
  put(manifestPath, JSON.stringify(manifest, null, 2) + "\n");
  const zip = zipSync(entries, { level: 6, mtime: new Date("1980-01-01T00:00:00Z") });
  return { zip, documents };
}

export async function readOptionBArtifact(): Promise<{ zip: Uint8Array; report: string; summary: OptionBAlignment }> {
  const [saved, raw] = await Promise.all([readFile(localFile(updatedOptionBPath)), readFile(localFile(originalOptionBPath))]);
  if (sha256(raw) !== originalOptionBSha256) throw new Error("Das ursprüngliche Option-B-Archiv wurde verändert.");
  const entries = unzipSync(saved);
  const original = unzipSync(raw);
  const manifest = JSON.parse(strFromU8(entries[manifestPath])) as { files: Array<{ path: string; sha256: string }> };
  for (const item of manifest.files) {
    if (!entries[item.path] || sha256(entries[item.path]) !== item.sha256) throw new Error("Dateiprüfsumme im Option-B-Paket stimmt nicht.");
  }
  const snapshot = JSON.parse(strFromU8(entries[snapshotPath])) as { modelVersion: string; reviews: CalendarReview[] };
  if (snapshot.reviews.length !== 2 || !snapshot.reviews.some((r) => r.year === 2026) || !snapshot.reviews.some((r) => r.year === 2027)) throw new Error("Option-B-Prüfdaten sind unvollständig.");
  const checks = ([2026, 2027] as const).flatMap((year) => {
    const optionA = buildCalendarReview(year);
    const optionB = snapshot.reviews.find((r) => r.year === year)!;
    return (["advent", "christmas"] as const).map((kind) => {
      const a = alignmentValue(optionA[kind]), b = alignmentValue(optionB[kind]);
      return { id: a.periods[0].id.replace(/-P\d+$/, ""), year, label: kind === "advent" ? `Herne ${year} · ${a.weekdayLabel}` : `Dresden ${year} · durchgehend`, matches: JSON.stringify(a) === JSON.stringify(b), optionA: a, optionB: b };
    });
  });
  const sharedFiles = await Promise.all(sharedOptionBFiles.map(async (file) => {
    const current = await readFile(localFile(file));
    const optionASha256 = sha256(current), optionBSha256 = sha256(entries[file]);
    return { path: file, matches: optionASha256 === optionBSha256, optionASha256, optionBSha256 };
  }));
  const originalSourcesPreserved = originalSourceFiles.every((file) => sha256(original[file]) === sha256(entries[file]));
  return {
    zip: saved, report: strFromU8(entries[reportPath]),
    summary: {
      modelVersion: snapshot.modelVersion,
      aligned: snapshot.modelVersion === timeModelVersion && checks.every((c) => c.matches) && sharedFiles.every((f) => f.matches) && originalSourcesPreserved,
      remoteArenaChanged: false, optionAInterfacePreserved: true, databaseChanged: false,
      originalSourcesPreserved, originalArchiveSha256: originalOptionBSha256, updatedArchiveSha256: sha256(saved),
      sharedFiles, checks,
      downloads: { zip: "/api/review/option-b?format=zip", report: "/api/review/option-b?format=md" },
    },
  };
}
