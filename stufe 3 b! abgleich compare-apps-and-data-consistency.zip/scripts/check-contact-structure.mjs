#!/usr/bin/env node
import assert from "node:assert/strict";
import { readFileSync } from "node:fs";
import { createHash } from "node:crypto";
import { createRequire } from "node:module";
import ts from "typescript";

const require = createRequire(import.meta.url);
const cache = new Map();
function load(file) {
  const resolved = file.startsWith("@/") ? `src/${file.slice(2)}.ts` : file;
  if (cache.has(resolved)) return cache.get(resolved).exports;
  const module = { exports: {} }; cache.set(resolved, module);
  const output = ts.transpileModule(readFileSync(resolved, "utf8"), {
    compilerOptions: { target: ts.ScriptTarget.ES2022, module: ts.ModuleKind.CommonJS, esModuleInterop: true },
  }).outputText;
  new Function("require", "module", "exports", output)((id) => id.startsWith("@/") ? load(id) : require(id), module, module.exports);
  return module.exports;
}
function csvRows(text) {
  const rows = []; let row = [], cell = "", quoted = false;
  const input = text.replace(/^\uFEFF/, "");
  for (let index = 0; index < input.length; index++) {
    const char = input[index];
    if (quoted) {
      if (char === '"' && input[index + 1] === '"') { cell += '"'; index++; }
      else if (char === '"') quoted = false;
      else cell += char;
    } else if (char === '"') quoted = true;
    else if (char === ";") { row.push(cell); cell = ""; }
    else if (char === "\r" && input[index + 1] === "\n") { row.push(cell); rows.push(row); row = []; cell = ""; index++; }
    else cell += char;
  }
  assert.equal(quoted, false, "Nicht geschlossene CSV-Zelle");
  if (row.length || cell) { row.push(cell); rows.push(row); }
  const headers = rows.shift();
  return { headers, records: rows.map((values) => {
    assert.equal(values.length, headers.length); return Object.fromEntries(headers.map((header, index) => [header, values[index]]));
  }) };
}
const root = "werkstatt/02-normiert/";
const model = load("src/lib/contact-model.ts");
const csv = load("src/lib/normalization-csv.ts");
const md = readFileSync("werkstatt/01-roh/Kurverwaltungen_2025.md", "utf8");
const supplements = JSON.parse(readFileSync(root + "nutzer-ergaenzungen.json", "utf8"));
const snapshot = JSON.parse(readFileSync(root + "kontakte-struktur.json", "utf8"));
const generated = model.buildContactStructure(md, supplements);
const { source, ...stored } = snapshot;
assert.deepEqual(stored, generated);
assert.equal(source.sha256, createHash("sha256").update(md).digest("hex"));
assert.equal(snapshot.missingValue, " - ");
assert.deepEqual(snapshot.counts, { rawBlocks: 32, contacts: 32, regions: 8, groups: 1, places: 22, sourcePlaceHeadings: 24, treeNodes: 63, explicitDistricts: 3, supplementedContacts: 5 });
const contacts = csvRows(readFileSync(root + "kurverwaltungen.csv", "utf8"));
assert.deepEqual(contacts.headers, [...model.contactCsvHeaders]);
assert.deepEqual(contacts.records, snapshot.contacts);
const tree = csvRows(readFileSync(root + "kontaktstruktur.csv", "utf8"));
assert.deepEqual(tree.headers, [...model.contactTreeCsvHeaders]);
assert.deepEqual(tree.records, snapshot.nodes.map((node) => Object.fromEntries(model.contactTreeCsvHeaders.map((key) => [key, node[key]]))));
const by = Object.fromEntries(snapshot.contacts.map((record) => [record.kv_id, record]));
assert.equal(by.KV33, undefined);
assert.equal(by.KV12.name_haupt_original, "Kurverwaltung Mönchgut");
assert.equal(by.KV12.name_zusatz_original, "Tourist-Information Middelhagen");
assert.equal(by.KV12.name_zusatz_normiert, "Tourist-Information Middelhagen");
assert.equal(by.KV12.strasse_original, "Dorfstraße 4");
assert.equal(by.KV13.parent_id, by.KV12.parent_id);
assert.equal(by.KV13.organisations_parent_id, "KV12");
assert.equal(by.KV12.ort_normiert, "Ostseebad Mönchgut");
assert.equal(by.KV12.ortsteil_normiert, "Middelhagen");
assert.equal(by.KV13.ortsteil_normiert, "Thiessow");
assert.equal(by.KV24.ortsteil_normiert, "Grubnow");
assert.equal(by.KV10.web_original, " - "); assert.equal(by.KV10.email_1_original, " - ");
assert.equal(by.KV10.web_normiert, "www.baabe.de"); assert.equal(by.KV10.email_1_normiert, "willkommen@baabe.de");
assert.ok(by.KV10.web_herkunft.includes("x.1.2")); assert.ok(by.KV10.email_1_herkunft.startsWith("nutzerangabe"));
assert.equal(by.KV10.fax_normiert, " - "); assert.equal(by.KV13.fax_normiert, " - ");
assert.equal(by.KV13.telefon_normiert, "+49 38308 66010"); assert.equal(by.KV12.telefon_normiert, "+49 38308 66010");
assert.equal(by.KV12.web_normiert, "www.ostseebad-moenchgut.de"); assert.equal(by.KV12.email_1_normiert, "info@ostseebad-moenchgut.de");
assert.ok(by.KV12.web_herkunft.includes("ja die erste Angabe"));
assert.deepEqual(snapshot.contacts.filter((c) => c.region_original === "Halbinsel Mönchgut").map((c) => c.hierarchie_pfad), ["3.1.1", "3.1.2", "3.1.3", "3.2.1", "3.2.2", "3.3.1", "3.3.2"]);

const group = snapshot.nodes.find((node) => node.id === "REG01");
assert.equal(group.typ, "gruppe"); assert.equal(group.name, "Rügen Übergreifend");
assert.equal(group.name_original, "Kurverwaltungen, Fremdenverkehrsvereine, Tourismusinformationen und Zimmervermittlungen");
assert.deepEqual(group.quellvorkommen.map((s) => [s.id, s.quellzeile]), [["REG01", "5"], ["ORT01", "7"]]);
assert.equal(by.KV01.parent_id, group.id); assert.equal(by.KV01.ort_id, " - ");
assert.equal(by.KV01.region_anzeige, "Rügen Übergreifend"); assert.equal(by.KV01.ort_original, "Übergreifend");
assert.equal(by.KV01.ort_anzeige, " - "); assert.equal(by.KV01.ort_normiert, "Bergen auf Rügen");
assert.equal(by.KV01.strasse_original, "Markt 25");
assert.equal(snapshot.nodes.some((node) => node.typ === "ort" && /Übergreifend/.test(node.name)), false);
const v = snapshot.nodes.filter((node) => node.typ === "ort" && node.name === "Vitte");
assert.equal(v.length, 1); assert.equal(v[0].id, "ORT22");
assert.deepEqual(v[0].quellvorkommen.map((s) => [s.id, s.quellzeile]), [["ORT22", "294"], ["ORT24", "313"]]);
assert.equal(v[0].quellzeile, "294;313"); assert.equal(v[0].quellknoten_ids, "ORT22;ORT24");
assert.equal(by.KV30.parent_id, v[0].id); assert.equal(by.KV32.parent_id, v[0].id);
assert.equal(by.KV30.hierarchie_pfad, "9.1.1"); assert.equal(by.KV32.hierarchie_pfad, "9.1.2");
assert.equal(by.KV31.hierarchie_pfad, "9.2.1"); assert.equal(by.KV31.ort_anzeige, "Kloster");
assert.notEqual(by.KV31.parent_id, v[0].id);
assert.equal(by.KV32.name_haupt_original, "HTS"); assert.equal(by.KV32.name_zusatz_original, " - ");
assert.equal(by.KV32.name_zusatz_ergaenzung, "Hiddensee Touristik & Service");
assert.equal(by.KV32.name_zusatz_normiert, "Hiddensee Touristik & Service");
assert.ok(by.KV32.name_zusatz_herkunft.includes("Auftraggeber"));
assert.equal(by.KV32.organisations_parent_id, " - ", "Keine abgeleitete organisatorische Unterstellung unter Insel Information");
for (const id of ["KV30", "KV31", "KV32"]) assert.equal(by[id].quellblock_id, id);
const regionHiddensee = snapshot.nodes.find((node) => node.name === "Seebad Insel Hiddensee");
assert.deepEqual(snapshot.nodes.filter((node) => node.typ === "ort" && node.parent_id === regionHiddensee.id).map((node) => node.name), ["Vitte", "Kloster"]);
assert.equal(new Set(snapshot.nodes.map((node) => node.id)).size, snapshot.nodes.length);
assert.equal(new Set(snapshot.nodes.map((node) => node.hierarchie_pfad)).size, snapshot.nodes.length);
for (const node of snapshot.nodes) {
  const expectedDepth = node.parent_id === " - " ? 1 : snapshot.nodes.find((p) => p.id === node.parent_id).hierarchie_pfad.split(".").length + 1;
  assert.equal(node.hierarchie_pfad.split(".").length, expectedDepth);
  if (node.parent_id !== " - ") {
    const parent = snapshot.nodes.find((n) => n.id === node.parent_id);
    assert.ok(parent); assert.equal(node.hierarchie_pfad.startsWith(parent.hierarchie_pfad + "."), true);
  }
}
const withoutPavilion = model.buildContactStructure(md, { ...supplements, eintraege: supplements.eintraege.filter((c) => c.kv_id !== "KV10") });
assert.equal(withoutPavilion.contacts.find((c) => c.kv_id === "KV10").web_normiert, " - ");
assert.equal(withoutPavilion.contacts.find((c) => c.kv_id === "KV10").email_1_normiert, " - ");
const withoutHTS = model.buildContactStructure(md, { ...supplements, eintraege: supplements.eintraege.filter((c) => c.kv_id !== "KV32") });
assert.equal(withoutHTS.contacts.find((c) => c.kv_id === "KV32").name_zusatz_normiert, " - ");
const withoutStructureRules = model.buildContactStructure(md, { ...supplements, strukturregeln: [] });
assert.equal(withoutStructureRules.nodes.filter((node) => node.typ === "ort" && node.name === "Vitte").length, 2, "Keine globale Ortszusammenführung");
assert.equal(withoutStructureRules.contacts.find((c) => c.kv_id === "KV01").ort_original, "Übergreifend");
assert.throws(() => model.buildContactStructure(md, { ...supplements, eintraege: [...supplements.eintraege, { ...supplements.eintraege[0], kv_id: "KV99" }] }));
const badRules = structuredClone(supplements);
badRules.strukturregeln[1].quell_ort_ids = ["ORT22", "ORT23"];
assert.throws(() => model.buildContactStructure(md, badRules), "Keine Zusammenführung von Vitte und Kloster");
assert.equal(csv.normalizedCsvCell(" - "), '" - "'); assert.equal(csv.normalizedCsvCell("-"), '" - "');
assert.equal(csv.normalizedCsvCell("+49 38308 66010"), '"+49 38308 66010"');
const schedule = csvRows(readFileSync(root + "suendenfrei-termine.csv", "utf8")).records;
assert.equal(schedule.length, 54); assert.equal(schedule.filter((r) => r.jahr === "2026").length, 9);
assert.equal(schedule.filter((r) => r.jahr === "2027").length, 45);
assert.equal(schedule.reduce((total, r) => total + Number(r.zeitfenster_anzahl), 0), 60);
assert.equal(schedule.find((r) => r.sf_id === "SF17").name_normiert, " - ");
for (const row of [...schedule, ...snapshot.contacts]) {
  assert.ok(Object.values(row).every((value) => value !== "" && value !== "-")); assert.equal(row.status_verifikation, "nicht_verifiziert");
}
console.log("Kontaktstruktur geprüft: 32 Einrichtungen; 8 Regionen + Rügen Übergreifend als Gruppe; 22 Orte; 63 Knoten.");
console.log("Hiddensee: gemeinsamer Vitte-Knoten für Insel Information und HTS, Kloster separat; beide Rohfundstellen erhalten.");
console.log("HTS-Zusatzname als Nutzerangabe; Baabe/Middelhagen bestätigt; keine automatische Vererbung oder Ortszusammenführung.");
console.log('Originalwerte, CSV-Roundtrip und Fehlmarker exakt " - " erhalten; 54 Terminzeilen / 60 Zeitfenster unverändert; keine DB-Zugriffe.');
