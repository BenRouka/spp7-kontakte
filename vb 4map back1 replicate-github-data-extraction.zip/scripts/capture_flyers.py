"""Structured capture of the 50 previously uncaptured flyers (source: ChatExport_2026-09-20).
Every value is transcribed from OCR text of the original image (or the user's screenshot for F51 Anbieter).
Empty = not legible / not present in source. Nothing is inferred."""
import json, re, datetime

DATA = 'public/data/spp7-datasets.json'
REF_DATE = datetime.date(2026, 9, 14)   # date the flyers were posted to the chat (manifest)
REF_LABEL = '14.09.2026'
d = json.load(open(DATA, encoding='utf-8'))
ds = d['datasets']
ocr = json.load(open('/tmp/ocr/result.json'))
manifest = {e['n']: e for e in json.load(open('/tmp/reference-app/work/manifest.json'))}
montage = {}
for line in open('/tmp/reference-app/work/montage_map.txt', encoding='utf-8'):
    m = re.match(r'(m\d+) (\S+) = flyer (.+)', line.strip())
    if m:
        for n in m.group(3).split(','):
            montage[int(n)] = f'{m.group(1)} ({m.group(2)})'

NEW_FIELDS = ['ANBIETER', 'FREIE_SLOTS', 'GESUCHTE_ACTS', 'GENRE', 'GENRE_AUSGESCHLOSSEN', 'KOSTEN',
              'BEWERBER', 'GEPOSTET', 'BEWERBUNG_STATUS', 'BEWERBUNG_STATUS_GRUND', 'GAGE_STATUS', 'ERFASSUNG']
EVENT_KEYS = list(ds['events'][0].keys())
EVENT_KEYS = [k for k in EVENT_KEYS if k not in NEW_FIELDS] + NEW_FIELDS

def iso(dmy):
    try:
        dd, mm, yy = dmy.split('.'); return f'{yy}-{mm}-{dd}'
    except ValueError:
        return ''

def as_date(dmy):
    s = iso(dmy)
    return datetime.date.fromisoformat(s) if s else None

# ---- 35 platform listings: (flyer, title, plz, ort, anbieter, location, von, bis, zeit, termin_note,
#      slots, acts, genre, ausgeschlossen, gage, kosten, bewerber, gepostet, performance, pruefhinweis)
G = [
 (36,"Spielt beim Kieler Bootshafensommer 2026","24103","Kiel","","24103 Kiel","17.07.2026","22.08.2026","18:00","Reihe, 12 Termine","40","Band, Singer/Songwriter, Soloact, DJ, Soundsystem","alle","","Gage verhandelbar","","","","Live-Performance","Anbieter unleserlich"),
 (39,"Songwriter gesucht für Straßenkulturfestival Juli","71729","Erdmannhausen","","Rathausplatz, Erdmannhausen","25.07.2026","","20:00","","4","Singer/Songwriter","alle","Metal, Punk/Hardcore, Hip Hop/Rap, Techno/House/Dance, Electronic, Gothic/Wave","Aufwandspauschale","","247","","Live-Performance","Anbieter unleserlich"),
 (40,"unterGRUND Streamingkonzert 15.05.","10117","Berlin","","ape45 Showroom, Berlin","15.05.2026","","19:30","","1","Band, Singer/Songwriter, Solist (klassisch)","Pop, Rock, Alternative/Independent, Gothic/Wave, Liedermacher/Chanson","Punk/Hardcore, Hip Hop/Rap, Techno/House/Dance, Schlager/Unterhaltung","Keine Gage","Kostenbeitrag (160 €)","","","Performance für Streaming","Anbieter unleserlich; Genre/Ausgeschlossen-Zuordnung und Location-Schreibweise per OCR unsicher"),
 (41,"Live Musik (Cover) in der Bar vom A&O Hostel in Köln","","Köln","","A&O Hostel Köln Neumarkt, Köln","25.04.2026","","20:00","","","Cover-/Tribute-Act, Singer/Songwriter, Soloact","Pop, Rock","","Festgage 150 €","","20","","Live-Performance","Anbieter unleserlich; PLZ unvollständig; Freie Slots nicht sichtbar"),
 (42,"Rootopia Festival Iserlohn 08.08.2026","58644","Iserlohn","Rootopia Festival","Rootopia Festival, Iserlohn","08.08.2026","","16:00","","5","Band","Pop, Rock, Metal, Alternative/Independent, Punk/Hardcore, Funk","Schlager/Unterhaltung","Keine Gage","","","","Live-Performance",""),
 (43,"Typsy Apes Jahresfeier 2026","21079","Hamburg","privater Veranstalter (Name unleserlich)","Am Radeland 25a, 21079 Hamburg","12.09.2026","","16:00","","4","Band","Rock, Metal, Alternative/Independent, Punk/Hardcore, Gothic/Wave","","Aufwandspauschale","","101","25.03.2026","Live-Performance","Titel-Schreibweise per OCR – bitte prüfen"),
 (44,"Stadtpark Open Air Vol.6","09212","Limbach-Oberfrohna","","Stadtpark Open Air, Limbach-Oberfrohna","14.07.2026","","18:00","","2","Band, Singer/Songwriter, Soloact","Pop, Rock, Alternative/Independent, Rock'n'Roll/Rockabilly, Ska/Reggae/Dancehall, Funk","Comedy, Show/Tanz, Schlager/Unterhaltung","Gage verhandelbar","","","","Live-Performance","Anbieter unleserlich"),
 (45,"Open Air auf der Seebühne Kronach","96317","Kronach","BLAUBART","Seebühne, Kronach","25.07.2026","","19:00","","1","Band","Rock","","Benefiz- bzw. nichtkommerzielle Veranstaltung ohne Gage","","","","Live-Performance","Post-Datum unvollständig lesbar"),
 (46,"Die Galerie Zeitzone Berlin-Kreuzberg bietet Konzertmöglichkeit","10997","Berlin","Galerie ZeitZone (privater Veranstalter)","Galerie ZeitZone, Berlin","23.05.2026","","20:00","","3","Band, Singer/Songwriter, Soundsystem","Pop, Rock, Alternative/Independent, Electronic, Ska/Reggae/Dancehall, Gothic/Wave","Schlager/Unterhaltung","Doordeal","","","","Live-Performance",""),
 (47,"Gig Großmehring Basement","85095","Großmehring","Zwoa Capz","Basement Eventbar, Großmehring","07.11.2026","","20:00","","1","Band, Singer/Songwriter, Soloact","alle","Metal, Techno/House/Dance, Electronic","noch nicht bekannt","","","","Live-Performance",""),
 (48,"VOCUZ @ Kultopia Hagen","58095","Hagen","vocuz","Kultopia, Hagen","16.05.2026","","20:00","","1","Band","Rock, Alternative/Independent","","Aufwandspauschale","","","","Live-Performance","Titel-Anfang per OCR unsicher"),
 (49,"Singer & Songwriter Night Oberwesel","55430","Oberwesel","","Kulturhaus, Oberwesel","16.10.2026","","20:00","","3","Singer/Songwriter","Pop, Liedermacher/Chanson","Metal, Alternative/Independent, Punk/Hardcore, Hip Hop/Rap, Electronic","Aufwandspauschale","","","","Live-Performance","Anbieter unleserlich"),
 (50,"Klausdorf Open","24222","Schwentinental","Tim Steffen (privater Veranstalter)","Kinder- und Jugendhaus Klausdorf, Schwentinental","06.06.2026","","06:24","","1","Band","Pop, Rock, Metal, Rock'n'Roll/Rockabilly","","Festgage 300 €","","216","19.03.2026","Live-Performance","Uhrzeit 06:24 wie in Quelle; zusätzlich durch Nutzer-Screenshot bestätigt"),
 (51,"Support Act gesucht – 01.05. im Betty's Black Pearl","28195","Bremen","Losing Gravity","Betty's Black Pearl, Bremen","01.05.2026","","20:00","","1","Band","Rock, Alternative/Independent, Punk/Hardcore, Rock'n'Roll/Rockabilly","","Doordeal","","","","Live-Performance","Anbieter aus Nutzer-Screenshot (OCR unleserlich)"),
 (52,"Marching Act auf dem Schuhmachermarkt","76846","Hauenstein","Kultur Im Dorf (privater Veranstalter)","Hauenstein, Hauenstein","31.05.2026","","14:00","","2","alle","alle","Hip Hop/Rap, Klassik/E-Musik","Festgage 600 €","","","","Live-Performance",""),
 (53,"Steinauvision Songcontest 2026 (nur ein Song)","36396","Steinau an der Straße","Steinauvision Songcontest (privater Veranstalter)","Schwimmbad, Steinau an der Straße","08.08.2026","","19:00","","12","Band, Soloact, Rapper/MC","Pop, Rock, Metal, R'n'B/Soul/Black, Hip Hop/Rap","","Keine Gage","","","","Live-Performance",""),
 (54,"Rock im Freizi","82166","Gräfelfing","","Das Freizi - Jugendhaus an der Würm, Gräfelfing","18.04.2026","","20:00","","1","Band, Soloact","Pop, Rock, Alternative/Independent","","Doordeal","","","","Live-Performance","Anbieter unleserlich"),
 (55,"… Rock und Metal","47137","Duisburg","","Parkhaus Meiderich, Duisburg","06.11.2026","","20:00","","1","Band","Rock, Metal, Alternative/Independent","Hip Hop/Rap, Techno/House/Dance, Ska/Reggae/Dancehall, Klassik/E-Musik, Schlager/Unterhaltung","Doordeal","Fixbetrag bzw. Buy-In (100 €)","45","04.03.2026","Live-Performance","Titel vorn abgeschnitten; Anbieter unleserlich; Ausgeschlossen-Label per OCR unsicher"),
 (56,"Mach Ma Akusitk 2026","59329","Wadersloh","privater Veranstalter (Name unsicher)","Museum Abtei Liesborn, Wadersloh","12.07.2026","","17:00","","3","Band, Singer/Songwriter","Pop, Rock, Alternative/Independent, Rock'n'Roll/Rockabilly, World/Ethno","Punk/Hardcore, Techno/House/Dance, Electronic, Breakbeat/Drum'n'Bass","Aufwandspauschale","","","","Live-Performance","Titel-Schreibweise laut OCR – prüfen; Ausgeschlossen-Label per OCR unsicher"),
 (57,"Punk im Ponyhof","60594","Frankfurt am Main","","Ponyhof, Frankfurt am Main","27.06.2026","","18:00","","3","Band","Rock, Alternative/Independent, Punk/Hardcore","R'n'B/Soul/Black, Hip Hop/Rap, Techno/House/Dance, Electronic","Doordeal","","","","Live-Performance","Anbieter unleserlich"),
 (58,"Konzert im Saarland","66538","Neunkirchen (Saar)","Rafael Goltsche (privater Veranstalter)","Stummsche Reithalle, Neunkirchen (Saar)","24.10.2026","","20:00","","6","Band","Metal, Punk/Hardcore, Gothic/Wave","","Gage verhandelbar","Fixbetrag bzw. Buy-In (225 €)","","26.02.2026","Live-Performance","Titel-Anfang per OCR unsicher"),
 (59,"Schloss Walbeck Biergarten 02.07","47608","Geldern","Lukas Schultes (privater Veranstalter)","Schloss Walbeck, Geldern","02.07.2026","","20:00","","1","Band, Singer/Songwriter","Pop, R'n'B/Soul/Black","Rock, Metal, Alternative/Independent, Punk/Hardcore","Festgage 500 €","","30","20.02.2026","Live-Performance",""),
 (60,"Live Jam Session","71134","Aidlingen","The Barn Aidlingen at Lindenhof Aidlingen","The Barn Aidlingen at Lindenhof, Aidlingen","10.04.2026","12.06.2026","19:00","Reihe, 3 Termine","15","Band, Cover-/Tribute-Act, Singer/Songwriter","Rock, Rock'n'Roll/Rockabilly, R'n'B/Soul/Black, Blues, Folk/Country","","Keine Gage","","","","Live-Performance","Titel-Anfang per OCR unsicher; Chat-Caption #blanketattack"),
 (61,"Rock im Murphy's Law","","Ulm","Tonphobie","Murphy's Law, Ulm","23.10.2026","","20:00","","1","Band, Singer/Songwriter","Rock, Alternative/Independent, Punk/Hardcore, Rock'n'Roll/Rockabilly","Electronic","noch nicht bekannt","","22","","Live-Performance","PLZ unleserlich; Anbieter-Schreibweise unsicher"),
 (62,"Fête de la Musique 2026","17489","Greifswald","radio 98eins e.V.","Soziokulturelles Zentrum St. Spiritus, Greifswald","21.06.2026","","18:00","","2","alle","alle","Metal, Schlager/Unterhaltung","Keine Gage","","47","18.02.2026","Live-Performance",""),
 (63,"Echem Rockt! sucht Bands/Künstler","21379","Echem","","Schützenhaus, Echem","12.09.2026","","20:00","","1","Band, Singer/Songwriter","alle","Techno/House/Dance, Breakbeat/Drum'n'Bass, Gothic/Wave, Klassik/E-Musik","Benefiz- bzw. nichtkommerzielle Veranstaltung ohne Gage","","","","Live-Performance","Anbieter unleserlich; Chat-Caption #blanketattack"),
 (64,"Asylum Metal Madness Vol 3","74321","Bietigheim-Bissingen","","Jugendhaus 4D, Bietigheim-Bissingen","16.05.2026","","17:00","","3","Band","Metal, Punk/Hardcore","","Doordeal","","","","Live-Performance","Anbieter unleserlich"),
 (65,"Band für 21. Waldfest in Truckenthal gesucht","96528","Schalkau","21. Waldfest","21. Waldfest, Schalkau","01.08.2026","","20:00","","1","Band, Singer/Songwriter, Soloact","alle","","Benefiz- bzw. nichtkommerzielle Veranstaltung ohne Gage","","","","Live-Performance",""),
 (66,"Liedermacherabend Mittelhessen 2026","35390","Gießen","","Anschlussverwendung, Gießen","05.06.2026","04.12.2026","19:00","Reihe, 3 Termine","5","Singer/Songwriter, Soloact","Folk/Country, Liedermacher/Chanson","","Aufwandspauschale","","","","Live-Performance","Anbieter unleserlich"),
 (67,"Hermershausen rock! – Festival 21.08.2026 - 23.08.2026","35041","Marburg","","Hermershausen, Marburg","22.08.2026","","10:00","Festival laut Titel 21.–23.08.2026","","Band, Cover-/Tribute-Act","Pop, Rock, Schlager/Unterhaltung","Metal, Punk/Hardcore, Klassik/E-Musik","Spendenkasse","","","","Live-Performance","Titel-Anfang und Anbieter per OCR unsicher; Freie Slots nicht sichtbar"),
 (68,"Punkkonzert in Saarbrücken","66111","Saarbrücken","","Nilles Saarbrooklyn, Saarbrücken","08.05.2026","","19:30","","1","Band","Alternative/Independent, Punk/Hardcore","","Doordeal","","","","Live-Performance","Anbieter unleserlich"),
 (69,"Support Act im Kopf und Kragen gesucht","90762","Fürth","","Kopf und Kragen, Fürth","20.06.2026","","20:00","","1","Band","Pop, Rock, Alternative/Independent, Funk","","Gage verhandelbar","","","","Live-Performance","Anbieter unleserlich"),
 (70,"Sommerfest der Kulturbühne Strohalm e.V.","91052","Erlangen","Kulturbühne Strohalm e.V.","91052 Erlangen","15.08.2026","","21:00","","1","Band, Cover-/Tribute-Act","Pop, Rock, Alternative/Independent","Metal, Hip Hop/Rap, Techno/House/Dance","noch nicht bekannt","","","","Live-Performance",""),
 (71,"Support gesucht für Konzert in Osnabrück Musikbüro","","Osnabrück","","Musikbüro, Osnabrück","06.09.2026","","20:00","","2","Band, Cover-/Tribute-Act","Rock, Metal, Alternative/Independent, Punk/Hardcore","","Doordeal","","20","","Live-Performance","PLZ nicht sichtbar; Anbieter unleserlich"),
 (72,"Fischtival 2026: Das Ankerdeck","33428","Harsewinkel","Florian H.","Fischtival, Harsewinkel","18.07.2026","","20:00","","5","Singer/Songwriter, Soloact, Rapper/MC","Alternative/Independent, Electronic, Comedy, Schlager/Unterhaltung, Liedermacher/Chanson","","Festgage 123 €","","","","Live-Performance",""),
]

# ---- 7 further events from posters / articles
OTHER = [
 dict(n=32, TYP="Auftritt SPP7 (Flyer)", NAME="SPP und die 7 Generäle – Kulturbude Naumburg", LOCATION="Marktplatz", ORT="Naumburg", ANBIETER="Kulturbude Naumburg e.V.", von="13.06.2026", bis="", art="Auftritt", komm="19:00 Uhr", TAGS="SPP7;Auftritt", KURZ="Plakat: KULTURBUDE NAUMBURG e.V. – SPP UND DIE 7 GENERÄLE – 13.06.2026, 19:00 Uhr, Naumburg, Marktplatz.", pruef="Kerndaten per OCR lesbar (Konfidenz niedrig)"),
 dict(n=37, TYP="Festival (Presseartikel)", NAME="Underground Death Fest", LOCATION="Saale-Orla-Kreis", REGION="Thüringen", von="Ende Juni 2026", bis="", art="Festivaltermin", komm="genaues Datum im Artikel-Ausschnitt nicht genannt", TAGS="Metal;Camping", KURZ="OTZ vom 05.04.2026: Die fünfte Ausgabe des Festivals steigt Ende Juni im Saale-Orla-Kreis. Camping, 13 Bands und Bier – ein Wochenende für Metal-Fans.", pruef="Quelle: Screenshot otz.de-Artikel (Marcus Cislak)"),
 dict(n=38, TYP="Festival", NAME="Pirate Fest", EINTRITT="Ticket (www.no-sax.de/pirate-fest/)", von="08.05.2026", bis="09.05.2026", art="Festivaltermin", komm="8.+9. Mai 2026", TAGS="PirateMetal", KURZ="Anzeige: 'Pure, ungefilterte Pirate Metal Energie' – Tickets über www.no-sax.de/pirate-fest/, 8.+9. Mai 2026.", channel=("Website","www.no-sax.de/pirate-fest/"), pruef="Ort im OCR-Text nicht enthalten"),
 dict(n=75, TYP="Auftritt (Ankündigung)", NAME="Live-Auftritt Kuppelhalle Tharandt", LOCATION="Kuppelhalle", ORT="Tharandt", von="22.08.2026", bis="", art="Auftritt", komm="'Wir spielen um 19:00 Uhr'", TAGS="Auftritt", KURZ="Ankündigung: Kuppelhalle Tharandt, Samstag 22.8.2026 – 'Wir spielen um 19:00 Uhr!!!'.", pruef="Auftretender Act im OCR-Text nicht erkennbar"),
 dict(n=76, TYP="Mittelaltermarkt – Mitwirkende gesucht", NAME="Michelaltermarkt anno domini 2026", LOCATION="Zum wilden Michel", PLZ="78120", ORT="Furtwangen", von="04.09.2026", bis="06.09.2026", art="Festivaltermin", komm="", BEWERBUNG="Aufruf an Mitwirkende ('Leben, Klang & Kurzweil') – Meldung an info@maximusmet.de", TAGS="Mittelalter;Markt;Aufruf", KURZ="Aufruf: Der Michelaltermarkt anno domini 2026 sucht Mitwirkende. Wann: 04.–06.09.2026, Wo: Zum wilden Michel, 78120 Furtwangen. Kontakt: info@maximusmet.de", channel=("E-Mail","info@maximusmet.de"), pruef="Schreibweise 'Michelaltermarkt' laut OCR – bitte am Bild prüfen"),
 dict(n=77, TYP="Festival – Booking offen", NAME="Rock am Hinkelhof (RAH) 2027", von="09.07.2027", bis="10.07.2027", art="Festivaltermin", komm="", BEWERBUNG="'Wir starten mit dem Booking für RAH 2027!' – Infos auf www.rockamhinkelhof.de", TAGS="Rock;Festival;Booking", KURZ="Post: Wir starten mit dem Booking für RAH 2027! 09. & 10. Juli 2027. Weitere Infos auf www.rockamhinkelhof.de", channel=("Website","www.rockamhinkelhof.de"), pruef="Langname aus Website-Adresse abgeleitet"),
 dict(n=79, TYP="Festival", NAME="Kulturbrücke Magdeburg", LOCATION="Hubbrücke", ORT="Magdeburg", von="04.09.2026", bis="06.09.2026", art="Festivaltermin", komm="", TAGS="Festival;Magdeburg", KURZ="Plakat: 4.–6. September 2026, Magdeburg / Hubbrücke; umfangreiches Line-up.", pruef="Line-up per OCR nur teilweise lesbar – nicht übernommen; Name aus unvollständigem Website-Schriftzug"),
]

SOURCE_ONLY = {
  8:  ("Duplikat", "F01", "Laut Originalnotiz (r08-09.md) Duplikat von flyer_01 – nur Quellenvermerk"),
  20: ("Duplikat", "F17", "Handle letthebadtimesrollfestival, '476 Bandbewerbungen', Manslagt – identisch mit F17"),
  29: ("Zusatzquelle", "F23", "Timetable des Bülow Straßenmusik Festivals lesbar (13 Programmpunkte) – Übernahme in 'timetable' offen"),
  31: ("Zusatzquelle", "K27", "33. Gößnitz Open Air, Line-up-Post; Jahr per OCR als 2016 gelesen – bitte prüfen"),
  78: ("Zusatzquelle (unsicher)", "F13", "Post 'Open Air Fotos 2026', 14.–15. Mai – OCR schwach, Zuordnung zu F13 bitte bestätigen"),
  19: ("Manuelle Sichtung nötig", "", "OCR unzureichend; Stichwort 'ACKERFEST' (evtl. Bezug F16) – nicht bestätigt"),
  21: ("Manuelle Sichtung nötig", "", "OCR unzureichend; Handle 'walterrafestival' (evtl. Bezug F18) – nicht bestätigt"),
  74: ("Manuelle Sichtung nötig", "", "OCR unzureichend; Fragmente 'Yachthafen', '10.07.', 'ab 19:00 Uhr'"),
}

def msg(n): return str(manifest[n]['msg'])
def src(n): return f"photo_{n} / msg {msg(n)} (OCR {ocr[f'f{n:02d}.jpg']['confidence']} %)"

def status_for(von, bis, explicit=None):
    last = as_date(bis) or as_date(von)
    if explicit == 'geschlossen': return 'geschlossen'
    if last is None: return 'unklar'
    return 'offen' if last >= REF_DATE else 'geschlossen'

def blank_event():
    return {k: '' for k in EVENT_KEYS}

existing_ids = {e['EVENT_ID'] for e in ds['events']}
new_events, new_dates, new_tags, new_channels = [], [], [], []
date_seq = max(int(x['DATE_ID'][1:]) for x in ds['event_dates'])
ch_seq = max(int(re.sub(r'\D', '', x['LINK_ID'])) for x in ds['event_channels'])

def add_date(eid, name, von, bis, art, komm):
    global date_seq
    date_seq += 1
    new_dates.append({'DATE_ID': f'D{date_seq}', 'EVENT_ID': eid, 'EVENT_NAME': name, 'VON': von, 'BIS': bis,
                      'VON_ISO': iso(von), 'BIS_ISO': iso(bis), 'ART': art, 'KOMMENTAR': komm})

for (n,title,plz,ort,anb,loc,von,bis,zeit,tnote,slots,acts,genre,ausg,gage,kosten,bew,gep,perf,pruef) in G:
    eid = f'F{n:02d}'
    if eid in existing_ids: continue
    st = status_for(von, bis)
    e = blank_event()
    e.update({'EVENT_ID': eid, 'QUELLE_TYP': 'Flyer', 'FLYER': f'{n:02d}', 'MSG': msg(n), 'TYP': 'Gesuch (Plattform)',
      'NAME': title, 'LOCATION': loc, 'PLZ': plz, 'ORT': ort, 'LAND': 'DE', 'GEO_STATUS': 'Ort aus Gesuch',
      'GAGE': gage, 'KONDITIONEN': ' · '.join(x for x in [f'Performance: {perf}', tnote] if x),
      'BEWERBUNG': f'Gesuch mit {slots} freien Slot(s)' if slots else 'Gesuch (Slots nicht sichtbar)',
      'TAGS': ';'.join(['Gesuch'] + [g.strip() for g in genre.split(',') if g.strip() and g.strip() != 'alle']),
      'KURZBESCHREIBUNG': f"Gesuch: {acts or '—'} · Genre {genre or '—'} · Gage: {gage or '—'}",
      'QUELLE': src(n), 'ANBIETER': anb, 'FREIE_SLOTS': slots, 'GESUCHTE_ACTS': acts, 'GENRE': genre,
      'GENRE_AUSGESCHLOSSEN': ausg, 'KOSTEN': kosten, 'BEWERBER': bew, 'GEPOSTET': gep,
      'BEWERBUNG_STATUS': st,
      'BEWERBUNG_STATUS_GRUND': (f'Termin nach Quelldatum {REF_LABEL} – Aktualität vor Bewerbung prüfen' if st == 'offen' else f'Termin vor Quelldatum {REF_LABEL}'),
      'GAGE_STATUS': 'unklar' if gage == 'noch nicht bekannt' else 'bestätigt',
      'ERFASSUNG': pruef or 'OCR-Erfassung ohne Auffälligkeiten'})
    new_events.append(e)
    add_date(eid, title, von, bis, 'Termin (Gesuch)', ' · '.join(x for x in [zeit and f'{zeit} Uhr', tnote] if x))
    if gep: add_date(eid, title, gep, '', 'Post-Datum', 'Gesuch gepostet')
    for t in e['TAGS'].split(';'):
        new_tags.append({'EVENT_ID': eid, 'EVENT_NAME': title, 'TAG': t})

for o in OTHER:
    n = o['n']; eid = f'F{n:02d}'
    if eid in existing_ids: continue
    e = blank_event()
    e.update({'EVENT_ID': eid, 'QUELLE_TYP': 'Flyer', 'FLYER': f'{n:02d}', 'MSG': msg(n), 'TYP': o['TYP'], 'NAME': o['NAME'],
      'LOCATION': o.get('LOCATION',''), 'PLZ': o.get('PLZ',''), 'ORT': o.get('ORT',''), 'REGION': o.get('REGION',''), 'LAND': 'DE',
      'GEO_STATUS': 'Ort aus Flyer' if o.get('ORT') else 'offen', 'EINTRITT': o.get('EINTRITT',''), 'BEWERBUNG': o.get('BEWERBUNG',''),
      'TAGS': o['TAGS'], 'KURZBESCHREIBUNG': o['KURZ'], 'QUELLE': src(n), 'ANBIETER': o.get('ANBIETER',''),
      'GAGE_STATUS': 'keine Angabe', 'ERFASSUNG': o['pruef']})
    if o.get('BEWERBUNG'):
        st = status_for(o['von'], o['bis'])
        e['BEWERBUNG_STATUS'] = st
        e['BEWERBUNG_STATUS_GRUND'] = f'Aufruf/Booking laut Quelle; Termin nach Quelldatum {REF_LABEL}' if st == 'offen' else f'Termin vor Quelldatum {REF_LABEL}'
    new_events.append(e)
    add_date(eid, o['NAME'], o['von'], o['bis'], o['art'], o['komm'])
    for t in o['TAGS'].split(';'):
        new_tags.append({'EVENT_ID': eid, 'EVENT_NAME': o['NAME'], 'TAG': t})
    if o.get('channel'):
        ch_seq += 1
        new_channels.append({'LINK_ID': f'EC{ch_seq:02d}', 'EVENT_ID': eid, 'EVENT_NAME': o['NAME'], 'KANAL': o['channel'][0], 'WERT': o['channel'][1]})

# ---- status fields for the 154 existing events (explicit, source-based)
EXISTING_BEWERBUNG = {
  'F03': ('offen', 'Bewerbungsportal bis 01.11.2026 (nach Quelldatum)'),
  'F04': ('unklar', "Aussage 'jetzt möglich', Frist/Weg in abgeschnittener Caption"),
  'F09': ('unklar', "'letzte Bandwelle' angekündigt – Spätbewerbung nur ggf. möglich"),
  'F13': ('offen', 'Bewerbungsphase 01.08.–30.09.2026 (läuft zum Quelldatum)'),
  'F17': ('geschlossen', "Bewerbungsfenster 2027 laut Quelle zu ('476 Bandbewerbungen')"),
  'F35': ('unklar', "Online-Registrierung, 'letzter Newcomer-Slot' – Termin unbekannt"),
}
for e in ds['events']:
    for k in NEW_FIELDS: e.setdefault(k, '')
    if e['EVENT_ID'] in EXISTING_BEWERBUNG:
        e['BEWERBUNG_STATUS'], e['BEWERBUNG_STATUS_GRUND'] = EXISTING_BEWERBUNG[e['EVENT_ID']]
    if e['GAGE'].strip():
        e['GAGE_STATUS'] = 'bestätigt'
    elif re.search(r'gage|honorar', ' '.join([e['UNKLAR'], e['LANGBESCHREIBUNG'], e['PASSUNG_SPP7']]), re.I):
        e['GAGE_STATUS'] = 'unklar'
    else:
        e['GAGE_STATUS'] = 'keine Angabe'
    if e['QUELLE_TYP'] == 'Flyer' and not e['ERFASSUNG']:
        e['ERFASSUNG'] = 'Erfassung aus Originalmodell (replic-Export)'

ds['events'] = [{k: e.get(k, '') for k in EVENT_KEYS} for e in ds['events'] + new_events]
ds['event_dates'] += new_dates
ds['event_tags'] += new_tags
ds['event_channels'] += new_channels

# ---- flyer_sources: one row per flyer (79)
event_by_flyer = {e['FLYER']: e for e in ds['events'] if e['QUELLE_TYP'] == 'Flyer'}
new_ids = {e['EVENT_ID'] for e in new_events}
rows = []
for n in range(1, 80):
    m = manifest[n]; key = f'{n:02d}'; o = ocr.get(f'f{key}.jpg')
    if n in SOURCE_ONLY:
        status, eid, note = SOURCE_ONLY[n]
    elif key in event_by_flyer:
        ev = event_by_flyer[key]; eid = ev['EVENT_ID']
        status = 'neu erfasst' if eid in new_ids else 'erfasst'
        note = ev['ERFASSUNG']
    else:
        status, eid, note = 'offen', '', ''
    target = next((x for x in ds['events'] if x['EVENT_ID'] == eid), None)
    rows.append({'FLYER': key, 'MSG': str(m['msg']), 'DATUM': m['date'][:10], 'MONTAGE': montage.get(n, ''),
                 'FORMAT': m['dim'], 'STATUS': status, 'EVENT_ID': eid, 'EVENT_NAME': target['NAME'] if target else '',
                 'OCR_KONFIDENZ': f"{o['confidence']} %" if o else '', 'HINWEIS': note,
                 'OCR_ROHTEXT': ' '.join(o['text'].split()) if o else ''})
ds['flyer_sources'] = rows
d['meta']['flyersCaptured'] = sum(1 for r in rows if r['STATUS'] in ('erfasst', 'neu erfasst'))
json.dump(d, open(DATA, 'w', encoding='utf-8'), ensure_ascii=False, separators=(',', ':'))

from collections import Counter
print('new events:', len(new_events), '| events total:', len(ds['events']))
print('new dates/tags/channels:', len(new_dates), len(new_tags), len(new_channels))
print('flyer status:', Counter(r['STATUS'] for r in rows))
print('Bewerbung status:', Counter(e['BEWERBUNG_STATUS'] for e in ds['events'] if e['BEWERBUNG_STATUS']))
print('Gage status:', Counter(e['GAGE_STATUS'] for e in ds['events']))
print('open:', [(e['EVENT_ID'], e['NAME']) for e in ds['events'] if e['BEWERBUNG_STATUS'] == 'offen'])
