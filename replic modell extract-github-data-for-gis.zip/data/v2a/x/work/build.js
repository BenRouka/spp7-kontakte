// Baut aus work/model/*.js + Chat-JSON das normalisierte Datenmodell (Parent → Child) und exportiert CSV / XLSX / HTML.
const fs = require('fs'); const path = require('path');
const ExcelJS = require('/app/node_modules/exceljs');
const ROOT = '/app'; const W = path.join(ROOT, 'work');
const F = require('./model/flyers.js'); const C = require('./model/chat.js');
const records = fs.readFileSync(path.join(W, 'records.jsonl'), 'utf8').trim().split('\n').map(JSON.parse);
const recByFlyer = Object.fromEntries(records.map(r => [r.flyer, r]));
const result = JSON.parse(fs.readFileSync(path.join(ROOT, 'data/zip/ChatExport_2026-09-20/result.json'), 'utf8'));
const msgs = result.messages.filter(m => m.type === 'message');
const entities = JSON.parse(fs.readFileSync(path.join(W, 'chat_entities.json'), 'utf8'));

// ───────────────────────── 1) Events zusammenführen ─────────────────────────
const events = [];
for (const e of F.events) {
  const r = recByFlyer[e.flyer] || {};
  events.push({ ...e, kurz: e.kurz || r.kurz || '', lang: e.lang || r.lang || '', passung: e.passung || r.passung || '',
    naechster: e.naechster || r.naechster_schritt || '', unklar: e.unklar || r.unklar || '', quelle: e.quelle || r.quelle || '' });
}
for (const e of C.events) events.push(e);
const dates = [...F.dates, ...C.dates]; const acts = [...F.acts, ...C.acts]; const partners = [...F.partners, ...C.partners];
const features = [...F.features, ...C.features]; const channels = [...F.channels, ...C.channels]; const feed = [...F.feed]; const timetable = [...F.timetable];

// ───────────────────────── 2) KI-Liste (msgs 44016–44018) parsen ─────────────
const MON = { januar:1, februar:2, märz:3, maerz:3, april:4, mai:5, juni:6, juli:7, august:8, september:9, oktober:10, november:11, dezember:12 };
const pad = n => String(n).padStart(2, '0');
const parseDate = s => { // -> {von,bis} | null
  s = s.replace(/\s+/g, ' ').trim();
  let m = s.match(/^(\d{1,2})\.\s*[–-]\s*(\d{1,2})\.\s*([A-Za-zäöü]+)(?:\s+(\d{4}))?$/);
  if (m && MON[m[3].toLowerCase()]) { const y = m[4] || '2026', mo = pad(MON[m[3].toLowerCase()]); return { von: `${pad(m[1])}.${mo}.${y}`, bis: `${pad(m[2])}.${mo}.${y}` }; }
  m = s.match(/^(\d{1,2})\.\s*([A-Za-zäöü]+)\s*[–-]\s*(\d{1,2})\.\s*([A-Za-zäöü]+)(?:\s+(\d{4}))?$/);
  if (m && MON[m[2].toLowerCase()] && MON[m[4].toLowerCase()]) { const y = m[5] || '2026'; return { von: `${pad(m[1])}.${pad(MON[m[2].toLowerCase()])}.${y}`, bis: `${pad(m[3])}.${pad(MON[m[4].toLowerCase()])}.${y}` }; }
  m = s.match(/^(\d{1,2})\.\s*([A-Za-zäöü]+)(?:\s+(\d{4}))?$/);
  if (m && MON[m[2].toLowerCase()]) { const y = m[3] || '2026'; return { von: `${pad(m[1])}.${pad(MON[m[2].toLowerCase()])}.${y}`, bis: '' }; }
  return null;
};
const dateFirst = s => { const m = s.match(/^(\d{1,2})\.\s*[–-]\s*(\d{1,2})\.(\d{2})\.\s*[–-]\s*(.+)$/); return m ? { von: `${pad(m[1])}.${m[3]}.2026`, bis: `${pad(m[2])}.${m[3]}.2026`, name: m[4].trim() } : null; };
const NAME_RX = /(fest|markt|spectaculum|spektakel|ritterturnier|königstage|zauberdorf|anno 1250|wikinger|mittsommernacht|historia|sternenklang|metrausch|hansefest|treiben|turnier)/i;
const SKIP_RX = /^(stärker|musikfestival \+|\s*\+ camping|ganz oben|mittelalter-festival$|historischer handwerkermarkt|großen bereich|heute der|wenn du willst|deutlich breiter|\d+$|altburg-faktor|allerbesten|lagerleben, zelte|160 händler|keltischen\/|beerenweine$|schenken und|extrem passend|tavernen|musik, ritterturnier|burg falkenstein$|mylau$|schkopau$|gardelegen$|„altburg festival|-festivals|größere mittelalter)/i;
const SPLIT_OVERRIDE = { 'Lichterfest „Halle im Mittelalter“': ['Lichterfest „Halle im Mittelalter“', 'Halle (Saale)'], 'Mittelalterstadtfest Bad Langensalza': ['Mittelalterstadtfest', 'Bad Langensalza'], 'Ritter-Spektakel Schloss Hermsdorf': ['Ritter-Spektakel Schloss Hermsdorf', 'Hermsdorf'], 'Historienspektakel Hansefest Gardelegen': ['Historienspektakel Hansefest', 'Gardelegen'], 'Kaiser-Otto-Fest Magdeburg': ['Kaiser-Otto-Fest', 'Magdeburg'], 'Historisches Burgfest Querfurt': ['Historisches Burgfest mit Ritterturnier', 'Querfurt'], 'Mittelalterfest Völpke': ['Mittelalterfest', 'Völpke'], 'Königstage Quedlinburg': ['Königstage', 'Quedlinburg'], 'Hansefest Salzwedel': ['Hansefest', 'Salzwedel'], 'Mittelaltermarkt Osnabrück': ['Mittelaltermarkt', 'Osnabrück'], 'Spectaculum Magdeburgense': ['Spectaculum Magdeburgense', 'Magdeburg'], 'Burgfest Creuzburg': ['Burgfest', 'Creuzburg'], 'Mittelalterfest Schkopau': ['Mittelalterfest Beerenweine', 'Schkopau'] };
const REGION_HINT = { Harz: 'Harz', Thüringen: 'Thüringen', 'Oktober-Ausgabe': '' };
const BL = { kalbe:'Sachsen-Anhalt','bad langensalza':'Thüringen',querfurt:'Sachsen-Anhalt',weißenfels:'Sachsen-Anhalt',halle:'Sachsen-Anhalt',hohenmölsen:'Sachsen-Anhalt',mylau:'Sachsen',hermsdorf:'Sachsen',zwickau:'Sachsen',gardelegen:'Sachsen-Anhalt',jerichow:'Sachsen-Anhalt',magdeburg:'Sachsen-Anhalt',thale:'Sachsen-Anhalt',falkenstein:'Sachsen-Anhalt (Harz)',kranichfeld:'Thüringen',gera:'Thüringen',kelbra:'Sachsen-Anhalt',heldburg:'Thüringen',blankenburg:'Sachsen-Anhalt',schkopau:'Sachsen-Anhalt',creuzburg:'Thüringen',posterstein:'Thüringen',freyburg:'Sachsen-Anhalt',orlamünde:'Thüringen',harztor:'Thüringen',breitungen:'Thüringen',gotha:'Thüringen',erfurt:'Thüringen',vacha:'Thüringen',ebeleben:'Thüringen',veilsdorf:'Thüringen',stadtilm:'Thüringen',stendal:'Sachsen-Anhalt',wernigerode:'Sachsen-Anhalt',völpke:'Sachsen-Anhalt',roßlau:'Sachsen-Anhalt',oschersleben:'Sachsen-Anhalt',quedlinburg:'Sachsen-Anhalt',salzwedel:'Sachsen-Anhalt',ilsenburg:'Sachsen-Anhalt','saalburg-ebersdorf':'Thüringen',römhild:'Thüringen',bremervörde:'Niedersachsen',höxter:'Nordrhein-Westfalen',osnabrück:'Niedersachsen' };
const ALIAS = { 'spectaculummagdeburgensemagdeburg':'K02', 'historiacaraslangera':'K01', 'sternenklangfestivalkranichfeld':'K15', 'mittelaltermarktzumherbstmarkthohenmölsen':'M-hohenmoelsen' };
const RANK = { 'sternenklangfestivalkranichfeld':1,'metrauschfestivalkalbe':2,'spectaculummagdeburgensemagdeburg':3,'mittelalterstadtfestbadlangensalza':4,'burgfestfalkenstein':5,'historiacaraslangera':6,'keltischeserntefestkelbra':7,'mittelalterfestbeerenweineschkopau':8,'fantasymittelaltermarktheldburg':9,'burgfestcreuzburg':10 };
const norm = s => s.toLowerCase().replace(/^\d+\.\s*/, '').replace(/\(.*?\)/g, '').replace(/[^a-z0-9äöüß]/g, '');
const splitName = raw => {
  let s = raw.replace(/^\d+\.\s*[🥇🥈🥉]?\s*/u, '').replace(/^[🥇🥈🥉]\s*/u, '').trim();
  if (SPLIT_OVERRIDE[s]) return { name: SPLIT_OVERRIDE[s][0], ort: SPLIT_OVERRIDE[s][1], regionHint: '' };
  let name = s, ort = '', regionHint = '';
  let m = s.match(/^(.*)\s+–\s+(.+)$/) || s.match(/^(.*?)\s+(?:in|auf)\s+(.+)$/);
  if (m) { name = m[1].trim(); ort = m[2].trim(); }
  else { const w = s.split(/\s+/); if (w.length >= 2 && /^[A-ZÄÖÜ]/.test(w[w.length-1]) && !/^(Fest|Markt|Spectaculum|Festival)$/i.test(w[w.length-1])) { ort = w.pop(); name = w.join(' '); } }
  const rm = ort.match(/\((.*?)\)/); if (rm && /thüringen|harz|sachsen|bayern/i.test(rm[1])) regionHint = rm[1];
  if (REGION_HINT[ort] !== undefined) { regionHint = REGION_HINT[ort] || regionHint; ort = ''; const w = name.split(/\s+/); if (w.length >= 2 && /^[A-ZÄÖÜ]/.test(w[w.length-1])) { ort = w.pop(); name = w.join(' '); } }
  ort = ort.replace(/\s*\(.*?\)\s*/g, ' ').split('/')[0].trim();
  if (/^(burg|schloss) /i.test(ort)) { name = name + ' ' + ort; ort = ort.replace(/^(burg|schloss) /i, ''); }
  return { name, ort, regionHint };
};
const kiEvents = new Map(); let mSeq = 0;
for (const msg of msgs.filter(m => [44016, 44017, 44018].includes(m.id))) {
  const bolds = (msg.text_entities || []).filter(e => e.type === 'bold').map(e => e.text.trim()).filter(Boolean);
  let pending = null;
  const add = (nameRaw, d, mid) => {
    const { name, ort, regionHint } = splitName(nameRaw); let key = `${norm(name)}${norm(ort)}`; if (ALIAS[key] === 'M-hohenmoelsen') key = 'mittelaltermarkthohenmölsen';
    const target = ALIAS[key]; const dateRow = d ? [null, d.von, d.bis, 'Festivaltermin (KI-Liste)', `Chat msg ${mid}`] : null;
    if (target) { if (dateRow && !dates.some(x => x[0] === target && x[1] === d.von)) dates.push([target, d.von, d.bis, 'Festivaltermin (KI-Liste)', `Chat msg ${mid}`]); return; }
    let ev = kiEvents.get(key);
    if (!ev) { mSeq++; ev = { id: 'M' + pad(mSeq), key, name, ort, regionHint, msgs: new Set(), dates: [] }; kiEvents.set(key, ev); }
    ev.msgs.add(mid); if (d && !ev.dates.some(x => x.von === d.von)) ev.dates.push(d);
  };
  for (const b of bolds) {
    const df = dateFirst(b); if (df) { add(df.name, df, msg.id); pending = null; continue; }
    const d = parseDate(b); if (d) { if (pending) { add(pending, d, msg.id); pending = null; } continue; }
    if (SKIP_RX.test(b)) { if (pending) add(pending, null, msg.id); pending = null; continue; }
    if (NAME_RX.test(b)) { if (pending) add(pending, null, msg.id); pending = b; } else pending = null;
  }
  if (pending) add(pending, null, msg.id);
}
for (const ev of kiEvents.values()) {
  const bl = BL[ev.ort.toLowerCase()] || BL[ev.ort.toLowerCase().split(' ')[0]] || '';
  events.push({ id: ev.id, quelle_typ: 'Chat (KI-Liste)', flyer: '', msg: [...ev.msgs].join(';'), typ: 'Mittelalterfest/-markt (KI-Recherche, unverifiziert)', name: ev.name, location: '', strasse: '', plz: '', ort: ev.ort,
    region: bl || ev.regionHint || '', land: 'DE', lat: '', lng: '', geo_status: ev.ort ? (bl ? 'Ort aus Quelle; Bundesland aus Ortsname – verifizieren' : 'Ort aus Quelle') : 'offen', eintritt: '', gage: '', konditionen: '', bewerbung: '',
    tags: 'Mittelalter;Markt;KI-Liste' + (RANK[ev.key] ? ';KI-Top10' : ''), kurz: `Aus der KI-Recherche im Chat (msg ${[...ev.msgs].join('/')}) – Suchprofil "Altburg-Gefühl": Musikfestival + historisches Gelände + Markt + Lagerleben.` + (RANK[ev.key] ? ` KI-Rang ${RANK[ev.key]} von 10 ("Altburg Festival, aber woanders").` : ''),
    lang: '', passung: RANK[ev.key] ? `hoch (KI-Rang ${RANK[ev.key]})` : 'zu prüfen', naechster: 'Veranstalter + Bewerbungsweg recherchieren', unklar: 'Alle Angaben KI-generiert → verifizieren', quelle: `Chat msg ${[...ev.msgs].join(', ')}`, ki_rang: RANK[ev.key] || '' });
  for (const d of ev.dates) dates.push([ev.id, d.von, d.bis, 'Festivaltermin (KI-Liste)', '']);
}
// KI-Rang auch bei zusammengeführten Knoten
for (const e of events) { const k = Object.keys(ALIAS).find(k => ALIAS[k] === e.id); if (k && RANK[k]) e.ki_rang = RANK[k]; }

// ───────────────────────── 3) Tabellen materialisieren ──────────────────────
const byId = Object.fromEntries(events.map(e => [e.id, e]));
const nm = id => (byId[id] ? byId[id].name : id);
const iso = d => { const m = /^(\d{2})\.(\d{2})\.(\d{4})$/.exec(d || ''); return m ? `${m[3]}-${m[2]}-${m[1]}` : ''; };
const T = {};
T.events = events.map(e => ({ EVENT_ID: e.id, QUELLE_TYP: e.quelle_typ, FLYER: e.flyer, MSG: e.msg, TYP: e.typ, NAME: e.name, LOCATION: e.location, STRASSE: e.strasse, PLZ: e.plz, ORT: e.ort, REGION: e.region, LAND: e.land, LAT: e.lat, LNG: e.lng, GEO_STATUS: e.geo_status,
  EINTRITT: e.eintritt, GAGE: e.gage, KONDITIONEN: e.konditionen, BEWERBUNG: e.bewerbung, KI_RANG: e.ki_rang || '', TAGS: e.tags, KURZBESCHREIBUNG: e.kurz, LANGBESCHREIBUNG: e.lang, PASSUNG_SPP7: e.passung, NAECHSTER_SCHRITT: e.naechster, UNKLAR: e.unklar, QUELLE: e.quelle }));
T.event_dates = dates.map(([id, von, bis, art, k], i) => ({ DATE_ID: 'D' + pad(i + 1), EVENT_ID: id, EVENT_NAME: nm(id), VON: von, BIS: bis, VON_ISO: iso(von), BIS_ISO: iso(bis), ART: art, KOMMENTAR: k }));
const actKey = s => s.toLowerCase().replace(/\s*\(.*?\)\s*/g, '').replace(/[^a-z0-9äöüß]/g, '');
const actIds = {}; let aSeq = 0;
T.event_acts = acts.map(([id, name, rolle, slot, uns, notiz], i) => { const k = actKey(name); if (!actIds[k]) actIds[k] = 'A' + pad(++aSeq); return { LINK_ID: 'EA' + pad(i + 1), EVENT_ID: id, EVENT_NAME: nm(id), ACT_ID: actIds[k], ACT_NAME: name, ROLLE: rolle, SLOT_TAG: slot, UNSICHER: uns ? 1 : 0, NOTIZ: notiz }; });
const actAgg = {}; for (const r of T.event_acts) { const a = actAgg[r.ACT_ID] ||= { ACT_ID: r.ACT_ID, ACT_NAME: r.ACT_NAME, names: new Set(), events: new Set(), rollen: new Set() }; a.names.add(r.ACT_NAME); if (!/Referenz/.test(r.ROLLE)) a.events.add(r.EVENT_NAME); a.rollen.add(r.ROLLE.split(' (')[0]); }
T.acts = Object.values(actAgg).map(a => ({ ACT_ID: a.ACT_ID, ACT_NAME: a.ACT_NAME, NAMENSVARIANTEN: [...a.names].join(' | '), ANZAHL_EVENTS: a.events.size, EVENTS: [...a.events].join(' | '), ROLLEN: [...a.rollen].join(' | ') })).sort((x, y) => y.ANZAHL_EVENTS - x.ANZAHL_EVENTS || x.ACT_NAME.localeCompare(y.ACT_NAME));
const pIds = {}; let pSeq = 0;
T.event_partners = partners.map(([id, name, rolle, uns], i) => { const k = actKey(name); if (!pIds[k]) pIds[k] = 'P' + pad(++pSeq); return { LINK_ID: 'EP' + pad(i + 1), EVENT_ID: id, EVENT_NAME: nm(id), PARTNER_ID: pIds[k], PARTNER_NAME: name, ROLLE: rolle, UNSICHER: uns ? 1 : 0 }; });
const pAgg = {}; for (const r of T.event_partners) { const p = pAgg[r.PARTNER_ID] ||= { PARTNER_ID: r.PARTNER_ID, PARTNER_NAME: r.PARTNER_NAME, events: new Set(), rollen: new Set() }; p.events.add(r.EVENT_NAME); p.rollen.add(r.ROLLE); }
T.partners = Object.values(pAgg).map(p => ({ PARTNER_ID: p.PARTNER_ID, PARTNER_NAME: p.PARTNER_NAME, ANZAHL_EVENTS: p.events.size, EVENTS: [...p.events].join(' | '), ROLLEN: [...p.rollen].join(' | ') })).sort((x, y) => y.ANZAHL_EVENTS - x.ANZAHL_EVENTS || x.PARTNER_NAME.localeCompare(y.PARTNER_NAME));
T.event_features = features.map(([id, f, k], i) => ({ LINK_ID: 'EF' + pad(i + 1), EVENT_ID: id, EVENT_NAME: nm(id), FEATURE: f, KATEGORIE: k }));
T.event_channels = channels.map(([id, k, v], i) => ({ LINK_ID: 'EC' + pad(i + 1), EVENT_ID: id, EVENT_NAME: nm(id), KANAL: k, WERT: v }));
T.event_tags = events.flatMap(e => (e.tags || '').split(';').map(t => t.trim()).filter(Boolean).map(t => ({ EVENT_ID: e.id, EVENT_NAME: e.name, TAG: t })));
T.timetable = timetable.map(([id, z, p], i) => ({ LINK_ID: 'TT' + pad(i + 1), EVENT_ID: id, EVENT_NAME: nm(id), ZEIT: z, PROGRAMMPUNKT: p }));
T.feed_context = feed.map(([id, acc, n, rel], i) => ({ LINK_ID: 'FC' + pad(i + 1), EVENT_ID: id, EVENT_NAME: nm(id), ACCOUNT: acc, NOTIZ: n, RELEVANZ: rel }));
T.contacts = C.contacts.map(([org, typ, mail, ort, region, msg, notiz], i) => ({ CONTACT_ID: 'K' + pad(i + 1), ORGANISATION: org, TYP: typ, EMAIL_TELEFON: mail, ORT: ort, REGION: region, LAT: '', LNG: '', MSG: msg, NOTIZ: notiz }));
// chat_items: alle Entities + Textnachrichten ohne Entities
const items = entities.filter(e => !['bold', 'italic', 'bot_command'].includes(e.type)).map(e => ({ MSG: e.msg, DATUM: e.date.slice(0, 16), TYP: { link: 'URL', text_link: 'URL (Text-Link)', email: 'E-Mail', hashtag: 'Hashtag', phone: 'Telefon' }[e.type] || e.type, WERT: e.value, FOTO: e.photo.replace('photos/', ''), KONTEXT: e.context, ZUGEORDNET: C.msgToEvent[e.msg] || '' }));
for (const m of msgs) { const t = (m.text_entities || []).map(e => e.text).join('').trim(); if (!t) continue; const hasEnt = (m.text_entities || []).some(e => !['plain', 'bold', 'italic', 'bot_command'].includes(e.type)); if (!hasEnt) items.push({ MSG: m.id, DATUM: m.date.slice(0, 16), TYP: m.photo ? 'Foto-Caption' : 'Text', WERT: t.replace(/\s+/g, ' ').slice(0, 400), FOTO: (m.photo || '').replace('photos/', ''), KONTEXT: '', ZUGEORDNET: C.msgToEvent[m.id] || '' }); }
T.chat_items = items.sort((a, b) => a.MSG - b.MSG || a.TYP.localeCompare(b.TYP));

// ───────────────────────── 4) Export CSV ────────────────────────────────────
const EXP = path.join(ROOT, 'export'); fs.mkdirSync(EXP, { recursive: true });
const csv = rows => { if (!rows.length) return ''; const h = Object.keys(rows[0]); const esc = v => '"' + String(v ?? '').replace(/"/g, '""').replace(/\r?\n/g, ' | ') + '"'; return '\uFEFF' + [h.join(';'), ...rows.map(r => h.map(k => esc(r[k])).join(';'))].join('\r\n'); };
for (const [name, rows] of Object.entries(T)) fs.writeFileSync(path.join(EXP, `${name}.csv`), csv(rows));

// ───────────────────────── 5) Export XLSX ───────────────────────────────────
const DESC = {
  events: 'PARENT – ein Datensatz je Festival/Location/Veranstalter/Tour-Stopp (F=Flyer, C=Chat, T=Tourplan, K=Festival-Knoten aus mehreren Quellen, R=KI-Empfehlung, M=KI-Liste Mittelalter)',
  event_dates: 'CHILD – mehrere Termine je Event (Haupttermin, Bewerbungsfrist, Post-Datum, Auftritt Band X …)', event_acts: 'CHILD (n:m) – eine Zeile je Event×Act; ROLLE = Headliner/Act/DJ/Referenz/Tourdatum; UNSICHER=1 = Lesung auf Flyer unsicher',
  acts: 'DIMENSION – jede Band einmal; ANZAHL_EVENTS zählt nur echte Auftritte (Referenzlisten ausgenommen)', event_partners: 'CHILD (n:m) – Sponsor/Förderer/Veranstalter je Event', partners: 'DIMENSION – Sponsor/Partner einmal, mit Event-Zählung',
  event_features: 'CHILD – Zonen/Bühnen/Infrastruktur/Programm (z. B. Mittelalter Markt, Camping)', event_channels: 'CHILD – Website/Instagram/Facebook/E-Mail/Telefon je Event', event_tags: 'CHILD – ein Tag je Zeile', timetable: 'CHILD – Zeitpläne (Slots)',
  feed_context: 'NEBENBEFUNDE – andere Accounts im selben Screenshot (bewusst getrennt)', contacts: 'KONTAKTE – Organisationen/Personen mit E-Mail/Telefon (Rügen-Liste u. a.); ORT für Geocoding', chat_items: 'ROHDATEN – jede URL/E-Mail/Hashtag/Telefon/Textnachricht aus dem Chat mit Zuordnung zu Events',
};
(async () => {
  const wb = new ExcelJS.Workbook(); wb.creator = 'SPP7';
  const readme = wb.addWorksheet('README'); readme.columns = [{ header: 'Tabelle', key: 't', width: 18 }, { header: 'Zeilen', key: 'n', width: 8 }, { header: 'Beschreibung', key: 'd', width: 120 }];
  for (const [n, rows] of Object.entries(T)) readme.addRow({ t: n, n: rows.length, d: DESC[n] || '' });
  readme.addRow({}); readme.addRow({ t: 'Verknüpfung', d: 'EVENT_ID ist der Schlüssel in allen Child-Tabellen. ACT_ID/PARTNER_ID verbinden zu den Dimensionen. Beispielabfrage: acts.ANZAHL_EVENTS ≥ 2 → Bands auf mehreren Festivals.' });
  readme.addRow({ t: 'Geodaten', d: 'LAT/LNG nur wo aus Quelle belegt (Shepherd’s Pub Zwickau). GEO_STATUS sagt, woher der Ort stammt. Geocoding = nächster Schritt → GeoPackage.' });
  readme.getRow(1).font = { bold: true };
  for (const [name, rows] of Object.entries(T)) {
    const ws = wb.addWorksheet(name, { views: [{ state: 'frozen', ySplit: 1 }] }); if (!rows.length) continue;
    const keys = Object.keys(rows[0]);
    ws.columns = keys.map(k => ({ header: k, key: k, width: Math.min(60, Math.max(10, ...rows.slice(0, 200).map(r => String(r[k] ?? '').length * 0.9), k.length + 2)) }));
    ws.getRow(1).eachCell(c => { c.fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: 'FF1E1E2E' } }; c.font = { bold: true, color: { argb: 'FFFFFFFF' } }; c.alignment = { vertical: 'middle' }; });
    ws.getRow(1).height = 24;
    rows.forEach((r, i) => { const row = ws.addRow(r); row.eachCell(c => { c.fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: i % 2 ? 'FFECEFF4' : 'FFF9FAFB' } }; c.alignment = { vertical: 'top', wrapText: true }; c.border = { bottom: { style: 'thin', color: { argb: 'FFDCE0E8' } } }; }); });
    ws.autoFilter = { from: { row: 1, column: 1 }, to: { row: 1, column: keys.length } };
  }
  fs.mkdirSync(path.join(ROOT, 'public/downloads'), { recursive: true });
  await wb.xlsx.writeFile(path.join(ROOT, 'public/downloads/spp7_modell.xlsx'));
  fs.copyFileSync(path.join(ROOT, 'public/downloads/spp7_modell.xlsx'), path.join(ROOT, 'spp7_modell.xlsx'));

  // ─────────────────────── 6) HTML mit Tabs + Suche ─────────────────────────
  const esc = s => String(s ?? '').replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
  const tab = (name, rows) => { if (!rows.length) return `<p class="mut">leer</p>`; const keys = Object.keys(rows[0]); return `<table><thead><tr>${keys.map(k => `<th>${esc(k)}</th>`).join('')}</tr></thead><tbody>${rows.map(r => `<tr>${keys.map(k => `<td${/_ID$/.test(k) || k === 'MSG' ? ' class="id"' : ''}>${r[k] === '' || r[k] == null ? '<span class="e">—</span>' : esc(r[k])}</td>`).join('')}</tr>`).join('')}</tbody></table>`; };
  const multi = T.acts.filter(a => a.ANZAHL_EVENTS >= 2);
  const html = `<!doctype html><html lang="de"><head><meta charset="utf-8"><title>SPP7 · Datenmodell (Parent → Child)</title><style>
:root{--bg:#0f1115;--fg:#e8eaf0;--mut:#9aa3b5;--line:#252b38;--card:#161a22;--acc:#8ab4ff}*{box-sizing:border-box}
body{margin:0;background:var(--bg);color:var(--fg);font:13px/1.45 ui-sans-serif,system-ui,"Segoe UI",Roboto,sans-serif}
header{padding:16px 20px 10px;border-bottom:1px solid var(--line);background:#12151c;position:sticky;top:0;z-index:9}
h1{margin:0 0 2px;font-size:17px}.sub{color:var(--mut);font-size:12px;margin:0 0 10px}
.tabs{display:flex;gap:6px;flex-wrap:wrap}.tabs button{background:var(--card);color:var(--fg);border:1px solid var(--line);border-radius:8px;padding:6px 10px;cursor:pointer;font-size:12px}
.tabs button.on{background:var(--acc);color:#0b1020;border-color:var(--acc);font-weight:700}.tabs small{color:inherit;opacity:.7;margin-left:4px}
.bar{display:flex;gap:10px;align-items:center;margin-top:10px}input{background:var(--card);border:1px solid var(--line);color:var(--fg);border-radius:8px;padding:7px 10px;width:340px}
.desc{color:var(--mut);font-size:12px}.wrap{padding:12px 20px 60px;overflow:auto}section{display:none}section.on{display:block}
table{border-collapse:separate;border-spacing:0;min-width:100%}thead th{position:sticky;top:0;background:#1a1f29;color:#cfd6e4;font-size:11px;text-transform:uppercase;letter-spacing:.04em;padding:8px 9px;text-align:left;border-bottom:1px solid var(--line);white-space:nowrap}
tbody td{padding:8px 9px;border-bottom:1px solid var(--line);vertical-align:top;max-width:440px;white-space:pre-wrap}tbody tr:nth-child(odd) td{background:var(--card)}tbody tr:hover td{background:#1d2330}
td.id{font-variant-numeric:tabular-nums;color:var(--acc);font-weight:700;white-space:nowrap}.e{color:#4b5568}.mut{color:var(--mut)}
.hl{background:#141a26;border:1px solid var(--line);border-radius:10px;padding:10px 14px;margin-bottom:12px}.hl b{color:#7ee2a8}
</style></head><body><header><h1>SPP7 · Datenmodell — Parent → Child</h1><p class="sub">Quellen: 79 Flyer (${F.events.length} erfasst) + ${msgs.length} Chat-Nachrichten · ${T.events.length} Events · ${T.event_acts.length} Event×Act-Zeilen · ${T.acts.length} Acts · ${T.contacts.length} Kontakte · identisch zu <code>spp7_modell.xlsx</code> / <code>export/*.csv</code></p>
<div class="tabs">${Object.entries(T).map(([n, r], i) => `<button data-t="${n}" class="${i ? '' : 'on'}">${n}<small>${r.length}</small></button>`).join('')}</div>
<div class="bar"><input id="q" placeholder="Filter in aktueller Tabelle … (z. B. Leipzig, Bewerbung, Hurley)"><span class="desc" id="d">${esc(DESC.events)}</span></div></header>
<div class="wrap"><div class="hl"><b>Bands auf mehreren Events:</b> ${multi.map(a => `${esc(a.ACT_NAME)} (${a.ANZAHL_EVENTS}: ${esc(a.EVENTS)})`).join(' · ') || '–'}</div>
${Object.entries(T).map(([n, r], i) => `<section id="s-${n}" class="${i ? '' : 'on'}">${tab(n, r)}</section>`).join('')}</div>
<script>const D=${JSON.stringify(DESC)};const bs=[...document.querySelectorAll('.tabs button')];const q=document.getElementById('q');
function show(t){bs.forEach(b=>b.classList.toggle('on',b.dataset.t===t));document.querySelectorAll('section').forEach(s=>s.classList.toggle('on',s.id==='s-'+t));document.getElementById('d').textContent=D[t]||'';q.value='';filt();}
bs.forEach(b=>b.onclick=()=>show(b.dataset.t));function filt(){const v=q.value.toLowerCase();document.querySelectorAll('section.on tbody tr').forEach(tr=>{tr.style.display=!v||tr.textContent.toLowerCase().includes(v)?'':'none';});}q.oninput=filt;</script></body></html>`;
  fs.writeFileSync(path.join(ROOT, 'public/spp7_modell.html'), html); fs.writeFileSync(path.join(ROOT, 'spp7_modell.html'), html);

  // ─────────────────────── 7) Konsole ───────────────────────────────────────
  console.log('Tabellen:', Object.entries(T).map(([n, r]) => `${n}=${r.length}`).join('  '));
  console.log('KI-Liste Events:', kiEvents.size, '| Beispiele:', [...kiEvents.values()].slice(0, 6).map(e => `${e.name} @ ${e.ort} [${e.dates.map(d => d.von).join(',')}]`).join(' ; '));
  console.log('Bands mit >=2 Events:'); multi.forEach(a => console.log('  ', a.ANZAHL_EVENTS, a.ACT_NAME, '→', a.EVENTS));
  const noOrt = T.events.filter(e => !e.ORT && !e.REGION).length; console.log('Events ohne Ort/Region:', noOrt, '| mit Koordinaten:', T.events.filter(e => e.LAT).length);
})();
