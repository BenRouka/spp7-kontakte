import { relations } from "drizzle-orm";
import {
  boolean,
  integer,
  pgTable,
  serial,
  text,
  timestamp,
  date,
  index,
  uniqueIndex,
} from "drizzle-orm/pg-core";

/* ------------------------------------------------------------------ */
/* Stufe-5-Schema — Zielbild aus dem Beschlussverzeichnis:             */
/* Hierarchie Region → Ort → Einrichtung (B-16), Termine als           */
/* Quellzeile + n Zeitfenster (B-10/B-12), Beschlüsse mit              */
/* Prio-1-Basis / Prio-2-Ergänzung / Status.                           */
/* ------------------------------------------------------------------ */

export const regionen = pgTable(
  "regionen",
  {
    id: integer("id").primaryKey(), // 1–9, explizit vergeben (Reihenfolge)
    name: text("name").notNull(),
  },
  (t) => [uniqueIndex("regionen_name_uq").on(t.name)],
);

export const kontakte = pgTable(
  "kontakte",
  {
    kvId: text("kv_id").primaryKey(), // KV01 … KV32, KV01.1, KV01.2, STADT-PUTBUS
    regionId: integer("region_id")
      .notNull()
      .references(() => regionen.id, { onDelete: "restrict" }),
    ort: text("ort").notNull(),
    name: text("name").notNull(),
    anschrift: text("anschrift"),
    telefon: text("telefon"),
    fax: text("fax"),
    email1: text("email_1"),
    email2: text("email_2"),
    email3: text("email_3"),
    web: text("web"),
    typ: text("typ").notNull(),
    prio2ChatHinweis: text("prio2_chat_hinweis"),
    hatMdBlock: boolean("hat_md_block").notNull().default(true),
    sortierung: integer("sortierung").notNull(), // Zeilenposition im Freeze
  },
  (t) => [
    index("kontakte_region_idx").on(t.regionId),
    index("kontakte_ort_idx").on(t.ort),
  ],
);

export const termine = pgTable("termine", {
  sfId: text("sf_id").primaryKey(), // SF01 … SF54
  jahr: integer("jahr").notNull(),
  datumOriginal: text("datum_original").notNull(),
  nameOriginal: text("name_original").notNull(),
  plzOrtOriginal: text("plz_ort_original").notNull(),
  zeitfensterAnzahl: integer("zeitfenster_anzahl").notNull(),
  sternchen: text("sternchen").notNull().default("kein"), // kein | * | **
  hinweis: text("hinweis"),
  sortierung: integer("sortierung").notNull(),
});

export const terminZeitfenster = pgTable(
  "termin_zeitfenster",
  {
    id: serial("id").primaryKey(),
    terminSfId: text("termin_sf_id")
      .notNull()
      .references(() => termine.sfId, { onDelete: "cascade" }),
    nr: integer("nr").notNull(), // 1..n — Advent bleibt 1 Quellzeile mit 4 Fenstern (B-10)
    von: date("von", { mode: "string" }).notNull(), // ISO YYYY-MM-DD
    bis: date("bis", { mode: "string" }).notNull(),
    raw: text("raw").notNull(), // Originalfenster "von/bis" aus dem Freeze
  },
  (t) => [
    index("zeitfenster_termin_idx").on(t.terminSfId),
    index("zeitfenster_von_idx").on(t.von),
  ],
);

export const beschluesse = pgTable("beschluesse", {
  id: text("id").primaryKey(), // B-01 … B-20
  bereich: text("bereich").notNull(), // Kontakte | Termine | Archiv | Ablauf | Offen
  titel: text("titel").notNull(),
  prio1Basis: text("prio_1_basis").notNull(),
  prio2Ergaenzung: text("prio_2_ergaenzung").notNull(),
  massnahme: text("massnahme").notNull(),
  status: text("status").notNull(), // entschieden | provisorisch
  sortierung: integer("sortierung").notNull(),
});

/**
 * Audit-Trail des Imports: eine Zeile je Freeze-Datei und Lauf.
 * sha256 ist der zum Importzeitpunkt neu berechnete Wert — er muss dem
 * Manifest PRUEFSUMMEN.sha256 entsprechen, sonst bricht der Import ab.
 */
export const importProtokoll = pgTable(
  "import_protokoll",
  {
    id: serial("id").primaryKey(),
    laufId: text("lauf_id").notNull(),
    datei: text("datei").notNull(),
    sha256: text("sha256").notNull(),
    datensaetze: integer("datensaetze").notNull(),
    detail: text("detail").notNull(),
    pruefsummeOk: boolean("pruefsumme_ok").notNull(),
    importiertAm: timestamp("importiert_am", {
      withTimezone: true,
      mode: "string",
    })
      .notNull()
      .defaultNow(),
  },
  (t) => [index("import_protokoll_lauf_idx").on(t.laufId)],
);

/* ------------------------------------------------------------------ */
/* Relationen                                                          */
/* ------------------------------------------------------------------ */

export const regionenRelations = relations(regionen, ({ many }) => ({
  kontakte: many(kontakte),
}));

export const kontakteRelations = relations(kontakte, ({ one }) => ({
  region: one(regionen, {
    fields: [kontakte.regionId],
    references: [regionen.id],
  }),
}));

export const termineRelations = relations(termine, ({ many }) => ({
  zeitfenster: many(terminZeitfenster),
}));

export const terminZeitfensterRelations = relations(
  terminZeitfenster,
  ({ one }) => ({
    termin: one(termine, {
      fields: [terminZeitfenster.terminSfId],
      references: [termine.sfId],
    }),
  }),
);

export type Region = typeof regionen.$inferSelect;
export type Kontakt = typeof kontakte.$inferSelect;
export type Termin = typeof termine.$inferSelect;
export type TerminZeitfenster = typeof terminZeitfenster.$inferSelect;
export type Beschluss = typeof beschluesse.$inferSelect;
export type ImportProtokollEintrag = typeof importProtokoll.$inferSelect;
