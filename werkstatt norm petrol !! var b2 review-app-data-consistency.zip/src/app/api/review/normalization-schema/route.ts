import {
  getNormalizationFile,
  normalizationHeaderCsv,
  normalizationMarkdown,
  normalizationProposal,
} from "@/lib/normalization-schema";

export const dynamic = "force-dynamic";

export async function GET(request: Request) {
  const query = new URL(request.url).searchParams;
  const format = query.get("format") ?? "json";
  const headers = {
    "Cache-Control": "no-store",
    "X-SPP7-Proposal-Version": normalizationProposal.version,
  };

  if (format === "json") {
    return Response.json(normalizationProposal, { headers });
  }

  if (format === "md") {
    return new Response(normalizationMarkdown(), {
      headers: {
        ...headers,
        "Content-Type": "text/markdown; charset=utf-8",
        "Content-Disposition": 'attachment; filename="stufe-2-spaltenvorschlag.md"',
      },
    });
  }

  if (format === "csv") {
    const file = getNormalizationFile(query.get("file"));
    if (!file) {
      return Response.json(
        { error: "Für CSV ist file=gruppen|kurverwaltungen|kontaktwege|termine|zeitfenster erforderlich." },
        { status: 400, headers },
      );
    }
    return new Response(normalizationHeaderCsv(file), {
      headers: {
        ...headers,
        "Content-Type": "text/csv; charset=utf-8",
        "Content-Disposition": `attachment; filename="vorschlag-${file.filename}"`,
      },
    });
  }

  return Response.json({ error: "Verfügbar: json, md, csv." }, { status: 400, headers });
}
