import { contactReviewMarkdown } from "@/lib/contact-hierarchy";
import { getContactReview } from "@/lib/contact-review-repository";

export const dynamic = "force-dynamic";
export const runtime = "nodejs";
export async function GET(request: Request) {
  const format = new URL(request.url).searchParams.get("format") ?? "json";
  if (format !== "json" && format !== "md") return Response.json({ error: "Verfügbar: json, md. Kein CSV-Import." }, { status: 400 });
  try {
    const review = await getContactReview();
    const headers = { "Cache-Control": "no-store", "X-SPP7-Contact-Review": review.version };
    if (format === "json") return Response.json(review, { headers });
    return new Response(contactReviewMarkdown(review), { headers: {
      ...headers, "Content-Type": "text/markdown; charset=utf-8",
      "Content-Disposition": 'attachment; filename="kontaktklaerung-parent-child.md"',
    } });
  } catch {
    return Response.json({ error: "Die Kontaktklärung konnte nicht gelesen werden. Es wurde nichts importiert." }, { status: 503 });
  }
}
