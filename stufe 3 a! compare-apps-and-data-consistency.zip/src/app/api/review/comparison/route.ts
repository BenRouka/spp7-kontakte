import { zipSync } from "fflate";
import { getComparisonReport } from "@/lib/comparison-repository";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";
const downloads: Record<string, string> = { md: "abgleich-01.md", contacts: "abgleich-01-kontakte.csv", schedules: "abgleich-01-termine.csv",
  fields: "abgleich-01-feldvergleich.csv", decisions: "abgleich-01-entscheidungen.csv" };
export async function GET(request: Request) {
  const format = new URL(request.url).searchParams.get("format") || "json";
  if (!["json", "zip", ...Object.keys(downloads)].includes(format)) return Response.json({ error: "Verfügbar: json, md, contacts, schedules, fields, decisions, zip." }, { status: 400 });
  try {
    const { report, files } = await getComparisonReport();
    const headers: Record<string, string> = { "Cache-Control": "no-store", "X-SPP7-Comparison-Version": report.version, "X-Robots-Tag": "noindex, nofollow" };
    if (format === "json") return Response.json(report, { headers });
    if (format === "zip") {
      const zipped = zipSync(files, { level: 6, mtime: new Date("1980-01-01T00:00:00Z") });
      return new Response(new Uint8Array(zipped).buffer, { headers: { ...headers, "Content-Type": "application/zip",
        "Content-Disposition": 'attachment; filename="spp7-abgleich-01.zip"' } });
    }
    const name = downloads[format];
    return new Response(new Uint8Array(files[name]).buffer, { headers: { ...headers,
      "Content-Type": `${format === "md" ? "text/markdown" : "text/csv"}; charset=utf-8`,
      "Content-Disposition": `attachment; filename="${name}"` } });
  } catch {
    return Response.json({ error: "Der Abgleichbericht gehört nicht zum aktuellen Prüfsummen-/Eingabestand oder ist nicht verfügbar. Es wurde nichts geändert. Berichtserzeugung erneut prüfen." }, { status: 503 });
  }
}
