# 02 — Normiert

**Status: noch leer — wird in Stufe 2 gefüllt.**

Hier entstehen aus den Originalen (`../01-roh/`) einheitliche, maschinenlesbare Tabellen.
**Noch keine Datenbank** — nur Dateien, die du öffnen und lesen kannst (CSV, mit Excel/LibreOffice).

## Was hier hineinkommt

| Datei | Zeilen | Aus |
|---|---|---|
| `kurverwaltungen.csv` | 32 | `Kurverwaltungen_2025.md` |
| `suendenfrei-termine.csv` | 54 | `Termine_2027_suendenfrei.txt` |

## Grundregel (vom Auftraggeber bestätigt)

> **Die Originalschreibweise bleibt immer erhalten — in einer eigenen Spalte.**
> Normiert wird nur *zusätzlich*, zum Vergleichen und Sortieren.

Beispiel: aus `Info@Ostseebad-Sellin.de` wird
`email_original = Info@Ostseebad-Sellin.de` **und** `email = info@ostseebad-sellin.de`.

So kann die Normierung nichts kaputtmachen, und es ist jederzeit nachprüfbar,
was wirklich in der Quelle stand.

## Weitere Regeln

- **Nichts erfinden.** Fehlt eine Angabe, bleibt das Feld leer und bekommt einen Statusvermerk.
- **Jede Zeile bekommt eine eigene ID** (`KV01`…`KV32`, `ST01`…`ST54`) — Orts- oder Namensfelder
  taugen nicht als Schlüssel (z. B. kommt „Vitte" zweimal vor).
- **Jede Zeile trägt ihre Herkunft** (Quelldatei + Zeilennummer) und einen **Status**
  (`bestätigt` / `unbestätigt` / `offen` / `berechnet`).
- Datumsangaben zusätzlich im ISO-Format (`2027-04-30`), damit sortiert und gefiltert werden kann.
