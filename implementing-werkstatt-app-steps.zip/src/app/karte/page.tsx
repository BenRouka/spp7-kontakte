import type { Metadata } from "next";
import { ShieldCheck } from "lucide-react";
import { getKarteDaten, fmtZeitstempel } from "@/lib/data";
import { KarteRadar } from "@/components/karten-radar";
import { Badge, Card, Eyebrow } from "@/components/ui";

export const dynamic = "force-dynamic";

export const metadata: Metadata = {
  title: "Event-Radar · SPP7 Werkstatt",
};

export default async function KartePage() {
  const daten = await getKarteDaten();
  const { stats, audit } = daten;
  const pruefen = audit.filter((g) => g.pruefstatus === "pruefen").length;
  const viaNominatim = audit.filter((g) => g.quelle === "nominatim-osm").length;

  return (
    <div className="space-y-8">
      {/* Kopf -------------------------------------------------------- */}
      <section className="rise pt-4">
        <Eyebrow>Karte · Schritt C · Geo auf beschlossener Basis (O-11)</Eyebrow>
        <div className="mt-4 flex flex-wrap items-end justify-between gap-6">
          <h1 className="font-display max-w-3xl text-[clamp(2.2rem,5vw,3.8rem)] font-medium leading-[1.02] tracking-tight text-ink">
            {stats.kuratiertGeocodiert} Terminorte,{" "}
            <span className="text-lime">frisch geocodiert</span> — nichts still
            übernommen.
          </h1>
          <div className="flex flex-wrap gap-2 pb-1">
            <Badge tone="lime">O-11 · Quelle + Status je Punkt</Badge>
            <Badge tone="amber">Zentroide nie als Gelände-Punkt</Badge>
          </div>
        </div>
        <p className="mt-4 max-w-2xl text-[14px] leading-relaxed text-ink-soft">
          Das Radar nutzt die Geometrie des Alt-Systems (460 × 330, Formel
          1:1), aber ausschließlich die neue, additive <em>geo_orte</em>-Tabelle:
          frisch über Nominatim/OSM geocodiert, mit Quelle, Genauigkeit und
          Prüfstatus je Eintrag. Die 212 Alt-Koordinaten bleiben
          Prio-2-Vergleich in <em>alt_events</em> — sichtbar als matter Layer,
          abschaltbar, ohne Zentroide.
        </p>
      </section>

      {/* Kennzahlen --------------------------------------------------- */}
      <section className="rise grid gap-3 sm:grid-cols-2 xl:grid-cols-4 [animation-delay:80ms]">
        <StatKachel
          wert={String(stats.kuratiertGeocodiert)}
          label="kuratierter Terminorte geocodiert"
          detail={`${viaNominatim}× nominatim-osm · ${audit.length - viaNominatim}× statisch-fallback`}
        />
        <StatKachel
          wert={String(stats.sf2027Anzahl)}
          label="Sündenfrei-2027-Orte auf der Karte"
          detail={stats.sf2027Spanne ? `Zeitraum ${stats.sf2027Spanne}` : "–"}
        />
        <StatKachel
          wert={String(stats.altAngezeigt)}
          label="Altbestand-Punkte (Vergleich, ungeprüft)"
          detail="nur Qualität osm/sonstige, klar markiert"
        />
        <StatKachel
          wert={String(stats.altZentroidAusgeblendet + stats.altOhneKoordinate)}
          label="bewusst nicht als Punkt dargestellt"
          detail={`${stats.altZentroidAusgeblendet} Zentroide · ${stats.altOhneKoordinate} ohne Koordinate`}
        />
      </section>

      {/* Radar --------------------------------------------------------- */}
      <Card className="rise overflow-hidden [animation-delay:140ms]">
        <KarteRadar daten={daten} />
      </Card>

      {/* O-11-Herkunftsnachweis ---------------------------------------- */}
      <section className="rise [animation-delay:200ms]">
        <div className="mb-4 flex flex-wrap items-end justify-between gap-3">
          <div>
            <Eyebrow>O-11 · Geo-Herkunftsnachweis</Eyebrow>
            <h2 className="font-display mt-2 text-[clamp(1.4rem,2.4vw,1.9rem)] font-medium leading-tight tracking-tight text-ink">
              {audit.length} Einträge in <span className="text-lime">geo_orte</span>
            </h2>
          </div>
          <div className="flex flex-wrap gap-2">
            <Badge tone="lime">{viaNominatim} nominatim-osm</Badge>
            {pruefen > 0 ? (
              <Badge tone="red">{pruefen} zu prüfen</Badge>
            ) : (
              <Badge tone="neutral">0 im Status „prüfen“</Badge>
            )}
          </div>
        </div>

        <Card>
          <div className="overflow-x-auto">
            <table className="w-full min-w-[880px] border-collapse text-[12.5px]">
              <thead>
                <tr className="border-b border-line text-left font-mono text-[10.5px] uppercase tracking-[0.14em] text-muted">
                  <th className="px-4 py-3 font-semibold">PLZ</th>
                  <th className="px-4 py-3 font-semibold">Ort (Schlüssel)</th>
                  <th className="px-4 py-3 font-semibold">Koordinate</th>
                  <th className="px-4 py-3 font-semibold">Quelle</th>
                  <th className="px-4 py-3 font-semibold">Genauigkeit</th>
                  <th className="px-4 py-3 font-semibold">Prüfstatus</th>
                  <th className="px-4 py-3 font-semibold">Geocodiert am</th>
                </tr>
              </thead>
              <tbody>
                {audit.map((g) => (
                  <tr
                    key={`${g.plz}|${g.ort}`}
                    className="border-b border-line-soft/60 last:border-0 hover:bg-raised2/40"
                  >
                    <td className="px-4 py-2.5 font-mono text-ink-soft">{g.plz}</td>
                    <td className="px-4 py-2.5 font-medium text-ink" title={g.anzeige ?? undefined}>
                      {g.ort}
                    </td>
                    <td className="px-4 py-2.5 font-mono text-muted">
                      {Number(g.lat).toFixed(4)}, {Number(g.lng).toFixed(4)}
                    </td>
                    <td className="px-4 py-2.5">
                      <Badge tone={g.quelle === "nominatim-osm" ? "lime" : "amber"}>
                        {g.quelle}
                      </Badge>
                    </td>
                    <td className="px-4 py-2.5 font-mono text-ink-soft">{g.genauigkeit}</td>
                    <td className="px-4 py-2.5">
                      <Badge tone={g.pruefstatus === "geprueft" ? "lime" : g.pruefstatus === "pruefen" ? "red" : "neutral"}>
                        {g.pruefstatus.replace("ungeprueft", "ungeprüft").replace("pruefen", "prüfen").replace("geprueft", "geprüft")}
                      </Badge>
                    </td>
                    <td className="px-4 py-2.5 font-mono text-[11.5px] text-muted">
                      {fmtZeitstempel(g.geocodiertAm)}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </Card>

        <p className="mt-3 flex max-w-3xl items-start gap-2 font-mono text-[10.5px] leading-relaxed text-muted">
          <ShieldCheck className="mt-0.5 h-3.5 w-3.5 shrink-0 text-lime/70" />
          Prüfworkflow: Einträge mit Status „ungeprüft“ stammen aus der
          Nominatim-Frischgeocodierung (Stadtebene, addresstype je Treffer).
          „statisch-fallback“-Einträge sind Platzhalter auf Ortskern-Ebene und
          ausdrücklich zum Prüfen vorgesehen. Status „geprüft“ wird vom
          Geocodierungs-Skript niemals überschrieben.
        </p>
      </section>
    </div>
  );
}

function StatKachel({
  wert,
  label,
  detail,
}: {
  wert: string;
  label: string;
  detail: string;
}) {
  return (
    <Card className="px-4 py-3.5">
      <p className="font-display text-3xl font-medium leading-none tracking-tight text-ink">
        {wert}
      </p>
      <p className="mt-1.5 text-[12px] font-medium text-ink-soft">{label}</p>
      <p className="mt-0.5 font-mono text-[10.5px] text-muted">{detail}</p>
    </Card>
  );
}
