import { readFile } from "node:fs/promises";
import path from "node:path";

export type ContactComparisonRow = {
  kv_id: string;
  name_haupt_sauber: string;
  name_zusatz_sauber: string;
  ort_sauber: string;
  ortsteil_sauber: string;
  email_sauber: string;
  telefon_sauber: string;
  web_sauber: string;
  status_abgleich: string;
  app_contact_ids: string;
  app_organisationen: string;
  app_kanaele: string;
  befund_details: string;
};

export type TermineComparisonRow = {
  sf_id: string;
  jahr: string;
  datum_original: string;
  name_original: string;
  plz_ort_original: string;
  sternchen: string;
  status_abgleich: string;
  app_event_ids: string;
  app_event_namen: string;
  app_quellen_typen: string;
  befund_details: string;
};

export type AbgleichSummary = {
  version: string;
  datum: string;
  stufe: string;
  datenbank_geaendert: boolean;
  import_ausgefuehrt: boolean;
  statistik: {
    kurverwaltungen: {
      saubere_blöcke_gesamt: number;
      abgedeckt_in_app: number;
      fehlend_in_app: number;
      app_kontakte_gesamt: number;
      app_kontakte_mit_kurverwaltungsbezug: number;
      app_kontakte_andere_chat_kontakte: number;
      dubletten_cluster_in_app: Array<{
        name: string;
        app_ids: string[];
        anzahl: number;
        saubere_referenz?: string[];
        befund?: string;
      }>;
    };
    suendenfrei_termine: {
      saubere_termine_gesamt: number;
      termine_2026: number;
      termine_2027: number;
      abgedeckt_in_app: number;
      fehlend_in_app: number;
      fehlend_prozent: number;
      app_events_gesamt: number;
      app_events_suendenfrei_typ: number;
      hauptbefund: string;
    };
    flyer_bilder: {
      app_flyer_sources: number;
      bilder_im_app_zip: number;
      bilder_im_chatexport: number;
      rekonstruierbar: boolean;
      befund: string;
    };
  };
};

export type AbgleichWorkspace = {
  summary: AbgleichSummary;
  contactsComparison: ContactComparisonRow[];
  termineComparison: TermineComparisonRow[];
};

function parseCsv(text: string): Record<string, string>[] {
  const lines = text.replace(/^\uFEFF/, "").split(/\r?\n/).filter(Boolean);
  if (lines.length < 2) return [];
  const headers = lines[0].split(";").map((h) => h.replace(/^"|"$/g, "").trim());
  return lines.slice(1).map((line) => {
    const cells = line.split(";").map((c) => c.replace(/^"|"$/g, "").trim());
    return Object.fromEntries(headers.map((h, i) => [h, cells[i] || " - "]));
  });
}

export async function getAbgleichWorkspace(): Promise<AbgleichWorkspace> {
  const basePath = path.join(process.cwd(), "werkstatt", "03-berichte");
  const [summaryRaw, contactsRaw, termineRaw] = await Promise.all([
    readFile(path.join(basePath, "abgleich-zusammenfassung.json"), "utf8"),
    readFile(path.join(basePath, "abgleich-kontakte.csv"), "utf8"),
    readFile(path.join(basePath, "abgleich-termine.csv"), "utf8"),
  ]);

  const summary = JSON.parse(summaryRaw) as AbgleichSummary;
  const contactsComparison = parseCsv(contactsRaw) as unknown as ContactComparisonRow[];
  const termineComparison = parseCsv(termineRaw) as unknown as TermineComparisonRow[];

  return { summary, contactsComparison, termineComparison };
}
