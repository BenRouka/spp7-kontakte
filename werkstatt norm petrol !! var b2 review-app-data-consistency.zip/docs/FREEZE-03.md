# SPP7 · FREEZE-03 — Beschriftungen in normaler Schreibweise

**Status: eingefroren (Pause)** · 2026-10-01 UTC
**Aktueller Einstieg bei Wiederaufnahme.** Ergänzt FREEZE-02; die Prüfpunkte FREEZE-01 und FREEZE-02 bleiben unverändert erhalten.

> Bis zur Wiederaufnahme: keine Code-, Layout-, Daten- oder Schemaänderung.
> Weiter erst nach ausdrücklicher Freigabe.

Begleitdateien:
- `docs/FREEZE-03-pruefprotokoll.txt` — automatisches Browser-, Regression-, Build- und Laufzeitprotokoll
- `docs/FREEZE-03.sha256` — SHA-256-Prüfsummen des aktuellen Arbeitsstands

## 1. Bestätigte Änderung

Die drei 12-px-Beschriftungen stehen jetzt in normaler Groß-/Kleinschreibung:

- `Tour Intelligence`
- `Klärung vor Stufe 2` · `Option A`
- `Arbeitsbereich`

Schriftart, Schriftgröße (12 px), Farbe, Position und Abstände bleiben unverändert. Im Hinweis „Klärung vor Stufe 2 · Option A“ ist auch „Option A“ normal geschrieben.

## 2. Unverändert

- Option-A-Petrol-Dunkelschema und die in FREEZE-02 bestätigte Typografie.
- Zeitmodell `zeitmodell-2026-2027-v2`, Option-B-Abgleich und beide Veranstaltungsquellen.
- Pipeline-Stufe 2 (vollständige Normierung): **nicht begonnen**.
- Rohquellen, Datenmodell/Schema und Datenbank: nicht geändert; kein Import.
- Option-B-Paket und Oberfläche: nicht geändert.
- Alle Entscheidungen und offenen Punkte aus `docs/FREEZE-01.md` sowie `docs/FREEZE-02.md` bleiben gültig.

Vergleich zur `docs/FREEZE-02.sha256`: Erwartete Abweichung ist genau `src/components/workshop.tsx` (nur die drei zuvor vereinbarten Textbeschriftungen und „Option A“ im selben Hinweis).

## 3. Wiederaufnahme

1. Dieses Dokument lesen.
2. `sha256sum -c docs/FREEZE-03.sha256` aus der Projektwurzel ausführen.
3. `node scripts/check-time-model.mjs` sowie `cd werkstatt/01-roh && sha256sum -c PRUEFSUMMEN.sha256` ausführen.
4. Aktuelle Preview und visuellen Stand ansehen.
5. Den nächsten Arbeitsschritt separat abstimmen; Stufe 2 bleibt bis zur Freigabe unangetastet.

Der vorherige Stil-Freeze ist `docs/FREEZE-02.md`; dessen historisches Manifest `docs/FREEZE-02.sha256` wird absichtlich nicht überschrieben.
