# Stufe 2 · Region / Ort / Einrichtung — aktuelle Klarstellungen

**CSV-Vertrag:** `kontaktstruktur-region-ort-einrichtung-v4`.
Die MD-/TXT-Rohquellen bleiben unverändert. Keine Datenbank, keine Migration, kein Import.

## Dateien und Kontrollzahlen

| Datei | Inhalt |
|---|---|
| `kurverwaltungen.csv` | 32 Einrichtungen aus 32 MD-Adressblöcken; Haupt- und ggf. Zusatzname in einem Eintrag |
| `kontaktstruktur.csv` | 8 Regionen, 1 übergreifende Quellgruppe, 22 angezeigte Orte, 32 Einrichtungen = 63 Knoten |
| `kontakte-struktur.json` | gleicher Baum mit allen Roh-Fundstellen, Nutzerregeln, Einrichtungsdaten und Quellenprüfsummen |
| `kontaktstruktur.md` | gegliederte Übersicht mit Original-/Ergänzungsherkunft |
| `suendenfrei-termine.csv` | bytegleich zum vorherigen Stand: 54 Quellzeilen, 60 Zeitfenster |
| `nutzer-ergaenzungen.json` | nur ausdrückliche Nutzerwerte, Namenszusätze und Strukturregeln |
| `PRUEFSUMMEN.sha256` | Prüfsummen der erzeugten Dateien und Nutzerangaben |

24 ursprüngliche H3-Fundstellen bleiben nachvollziehbar. Aus „Übergreifend“ wird kein Ort; die beiden Vitte-Fundstellen werden nach ausdrücklicher Freigabe gemeinsam angezeigt. Die Anzahl der Einrichtungen bleibt 32.

CSV: UTF-8 mit BOM, Semikolon, CRLF, alle Felder in Anführungszeichen. **Fehlmarker exakt `" - "`**, einschließlich je eines Leerzeichens. Die Leerzeichen gehören zum Wert, nicht wegtrimmen. Kein Minus-Zahlenwert und keine leeren CSV-Zellen.

## Bestätigungen aus dem aktuellen Gespräch

### Baabe-Infopavillon

„Wo ich es hinschreibe, nimm das“ gilt ausschließlich für konkret genannte Einträge. KV10 erhält `www.baabe.de` und `willkommen@baabe.de`, wie ausdrücklich angegeben. Die MD-Originalfelder bleiben `" - "`. Ohne KV10-Nutzerergänzung bleiben diese Felder fehlend; das wird im Regressionstest bewiesen. **Keine allgemeine Kontaktvererbung.**

### Middelhagen

„Ja die erste Angabe“ bestätigt die frühere Ergänzung `www.ostseebad-moenchgut.de` und `info@ostseebad-moenchgut.de`. Beide bleiben für KV12 erhalten. Die MD-Kontaktfelder, Name, Zusatzname und Dorfstraße-4-Adresse bleiben neben den ergänzten Werten stehen.

### Rügen Übergreifend — ausdrücklich kein Ort

- Anzeigename der Quellgruppe REG01: **Rügen Übergreifend**.
- Knotentyp: `gruppe`, nicht `region` oder `ort`.
- KV01 (Baltic Project GmbH / Tourismusverband Rügen e. V.) liegt unmittelbar darunter. `parent_id=REG01`, `ort_id=" - "`.
- Seine echte Postanschrift **Markt 25, 18528 Bergen auf Rügen** bleibt unverändert. Gruppierung und postalischer Ort sind unabhängig.
- `region_original` bleibt die lange ursprüngliche H2-Überschrift; `ort_original` bleibt „Übergreifend“.
- Anzeigename steht separat in `region_anzeige="Rügen Übergreifend"`, `ort_anzeige=" - "`.
- REG01 erhält beide Quellenüberschriften als `quellvorkommen`: MD-Zeile 5 und Zeile 7. Es wurde keine Rohüberschrift umgeschrieben und kein künstlicher Ort geschaffen.

### Hiddensee

- **9. Seebad Insel Hiddensee**
  - **9.1. Vitte** (kanonischer Ortsknoten ORT22)
    - **9.1.1. Insel Information Hiddensee** (KV30, Achtern Diek 18a)
    - **9.1.2. HTS / Hiddensee Touristik & Service** (KV32, Wiesenweg 21a)
  - **9.2. Kloster** (ORT23)
    - **9.2.1. Tourist Information im Hafencenter Kloster** (KV31, Hafenweg 15)

Vitte wird **nur aufgrund der ausdrücklichen Nutzerzuordnung** zusammengeführt. Beide ursprünglichen Fundstellen bleiben erhalten: ORT22 / MD-Zeile 294 und ORT24 / MD-Zeile 313. ORT24 wird nicht mehr als zweiter Anzeigeknoten geführt, seine ursprüngliche ID und Fundstelle sind in der kanonischen Vitte-Zeile verzeichnet.

HTS bleibt MD-Originalname. **Hiddensee Touristik & Service** steht als Nutzer-Namenszusatz in separaten Spalten, nicht in `name_zusatz_original`. Der Zusatz ist suchbar und wird in Baum/CSV/Bericht angezeigt. Anschriften, Telefon/Fax und E-Mails der drei Einrichtungen bleiben getrennt und unverändert.

Die Ortszuordnung sagt nicht, dass HTS oder Kloster organisatorisch der Insel Information unterstehen. Eine solche Organisationsbeziehung wurde **nicht** abgeleitet. Thiessows bereits ausdrücklich vorgegebene Organisationszuordnung zu KV12 bleibt hingegen erhalten.

## Mönchgut bleibt wie bestätigt

- 3. Halbinsel Mönchgut
  - 3.1. Ostseebad Baabe: KV09 Kurverwaltung, KV10 Infopavillon, KV11 Zimmervermittlung.
  - 3.2. Ostseebad Mönchgut: KV12 Kurverwaltung / Tourist-Information Middelhagen, KV13 Thiessow.
  - 3.3. Ostseebad Göhren: KV14 Kurverwaltung, KV15 Fremdenverkehrs-und Gewerbeverein.

KV12 bleibt ein vollständiger Quelladressblock mit Haupt- und Zusatzname. Kein zusätzlicher KV33-Eintrag. Thiessows `organisations_parent_id=KV12` ist separat vom geografischen Parent ORT06.

## CSV-Spalten (aktuell)

### `kurverwaltungen.csv` · 54 Spalten

- Identität: `kv_id`, `quellblock_id`.
- Struktur: `region_id`, `ort_id`, `parent_id`, `hierarchie_pfad`, `hierarchie_rolle`, `hierarchie_herkunft`.
- Organisation: `organisations_parent_id`, `beziehungsherkunft` — nur ausdrückliche Organisationsbeziehungen.
- Gliederungsnamen: `region_original` / `region_anzeige`, `ort_original` / `ort_anzeige`.
- Namen: `eintragsname_original`, `name_haupt_original`, `name_zusatz_original`, **`name_zusatz_ergaenzung`, `name_zusatz_normiert`, `name_zusatz_herkunft`**. Normalisiert bedeutet hier Auswahl des Originals oder des ausdrücklichen Nutzerzusatzes, keine automatische Namenskorrektur.
- Adresse: `strasse_original`, `plz_ort_original`, `plz_normiert`, `ort_normiert`.
- Ortsteil: `ortsteil_original`, `ortsteil_normiert`, `ortsteil_herkunft` — nur ausdrücklich genanntes „OT“ (Middelhagen, Thiessow, Grubnow); für die übrigen Einrichtungen `" - "`.
- Telefon/Fax/Web/E-Mail 1: jeweils `*_original`, `*_ergaenzung`, `*_normiert`, `*_herkunft`.
- Zweite E-Mail: `email_2_original`, `email_2_normiert`.
- Nutzerbeleg: `nutzer_zitat`, `quelle_ergaenzung`, `chat_msg_id`.
- Status: `hinweis`, `felder_fehlend_quelle`, `felder_fehlend_arbeitsstand`, `quellzeile`, `status_verifikation`, `quelle_stand`.

Telefon zusätzlich +49-Format; Fax getrennt als Ziffernfolge. Originals bleiben daneben. Ergänzungen beseitigen keine Lücke im Rohoriginal. Alle Einträge weiterhin `status_verifikation=nicht_verifiziert`; Nutzerangaben sind keine unabhängige Prüfung.

### `kontaktstruktur.csv` · 10 Spalten

`id`, `parent_id`, `typ`, `name`, `name_original`, `zusatzname`, `hierarchie_pfad`, `quellzeile`, `quellknoten_ids`, `herkunft`.

Bei der zusammengeführten Vitte-Zeile sind `quellzeile="294;313"` und `quellknoten_ids="ORT22;ORT24"`. Der Semikoloninhalt bleibt als eine zitierte CSV-Zelle erhalten. JSON enthält zusätzlich das vollständige Array `quellvorkommen` mit ID, Originalname und Fundstelle.

Gruppierungsnummern sind Anzeige-/Quellreihenfolge, keine amtlichen IDs. Bei der übergreifenden Gruppe kann eine Einrichtung direkt am Gruppenroot hängen; alle übrigen Einrichtungen liegen unter einem Ortsknoten.

## Prüfen

```bash
node scripts/normalize-sources.mjs --verify
node scripts/check-contact-structure.mjs
node scripts/check-time-model.mjs
cd werkstatt/02-normiert && sha256sum -c PRUEFSUMMEN.sha256
```

Ohne `--verify` erzeugt das Normierungsskript ausschließlich die abgeleiteten Dateien in `02-normiert/`. Regressionsfälle prüfen auch **ohne Nutzerregel**: keine geerbte Pavillon-E-Mail, kein erfundener HTS-Zusatz, zwei getrennte Vitte-Fundstellen. Eine ungültige Merge-Regel Vitte/Kloster wird abgewiesen.

## Prüfansicht / Downloads

Option A → Normierung → Kontaktstruktur. Gruppen-/Regionsfilter, Suche (auch „Hiddensee Touristik & Service“), auf-/zuklappbare Ortsgruppen und Original-/Herkunftsanzeige. „Rügen Übergreifend“ erscheint als Gruppe mit Hinweis „kein Ort“. Vitte zeigt beide Fundstellen.

`GET /api/review/contacts` prüft Quelle, Nutzerangaben, Prüfsummen und reproduzierbare Ableitung. Downloads `csv`, `tree`, `md`, `zip` sind allowlist-beschränkt. ZIP enthält den Normierungsentwurf, keine .env, Datenbank oder privaten Chat-Archive.

## Grenzen / Historie

- Roh-MD und Roh-TXT sind unverändert.
- Die frühere Zwei-Vitte-Anzeige und die Sonderfallfrage P7 aus FREEZE-06 sind mit diesen Nutzerregeln geklärt, nicht rückwirkend aus historischen Dateien entfernt.
- Tippfehler/„…-und…“-Schreibweisen in übrigen Kontaktnamen bleiben original.
- Kalender: 54 Terminzeilen, 60 Zeitfenster, je vier Adventswochenenden; Dresden bleibt durchgehend. Keine Änderung in diesem Schritt.
- Keine Datenbank-Schemaänderung, keine allgemeine Dublettenentscheidung; Stufe 3 und Import nicht begonnen.
