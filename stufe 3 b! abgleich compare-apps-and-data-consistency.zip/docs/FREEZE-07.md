# SPP7 · FREEZE-07 — Bestätigte Nutzerergänzungen und Hiddensee

**Aktueller Einstieg für die Wiederaufnahme.** Arbeitsstand nach den neuen Klarstellungen; FREEZE-01…06 bleiben als historische Nachweise unverändert.

## Bestätigt und berücksichtigt

1. Baabe-Infopavillon: Web/E-Mail ausschließlich aus der expliziten Nutzerangabe. Keine allgemeine Vererbung.
2. Middelhagen: frühere Angaben `www.ostseebad-moenchgut.de` und `info@ostseebad-moenchgut.de` ausdrücklich bestätigt, unverändert behalten.
3. Sondergruppe: **Rügen Übergreifend**, kein Ort. KV01 hängt direkt darunter; echte Adresse Bergen auf Rügen bleibt erhalten. Originalüberschriften neben Anzeigename und Nutzerherkunft.
4. Hiddensee: gemeinsamer Ortsknoten Vitte mit KV30 Insel Information und KV32 HTS. Kloster mit KV31 bleibt separat. Beide Vitte-Originalfundstellen (294 / 313) bleiben am kanonischen Knoten dokumentiert.
5. HTS: Originalname bleibt `HTS`; Nutzerzusatz **Hiddensee Touristik & Service** separat gespeichert, angezeigt und suchbar. Keine organisatorische Verbindung zu Insel Information erfunden.

## Aktueller Normierungsstand

- Modell: `kontaktstruktur-region-ort-einrichtung-v4`.
- 32 Einrichtungen aus 32 Rohblöcken; 8 Regionen + 1 Quellgruppe, 22 angezeigte Orte; 63 Strukturknoten.
- 24 H3-Rohfundstellen bleiben nachvollziehbar (davon Übergreifend kein Ort, Vitte zweimal in der MD).
- Kontakt-CSV: 54 Spalten, Struktur-CSV: 10 Spalten; separate Namenszusatz- und Original-/Anzeige-Felder.
- Ortsteil weiterhin nur aus explizitem OT: Middelhagen, Thiessow, Grubnow.
- Fehlwerte unverändert exakt `" - "` einschließlich der beiden Leerzeichen.
- CSV-Vertrag: `werkstatt/02-normiert/LIESMICH.md`.

## Schutzbereich unverändert

Roh-MD, Roh-TXT, .env, Datenbankschema, Termin-CSV, Zeitmodell und Option-B-ZIP nicht verändert. Keine DB-Tabellen oder Imports. A/B-Gleichstand betrifft das Zeitmodell; die Kontakt-Prüfansicht ist nur Option A. Stufe 3 nicht begonnen.

## Historie

Die FREEZE-06-Aussage „zwei Vitte-Ortsknoten“ und die offene Frage P7 gelten nur für den früheren Stand. Sie sind jetzt durch ausdrückliche Nutzerregeln geklärt. Gleichnamige Orte werden weiterhin nicht automatisch zusammengeführt. Organisations- und Ortsbeziehungen bleiben getrennt.

Weiter offen: Namensschreibweisen P4, Bestands-Dubletten F3, spätere Datenbankentscheidungen E3/E4, Datenschutz E5. Keine nächste Stufe automatisch ausführen.

## Wiederaufnahme / Prüfung

1. Dieses Dokument und `werkstatt/02-normiert/LIESMICH.md` lesen.
2. `sha256sum -c docs/FREEZE-07.sha256`.
3. `node scripts/normalize-sources.mjs --verify` und `node scripts/check-contact-structure.mjs`.
4. Kalender/A/B prüfen: `node scripts/check-time-model.mjs`.
5. Rohquellen-Prüfsummen prüfen. Nächsten Schritt ausdrücklich abstimmen.

Prüfergebnisse: `docs/FREEZE-07-pruefprotokoll.txt`. Historische Freeze-Dokumente nicht überschreiben. Keine .env oder Build-Artefakte im aktuellen Freeze-Manifest.
