import "server-only";
import { createHash } from "node:crypto";
import { readFile } from "node:fs/promises";
import path from "node:path";
import { buildContactReview } from "@/lib/contact-hierarchy";

const originalAddressSha256 = "28512c72423ac270d4c423007b29dc85266e6938441d830bf0ec8a3239c1bfa1";
export async function getContactReview() {
  // Only this allowlisted local source; no URL/path from a request and no DB writes.
  const raw = await readFile(path.join(process.cwd(), "werkstatt", "01-roh", "Kurverwaltungen_2025.md"));
  const checksum = createHash("sha256").update(raw).digest("hex");
  if (checksum !== originalAddressSha256) throw new Error("Die Original-Kurverwaltungsquelle wurde verändert.");
  return buildContactReview(raw.toString("utf8"), checksum);
}
