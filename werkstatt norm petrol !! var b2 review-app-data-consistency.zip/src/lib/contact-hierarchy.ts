// Read-only contact clarification. This is not the complete stage-2 normalization.
export const contactReviewVersion = "kontaktklaerung-v2";
export const missingContactMarker = "-";
export type ContactKind = "telefon" | "fax" | "internet" | "email";
export type ContactOrigin = "md" | "nutzer" | "fehlt";
export type PhoneResult = {
  original: string | null;
  international: string | null;
  display: string | null;
  status: "fehlt" | "abgeleitet" | "vorhanden" | "pruefen";
  rule: string | null;
};

// +49 is explicitly approved for this German/Rügen source, not a global default.
// Syntax conversion does not verify reachability or ownership of a number.
export function internationalGermanPhone(raw: string | null): PhoneResult {
  if (raw === null || raw.trim() === "" || raw.trim() === "-") {
    return { original: raw, international: null, display: null, status: "fehlt", rule: null };
  }
  const text = raw.trim();
  if (!/^[+\d\s()./-]+$/.test(text)) return { original: raw, international: null, display: null, status: "pruefen", rule: null };
  const compact = text.replace(/[\s()./-]/g, "");
  let international: string;
  let rule: string;
  let status: PhoneResult["status"];
  if (/^0[1-9]\d+$/.test(compact)) {
    international = `+49${compact.slice(1)}`;
    rule = "de_49_freigegeben";
    status = "abgeleitet";
  } else if (/^\+49[1-9]\d+$/.test(compact)) {
    international = compact;
    rule = "international_bereits_in_quelle";
    status = "vorhanden";
  } else if (/^0049[1-9]\d+$/.test(compact)) {
    international = `+${compact.slice(2)}`;
    rule = "international_00_zu_plus";
    status = "abgeleitet";
  } else {
    return { original: raw, international: null, display: null, status: "pruefen", rule: null };
  }
  if (international.length < 8 || international.length > 16) {
    return { original: raw, international: null, display: null, status: "pruefen", rule: null };
  }
  // Only group an area code explicitly separated in the source. Do not guess it.
  const parentheses = /^\(([^)]+)\)\s*(.+)$/.exec(text);
  const alreadyGrouped = /^\+49\s+([1-9]\d+)\s+([\d\s]+)$/.exec(text);
  let display = international;
  if (parentheses) {
    const area = parentheses[1].replace(/\s/g, "");
    const subscriber = parentheses[2].replace(/\s/g, "");
    if (/^0[1-9]\d+$/.test(area) && /^\d+$/.test(subscriber)) display = `+49 ${area.slice(1)} ${subscriber}`;
  } else if (alreadyGrouped) {
    display = `+49 ${alreadyGrouped[1]} ${alreadyGrouped[2].replace(/\s/g, "")}`;
  }
  return { original: raw, international, display, status, rule };
}

export type AddressBlock = {
  id: string;
  names: string[];
  street: string;
  postalCity: string;
  startLine: number;
  endLine: number;
  originalBlock: string;
  channels: Array<{ type: ContactKind; value: string; line: number }>;
};

export function readAddressBlocks(md: string): AddressBlock[] {
  const lines = md.split(/\r?\n/);
  const blocks: AddressBlock[] = [];
  let current: AddressBlock | null = null;
  let previousBold = false;
  const channelKinds: Record<string, ContactKind> = { Telefon: "telefon", Fax: "fax", Internet: "internet", "E-Mail": "email" };
  function finish() {
    if (current) {
      current.originalBlock = lines.slice(current.startLine - 1, current.endLine).join("\n");
      blocks.push(current);
      current = null;
    }
  }
  for (const [index, raw] of lines.entries()) {
    const line = raw.trim();
    if (line === "---") { finish(); break; }
    if (line.startsWith("#")) { finish(); previousBold = false; continue; }
    const bold = /^\*\*(.+)\*\*\s*$/.exec(line);
    if (bold) {
      if (current && previousBold) { current.names.push(bold[1]); current.endLine = index + 1; }
      else {
        finish();
        current = { id: `KV${String(blocks.length + 1).padStart(2, "0")}`, names: [bold[1]], street: "", postalCity: "", startLine: index + 1, endLine: index + 1, originalBlock: "", channels: [] };
      }
    } else if (current && line) {
      current.endLine = index + 1;
      const channel = /^(Telefon|Fax|Internet|E-Mail):\s*(.*)$/.exec(line);
      if (channel) current.channels.push({ type: channelKinds[channel[1]], value: channel[2], line: index + 1 });
      else if (/^\d{5}\s/.test(line)) current.postalCity = line;
      else if (!current.street && !line.startsWith("_")) current.street = line;
    }
    previousBold = Boolean(bold);
  }
  finish();
  return blocks;
}

export type ContactValue = {
  type: ContactKind;
  value: string | null;
  mdValue: string | null;
  mdLine: number | null;
  origin: ContactOrigin;
  evidence: string;
  status: "aus_md" | "nutzerangabe" | "nicht_genannt" | "fehlt_laut_nutzer";
  phone: PhoneResult | null;
};
export type ContactLocation = {
  id: string;
  parentId: string;
  displayNumber: string;
  title: string;
  subtitle: string | null;
  street: string;
  postalCity: string;
  sourceLines: { from: number; to: number };
  originalBlock: string;
  note: string | null;
  channels: ContactValue[];
};
export type ContactGroup = {
  id: string;
  name: string;
  displayNumber: string;
  origin: "nutzer";
  children: ContactLocation[];
};
export type ContactReview = {
  version: string;
  scope: "vier_beispielstandorte";
  stage2Started: false;
  databaseChanged: false;
  sourceFile: string;
  sourceSha256: string;
  groups: ContactGroup[];
  counts: { originalLocations: number; originalContactValues: number; supplementedContactValues: number; addedContactValues: number; originalMissingEmails: number; remainingMissingEmails: number; parentGroups: number; exampleLocations: number };
  rules: { missingMarker: string; phoneRegion: "DE"; inheritance: "keine"; hierarchySource: string };
};

// Values supplied explicitly by the user in the contact clarification message.
// No values are inherited merely because two offices share a parent.
export const contactClarifications = {
  sourceId: "nutzer-kontaktklaerung-01",
  sourceLabel: "Deine Kontaktklärung (Mönchgut, Baabe, Parent/Child und +49)",
  groups: [
    { id: "KVG01", name: "Ostseebad Mönchgut", displayNumber: "1", locationIds: ["KV12", "KV13"] },
    { id: "KVG02", name: "Ostseebad Baabe", displayNumber: "2", locationIds: ["KV09", "KV10"] },
  ],
  additions: [
    { locationId: "KV12", type: "internet" as ContactKind, value: "www.ostseebad-moenchgut.de" },
    { locationId: "KV12", type: "email" as ContactKind, value: "info@ostseebad-moenchgut.de" },
    { locationId: "KV13", type: "telefon" as ContactKind, value: "+49 38308 66010" },
  ],
  explicitMissing: [{ locationId: "KV13", type: "fax" as ContactKind, suppliedValue: "-" }],
  // Recorded as user-cited chat excerpts, not independently re-verified chat IDs.
  citedChat: [
    "Tourist-Info Thiessow info@ostseebad-moenchgut.de Insel Rügen",
    "Kurverwaltung Baabe willkommen@baabe.de Insel Rügen",
  ],
} as const;

export function buildContactReview(md: string, sourceSha256: string): ContactReview {
  const blocks = readAddressBlocks(md);
  if (blocks.length !== 32) throw new Error("Die Kurverwaltungsquelle enthält nicht die erwarteten 32 Blöcke.");
  const byId = new Map(blocks.map((block) => [block.id, block]));
  const groups: ContactGroup[] = contactClarifications.groups.map((group) => ({
    id: group.id, name: group.name, displayNumber: group.displayNumber, origin: "nutzer",
    children: group.locationIds.map((id, index) => {
      const block = byId.get(id);
      if (!block) throw new Error("Die benannte Außenstelle fehlt in der Originalquelle.");
      const channels: ContactValue[] = (["internet", "email", "telefon", "fax"] as const).map((type) => {
        const fromMd = block.channels.filter((item) => item.type === type);
        if (fromMd.length > 1) throw new Error("Mehrere Kanäle gleichen Typs in einer Beispielstelle benötigen eine Einzelzuordnung.");
        const addition = contactClarifications.additions.find((item) => item.locationId === id && item.type === type);
        const explicitlyMissing = contactClarifications.explicitMissing.some((item) => item.locationId === id && item.type === type);
        const value = addition ? addition.value : explicitlyMissing ? null : fromMd[0]?.value ?? null;
        const status: ContactValue["status"] = addition ? "nutzerangabe" : explicitlyMissing ? "fehlt_laut_nutzer" : fromMd.length ? "aus_md" : "nicht_genannt";
        return {
          type, value, mdValue: fromMd[0]?.value ?? null, mdLine: fromMd[0]?.line ?? null,
          origin: addition || explicitlyMissing ? "nutzer" : fromMd.length ? "md" : "fehlt",
          evidence: addition || explicitlyMissing ? contactClarifications.sourceId : fromMd.length ? `Kurverwaltungen_2025.md:L${fromMd[0].line}` : `Kurverwaltungen_2025.md:L${block.startLine}-L${block.endLine} (nicht angegeben)`,
          status,
          phone: type === "telefon" ? internationalGermanPhone(value) : null,
        };
      });
      return {
        id, parentId: group.id, displayNumber: `${group.displayNumber}.${index + 1}`,
        title: block.names[0], subtitle: block.names[1] ?? null,
        street: block.street, postalCity: block.postalCity,
        sourceLines: { from: block.startLine, to: block.endLine }, originalBlock: block.originalBlock,
        note: id === "KV10" ? "außer Winter (Originalhinweis)" : null, channels,
      };
    }),
  }));
  const originalContactValues = blocks.reduce((sum, block) => sum + block.channels.length, 0);
  const originalMissingEmails = blocks.filter((block) => !block.channels.some((channel) => channel.type === "email")).length;
  const addedContactValues = groups.flatMap((group) => group.children).flatMap((location) => location.channels).filter((value) => value.mdValue === null && value.value !== null).length;
  const addedEmails = contactClarifications.additions.filter((item) => item.type === "email").length;
  return {
    version: contactReviewVersion, scope: "vier_beispielstandorte", stage2Started: false, databaseChanged: false,
    sourceFile: "Kurverwaltungen_2025.md", sourceSha256, groups,
    counts: { originalLocations: blocks.length, originalContactValues, supplementedContactValues: originalContactValues + addedContactValues, addedContactValues, originalMissingEmails, remainingMissingEmails: originalMissingEmails - addedEmails, parentGroups: groups.length, exampleLocations: groups.reduce((sum, group) => sum + group.children.length, 0) },
    rules: { missingMarker: missingContactMarker, phoneRegion: "DE", inheritance: "keine", hierarchySource: contactClarifications.sourceId },
  };
}

export function contactReviewMarkdown(review: ContactReview): string {
  const lines = [
    "# Kontaktklärung · Parent/Child und Nutzerergänzungen", "",
    `Stand: ${review.version}. Vier Beispielstandorte, keine vollständige Stufe-2-Normierung und keine Datenbankänderung.`, "",
    `Original-MD: ${review.sourceFile} · SHA-256 ${review.sourceSha256}.`,
    `Die Originalquelle behält ${review.counts.originalLocations} Blöcke und ${review.counts.originalContactValues} Kontaktwerte. Mit drei ausdrücklich ergänzten Werten sind ${review.counts.supplementedContactValues} Kontaktwerte belegt.`,
    "", "## Regeln", "",
    "- Parents sind Standortgruppen aus Nutzervorgabe; getrennte Adressen/Außenstellen bleiben getrennte Child-Datensätze.",
    "- Zwei Namen an derselben Adresse allein begründen keine neue Außenstelle. Die vier originalen Doppel-Namensblöcke bleiben als Quellenbefund bestehen.",
    "- Kein automatisches Erben von E-Mail, Telefon, Website oder Fax. Baabes Infopavillion bekommt nicht die E-Mail der Kurverwaltung.",
    "- Fehlende Werte werden als - angezeigt; intern null plus Fehlstatus. Originalfelder werden nicht mit einem erfundenen Strich überschrieben.",
    "- Zusätzliche +49-Form ist für die deutsche/Rügen-Quelle freigegeben. Original bleibt erhalten; die Umrechnung ist keine Erreichbarkeitsprüfung.",
    "- www-Adressen werden nicht stillschweigend um http:// oder https:// ergänzt.", "",
  ];
  for (const group of review.groups) {
    lines.push(`## ${group.displayNumber} · ${group.name} (${group.id})`, "", "Parent-Herkunft: ausdrückliche Nutzerzuordnung.", "");
    for (const location of group.children) {
      lines.push(`### ${location.displayNumber} · ${location.title} (${location.id})`, "",
        `Zusatzname: ${location.subtitle ?? "-"}`, `Adresse: ${location.street} · ${location.postalCity}`,
        `MD-Quelle: Zeilen ${location.sourceLines.from}–${location.sourceLines.to}.`, "",
        "| Feld | Aktueller Wert | MD-Wert | Herkunft / Status | Internationale Telefonform |", "|---|---|---|---|---|");
      for (const value of location.channels) lines.push(`| ${value.type} | ${value.value ?? "-"} | ${value.mdValue ?? "- (nicht angegeben)"} | ${value.evidence}; ${value.status} | ${value.phone?.display ?? "-"} |`);
      lines.push("");
    }
  }
  lines.push("## E-Mail-Lücken", "",
    `Unveränderte MD: ${review.counts.originalMissingEmails} Blöcke ohne E-Mail. Nach der Nutzerergänzung von Middelhagen verbleibt ${review.counts.remainingMissingEmails}: Infopavillion KV Baabe.`,
    "Die leere E-Mail im MD-Original von Mönchgut/Middelhagen bleibt erhalten; der ergänzte Wert ist ausschließlich als Nutzerangabe geführt.", "",
    "## Telefonnummer-Test", "", "(0 38 38) 80 77 80 → +49 3838 807780 (maschinenlesbar +493838807780).", "",
    "Middelhagen und Thiessow haben nach Nutzervorgabe dieselbe Telefonnummer; ihre eigenständigen Adressen werden deshalb nicht zusammengeführt.", "");
  return lines.join("\n");
}
