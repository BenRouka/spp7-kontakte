import type { ReactNode } from "react";
import clsx from "clsx";

export function Eyebrow({
  children,
  className,
}: {
  children: ReactNode;
  className?: string;
}) {
  return (
    <p
      className={clsx(
        "font-mono text-[11px] font-semibold uppercase tracking-[0.22em] text-muted",
        className,
      )}
    >
      {children}
    </p>
  );
}

export function SectionHead({
  eyebrow,
  title,
  right,
  className,
}: {
  eyebrow: string;
  title: ReactNode;
  right?: ReactNode;
  className?: string;
}) {
  return (
    <div className={clsx("mb-6 flex flex-wrap items-end justify-between gap-4", className)}>
      <div>
        <Eyebrow>{eyebrow}</Eyebrow>
        <h2 className="font-display mt-2 text-[clamp(1.6rem,3vw,2.2rem)] font-medium leading-[1.08] tracking-tight text-ink">
          {title}
        </h2>
      </div>
      {right ? <div className="pb-1">{right}</div> : null}
    </div>
  );
}

export function Card({
  children,
  className,
  lift = false,
}: {
  children: ReactNode;
  className?: string;
  lift?: boolean;
}) {
  return (
    <div
      className={clsx(
        "rounded-xl border border-line bg-raised/80",
        lift && "card-lift",
        className,
      )}
    >
      {children}
    </div>
  );
}

export function Badge({
  children,
  tone = "neutral",
  className,
}: {
  children: ReactNode;
  tone?: "neutral" | "lime" | "amber" | "red";
  className?: string;
}) {
  const tones = {
    neutral: "border-line bg-raised2/70 text-ink-soft",
    lime: "border-lime/35 bg-lime/10 text-lime",
    amber: "border-amber/35 bg-amber/10 text-amber",
    red: "border-red/40 bg-red/10 text-red",
  } as const;
  return (
    <span
      className={clsx(
        "inline-flex items-center gap-1 rounded-full border px-2 py-0.5 font-mono text-[10px] font-medium uppercase tracking-[0.1em]",
        tones[tone],
        className,
      )}
    >
      {children}
    </span>
  );
}

export function MonoValue({
  label,
  value,
  sub,
  className,
}: {
  label: string;
  value: ReactNode;
  sub?: ReactNode;
  className?: string;
}) {
  return (
    <div className={clsx("min-w-0", className)}>
      <p className="font-mono text-[10px] uppercase tracking-[0.18em] text-muted">
        {label}
      </p>
      <p className="tnum mt-1 text-[clamp(1.7rem,2.6vw,2.3rem)] font-medium leading-none text-ink">
        {value}
      </p>
      {sub ? (
        <p className="mt-1.5 text-[12px] leading-snug text-muted">{sub}</p>
      ) : null}
    </div>
  );
}

export function Empty({ children }: { children: ReactNode }) {
  return (
    <span className="font-mono text-[11px] text-muted/60">— {children}</span>
  );
}
