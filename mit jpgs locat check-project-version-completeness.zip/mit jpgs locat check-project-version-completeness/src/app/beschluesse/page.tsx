import {
  ArrowRight,
  CheckCircle2,
  CircleDot,
  Scale,
  Wrench,
} from "lucide-react";
import { getBeschluesseGruppiert, getBeschlussStats } from "@/lib/data";
import { Badge, Eyebrow } from "@/components/ui";
import type { Beschluss } from "@/db/schema";

export const dynamic = "force-dynamic";

function StatusBadge({ status }: { status: string }) {
  if (status === "entschieden") {
    return (
      <Badge tone="lime">
        <CheckCircle2 className="h-3 w-3" />
        entschieden
      </Badge>
    );
  }
  return (
    <Badge tone="amber">
      <CircleDot className="h-3 w-3" />
      provisorisch
    </Badge>
  );
}

function BeschlussKarte({ b, index }: { b: Beschluss; index: number }) {
  const istB20 = b.id === "B-20";
  return (
    <article
      id={b.id}
      className="rise card-lift rounded-xl border border-line bg-raised/80 p-5"
      style={{ animationDelay: `${Math.min(index, 8) * 50}ms` }}
    >
      <div className="flex flex-wrap items-center gap-2">
        <span className="rounded border border-line-soft bg-raised2 px-2 py-0.5 font-mono text-[11px] font-semibold tracking-wide text-ink">
          {b.id}
        </span>
        <StatusBadge status={b.status} />
        {istB20 ? (
          <Badge tone="neutral">historischer Zustand → Stufe 5 abgeschlossen</Badge>
        ) : null}
      </div>
      <h3 className="font-display mt-3 text-[clamp(1.15rem,2vw,1.4rem)] font-medium leading-snug tracking-tight text-ink">
        {b.titel}
      </h3>

      <div className="mt-4 grid gap-3 lg:grid-cols-3">
        <div className="rounded-lg border border-lime/20 bg-lime/[0.04] p-3">
          <p className="flex items-center gap-1.5 font-mono text-[9.5px] font-semibold uppercase tracking-[0.14em] text-lime">
            <Scale className="h-3 w-3" />
            Prio 1 · Basis
          </p>
          <p className="mt-1.5 text-[12.5px] leading-snug text-ink-soft">
            {b.prio1Basis}
          </p>
        </div>
        <div className="rounded-lg border border-amber/20 bg-amber/[0.04] p-3">
          <p className="flex items-center gap-1.5 font-mono text-[9.5px] font-semibold uppercase tracking-[0.14em] text-amber">
            <Scale className="h-3 w-3" />
            Prio 2 · Ergänzung
          </p>
          <p className="mt-1.5 text-[12.5px] leading-snug text-ink-soft">
            {b.prio2Ergaenzung}
          </p>
        </div>
        <div className="rounded-lg border border-line-soft bg-raised2/50 p-3">
          <p className="flex items-center gap-1.5 font-mono text-[9.5px] font-semibold uppercase tracking-[0.14em] text-muted">
            <Wrench className="h-3 w-3" />
            Maßnahme
          </p>
          <p className="mt-1.5 text-[12.5px] leading-snug text-ink-soft">
            {b.massnahme}
          </p>
        </div>
      </div>

      {istB20 ? (
        <p className="mt-3 rounded-lg border border-lime/25 bg-lime/[0.05] px-3 py-2 text-[12px] leading-snug text-lime-soft">
          Dieser Beschluss dokumentiert den Zustand bei Übergabe (0 Tabellen,
          kein Import). Stufe 5 setzt exakt hier an — das Import-Protokoll
          unter <a href="/stufe-5" className="underline decoration-lime/40 underline-offset-2">/stufe-5</a> weist
          die sechs Tabellen und den verifizierten Lauf nach.
        </p>
      ) : null}
    </article>
  );
}

export default async function BeschluessePage() {
  const [gruppen, stats] = await Promise.all([
    getBeschluesseGruppiert(),
    getBeschlussStats(),
  ]);

  let cardIndex = 0;

  return (
    <div className="space-y-10">
      <section className="rise pt-4">
        <Eyebrow>Beschlussverzeichnis · aus der Datenbank</Eyebrow>
        <div className="mt-4 flex flex-wrap items-end justify-between gap-6">
          <h1 className="font-display max-w-3xl text-[clamp(2.2rem,5vw,3.8rem)] font-medium leading-[1.02] tracking-tight text-ink">
            {stats.gesamt} Beschlüsse — <span className="text-lime">verbindlich</span>, nicht verhandelbar.
          </h1>
          <div className="flex flex-wrap gap-2 pb-1">
            <Badge tone="lime">{stats.entschieden} entschieden</Badge>
            <Badge tone="amber">{stats.provisorisch} provisorisch</Badge>
          </div>
        </div>
        <p className="mt-4 max-w-2xl text-[14px] leading-relaxed text-ink-soft">
          Jeder Beschluss führt seine Prio-1-Basis (MD / offizielle Website /
          Register), die ergänzende Prio-2-Schicht (Chat / App-Altbestand)
          und die Maßnahme. Prio 1 gilt immer, Prio 2 ergänzt Lücken und
          überschreibt nie (B-15).
        </p>
      </section>

      {gruppen.map((g) => (
        <section key={g.bereich}>
          <div className="mb-4 flex items-baseline gap-3 border-b border-line pb-3">
            <ArrowRight className="h-4 w-4 translate-y-0.5 text-lime" />
            <h2 className="font-display text-[clamp(1.4rem,2.6vw,1.9rem)] font-medium tracking-tight text-ink">
              {g.bereich}
            </h2>
            <span className="ml-auto font-mono text-[11px] text-muted">
              {g.beschluesse.length} {g.beschluesse.length === 1 ? "Beschluss" : "Beschlüsse"}
            </span>
          </div>
          <div className="space-y-4">
            {g.beschluesse.map((b) => (
              <BeschlussKarte key={b.id} b={b} index={cardIndex++} />
            ))}
          </div>
        </section>
      ))}
    </div>
  );
}
