# Ostsee-Tour: Auftritte 2026 und Vormerkungen 2027

Änderungsprotokoll für die bestehende Eventstruktur. Es wurden **keine neuen Events für die beiden Auftritte** angelegt: T04 und T09 bleiben Standort-/Tourstoppeinträge, zu denen jeweils ein bestätigter Datumseintrag ergänzt wurde. Kein Termin 2027 wurde für diese zwei Orte erfunden.

## 21.07.2026 – Rügenhof Putgarten (T04)

- **Beleg aus erster Hand:** Band bestätigt gespielten Auftritt am 21.07.2026.
- **Öffentlicher Beleg:** [Piratenfest Rügenhof Putgarten bei Visit MV](https://www.visit-mv.com/event-search/e-pirate-festival-ruegenhof-putgarten-21-july-2026): nennt SPP & die 7 Generäle ausdrücklich; Veranstaltung 13–18 Uhr, keine separate Spielzeit angegeben.
- **Vorher:** T04 zeigte nur den Chat-Tourplan #44031 für 20./21./26.08.2026, ohne Juli-Auftritt.
- **Nachher:** zusätzlicher Termin 21.07.2026 mit Art „SPP7-Auftritt 2026 (gespielt, bestätigt)“. Die Augusttermine bleiben als **Chat-Tourplan** erhalten und sind nicht als gespielte Auftritte bestätigt.
- **2027:** Von der Band vorgemerkt; kein öffentlicher Termin für ein erneutes Piratenfest / einen SPP7-Auftritt gefunden. Keine 2027-Datumzeile angelegt.
- **Veranstalter der 2026-Veranstaltung:** Tourismusgesellschaft Kap Arkona mbH (laut [Inselticker](https://www.inselticker-ruegen.de/events/piratenfest-auf-dem-ruegenhof)).

## 22.07.2026 – Hafen Schaprode (T09)

- **Beleg aus erster Hand:** Band bestätigt gespielten Auftritt am 22.07.2026 beim „Hafenfest“.
- **Öffentlicher Beleg:** [Veranstaltungen der Rügener Hafen und Touristik GmbH](https://hafen-schaprode.de/de/veranstaltungen/) bezeichnet das Fest als **„Piratenfest“** am 22.07.2026, 15–18 Uhr, und nennt SPP & die 7 Generäle ausdrücklich. Veranstaltungstermin, keine separate Spielzeit.
- **Vorher:** T09 war nur „Schaprode (Vormerkung 2027)“ mit Datum 21.–23.08.2026 für das **andere** Wikingerfest/Blauzahntage (kein SPP7-Auftritt belegt).
- **Nachher:** Name „Hafen Schaprode“; zusätzlicher Termin 22.07.2026 mit Art „SPP7-Auftritt 2026 (gespielt, bestätigt)“. Blauzahntage bleiben getrennt als Termin eines anderen Festes.
- **2027:** Von der Band vorgemerkt; kein öffentlicher Termin / kein bestätigter SPP7-Auftritt für 2027 gefunden. Keine 2027-Datumzeile angelegt.
- **Veranstalter 2026:** Rügener Hafen und Touristik GmbH laut eigener Website.

## Karte / Orientierung

Die vier 2027-Tourstationen werden nun mit unterschiedlichen Zuständen angezeigt:

- **Poel 16.–18.07.2027** und **Wallensteintage Stralsund 22.–25.07.2027**: Termine der jeweiligen **Veranstaltung** laut Sündenfrei, nicht als SPP7-Buchung behauptet.
- **Rügenhof Putgarten** und **Hafen Schaprode**: Vormerkungen **ohne 2027-Termin**; die bestätigten SPP7-Auftritte vom Juli 2026 stehen in ihren jeweiligen Termindetails.
- **Zentralcamp Putgarten:** Nutzerangabe ca. zwei Wochen; gleiche Karte/Koordinaten wie der Rügenhof, kein eigener Auftritt.

Die Übersichtssuche durchsucht die vorhandenen Events, Termine, Locations, explizit erfassten Veranstalter, Adressen und Kontakte, ohne neue oder vermutete Ansprechpartner anzulegen.
