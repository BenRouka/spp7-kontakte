import { zipSync } from "fflate";
import { getContactWorkspace } from "@/lib/contact-repository";

export const dynamic = "force-dynamic";
export const runtime = "nodejs";
export async function GET(request: Request) {
  const format = new URL(request.url).searchParams.get("format") || "json";
  if (!["json", "csv", "tree", "md", "zip"].includes(format)) return Response.json({ error: "Erlaubt: json, csv, tree, md, zip." }, { status: 400 });
  try {
    const { data, files } = await getContactWorkspace();
    const headers: Record<string, string> = { "Cache-Control": "no-store", "X-SPP7-Contact-Version": data.version };
    if (format === "json") return Response.json(data, { headers });
    if (format === "zip") {
      const archive = zipSync(files, { level: 6, mtime: new Date("1980-01-01T00:00:00Z") });
      return new Response(new Uint8Array(archive).buffer, { headers: {
        ...headers, "Content-Type": "application/zip", "Content-Disposition": 'attachment; filename="spp7-normierungsentwurf-v4.zip"',
      } });
    }
    const name = format === "csv" ? "kurverwaltungen.csv" : format === "tree" ? "kontaktstruktur.csv" : "kontaktstruktur.md";
    return new Response(new Uint8Array(files[name]).buffer, { headers: {
      ...headers, "Content-Type": `${format === "md" ? "text/markdown" : "text/csv"}; charset=utf-8`,
      "Content-Disposition": `attachment; filename="${name}"`,
    } });
  } catch {
    return Response.json({ error: "Die Kontaktstruktur konnte nicht anhand ihrer Rohquelle und Prüfsummen bestätigt werden. Es wurde nichts importiert." }, { status: 503 });
  }
}
