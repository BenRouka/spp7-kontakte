# Befundbericht C — Welches Altmaterial hängt tatsächlich an den kuratierten Daten?

**Stand:** 2026-10-04 · rein lesend, keine Änderung
**Frage:** Welche der Zusatzgruppen beziehen sich auf die 54 kuratierten Termine / 35 Kontakte, was bleibt „Rest"?
**Basis:** Abgleichmatrix (54 Termine), 3 Fehlzuordnungen (SF02/SF04/SF05) ausgeschlossen → **51 Termine ↔ 43 Alt-Events** belastbar.

---

## 1. Kernbefund: Die kuratierten Termine und das reiche Material sind nahezu DISJUNKT

| Gruppe | an kuratierten (43 Events) | am Rest (197 Events) | Gesamt |
|---|---:|---:|---:|
| event_acts (Bands) | **0** | 270 | 270 |
| event_partners | **0** | 46 | 46 |
| event_features | **0** | 47 | 47 |
| timetable | **0** | 15 | 15 |
| **flyer_sources** | **0** | 76 | 79 |
| feed_context | **0** | 21 | 22 |
| event_channels | 5 | 75 | 80 |
| event_tags | 39 (18 distinkt) | 672 | 711 |
| event_dates | 57 | 183 | 240 |

**Eventfelder an den 43 kuratierten Events:**

| Feld | gefüllt |
|---|---|
| BEWERBUNG / BEWERBUNG_STATUS | **0 / 43** |
| GAGE / KONDITIONEN / EINTRITT | **0 / 43** |
| FLYER | **0 / 43** |
| LANGBESCHREIBUNG | 0 / 43 |
| KURZBESCHREIBUNG | 9 / 43 |
| LAT/LNG | **41 / 43** |
| PASSUNG_SPP7 / NAECHSTER_SCHRITT / UNKLAR | 43 / 43 (Standardtexte) |
| QUELLE_TYP | 39× „Sündenfrei", 4× „Chat (KI-Liste)" |

Die drei vollbesetzten Felder sind **Serientexte ohne Informationsgehalt**, z. B.:
- PASSUNG_SPP7: „unbewertet - reine Terminliste, keine Bewerbungsdaten"
- UNKLAR: „Terminliste ohne Booking-/Gagenangaben."
- NAECHSTER_SCHRITT: „Termin beim Veranstalter verifizieren, Konditionen erfragen"

**Schlussfolgerung:** Flyer, Bewerbungen, Gagen, Acts, Partner, Timetable und Beschreibungen gehören **ausschließlich** zur Festival-/Chat-Sammlung (F/M/K/C/T/R-Events) — **nicht** zu den kuratierten Sündenfrei-Terminen. Die frühere Annahme „Flyer/Bewerbungen/Gagen gehören zu unseren Terminen" trifft **nicht** zu.

---

## 2. Was von den kuratierten Daten tatsächlich profitiert

| Material | Nutzen | Einschränkung |
|---|---|---|
| **Event-Koordinaten** | 41/43 Termine | ⚠️ 34 davon nur **PLZ-Zentroid** (1–10 km, kein Veranstaltungsgelände), 2 OSM, 7 sonstige → O-11-Prüfliste zwingend |
| **Kontakt-Koordinaten** | 36/37 KV-bezogene Kontakte | dito |
| **Tags** | 39 Zeilen, 18 distinkt (Sündenfrei, Mittelalter, Markt, Ostsee, Stolpen, Winter, Vormerkung2027 …) | geringer Umfang, teils redundant zu Region/Typ |
| **Channels** | 5 Zeilen | marginal |
| **Herkunftsvermerk QUELLE_TYP** | 43/43 | **strukturell wertvoll** — fertiges Prio-Modell |
| **Kontakt-Notizen/MSG-Verweise** | 12 Notizen, 29 Chat-Verweise an 37 Kontakten | Belegspur in den Chat |

---

## 3. Bewertung des vorgeschlagenen Wegs

**Der Vorschlag lautet:** nur das übernehmen, was sich auf kuratierte Daten bezieht; den Rest stehen lassen; die **Struktur** aber mitübernehmen.

**Bewertung: gangbar und empfehlenswert — mit einer Präzisierung.**

**Was dafür spricht:**
1. Der Datenimport bleibt winzig und vollständig prüfbar: 41 Koordinaten + 39 Tag-Zeilen + 5 Channels + 37 Kontaktbezüge. Das ist in einer Sitzung belegbar durchzugehen.
2. Keine unkuratierte Masse in der Werkstatt — die Prio-1-Disziplin bleibt erhalten.
3. Die Struktur ist erprobt (Alt-App + Mockup laufen damit) und erlaubt späteres Nachziehen ohne zweiten Umbau.

**Präzisierung — die wichtigste Konsequenz:**
Wenn die Struktur für Flyer/Acts/Bewerbungen/Gagen angelegt wird, bleiben diese Tabellen zunächst **leer**, weil kein einziger kuratierter Termin solche Daten hat. Das ist kein Fehler, sondern Absicht: Platzhalter für späteres Material. Die Alternative wäre, diese Strukturen erst dann anzulegen, wenn Inhalte dafür vorliegen.

⚠️ **Hinweis Datenmodell:** Struktur anlegen = Schemaerweiterung. Leere Tabellen kosten nichts, erhöhen aber die Komplexität von Migrationen und UI.

**Dritter Weg (zur Abwägung):** „Struktur light" — nur Tabellen anlegen, die sofort Inhalt bekommen (Geo, Tags, Herkunft), und die übrigen (Acts/Partner/Features/Timetable/Flyer) als dokumentiertes Zielbild festhalten, aber erst bei Bedarf bauen.

---

## 4. Nebenbefund: Rügen-Bezug außerhalb der Sündenfrei-Liste

9 Rest-Events mit Rügen/MV-Bezug — fachlich evtl. relevant, da die Kontaktkuratierung Rügen betrifft:

| ID | Name | Ort | Herkunft |
|---|---|---|---|
| S05 | Strandkorbsilvester Göhren | 18586 Göhren | Sündenfrei |
| T04 | Rügenhof Kap Arkona | 18556 Putgarten | Chat |
| T05 | Straßenmusik Rügen | Rügen (Insel) | Chat |
| T06 | Neptunfest Ostseebad Göhren | Göhren | Chat |
| T09 | Hafen Schaprode | 18569 Schaprode | Nutzer/Tourplanung |
| T10 | Zentralcamp Putgarten | 18556 Putgarten | Nutzer/Tourplanung |
| C29 | Waldbühne Rügen | Bergen auf Rügen | Chat |
| C30 | La Grange e.V. | Bergen auf Rügen | Chat |
| C31 | Aedenlife Rügen | — | Chat |

Keine Bewertung — nur Hinweis, dass „Rest" nicht gleichbedeutend mit „irrelevant" ist.

---

## 5. Vorgeschlagene Entscheidungsfragen (keine davon ausgeführt)

1. **Strukturumfang:** volle Struktur (inkl. leerer Tabellen) · „Struktur light" (nur befüllte) · nur Geo?
2. **Rest-Daten:** gar nicht übernehmen · als gekennzeichneter Altbestand mitführen (Herkunft „Alt-App, unkuratiert") · separat archivieren?
3. **Rügen-Rest (9 Events):** gesondert prüfen oder zurückstellen?

**Ende Befundbericht C.**
