/* ------------------------------------------------------------------ */
/* C1 — Frisch-Geocodierung der Ortskerne via Nominatim/OpenStreetMap. */
/*                                                                    */
/* Verbindlich (O-11 / freigegebene Geo-Strategie):                    */
/*   · Schreiber dieser Tabelle ist AUSSCHLIESSLICH dieses Skript      */
/*     (plus der Prüf-Workflow C3, der nur den Status setzt).          */
/*   · Idempotent: Zeilen mit pruefstatus „geprueft“ werden nie        */
/*     angerührt. Alle anderen werden bei Änderung aktualisiert.       */
/*   · Kein Treffer / nur PLZ-Zentroid  → lat/lng = null bzw. Status   */
/*     „pruefen“, es wird NICHTS geschätzt und nichts geraten.         */
/*   · Alt-Koordinaten (alt_events.lat/lng) werden nicht übernommen.   */
/*   · Ausnahme: Ziele mit fester Koordinate (Nutzer-Tourplanung) werden */
/*     ohne Abruf als quelle „manuell“ / Status „geprueft“ übernommen.  */
/*   · Nominatim Usage Policy: 1 Anfrage pro Sekunde, eigener UA.      */
/* Ausführung:  npx tsx --env-file=.env src/db/geocode.ts              */
/* ------------------------------------------------------------------ */

import { and, eq, ne } from "drizzle-orm";
import { db, pool } from "./index";
import { geoOrte, termine } from "./schema";
import { KORRIDOR_PLZ, normalizePlzOrt } from "../lib/geo";

const NOMINATIM = "https://nominatim.openstreetmap.org/search";
const HEADERS = {
  "user-agent": "spp7-werkstatt-geo/1.0 (interne werkstatt, frisch-geocodierung)",
  "accept-language": "de",
};

/* OSM-addresstypes, die einen Ortskern (keinen Zentroid, kein Venue)   */
/* beschreiben. Alles andere landet prüfpflichtig im Status „pruefen“. */
const ORTSKERN_TYPEN = new Set([
  "city",
  "town",
  "village",
  "municipality",
  "suburb",
  "hamlet",
  "borough",
  "quarter",
  "locality",
  "island",
]);

interface Ziel {
  plz: string | null;
  ort: string;
  label: string;
  art: "terminort" | "korridor-vormerkung";
  /* Feste Koordinate (Nutzer-Tourplanung) — dann kein Nominatim-Abruf,     */
  /* sondern Übernahme als quelle „manuell“, Status „geprueft“.              */
  fest?: { lat: number; lng: number };
}

interface Treffer {
  lat: number;
  lng: number;
  genauigkeit: string;
  display: string;
}

function sleep(ms: number) {
  return new Promise((r) => setTimeout(r, ms));
}

async function nominatim(params: Record<string, string>): Promise<Treffer | null> {
  const url = new URL(NOMINATIM);
  url.search = new URLSearchParams({
    format: "jsonv2",
    limit: "5",
    ...params,
  }).toString();
  const res = await fetch(url, { headers: HEADERS });
  if (!res.ok) throw new Error(`Nominatim HTTP ${res.status}`);
  const rows = (await res.json()) as Array<{
    lat: string;
    lon: string;
    addresstype?: string;
    type?: string;
    display_name?: string;
  }>;
  if (!rows.length) return null;
  /* Ortskern-Treffer bevorzugen, sonst besten Treffer nehmen. */
  const best =
    rows.find((r) => ORTSKERN_TYPEN.has(r.addresstype ?? r.type ?? "")) ?? rows[0];
  const lat = Number(best.lat);
  const lng = Number(best.lon);
  if (!Number.isFinite(lat) || !Number.isFinite(lng)) return null;
  return {
    lat,
    lng,
    genauigkeit: best.addresstype ?? best.type ?? "unbekannt",
    display: best.display_name ?? "",
  };
}

/** Dreistufig: PLZ+Ort → PLZ → Ortsname. Jede Stufe zählt als 1 Anfrage. */
async function geocode(ziel: Ziel): Promise<Treffer | null> {
  const versuche: Array<Record<string, string>> = [];
  if (ziel.plz) {
    versuche.push({
      postalcode: ziel.plz,
      city: ziel.ort,
      country: "Deutschland",
    });
    versuche.push({ postalcode: ziel.plz, country: "Deutschland" });
  }
  versuche.push({ q: `${ziel.ort}, Deutschland`, countrycodes: "de" });

  for (const params of versuche) {
    await sleep(1100); // Nominatim Policy — strikt
    try {
      const t = await nominatim(params);
      if (t) return t;
    } catch (err) {
      console.log(`     ! Anfragefehler (${params.q ?? params.postalcode}): ${String(err)}`);
    }
  }
  return null;
}

async function zielmenge(): Promise<Ziel[]> {
  const rows = await db
    .select({ plzOrt: termine.plzOrtOriginal })
    .from(termine);
  const map = new Map<string, Ziel>();
  for (const { plzOrt } of rows) {
    const norm = normalizePlzOrt(plzOrt);
    if (!norm) continue;
    const key = `${norm.plz}|${norm.ort.toLowerCase()}`;
    if (!map.has(key)) {
      map.set(key, {
        plz: norm.plz,
        ort: norm.ort,
        label: norm.ort,
        art: "terminort",
      });
    }
  }
  /* Korridor-Vormerkungen — Beleg alt_events T04/T09 (PLZ dort vorhanden) */
  /* sowie Nutzer-Tourplanung 2027 (Wagendorf Karow, Arcanoa, CLASH,       */
  /* Schokoladen, Supamolly, Trinkteufel — Termin noch offen).             */
  const vormerkungen: Ziel[] = [
    {
      plz: "18556",
      ort: "Putgarten",
      label: "Putgarten · Rügenhof (Kap Arkona)",
      art: "korridor-vormerkung",
    },
    {
      plz: "18569",
      ort: "Schaprode",
      label: "Schaprode (Rügen)",
      art: "korridor-vormerkung",
    },
    {
      plz: "13125",
      ort: "Berlin-Karow",
      label: "Wagendorf Karow",
      art: "korridor-vormerkung",
      fest: { lat: 52.617, lng: 13.454 },
    },
    {
      plz: "10965",
      ort: "Berlin-Kreuzberg",
      label: "Arcanoa",
      art: "korridor-vormerkung",
      fest: { lat: 52.488, lng: 13.3868 },
    },
    {
      plz: "10961",
      ort: "Berlin-Kreuzberg",
      label: "CLASH Berlin",
      art: "korridor-vormerkung",
      fest: { lat: 52.4927, lng: 13.3888 },
    },
    {
      plz: "10115",
      ort: "Berlin-Mitte",
      label: "Schokoladen e.V.",
      art: "korridor-vormerkung",
      fest: { lat: 52.5303, lng: 13.3976 },
    },
    {
      plz: "10247",
      ort: "Berlin-Friedrichshain",
      label: "Supamolly",
      art: "korridor-vormerkung",
      fest: { lat: 52.5085, lng: 13.4727 },
    },
    {
      plz: "10997",
      ort: "Berlin-Kreuzberg",
      label: "Trinkteufel",
      art: "korridor-vormerkung",
      fest: { lat: 52.502, lng: 13.4217 },
    },
  ];
  for (const v of vormerkungen) {
    const key = `${v.plz}|${v.ort.toLowerCase()}`;
    if (!map.has(key)) map.set(key, v);
  }
  return [...map.values()].sort((a, b) =>
    `${a.plz}${a.ort}`.localeCompare(`${b.plz}${b.ort}`, "de"),
  );
}

async function main() {
  console.log("— C1 · Frisch-Geocodierung geo_orte (Nominatim/OSM) —");
  const ziele = await zielmenge();
  console.log(`  Zielmenge: ${ziele.length} Orte (${ziele.filter((z) => z.art === "terminort").length} Terminorte + ${ziele.filter((z) => z.art !== "terminort").length} Korridor-Vormerkungen)`);

  let neu = 0;
  let aktualisiert = 0;
  let uebersprungenGeprueft = 0;
  let pruefFaellig = 0;
  let gefunden = 0;

  for (const ziel of ziele) {
    const bestehend = await db
      .select()
      .from(geoOrte)
      .where(
        ziel.plz === null
          ? and(eq(geoOrte.ort, ziel.ort))
          : and(eq(geoOrte.plz, ziel.plz), eq(geoOrte.ort, ziel.ort)),
      )
      .limit(1);
    const alt = bestehend[0];

    if (alt?.pruefstatus === "geprueft") {
      uebersprungenGeprueft++;
      console.log(`  · „geprüft“ → unangetastet: ${ziel.label}`);
      continue;
    }

    let treffer: Treffer | null;
    let quelle: "osm" | "manuell" = "osm";
    if (ziel.fest) {
      /* Nutzer-Tourplanung: exakte Koordinate, kein Nominatim. */
      treffer = {
        lat: ziel.fest.lat,
        lng: ziel.fest.lng,
        genauigkeit: "manuell",
        display: `manuell (Nutzer-Tourplanung): ${ziel.label}`,
      };
      quelle = "manuell";
    } else {
      treffer = await geocode(ziel);
    }

    let status: "ungeprueft" | "pruefen" | "geprueft";
    if (ziel.fest) {
      status = "geprueft";
      gefunden++;
    } else if (!treffer) {
      status = "pruefen";
    } else {
      gefunden++;
      status = ORTSKERN_TYPEN.has(treffer.genauigkeit) ? "ungeprueft" : "pruefen";
    }
    if (status === "pruefen") pruefFaellig++;

    const werte = {
      plz: ziel.plz,
      ort: ziel.ort,
      label: ziel.label,
      art: ziel.art,
      lat: treffer?.lat ?? null,
      lng: treffer?.lng ?? null,
      quelle,
      genauigkeit: treffer?.genauigkeit ?? null,
      pruefstatus: status,
      geocodiertAm: new Date().toISOString(),
    };

    if (alt) {
      await db.update(geoOrte).set(werte).where(eq(geoOrte.id, alt.id));
      aktualisiert++;
    } else {
      await db.insert(geoOrte).values(werte);
      neu++;
    }
    console.log(
      `  ${treffer ? "OK  " : "…   "}${ziel.plz ?? "·····"} ${ziel.label}  →  ${treffer ? `${treffer.genauigkeit} · ${treffer.lat.toFixed(4)},${treffer.lng.toFixed(4)}` : "kein Treffer"}  [${status}]`,
    );
  }

  console.log(
    `\nFertig: ${neu} neu · ${aktualisiert} aktualisiert · ${uebersprungenGeprueft} „geprüft“ unangetastet · ${gefunden}/${ziele.length} geocodiert · ${pruefFaellig} prüfpflichtig`,
  );
  if (gefunden === 0 && ziele.length > 0) {
    console.error(
      "ABBRUCH-VERDACHT: Kein einziger Treffer — Geocoder nicht erreichbar? Es wurden möglicherweise Null-Zeilen geschrieben, bitte prüfen.",
    );
    process.exitCode = 1;
  }

  const korridor = await db
    .select({ plz: geoOrte.plz, lat: geoOrte.lat })
    .from(geoOrte);
  const fehlendeStationen = KORRIDOR_PLZ.filter(
    (plz) => !korridor.some((k) => k.plz === plz && k.lat !== null),
  );
  if (fehlendeStationen.length) {
    console.log(
      `  ⚠ Korridor-Stationen ohne Koordinate: ${fehlendeStationen.join(", ")} — Karte zeigt Stationen ohne Punkte an.`,
    );
  }

  await pool.end();
}

main().catch((err) => {
  console.error(err);
  process.exit(1);
});
