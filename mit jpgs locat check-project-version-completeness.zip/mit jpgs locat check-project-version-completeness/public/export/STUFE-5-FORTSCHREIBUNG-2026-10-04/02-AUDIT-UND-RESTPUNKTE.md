# Audit- und Restpunkte · Fortschreibung Stufe 5

**Stand:** 2026-10-04  
**Zweck:** Integritäts- und Umfangsgrenzen dieser Gesprächsfortschreibung dokumentieren.

## 1. Ursprüngliche Artefakte

Vor Erstellung dieses Ergänzungspakets geprüft:

- `public/export/STUFE-5-FREEZE-2026-10-04/PRUEFSUMMEN.sha256`: alle 5 gelisteten Dateien `OK`.
- `public/export/FREEZE/PRUEFSUMMEN.sha256`: alle 4 gelisteten Dateien `OK`.
- Die ursprüngliche Liste `01-OFFENE-PUNKTE.csv` und die Auditdatei `02-BEFUND-ABGRENZUNG-65.csv` wurden nicht verändert.

Der ursprüngliche Handoff dokumentiert 65 Ausgangsbefunde: 52 abgedeckt und 13 offen. Die hier dokumentierten Gespräche aktualisieren den ursprünglichen Export nicht nachträglich. Sie bilden eine separate Fortschreibung der Nutzerentscheidungen.

## 2. Werkstatt-Datenbank beim Checkpoint

Rein lesend gezählte Bestände:

| Tabelle | Ist | Soll laut ursprünglichem Handoff | Ergebnis |
|---|---:|---:|---|
| `regionen` | 9 | 9 | OK |
| `kontakte` | 35 | 35 | OK |
| `termine` | 54 | 54 | OK |
| `termin_zeitfenster` | 60 | 60 | OK |
| `beschluesse` | 20 | 20 | OK |
| `import_protokoll` | 3 | 3 | OK |

Keine Datenbank-, Schema-, Seed- oder Alt-App-Änderung wurde im Rahmen dieser Fortschreibung ausgeführt. Die drei Importprotokolleinträge beziehen sich weiterhin auf die ursprünglichen Freeze-Dateien.

## 3. Grenzen der Prüfung

Das vorliegende Projekt enthält die Werkstatt-App und die Stufe-4-/Stufe-5-Exportdateien. Die Alt-App selbst wurde nicht bereitgestellt. Insbesondere liegt `public/data/spp7-datasets.json` mit `feed_context/20` hier nicht vor. Daher:

- kann der Inhalt von F29 nicht ausgegeben oder beurteilt werden;
- konnte der JSON-Synchronisationspfad der Alt-App nicht untersucht werden;
- wurden D113, D196, D197 und D198 nicht in den Alt-App-Quelldateien nachgeprüft oder verändert;
- wurden die 79 Bildverweise und die physischen Bilddateien nicht neu gezählt oder zugeordnet;
- wurden die 180 Event- und 68 Kontaktkoordinaten nicht geprüft;
- wurde die vollständige `Kurverwaltungen_2025.md` nicht Feld für Feld mit dem Datenbankschema verglichen.

Diese Punkte sind keine behaupteten Ergebnisse. Sie bleiben Aufgaben nach Bereitstellung der jeweils nötigen Originaldateien.

## 4. Explizite Prüfsperren

1. **O-04 Datum:** Der Screenshot zeigt D196 als 08.–09.08.2026; die frühere Nutzerformulierung nannte 08.08.2027. Der spätere Gesprächskonsens darf nicht als Erlaubnis verstanden werden, ohne Alt-App-Abgleich eine Zeile mit abweichendem Jahr zu löschen.
2. **O-08 Identitäten:** D113/D198 wurden im Gespräch als gleicher Termin behandelt; die vollständigen Alt-App-Zeilen müssen vor einer Löschung dennoch anhand ihrer IDs und Felder abgeglichen werden.
3. **O-13 Synchronisation:** Keine Datensatz-Rückportierung, bevor JSON-Sync abgesichert und der Neustart-Regressionstest bestanden ist.
4. **O-02 Datenmodell:** Der Wunsch, die vollständige MD-Struktur künftig in der DB abzubilden, ist dokumentiert. Vor der Umsetzung muss geklärt werden, welche Angaben bereits vorhanden sind und ob dafür eine Schemaänderung nötig ist.
5. **O-12 Bildquellen:** Keine Annahme, dass alle Dateien noch verfügbar oder vollständig sind; erst zählen und Zuordnungen belegen.

## 5. Was dieser Freeze nicht behauptet

- Nicht alle 13 Punkte sind technisch umgesetzt oder aus dem ursprünglichen Arbeitslisten-CSV entfernt.
- Es existiert noch kein fertiger Alt-App-Rückportierungs-Freeze.
- Die Chatentscheidungen wurden nicht als formelle B-21+-Beschlüsse in der Werkstatt gespeichert.
- Die Alt-App ist nicht gegen JSON-Überschreiben abgesichert.
- Bild-, Geo- und Herkunftsdaten sind nicht geprüft oder repariert.
- Es gibt keine Garantie, dass die fehlenden Alt-App- oder Bilddateien später vollständig gefunden werden.
