# SPP7 · Abgleich 01 — Stufe 3

Version: abgleich-01-v1. Kontaktmodell: kontaktstruktur-region-ort-einrichtung-v4.
Stufe 3: unveränderte App-ZIP ↔ normierte Quellen und ausdrückliche Nutzerangaben. Keine Live-Datenbankprüfung als Datenbestand, keine externe Verifikation, kein Import, keine Stufe-4-Entscheidung.

**Keine Zuordnung, kein Merge, keine Löschung und keine Datenbankänderung ausgeführt. Alle Entscheidungspunkte sind offen.**

## Übersicht

- Kontakte: 32 Referenzeinrichtungen ↔ 74 Bestandszeilen. 38 Kandidatenpaare; 38 Bestandszeilen ohne Referenzkandidat nach diesen Regeln.
- Kontaktstatus Name-/Kanalhinweis: 20.
- Kontaktstatus Nur gleicher Kanal: 12.
- Kontaktstatus Nur Namenshinweis: 0.
- Kontaktstatus Kein Kandidat nach Regel: 0.
- Termine: 54 Quellzeilen (9 aus 2026 / 45 aus 2027), 60 getrennte Zeitfenster.
- 10 Quellzeilen haben vollständige Datum-/Ort-Hinweise; davon 9 mit zusätzlichem Namenswortfolge-Hinweis. Kein automatischer Identitätsnachweis.
- 44 Quellzeilen ohne vollständigen Datum-/Ort-Nachweis; darunter 2 Referenz-Ortsplatzhalter. „Fehlt“ bedeutet hier nur: nicht mit Datum+Ort im App-ZIP belegt.
- Von 60 Referenzzeitfenstern sind 10 mit Datum-/Ort-Hinweis auffindbar. Vier Adventswochenenden zählen als vier Fenster, aber ein Quelltermin.
- 65 nummerierte Entscheidungspunkte für Stufe 4.

Die frühere Handoff-Aussage „46 von 54 fehlen“ wird nicht übernommen: sie verglich Eventnamen mit Terminzeilen. Dieser Bericht vergleicht jede Quellzeile und ihre Fenster einzeln.

## Eingaben / Prüfsummen

| Datei | Rolle | SHA-256 |
|---|---|---|
| werkstatt/01-roh/app-workflow-setup.zip | unveränderter App-Bestand | 3776094a1a5b3015ea4bbc8f4343bedaa0b7746ec4c19b1bcd6ad4e76ba2adef |
| werkstatt/01-roh/app-workflow-setup.herkunft.json | Herkunft des App-ZIPs | 952d8a976a67cff7672c3ca5c4a4e4d9b9d134f984358f3f5421c625e4306697 |
| werkstatt/01-roh/Kurverwaltungen_2025.md | Original-Adressreferenz | 28512c72423ac270d4c423007b29dc85266e6938441d830bf0ec8a3239c1bfa1 |
| werkstatt/01-roh/Termine_2027_suendenfrei.txt | Original-Terminreferenz | 2ed2f631b158a8e3eaffc1f85d67d01abfdf8672c9f794f293e4ded263161cc7 |
| werkstatt/02-normiert/kontakte-struktur.json | normierte Kontaktreferenz und Nutzerregeln | 938d76b10524047b78cf6350b6c41b7f7d5b8b189d444792f3ce524e11f51d33 |
| werkstatt/02-normiert/suendenfrei-termine.csv | 54 normierte Terminzeilen | b6d075c8087259dc13852ca3d0c2bb415775700da0398937a9358f2fde25aa0e |
| werkstatt/02-normiert/nutzer-ergaenzungen.json | ausdrückliche Nutzerergänzungen | c59f3e5de6629f099deee521c29e642c7769266d84f6460bf489bab7162a9f24 |
| src/lib/comparison-model.ts | deterministisches Vergleichsmodell | c296b80fd546dca8c6c99c5b8982464bc0ba2b4793334197abd0146a8fae492e |
| scripts/build-comparison.mjs | Berichtserzeugung | 03cfc4edc4ebffec2385209576acbabfc35ee06cdfd4e44b1e83f9f610fc1cd6 |

App-Fundstellen sind JSON-Pointer innerhalb des unveränderten App-ZIPs (public/data/spp7-datasets.json). Das ZIP liegt außerhalb public/. Berichtsfundstellen ersetzen keine Originalnachricht. Keine neue Veröffentlichung privater Chattexte.

## Vergleichsregeln

1. Kontaktkandidaten nur durch identischen E-Mail-/Telefonkanal oder gleiche/enthaltene Namenswortfolge. Info/Information, Interpunktion und Rechtsformkürzel werden nur beim Textvergleich vereinheitlicht.
2. Gleicher Kanal ist kein Identitätsnachweis. Baabe und Mönchgut liefern ausdrücklich gemeinsam benutzte Kanäle; jede Referenzeinrichtung bleibt separat.
3. Termin-Kriterium Datum+Ort: alle getrennten Referenzfenster müssen innerhalb desselben Bestands-Events wortgleich vorkommen, und der gesamte Bestands-Ortstext muss im Referenz-Ortstext enthalten sein. Name/PLZ werden separat geprüft.
4. Postzeiten, Bewerbungsphasen, Fristen, Feed-Kontext, Booking-Hinweise, Ausgabe/Ankündigung werden nicht als Veranstaltungszeitfenster verglichen. Ein fehlendes BIS wird nicht zu einem Zeitraum ergänzt.
5. Nur-Ort-, andere Jahres- und Namenshinweise sind schwache Kandidaten, keine vorhandenen Referenztermine. Keine Fuzzy-Scores, keine Geografie- oder Termininterpretation.
6. Platzhalter xxxx/xxxxx bleiben Quelle offen. Sternchenstatus und berechnete Adventsfenster ändern sich nicht.
7. NOTIZ wird auf wörtlich vorhandene Referenzwerte geprüft, aber nicht als strukturiertes Feld interpretiert. Bestandsfelder ohne Struktur werden ausdrücklich als nicht strukturiert ausgewiesen.
8. Nicht zuordenbare Bestandskontakte/-events sind Überhang gegenüber diesen begrenzten Referenzen, nicht ungültig und nicht zum Löschen freigegeben.
9. Personennamen und ihre Bestandskanäle sind ausgeblendet. Nicht zugeordneter Kontakt-/Eventbestand erscheint nur mit ID und Typ, ohne neue persönliche Namen, Kanäle oder Linkbezeichnungen. Keine privaten Chattexte oder kompletten Bestandsdatensätze über die Bericht-API.

## Alle 32 Referenzeinrichtungen

| Referenz | Einrichtung | Status | Bestandskandidaten | Fundstelle |
|---|---|---|---|---|
| KV01 | Baltic Project GmbH / Tourismusverband Rügen e. V. | Name-/Kanalhinweis | K33, K65 | Kurverwaltungen_2025.md:L9-15 |
| KV02 | Kurverwaltung Binz | Name-/Kanalhinweis | K03 | Kurverwaltungen_2025.md:L21-27 |
| KV03 | Fremdenverkehrsverein Binz/Rügen e. V. | Name-/Kanalhinweis | K04 | Kurverwaltungen_2025.md:L29-35 |
| KV04 | Rujana Immobilien GmbH | Name-/Kanalhinweis | K66 | Kurverwaltungen_2025.md:L37-43 |
| KV05 | Tourist-Info Lancken-Granitz | Name-/Kanalhinweis | K05 | Kurverwaltungen_2025.md:L47-51 |
| KV06 | Kurverwaltung Sellin | Name-/Kanalhinweis | K06 | Kurverwaltungen_2025.md:L55-61 |
| KV07 | Infopoint Sellin | Name-/Kanalhinweis | K07, K68 | Kurverwaltungen_2025.md:L63-70 |
| KV08 | Ostseeappartements Rügen Vermarktungs-GmbH & Co.KG | Name-/Kanalhinweis | K67 | Kurverwaltungen_2025.md:L72-78 |
| KV09 | Kurverwaltung Baabe | Name-/Kanalhinweis | K08 | Kurverwaltungen_2025.md:L84-90 |
| KV10 | Infopavillion KV Baabe (außer Winter) | Nur gleicher Kanal | K08 | Kurverwaltungen_2025.md:L92-95 |
| KV11 | Mönchguter Zimmervermittlung | Name-/Kanalhinweis | K69 | Kurverwaltungen_2025.md:L97-103 |
| KV12 | Kurverwaltung Mönchgut / Tourist-Information Middelhagen | Nur gleicher Kanal | K09, K10 | Kurverwaltungen_2025.md:L107-112 |
| KV13 | Tourist-Information Thiessow (Außenstelle) | Name-/Kanalhinweis | K10 | Kurverwaltungen_2025.md:L114-118 |
| KV14 | Kurverwaltung Göhren | Name-/Kanalhinweis | K11 | Kurverwaltungen_2025.md:L122-128 |
| KV15 | Fremdenverkehrs-und Gewerbeverein Göhren e. V. | Nur gleicher Kanal | K12 | Kurverwaltungen_2025.md:L130-136 |
| KV16 | Tourist-Infostelle/Gemeinde Glowe | Nur gleicher Kanal | K13 | Kurverwaltungen_2025.md:L142-148 |
| KV17 | Touristik Lohme GmbH | Nur gleicher Kanal | K53 | Kurverwaltungen_2025.md:L152-158 |
| KV18 | Tourist-Service der Stadt Sassnitz | Nur gleicher Kanal | K14, K47 | Kurverwaltungen_2025.md:L162-168 |
| KV19 | Fremdenverkehrsamt Dranske | Name-/Kanalhinweis | K15 | Kurverwaltungen_2025.md:L174-180 |
| KV20 | Informationsamt Seebad Breege-Juliusruh | Nur gleicher Kanal | K16 | Kurverwaltungen_2025.md:L184-190 |
| KV21 | Tourismusgesellschaft mbH Kap Arkona | Nur gleicher Kanal | K17 | Kurverwaltungen_2025.md:L194-200 |
| KV22 | Tourismusinformation Wiek | Nur gleicher Kanal | K18 | Kurverwaltungen_2025.md:L204-210 |
| KV23 | Tourismusverein West-Rügen e. V. / Info-Stube Gingst | Name-/Kanalhinweis | K19 | Kurverwaltungen_2025.md:L216-223 |
| KV24 | Zimmervermittlung Rügen | Nur gleicher Kanal | K57 | Kurverwaltungen_2025.md:L227-233 |
| KV25 | Ummanz-Information | Name-/Kanalhinweis | K20 | Kurverwaltungen_2025.md:L237-243 |
| KV26 | Gemeinde Seebad Altefähr / Eigenbetrieb Hafen-und Tourismuswirtschaft Altefähr | Nur gleicher Kanal | K21 | Kurverwaltungen_2025.md:L249-256 |
| KV27 | Kurverwaltung Putbus/Stadtinformation | Name-/Kanalhinweis | K22, K23, K70 | Kurverwaltungen_2025.md:L260-266 |
| KV28 | Tourismus-und Gewerbeverein Putbus e. V. | Name-/Kanalhinweis | K71 | Kurverwaltungen_2025.md:L270-277 |
| KV29 | Stadtinformation Bergen auf Rügen / Bergen Touristik Service UG | Name-/Kanalhinweis | K29 | Kurverwaltungen_2025.md:L283-290 |
| KV30 | Insel Information Hiddensee | Name-/Kanalhinweis | K31 | Kurverwaltungen_2025.md:L296-302 |
| KV31 | Tourist Information im Hafencenter Kloster | Nur gleicher Kanal | K32 | Kurverwaltungen_2025.md:L306-311 |
| KV32 | HTS / Hiddensee Touristik & Service | Name-/Kanalhinweis | K72 | Kurverwaltungen_2025.md:L315-321 |

### KV01 · Baltic Project GmbH / Tourismusverband Rügen e. V.

Namensbestandteile und Kontaktkanal passen wörtlich; Zuordnung trotzdem nicht entschieden und Datenmodell unvollständig.
Fundstelle: Kurverwaltungen_2025.md:L9-15. Hierarchie: 1.1.
Fehlend im MD-Original:  - ; fehlend im Arbeitsstand:  - . Nutzerergänzung: nein.

#### Kandidat K33 · Tourismusverband Rügen (Kampagne)
Fundstelle: public/data/spp7-datasets.json#/datasets/contacts/32.
Namenshinweis: Wörtlich enthaltene Namenswortfolge:  Tourismusverband Rügen e. V. ↔ Tourismusverband Rügen (Kampagne). Kanalhinweis:  - .
Gleicher Kanal auch bei Referenzen:  - .

| Feld | Referenz-Arbeitswert | MD-Original | Herkunft | Bestand | Vergleich | Hinweis |
|---|---|---|---|---|---|---|
| Name | Baltic Project GmbH / Tourismusverband Rügen e. V. | Baltic Project GmbH / Tourismusverband Rügen e. V. | MD-Zeilen 9-15 | Tourismusverband Rügen (Kampagne) | abweichender_text | Abweichende Schreibweise ist nicht automatisch ein Sachfehler oder Identitätsnachweis. |
| Ort | Bergen auf Rügen | 18528 Bergen auf Rügen | MD-Zeilen 9-15 | Bergen auf Rügen | gleich | Nur Textvergleich, keine geografische Korrektur. |
| Straße | Markt 25 | Markt 25 | MD-Zeilen 9-15 |  -  | nicht_strukturiert |  -  |
| PLZ | 18528 | 18528 Bergen auf Rügen | MD-Zeilen 9-15 |  -  | nicht_strukturiert |  -  |
| Telefon | +49 3838 807780 | (0 38 38) 80 77 80 | MD, Zeilen 9-15 |  -  | nicht_strukturiert |  -  |
| Fax | 03838807781 | (0 38 38) 80 77 81 | MD, Zeilen 9-15 |  -  | nicht_strukturiert |  -  |
| Web | www.ruegen.de | www.ruegen.de | MD, Zeilen 9-15 |  -  | nicht_strukturiert |  -  |
| E-Mail 1 | inselexperten@ruegen.de | inselexperten@ruegen.de | MD, Zeilen 9-15 | mail@tourismus-ruegen.de | abweichender_text | Bestand hat nur EMAIL_TELEFON; keine getrennten Kanal-/Zweckspalten. |
| E-Mail 2 |  -  |  -  | MD-Zeilen 9-15 | mail@tourismus-ruegen.de | quelle_offen | Bestand hat nur EMAIL_TELEFON; keine getrennten Kanal-/Zweckspalten. |
| Ortsteil |  -  |  -  |  -  |  -  | quelle_offen |  -  |
| Geografischer Parent | REG01 | Übergreifend | MD-Gliederung + explizite Nutzerregeln; Parent: MD-Gliederung + nutzerangabe: Auftraggeber-Klarstellung: Übergreifend ist kein Ort; schreibe hier Rügen Übergreifend |  -  | nicht_strukturiert |  -  |
| Organisatorischer Parent |  -  |  -  |  -  |  -  | quelle_offen |  -  |

#### Kandidat K65 · Baltic Project GmbH / Tourismusverband Rügen e. V.
Fundstelle: public/data/spp7-datasets.json#/datasets/contacts/64.
Namenshinweis: Namenswortfolge gleich (Interpunktion/Rechtsformkürzel/Info-Schreibung vereinheitlicht): Baltic Project GmbH / Tourismusverband Rügen e. V.. Kanalhinweis: email:inselexperten@ruegen.de.
Gleicher Kanal auch bei Referenzen:  - .

| Feld | Referenz-Arbeitswert | MD-Original | Herkunft | Bestand | Vergleich | Hinweis |
|---|---|---|---|---|---|---|
| Name | Baltic Project GmbH / Tourismusverband Rügen e. V. | Baltic Project GmbH / Tourismusverband Rügen e. V. | MD-Zeilen 9-15 | Baltic Project GmbH / Tourismusverband Rügen e. V. | gleich | Abweichende Schreibweise ist nicht automatisch ein Sachfehler oder Identitätsnachweis. |
| Ort | Bergen auf Rügen | 18528 Bergen auf Rügen | MD-Zeilen 9-15 | Bergen auf Rügen | gleich | Nur Textvergleich, keine geografische Korrektur. |
| Straße | Markt 25 | Markt 25 | MD-Zeilen 9-15 |  -  | nicht_strukturiert | Referenzwert wörtlich im NOTIZ-Text vorhanden; bleibt Freitext, kein strukturiertes Feld. |
| PLZ | 18528 | 18528 Bergen auf Rügen | MD-Zeilen 9-15 |  -  | nicht_strukturiert | Referenzwert wörtlich im NOTIZ-Text vorhanden; bleibt Freitext, kein strukturiertes Feld. |
| Telefon | +49 3838 807780 | (0 38 38) 80 77 80 | MD, Zeilen 9-15 |  -  | nicht_strukturiert | Referenz-Ziffernfolge in ausdrücklich als Telefon bezeichnetem NOTIZ-Teil vorhanden; bleibt Freitext, kein strukturiertes Feld. |
| Fax | 03838807781 | (0 38 38) 80 77 81 | MD, Zeilen 9-15 |  -  | nicht_strukturiert |  -  |
| Web | www.ruegen.de | www.ruegen.de | MD, Zeilen 9-15 |  -  | nicht_strukturiert | Referenzwert wörtlich im NOTIZ-Text vorhanden; bleibt Freitext, kein strukturiertes Feld. |
| E-Mail 1 | inselexperten@ruegen.de | inselexperten@ruegen.de | MD, Zeilen 9-15 | inselexperten@ruegen.de | gleich | Bestand hat nur EMAIL_TELEFON; keine getrennten Kanal-/Zweckspalten. |
| E-Mail 2 |  -  |  -  | MD-Zeilen 9-15 | inselexperten@ruegen.de | quelle_offen | Bestand hat nur EMAIL_TELEFON; keine getrennten Kanal-/Zweckspalten. |
| Ortsteil |  -  |  -  |  -  |  -  | quelle_offen |  -  |
| Geografischer Parent | REG01 | Übergreifend | MD-Gliederung + explizite Nutzerregeln; Parent: MD-Gliederung + nutzerangabe: Auftraggeber-Klarstellung: Übergreifend ist kein Ort; schreibe hier Rügen Übergreifend |  -  | nicht_strukturiert |  -  |
| Organisatorischer Parent |  -  |  -  |  -  |  -  | quelle_offen |  -  |

### KV02 · Kurverwaltung Binz

Namensbestandteile und Kontaktkanal passen wörtlich; Zuordnung trotzdem nicht entschieden und Datenmodell unvollständig.
Fundstelle: Kurverwaltungen_2025.md:L21-27. Hierarchie: 2.1.1.
Fehlend im MD-Original:  - ; fehlend im Arbeitsstand:  - . Nutzerergänzung: nein.

#### Kandidat K03 · Kurverwaltung Binz
Fundstelle: public/data/spp7-datasets.json#/datasets/contacts/2.
Namenshinweis: Namenswortfolge gleich (Interpunktion/Rechtsformkürzel/Info-Schreibung vereinheitlicht): Kurverwaltung Binz. Kanalhinweis: email:info@binzer-bucht.de.
Gleicher Kanal auch bei Referenzen:  - .

| Feld | Referenz-Arbeitswert | MD-Original | Herkunft | Bestand | Vergleich | Hinweis |
|---|---|---|---|---|---|---|
| Name | Kurverwaltung Binz | Kurverwaltung Binz | MD-Zeilen 21-27 | Kurverwaltung Binz | gleich | Abweichende Schreibweise ist nicht automatisch ein Sachfehler oder Identitätsnachweis. |
| Ort | Ostseebad Binz | 18609 Ostseebad Binz | MD-Zeilen 21-27 | Binz | abweichender_text | Nur Textvergleich, keine geografische Korrektur. |
| Straße | Heinrich-Heine-Straße 7 (Haus des Gastes) | Heinrich-Heine-Straße 7 (Haus des Gastes) | MD-Zeilen 21-27 |  -  | nicht_strukturiert |  -  |
| PLZ | 18609 | 18609 Ostseebad Binz | MD-Zeilen 21-27 |  -  | nicht_strukturiert |  -  |
| Telefon | +49 38393 148148 | (03 83 93) 14 81 48 | MD, Zeilen 21-27 |  -  | nicht_strukturiert |  -  |
| Fax | 038393148145 | (03 83 93) 14 81 45 | MD, Zeilen 21-27 |  -  | nicht_strukturiert |  -  |
| Web | www.ostseebad-binz.de | www.ostseebad-binz.de | MD, Zeilen 21-27 |  -  | nicht_strukturiert |  -  |
| E-Mail 1 | info@binzer-bucht.de | info@binzer-bucht.de | MD, Zeilen 21-27 | info@binzer-bucht.de | gleich | Bestand hat nur EMAIL_TELEFON; keine getrennten Kanal-/Zweckspalten. |
| E-Mail 2 |  -  |  -  | MD-Zeilen 21-27 | info@binzer-bucht.de | quelle_offen | Bestand hat nur EMAIL_TELEFON; keine getrennten Kanal-/Zweckspalten. |
| Ortsteil |  -  |  -  |  -  |  -  | quelle_offen |  -  |
| Geografischer Parent | ORT02 | Ostseebad Binz | MD-Gliederung + explizite Nutzerregeln; Parent: MD-Gliederung: ### |  -  | nicht_strukturiert |  -  |
| Organisatorischer Parent |  -  |  -  |  -  |  -  | quelle_offen |  -  |

### KV03 · Fremdenverkehrsverein Binz/Rügen e. V.

Namensbestandteile und Kontaktkanal passen wörtlich; Zuordnung trotzdem nicht entschieden und Datenmodell unvollständig.
Fundstelle: Kurverwaltungen_2025.md:L29-35. Hierarchie: 2.1.2.
Fehlend im MD-Original:  - ; fehlend im Arbeitsstand:  - . Nutzerergänzung: nein.

#### Kandidat K04 · Fremdenverkehrsverein Binz/Rügen
Fundstelle: public/data/spp7-datasets.json#/datasets/contacts/3.
Namenshinweis: Namenswortfolge gleich (Interpunktion/Rechtsformkürzel/Info-Schreibung vereinheitlicht): Fremdenverkehrsverein Binz/Rügen e. V.. Kanalhinweis: email:info@gastgeber-binz.de.
Gleicher Kanal auch bei Referenzen:  - .

| Feld | Referenz-Arbeitswert | MD-Original | Herkunft | Bestand | Vergleich | Hinweis |
|---|---|---|---|---|---|---|
| Name | Fremdenverkehrsverein Binz/Rügen e. V. | Fremdenverkehrsverein Binz/Rügen e. V. | MD-Zeilen 29-35 | Fremdenverkehrsverein Binz/Rügen | abweichender_text | Abweichende Schreibweise ist nicht automatisch ein Sachfehler oder Identitätsnachweis. |
| Ort | Ostseebad Binz | 18609 Ostseebad Binz | MD-Zeilen 29-35 | Binz | abweichender_text | Nur Textvergleich, keine geografische Korrektur. |
| Straße | Wylichstraße 11 | Wylichstraße 11 | MD-Zeilen 29-35 |  -  | nicht_strukturiert |  -  |
| PLZ | 18609 | 18609 Ostseebad Binz | MD-Zeilen 29-35 |  -  | nicht_strukturiert |  -  |
| Telefon | +49 38393 665740 | (03 83 93) 66 57 40 | MD, Zeilen 29-35 |  -  | nicht_strukturiert |  -  |
| Fax | 038393665750 | (03 83 93) 66 57 50 | MD, Zeilen 29-35 |  -  | nicht_strukturiert |  -  |
| Web | www.gastgeber-binz.de | www.gastgeber-binz.de | MD, Zeilen 29-35 |  -  | nicht_strukturiert |  -  |
| E-Mail 1 | info@gastgeber-binz.de | info@gastgeber-binz.de | MD, Zeilen 29-35 | info@gastgeber-binz.de | gleich | Bestand hat nur EMAIL_TELEFON; keine getrennten Kanal-/Zweckspalten. |
| E-Mail 2 |  -  |  -  | MD-Zeilen 29-35 | info@gastgeber-binz.de | quelle_offen | Bestand hat nur EMAIL_TELEFON; keine getrennten Kanal-/Zweckspalten. |
| Ortsteil |  -  |  -  |  -  |  -  | quelle_offen |  -  |
| Geografischer Parent | ORT02 | Ostseebad Binz | MD-Gliederung + explizite Nutzerregeln; Parent: MD-Gliederung: ### |  -  | nicht_strukturiert |  -  |
| Organisatorischer Parent |  -  |  -  |  -  |  -  | quelle_offen |  -  |

### KV04 · Rujana Immobilien GmbH

Namensbestandteile und Kontaktkanal passen wörtlich; Zuordnung trotzdem nicht entschieden und Datenmodell unvollständig.
Fundstelle: Kurverwaltungen_2025.md:L37-43. Hierarchie: 2.1.3.
Fehlend im MD-Original:  - ; fehlend im Arbeitsstand:  - . Nutzerergänzung: nein.

#### Kandidat K66 · Rujana Immobilien GmbH
Fundstelle: public/data/spp7-datasets.json#/datasets/contacts/65.
Namenshinweis: Namenswortfolge gleich (Interpunktion/Rechtsformkürzel/Info-Schreibung vereinheitlicht): Rujana Immobilien GmbH. Kanalhinweis: email:urlaub@rujana.de.
Gleicher Kanal auch bei Referenzen:  - .

| Feld | Referenz-Arbeitswert | MD-Original | Herkunft | Bestand | Vergleich | Hinweis |
|---|---|---|---|---|---|---|
| Name | Rujana Immobilien GmbH | Rujana Immobilien GmbH | MD-Zeilen 37-43 | Rujana Immobilien GmbH | gleich | Abweichende Schreibweise ist nicht automatisch ein Sachfehler oder Identitätsnachweis. |
| Ort | Ostseebad Binz | 18609 Ostseebad Binz | MD-Zeilen 37-43 | Ostseebad Binz | gleich | Nur Textvergleich, keine geografische Korrektur. |
| Straße | Wylichstraße 11 | Wylichstraße 11 | MD-Zeilen 37-43 |  -  | nicht_strukturiert | Referenzwert wörtlich im NOTIZ-Text vorhanden; bleibt Freitext, kein strukturiertes Feld. |
| PLZ | 18609 | 18609 Ostseebad Binz | MD-Zeilen 37-43 |  -  | nicht_strukturiert | Referenzwert wörtlich im NOTIZ-Text vorhanden; bleibt Freitext, kein strukturiertes Feld. |
| Telefon | +49 38393 66640 | (03 83 93) 6 66 40 | MD, Zeilen 37-43 |  -  | nicht_strukturiert | Referenz-Ziffernfolge in ausdrücklich als Telefon bezeichnetem NOTIZ-Teil vorhanden; bleibt Freitext, kein strukturiertes Feld. |
| Fax | 038393666414 | (03 83 93) 66 64 14 | MD, Zeilen 37-43 |  -  | nicht_strukturiert |  -  |
| Web | www.rujana.de | www.rujana.de | MD, Zeilen 37-43 |  -  | nicht_strukturiert | Referenzwert wörtlich im NOTIZ-Text vorhanden; bleibt Freitext, kein strukturiertes Feld. |
| E-Mail 1 | urlaub@rujana.de | urlaub@rujana.de | MD, Zeilen 37-43 | urlaub@rujana.de | gleich | Bestand hat nur EMAIL_TELEFON; keine getrennten Kanal-/Zweckspalten. |
| E-Mail 2 |  -  |  -  | MD-Zeilen 37-43 | urlaub@rujana.de | quelle_offen | Bestand hat nur EMAIL_TELEFON; keine getrennten Kanal-/Zweckspalten. |
| Ortsteil |  -  |  -  |  -  |  -  | quelle_offen |  -  |
| Geografischer Parent | ORT02 | Ostseebad Binz | MD-Gliederung + explizite Nutzerregeln; Parent: MD-Gliederung: ### |  -  | nicht_strukturiert |  -  |
| Organisatorischer Parent |  -  |  -  |  -  |  -  | quelle_offen |  -  |

### KV05 · Tourist-Info Lancken-Granitz

Namensbestandteile und Kontaktkanal passen wörtlich; Zuordnung trotzdem nicht entschieden und Datenmodell unvollständig.
Fundstelle: Kurverwaltungen_2025.md:L47-51. Hierarchie: 2.2.1.
Fehlend im MD-Original: fax,web; fehlend im Arbeitsstand: fax,web. Nutzerergänzung: nein.

#### Kandidat K05 · Tourist-Info Lancken-Granitz
Fundstelle: public/data/spp7-datasets.json#/datasets/contacts/4.
Namenshinweis: Namenswortfolge gleich (Interpunktion/Rechtsformkürzel/Info-Schreibung vereinheitlicht): Tourist-Info Lancken-Granitz. Kanalhinweis: email:lancken-granitz@ruegen.de.
Gleicher Kanal auch bei Referenzen:  - .

| Feld | Referenz-Arbeitswert | MD-Original | Herkunft | Bestand | Vergleich | Hinweis |
|---|---|---|---|---|---|---|
| Name | Tourist-Info Lancken-Granitz | Tourist-Info Lancken-Granitz | MD-Zeilen 47-51 | Tourist-Info Lancken-Granitz | gleich | Abweichende Schreibweise ist nicht automatisch ein Sachfehler oder Identitätsnachweis. |
| Ort | Lancken-Granitz | 18586 Lancken-Granitz | MD-Zeilen 47-51 | Lancken-Granitz | gleich | Nur Textvergleich, keine geografische Korrektur. |
| Straße | Dorfstraße 8 | Dorfstraße 8 | MD-Zeilen 47-51 |  -  | nicht_strukturiert |  -  |
| PLZ | 18586 | 18586 Lancken-Granitz | MD-Zeilen 47-51 |  -  | nicht_strukturiert |  -  |
| Telefon | +49 38303 95678 | (03 83 03) 9 56 78 | MD, Zeilen 47-51 |  -  | nicht_strukturiert |  -  |
| Fax |  -  |  -  |  -  |  -  | quelle_offen |  -  |
| Web |  -  |  -  |  -  |  -  | quelle_offen |  -  |
| E-Mail 1 | lancken-granitz@ruegen.de | lancken-granitz@ruegen.de | MD, Zeilen 47-51 | lancken-granitz@ruegen.de | gleich | Bestand hat nur EMAIL_TELEFON; keine getrennten Kanal-/Zweckspalten. |
| E-Mail 2 |  -  |  -  | MD-Zeilen 47-51 | lancken-granitz@ruegen.de | quelle_offen | Bestand hat nur EMAIL_TELEFON; keine getrennten Kanal-/Zweckspalten. |
| Ortsteil |  -  |  -  |  -  |  -  | quelle_offen |  -  |
| Geografischer Parent | ORT03 | Lancken-Granitz | MD-Gliederung + explizite Nutzerregeln; Parent: MD-Gliederung: ### |  -  | nicht_strukturiert |  -  |
| Organisatorischer Parent |  -  |  -  |  -  |  -  | quelle_offen |  -  |

### KV06 · Kurverwaltung Sellin

Namensbestandteile und Kontaktkanal passen wörtlich; Zuordnung trotzdem nicht entschieden und Datenmodell unvollständig.
Fundstelle: Kurverwaltungen_2025.md:L55-61. Hierarchie: 2.3.1.
Fehlend im MD-Original:  - ; fehlend im Arbeitsstand:  - . Nutzerergänzung: nein.

#### Kandidat K06 · Kurverwaltung Sellin
Fundstelle: public/data/spp7-datasets.json#/datasets/contacts/5.
Namenshinweis: Namenswortfolge gleich (Interpunktion/Rechtsformkürzel/Info-Schreibung vereinheitlicht): Kurverwaltung Sellin. Kanalhinweis: email:kv@ostseebad-sellin.de.
Gleicher Kanal auch bei Referenzen:  - .

| Feld | Referenz-Arbeitswert | MD-Original | Herkunft | Bestand | Vergleich | Hinweis |
|---|---|---|---|---|---|---|
| Name | Kurverwaltung Sellin | Kurverwaltung Sellin | MD-Zeilen 55-61 | Kurverwaltung Sellin | gleich | Abweichende Schreibweise ist nicht automatisch ein Sachfehler oder Identitätsnachweis. |
| Ort | Ostseebad Sellin | 18586 Ostseebad Sellin | MD-Zeilen 55-61 | Sellin | abweichender_text | Nur Textvergleich, keine geografische Korrektur. |
| Straße | Warmbadstraße 4 (Haus des Gastes) | Warmbadstraße 4 (Haus des Gastes) | MD-Zeilen 55-61 |  -  | nicht_strukturiert |  -  |
| PLZ | 18586 | 18586 Ostseebad Sellin | MD-Zeilen 55-61 |  -  | nicht_strukturiert |  -  |
| Telefon | +49 38303 160 | (03 83 03) 1 60 | MD, Zeilen 55-61 |  -  | nicht_strukturiert |  -  |
| Fax | 03830316100 | (03 83 03) 1 61 00 | MD, Zeilen 55-61 |  -  | nicht_strukturiert |  -  |
| Web | www.ostseebad-sellin.de | www.ostseebad-sellin.de | MD, Zeilen 55-61 |  -  | nicht_strukturiert |  -  |
| E-Mail 1 | kv@ostseebad-sellin.de | kv@ostseebad-sellin.de | MD, Zeilen 55-61 | kv@ostseebad-sellin.de | gleich | Bestand hat nur EMAIL_TELEFON; keine getrennten Kanal-/Zweckspalten. |
| E-Mail 2 |  -  |  -  | MD-Zeilen 55-61 | kv@ostseebad-sellin.de | quelle_offen | Bestand hat nur EMAIL_TELEFON; keine getrennten Kanal-/Zweckspalten. |
| Ortsteil |  -  |  -  |  -  |  -  | quelle_offen |  -  |
| Geografischer Parent | ORT04 | Ostseebad Sellin | MD-Gliederung + explizite Nutzerregeln; Parent: MD-Gliederung: ### |  -  | nicht_strukturiert |  -  |
| Organisatorischer Parent |  -  |  -  |  -  |  -  | quelle_offen |  -  |

### KV07 · Infopoint Sellin

Namensbestandteile und Kontaktkanal passen wörtlich; Zuordnung trotzdem nicht entschieden und Datenmodell unvollständig.
Fundstelle: Kurverwaltungen_2025.md:L63-70. Hierarchie: 2.3.2.
Fehlend im MD-Original:  - ; fehlend im Arbeitsstand:  - . Nutzerergänzung: nein.

#### Kandidat K07 · Infopoint Sellin
Fundstelle: public/data/spp7-datasets.json#/datasets/contacts/6.
Namenshinweis: Namenswortfolge gleich (Interpunktion/Rechtsformkürzel/Info-Schreibung vereinheitlicht): Infopoint Sellin. Kanalhinweis: email:info@ostseebad-sellin.de.
Gleicher Kanal auch bei Referenzen:  - .

| Feld | Referenz-Arbeitswert | MD-Original | Herkunft | Bestand | Vergleich | Hinweis |
|---|---|---|---|---|---|---|
| Name | Infopoint Sellin | Infopoint Sellin | MD-Zeilen 63-70 | Infopoint Sellin | gleich | Abweichende Schreibweise ist nicht automatisch ein Sachfehler oder Identitätsnachweis. |
| Ort | Ostseebad Sellin | 18586 Ostseebad Sellin | MD-Zeilen 63-70 | Sellin | abweichender_text | Nur Textvergleich, keine geografische Korrektur. |
| Straße | Seeparkpromenade 1 | Seeparkpromenade 1 | MD-Zeilen 63-70 |  -  | nicht_strukturiert |  -  |
| PLZ | 18586 | 18586 Ostseebad Sellin | MD-Zeilen 63-70 |  -  | nicht_strukturiert |  -  |
| Telefon | +49 38303 16222 | (03 83 03) 1 62 22 | MD, Zeilen 63-70 |  -  | nicht_strukturiert |  -  |
| Fax | 03830316200 | (03 83 03) 1 62 00 | MD, Zeilen 63-70 |  -  | nicht_strukturiert |  -  |
| Web | www.ostseebad-sellin.de | www.ostseebad-sellin.de | MD, Zeilen 63-70 |  -  | nicht_strukturiert |  -  |
| E-Mail 1 | info@ostseebad-sellin.de | info@ostseebad-sellin.de | MD, Zeilen 63-70 | info@ostseebad-sellin.de | gleich | Bestand hat nur EMAIL_TELEFON; keine getrennten Kanal-/Zweckspalten. |
| E-Mail 2 | zimmervermittlung@ostseebad-sellin.de | zimmervermittlung@ostseebad-sellin.de | MD-Zeilen 63-70 | info@ostseebad-sellin.de | abweichender_text | Bestand hat nur EMAIL_TELEFON; keine getrennten Kanal-/Zweckspalten. |
| Ortsteil |  -  |  -  |  -  |  -  | quelle_offen |  -  |
| Geografischer Parent | ORT04 | Ostseebad Sellin | MD-Gliederung + explizite Nutzerregeln; Parent: MD-Gliederung: ### |  -  | nicht_strukturiert |  -  |
| Organisatorischer Parent |  -  |  -  |  -  |  -  | quelle_offen |  -  |

#### Kandidat K68 · Infopoint Sellin (Zimmervermittlung)
Fundstelle: public/data/spp7-datasets.json#/datasets/contacts/67.
Namenshinweis: Wörtlich enthaltene Namenswortfolge: Infopoint Sellin ↔ Infopoint Sellin (Zimmervermittlung). Kanalhinweis: email:zimmervermittlung@ostseebad-sellin.de.
Gleicher Kanal auch bei Referenzen:  - .

| Feld | Referenz-Arbeitswert | MD-Original | Herkunft | Bestand | Vergleich | Hinweis |
|---|---|---|---|---|---|---|
| Name | Infopoint Sellin | Infopoint Sellin | MD-Zeilen 63-70 | Infopoint Sellin (Zimmervermittlung) | abweichender_text | Abweichende Schreibweise ist nicht automatisch ein Sachfehler oder Identitätsnachweis. |
| Ort | Ostseebad Sellin | 18586 Ostseebad Sellin | MD-Zeilen 63-70 | Ostseebad Sellin | gleich | Nur Textvergleich, keine geografische Korrektur. |
| Straße | Seeparkpromenade 1 | Seeparkpromenade 1 | MD-Zeilen 63-70 |  -  | nicht_strukturiert | Referenzwert wörtlich im NOTIZ-Text vorhanden; bleibt Freitext, kein strukturiertes Feld. |
| PLZ | 18586 | 18586 Ostseebad Sellin | MD-Zeilen 63-70 |  -  | nicht_strukturiert | Referenzwert wörtlich im NOTIZ-Text vorhanden; bleibt Freitext, kein strukturiertes Feld. |
| Telefon | +49 38303 16222 | (03 83 03) 1 62 22 | MD, Zeilen 63-70 |  -  | nicht_strukturiert | Referenz-Ziffernfolge in ausdrücklich als Telefon bezeichnetem NOTIZ-Teil vorhanden; bleibt Freitext, kein strukturiertes Feld. |
| Fax | 03830316200 | (03 83 03) 1 62 00 | MD, Zeilen 63-70 |  -  | nicht_strukturiert |  -  |
| Web | www.ostseebad-sellin.de | www.ostseebad-sellin.de | MD, Zeilen 63-70 |  -  | nicht_strukturiert |  -  |
| E-Mail 1 | info@ostseebad-sellin.de | info@ostseebad-sellin.de | MD, Zeilen 63-70 | zimmervermittlung@ostseebad-sellin.de | abweichender_text | Bestand hat nur EMAIL_TELEFON; keine getrennten Kanal-/Zweckspalten. |
| E-Mail 2 | zimmervermittlung@ostseebad-sellin.de | zimmervermittlung@ostseebad-sellin.de | MD-Zeilen 63-70 | zimmervermittlung@ostseebad-sellin.de | gleich | Bestand hat nur EMAIL_TELEFON; keine getrennten Kanal-/Zweckspalten. |
| Ortsteil |  -  |  -  |  -  |  -  | quelle_offen |  -  |
| Geografischer Parent | ORT04 | Ostseebad Sellin | MD-Gliederung + explizite Nutzerregeln; Parent: MD-Gliederung: ### |  -  | nicht_strukturiert |  -  |
| Organisatorischer Parent |  -  |  -  |  -  |  -  | quelle_offen |  -  |

### KV08 · Ostseeappartements Rügen Vermarktungs-GmbH & Co.KG

Namensbestandteile und Kontaktkanal passen wörtlich; Zuordnung trotzdem nicht entschieden und Datenmodell unvollständig.
Fundstelle: Kurverwaltungen_2025.md:L72-78. Hierarchie: 2.3.3.
Fehlend im MD-Original:  - ; fehlend im Arbeitsstand:  - . Nutzerergänzung: nein.

#### Kandidat K67 · Ostseeappartements Rügen Vermarktungs-GmbH & Co.KG
Fundstelle: public/data/spp7-datasets.json#/datasets/contacts/66.
Namenshinweis: Namenswortfolge gleich (Interpunktion/Rechtsformkürzel/Info-Schreibung vereinheitlicht): Ostseeappartements Rügen Vermarktungs-GmbH & Co.KG. Kanalhinweis: email:info@oar1.de.
Gleicher Kanal auch bei Referenzen:  - .

| Feld | Referenz-Arbeitswert | MD-Original | Herkunft | Bestand | Vergleich | Hinweis |
|---|---|---|---|---|---|---|
| Name | Ostseeappartements Rügen Vermarktungs-GmbH & Co.KG | Ostseeappartements Rügen Vermarktungs-GmbH & Co.KG | MD-Zeilen 72-78 | Ostseeappartements Rügen Vermarktungs-GmbH & Co.KG | gleich | Abweichende Schreibweise ist nicht automatisch ein Sachfehler oder Identitätsnachweis. |
| Ort | Ostseebad Sellin | 18586 Ostseebad Sellin | MD-Zeilen 72-78 | Ostseebad Sellin | gleich | Nur Textvergleich, keine geografische Korrektur. |
| Straße | Granitzer Straße 8 | Granitzer Straße 8 | MD-Zeilen 72-78 |  -  | nicht_strukturiert | Referenzwert wörtlich im NOTIZ-Text vorhanden; bleibt Freitext, kein strukturiertes Feld. |
| PLZ | 18586 | 18586 Ostseebad Sellin | MD-Zeilen 72-78 |  -  | nicht_strukturiert | Referenzwert wörtlich im NOTIZ-Text vorhanden; bleibt Freitext, kein strukturiertes Feld. |
| Telefon | +49 38303 90940 | (03 83 03) 9 09 40 | MD, Zeilen 72-78 |  -  | nicht_strukturiert | Referenz-Ziffernfolge in ausdrücklich als Telefon bezeichnetem NOTIZ-Teil vorhanden; bleibt Freitext, kein strukturiertes Feld. |
| Fax | 03830390944 | (03 83 03) 9 09 44 | MD, Zeilen 72-78 |  -  | nicht_strukturiert |  -  |
| Web | www.oar1.de | www.oar1.de | MD, Zeilen 72-78 |  -  | nicht_strukturiert | Referenzwert wörtlich im NOTIZ-Text vorhanden; bleibt Freitext, kein strukturiertes Feld. |
| E-Mail 1 | info@oar1.de | info@oar1.de | MD, Zeilen 72-78 | info@oar1.de | gleich | Bestand hat nur EMAIL_TELEFON; keine getrennten Kanal-/Zweckspalten. |
| E-Mail 2 |  -  |  -  | MD-Zeilen 72-78 | info@oar1.de | quelle_offen | Bestand hat nur EMAIL_TELEFON; keine getrennten Kanal-/Zweckspalten. |
| Ortsteil |  -  |  -  |  -  |  -  | quelle_offen |  -  |
| Geografischer Parent | ORT04 | Ostseebad Sellin | MD-Gliederung + explizite Nutzerregeln; Parent: MD-Gliederung: ### |  -  | nicht_strukturiert |  -  |
| Organisatorischer Parent |  -  |  -  |  -  |  -  | quelle_offen |  -  |

### KV09 · Kurverwaltung Baabe

Namensbestandteile und Kontaktkanal passen wörtlich; Zuordnung trotzdem nicht entschieden und Datenmodell unvollständig.
Fundstelle: Kurverwaltungen_2025.md:L84-90. Hierarchie: 3.1.1.
Fehlend im MD-Original:  - ; fehlend im Arbeitsstand:  - . Nutzerergänzung: ja.

#### Kandidat K08 · Kurverwaltung Baabe
Fundstelle: public/data/spp7-datasets.json#/datasets/contacts/7.
Namenshinweis: Namenswortfolge gleich (Interpunktion/Rechtsformkürzel/Info-Schreibung vereinheitlicht): Kurverwaltung Baabe. Kanalhinweis: email:willkommen@baabe.de.
Gleicher Kanal auch bei Referenzen: KV10.

| Feld | Referenz-Arbeitswert | MD-Original | Herkunft | Bestand | Vergleich | Hinweis |
|---|---|---|---|---|---|---|
| Name | Kurverwaltung Baabe | Kurverwaltung Baabe | MD-Zeilen 84-90 | Kurverwaltung Baabe | gleich | Abweichende Schreibweise ist nicht automatisch ein Sachfehler oder Identitätsnachweis. |
| Ort | Ostseebad Baabe | 18586 Ostseebad Baabe | MD-Zeilen 84-90 | Baabe | abweichender_text | Nur Textvergleich, keine geografische Korrektur. |
| Straße | Am Kurpark 9 (Haus des Gastes) | Am Kurpark 9 (Haus des Gastes) | MD-Zeilen 84-90 |  -  | nicht_strukturiert |  -  |
| PLZ | 18586 | 18586 Ostseebad Baabe | MD-Zeilen 84-90 |  -  | nicht_strukturiert |  -  |
| Telefon | +49 38303 1420 | (03 83 03) 1 42 0 | MD, Zeilen 84-90 |  -  | nicht_strukturiert |  -  |
| Fax | 03830314299 | (03 83 03) 1 42 99 | MD, Zeilen 84-90 |  -  | nicht_strukturiert |  -  |
| Web | www.baabe.de | www.baabe.de | MD, Zeilen 84-90 |  -  | nicht_strukturiert |  -  |
| E-Mail 1 | willkommen@baabe.de | willkommen@baabe.de | MD, Zeilen 84-90 | willkommen@baabe.de | gleich | Bestand hat nur EMAIL_TELEFON; keine getrennten Kanal-/Zweckspalten. |
| E-Mail 2 |  -  |  -  | MD-Zeilen 84-90 | willkommen@baabe.de | quelle_offen | Bestand hat nur EMAIL_TELEFON; keine getrennten Kanal-/Zweckspalten. |
| Ortsteil |  -  |  -  |  -  |  -  | quelle_offen |  -  |
| Geografischer Parent | ORT05 | Ostseebad Baabe | MD-Gliederung + explizite Nutzerregeln; Parent: MD-Gliederung: ### |  -  | nicht_strukturiert |  -  |
| Organisatorischer Parent |  -  |  -  |  -  |  -  | quelle_offen |  -  |

### KV10 · Infopavillion KV Baabe (außer Winter)

Nur der Kontaktkanal stimmt. Gemeinsame E-Mail kann mehrere Einrichtungen bedienen; Identität nicht nachgewiesen.
Fundstelle: Kurverwaltungen_2025.md:L92-95. Hierarchie: 3.1.2.
Fehlend im MD-Original: fax,web,email; fehlend im Arbeitsstand: fax. Nutzerergänzung: ja.

#### Kandidat K08 · Kurverwaltung Baabe
Fundstelle: public/data/spp7-datasets.json#/datasets/contacts/7.
Namenshinweis:  - . Kanalhinweis: email:willkommen@baabe.de.
Gleicher Kanal auch bei Referenzen: KV09.

| Feld | Referenz-Arbeitswert | MD-Original | Herkunft | Bestand | Vergleich | Hinweis |
|---|---|---|---|---|---|---|
| Name | Infopavillion KV Baabe (außer Winter) | Infopavillion KV Baabe (außer Winter) | MD-Zeilen 92-95 | Kurverwaltung Baabe | abweichender_text | Abweichende Schreibweise ist nicht automatisch ein Sachfehler oder Identitätsnachweis. |
| Ort | Ostseebad Baabe | 18586 Ostseebad Baabe | MD-Zeilen 92-95 | Baabe | abweichender_text | Nur Textvergleich, keine geografische Korrektur. |
| Straße | Strandstraße | Strandstraße | MD-Zeilen 92-95 |  -  | nicht_strukturiert |  -  |
| PLZ | 18586 | 18586 Ostseebad Baabe | MD-Zeilen 92-95 |  -  | nicht_strukturiert |  -  |
| Telefon | +49 38303 14241 | (03 83 03) 1 42 41 | MD, Zeilen 92-95 |  -  | nicht_strukturiert |  -  |
| Fax |  -  |  -  | nutzerangabe: Explizite Nutzerangabe x.1.2; anschließend bestätigt: wo ich es hinschreibe, nimm das. Nur für diesen Infopavillon, keine allgemeine Vererbung |  -  | quelle_offen |  -  |
| Web | www.baabe.de |  -  | nutzerangabe: Explizite Nutzerangabe x.1.2; anschließend bestätigt: wo ich es hinschreibe, nimm das. Nur für diesen Infopavillon, keine allgemeine Vererbung |  -  | nicht_strukturiert |  -  |
| E-Mail 1 | willkommen@baabe.de |  -  | nutzerangabe: Explizite Nutzerangabe x.1.2; anschließend bestätigt: wo ich es hinschreibe, nimm das. Nur für diesen Infopavillon, keine allgemeine Vererbung | willkommen@baabe.de | gleich | Bestand hat nur EMAIL_TELEFON; keine getrennten Kanal-/Zweckspalten. |
| E-Mail 2 |  -  |  -  | MD-Zeilen 92-95 | willkommen@baabe.de | quelle_offen | Bestand hat nur EMAIL_TELEFON; keine getrennten Kanal-/Zweckspalten. |
| Ortsteil |  -  |  -  |  -  |  -  | quelle_offen |  -  |
| Geografischer Parent | ORT05 | Ostseebad Baabe | MD-Gliederung + explizite Nutzerregeln; Parent: MD-Gliederung: ### |  -  | nicht_strukturiert |  -  |
| Organisatorischer Parent |  -  |  -  |  -  |  -  | quelle_offen |  -  |

### KV11 · Mönchguter Zimmervermittlung

Namensbestandteile und Kontaktkanal passen wörtlich; Zuordnung trotzdem nicht entschieden und Datenmodell unvollständig.
Fundstelle: Kurverwaltungen_2025.md:L97-103. Hierarchie: 3.1.3.
Fehlend im MD-Original:  - ; fehlend im Arbeitsstand:  - . Nutzerergänzung: nein.

#### Kandidat K69 · Mönchguter Zimmervermittlung
Fundstelle: public/data/spp7-datasets.json#/datasets/contacts/68.
Namenshinweis: Namenswortfolge gleich (Interpunktion/Rechtsformkürzel/Info-Schreibung vereinheitlicht): Mönchguter Zimmervermittlung. Kanalhinweis: email:info@moenchguter-zimmervermittlung.de.
Gleicher Kanal auch bei Referenzen:  - .

| Feld | Referenz-Arbeitswert | MD-Original | Herkunft | Bestand | Vergleich | Hinweis |
|---|---|---|---|---|---|---|
| Name | Mönchguter Zimmervermittlung | Mönchguter Zimmervermittlung | MD-Zeilen 97-103 | Mönchguter Zimmervermittlung | gleich | Abweichende Schreibweise ist nicht automatisch ein Sachfehler oder Identitätsnachweis. |
| Ort | Ostseebad Baabe | 18586 Ostseebad Baabe | MD-Zeilen 97-103 | Ostseebad Baabe | gleich | Nur Textvergleich, keine geografische Korrektur. |
| Straße | Göhrener Chaussee 22 | Göhrener Chaussee 22 | MD-Zeilen 97-103 |  -  | nicht_strukturiert | Referenzwert wörtlich im NOTIZ-Text vorhanden; bleibt Freitext, kein strukturiertes Feld. |
| PLZ | 18586 | 18586 Ostseebad Baabe | MD-Zeilen 97-103 |  -  | nicht_strukturiert | Referenzwert wörtlich im NOTIZ-Text vorhanden; bleibt Freitext, kein strukturiertes Feld. |
| Telefon | +49 38303 9560500 | (03 83 03) 95 60 500 | MD, Zeilen 97-103 |  -  | nicht_strukturiert | Referenz-Ziffernfolge in ausdrücklich als Telefon bezeichnetem NOTIZ-Teil vorhanden; bleibt Freitext, kein strukturiertes Feld. |
| Fax | 038303909932 | (03 83 03) 90 99 32 | MD, Zeilen 97-103 |  -  | nicht_strukturiert |  -  |
| Web | www.moenchguter-zimmervermittlung.de | www.moenchguter-zimmervermittlung.de | MD, Zeilen 97-103 |  -  | nicht_strukturiert | Referenzwert wörtlich im NOTIZ-Text vorhanden; bleibt Freitext, kein strukturiertes Feld. |
| E-Mail 1 | info@moenchguter-zimmervermittlung.de | info@moenchguter-zimmervermittlung.de | MD, Zeilen 97-103 | info@moenchguter-zimmervermittlung.de | gleich | Bestand hat nur EMAIL_TELEFON; keine getrennten Kanal-/Zweckspalten. |
| E-Mail 2 |  -  |  -  | MD-Zeilen 97-103 | info@moenchguter-zimmervermittlung.de | quelle_offen | Bestand hat nur EMAIL_TELEFON; keine getrennten Kanal-/Zweckspalten. |
| Ortsteil |  -  |  -  |  -  |  -  | quelle_offen |  -  |
| Geografischer Parent | ORT05 | Ostseebad Baabe | MD-Gliederung + explizite Nutzerregeln; Parent: MD-Gliederung: ### |  -  | nicht_strukturiert |  -  |
| Organisatorischer Parent |  -  |  -  |  -  |  -  | quelle_offen |  -  |

### KV12 · Kurverwaltung Mönchgut / Tourist-Information Middelhagen

Nur der Kontaktkanal stimmt. Gemeinsame E-Mail kann mehrere Einrichtungen bedienen; Identität nicht nachgewiesen.
Fundstelle: Kurverwaltungen_2025.md:L107-112. Hierarchie: 3.2.1.
Fehlend im MD-Original: web,email; fehlend im Arbeitsstand:  - . Nutzerergänzung: ja.

#### Kandidat K09 · Tourist-Info Middelhagen
Fundstelle: public/data/spp7-datasets.json#/datasets/contacts/8.
Namenshinweis: Namenswortfolge gleich (Interpunktion/Rechtsformkürzel/Info-Schreibung vereinheitlicht): Tourist-Information Middelhagen. Kanalhinweis:  - .
Gleicher Kanal auch bei Referenzen:  - .

| Feld | Referenz-Arbeitswert | MD-Original | Herkunft | Bestand | Vergleich | Hinweis |
|---|---|---|---|---|---|---|
| Name | Kurverwaltung Mönchgut / Tourist-Information Middelhagen | Kurverwaltung Mönchgut | MD-Zeilen 107-112 | Tourist-Info Middelhagen | abweichender_text | Abweichende Schreibweise ist nicht automatisch ein Sachfehler oder Identitätsnachweis. |
| Ort | Ostseebad Mönchgut | 18586 Ostseebad Mönchgut OT Middelhagen | MD-Zeilen 107-112 | Middelhagen | abweichender_text | Bestands-Ortsfeld enthält den benannten Ortsteil; keine separate Ortsteilspalte. |
| Straße | Dorfstraße 4 | Dorfstraße 4 | MD-Zeilen 107-112 |  -  | nicht_strukturiert |  -  |
| PLZ | 18586 | 18586 Ostseebad Mönchgut OT Middelhagen | MD-Zeilen 107-112 |  -  | nicht_strukturiert |  -  |
| Telefon | +49 38308 66010 | (03 83 08) 6 60 10 | MD, Zeilen 107-112 |  -  | nicht_strukturiert |  -  |
| Fax | 038308660110 | (03 83 08) 6 60 110 | MD, Zeilen 107-112 |  -  | nicht_strukturiert |  -  |
| Web | www.ostseebad-moenchgut.de |  -  | nutzerangabe: Frühere explizite Nutzerergänzung für Middelhagen; jetzt ausdrücklich bestätigt: ja die erste Angabe |  -  | nicht_strukturiert |  -  |
| E-Mail 1 | info@ostseebad-moenchgut.de |  -  | nutzerangabe: Frühere explizite Nutzerergänzung für Middelhagen; jetzt ausdrücklich bestätigt: ja die erste Angabe |  -  | fehlt | Bestand hat nur EMAIL_TELEFON; keine getrennten Kanal-/Zweckspalten. |
| E-Mail 2 |  -  |  -  | MD-Zeilen 107-112 |  -  | quelle_offen | Bestand hat nur EMAIL_TELEFON; keine getrennten Kanal-/Zweckspalten. |
| Ortsteil | Middelhagen | Middelhagen | MD, Zeilen 107-112: explizites OT im PLZ-/Ort-Feld |  -  | nicht_strukturiert |  -  |
| Geografischer Parent | ORT06 | Ostseebad Mönchgut | MD-Gliederung + explizite Nutzerregeln; Parent: MD-Gliederung: ### |  -  | nicht_strukturiert |  -  |
| Organisatorischer Parent |  -  |  -  |  -  |  -  | quelle_offen |  -  |

#### Kandidat K10 · Tourist-Info Thiessow
Fundstelle: public/data/spp7-datasets.json#/datasets/contacts/9.
Namenshinweis:  - . Kanalhinweis: email:info@ostseebad-moenchgut.de.
Gleicher Kanal auch bei Referenzen: KV13.

| Feld | Referenz-Arbeitswert | MD-Original | Herkunft | Bestand | Vergleich | Hinweis |
|---|---|---|---|---|---|---|
| Name | Kurverwaltung Mönchgut / Tourist-Information Middelhagen | Kurverwaltung Mönchgut | MD-Zeilen 107-112 | Tourist-Info Thiessow | abweichender_text | Abweichende Schreibweise ist nicht automatisch ein Sachfehler oder Identitätsnachweis. |
| Ort | Ostseebad Mönchgut | 18586 Ostseebad Mönchgut OT Middelhagen | MD-Zeilen 107-112 | Thiessow (Mönchgut) | abweichender_text | Nur Textvergleich, keine geografische Korrektur. |
| Straße | Dorfstraße 4 | Dorfstraße 4 | MD-Zeilen 107-112 |  -  | nicht_strukturiert |  -  |
| PLZ | 18586 | 18586 Ostseebad Mönchgut OT Middelhagen | MD-Zeilen 107-112 |  -  | nicht_strukturiert |  -  |
| Telefon | +49 38308 66010 | (03 83 08) 6 60 10 | MD, Zeilen 107-112 |  -  | nicht_strukturiert |  -  |
| Fax | 038308660110 | (03 83 08) 6 60 110 | MD, Zeilen 107-112 |  -  | nicht_strukturiert |  -  |
| Web | www.ostseebad-moenchgut.de |  -  | nutzerangabe: Frühere explizite Nutzerergänzung für Middelhagen; jetzt ausdrücklich bestätigt: ja die erste Angabe |  -  | nicht_strukturiert |  -  |
| E-Mail 1 | info@ostseebad-moenchgut.de |  -  | nutzerangabe: Frühere explizite Nutzerergänzung für Middelhagen; jetzt ausdrücklich bestätigt: ja die erste Angabe | info@ostseebad-moenchgut.de | gleich | Bestand hat nur EMAIL_TELEFON; keine getrennten Kanal-/Zweckspalten. |
| E-Mail 2 |  -  |  -  | MD-Zeilen 107-112 | info@ostseebad-moenchgut.de | quelle_offen | Bestand hat nur EMAIL_TELEFON; keine getrennten Kanal-/Zweckspalten. |
| Ortsteil | Middelhagen | Middelhagen | MD, Zeilen 107-112: explizites OT im PLZ-/Ort-Feld |  -  | nicht_strukturiert |  -  |
| Geografischer Parent | ORT06 | Ostseebad Mönchgut | MD-Gliederung + explizite Nutzerregeln; Parent: MD-Gliederung: ### |  -  | nicht_strukturiert |  -  |
| Organisatorischer Parent |  -  |  -  |  -  |  -  | quelle_offen |  -  |

### KV13 · Tourist-Information Thiessow (Außenstelle)

Namensbestandteile und Kontaktkanal passen wörtlich; Zuordnung trotzdem nicht entschieden und Datenmodell unvollständig.
Fundstelle: Kurverwaltungen_2025.md:L114-118. Hierarchie: 3.2.2.
Fehlend im MD-Original: telefon,fax; fehlend im Arbeitsstand: fax. Nutzerergänzung: ja.

#### Kandidat K10 · Tourist-Info Thiessow
Fundstelle: public/data/spp7-datasets.json#/datasets/contacts/9.
Namenshinweis: Wörtlich enthaltene Namenswortfolge: Tourist-Information Thiessow (Außenstelle) ↔ Tourist-Info Thiessow. Kanalhinweis: email:info@ostseebad-moenchgut.de.
Gleicher Kanal auch bei Referenzen: KV12.

| Feld | Referenz-Arbeitswert | MD-Original | Herkunft | Bestand | Vergleich | Hinweis |
|---|---|---|---|---|---|---|
| Name | Tourist-Information Thiessow (Außenstelle) | Tourist-Information Thiessow (Außenstelle) | MD-Zeilen 114-118 | Tourist-Info Thiessow | abweichender_text | Abweichende Schreibweise ist nicht automatisch ein Sachfehler oder Identitätsnachweis. |
| Ort | Ostseebad Mönchgut | 18586 Ostseebad Mönchgut OT Thiessow | MD-Zeilen 114-118 | Thiessow (Mönchgut) | abweichender_text | Bestands-Ortsfeld enthält den benannten Ortsteil; keine separate Ortsteilspalte. |
| Straße | Hauptstraße 36 | Hauptstraße 36 | MD-Zeilen 114-118 |  -  | nicht_strukturiert |  -  |
| PLZ | 18586 | 18586 Ostseebad Mönchgut OT Thiessow | MD-Zeilen 114-118 |  -  | nicht_strukturiert |  -  |
| Telefon | +49 38308 66010 |  -  | nutzerangabe_mit_chatzitat: Auftraggeber zitiert den Chat und ergänzt separat Telefon +49 38308 66010 sowie fehlendes Fax |  -  | nicht_strukturiert |  -  |
| Fax |  -  |  -  | nutzerangabe_mit_chatzitat: Auftraggeber zitiert den Chat und ergänzt separat Telefon +49 38308 66010 sowie fehlendes Fax |  -  | quelle_offen |  -  |
| Web | www.ostseebad-moenchgut.de | www.ostseebad-moenchgut.de | MD, Zeilen 114-118 |  -  | nicht_strukturiert |  -  |
| E-Mail 1 | info@ostseebad-moenchgut.de | info@ostseebad-moenchgut.de | MD, Zeilen 114-118 | info@ostseebad-moenchgut.de | gleich | Bestand hat nur EMAIL_TELEFON; keine getrennten Kanal-/Zweckspalten. |
| E-Mail 2 |  -  |  -  | MD-Zeilen 114-118 | info@ostseebad-moenchgut.de | quelle_offen | Bestand hat nur EMAIL_TELEFON; keine getrennten Kanal-/Zweckspalten. |
| Ortsteil | Thiessow | Thiessow | MD, Zeilen 114-118: explizites OT im PLZ-/Ort-Feld |  -  | nicht_strukturiert |  -  |
| Geografischer Parent | ORT06 | Ostseebad Mönchgut | MD-Gliederung + explizite Nutzerregeln; Parent: MD-Gliederung: ### |  -  | nicht_strukturiert |  -  |
| Organisatorischer Parent | KV12 |  -  | Explizite Außenstellen-Zuordnung vom Auftraggeber; geografischer Parent ist dagegen Ostseebad Mönchgut |  -  | nicht_strukturiert |  -  |

### KV14 · Kurverwaltung Göhren

Namensbestandteile und Kontaktkanal passen wörtlich; Zuordnung trotzdem nicht entschieden und Datenmodell unvollständig.
Fundstelle: Kurverwaltungen_2025.md:L122-128. Hierarchie: 3.3.1.
Fehlend im MD-Original:  - ; fehlend im Arbeitsstand:  - . Nutzerergänzung: nein.

#### Kandidat K11 · Kurverwaltung Göhren
Fundstelle: public/data/spp7-datasets.json#/datasets/contacts/10.
Namenshinweis: Namenswortfolge gleich (Interpunktion/Rechtsformkürzel/Info-Schreibung vereinheitlicht): Kurverwaltung Göhren. Kanalhinweis: email:kv@goehren-ruegen.de.
Gleicher Kanal auch bei Referenzen:  - .

| Feld | Referenz-Arbeitswert | MD-Original | Herkunft | Bestand | Vergleich | Hinweis |
|---|---|---|---|---|---|---|
| Name | Kurverwaltung Göhren | Kurverwaltung Göhren | MD-Zeilen 122-128 | Kurverwaltung Göhren | gleich | Abweichende Schreibweise ist nicht automatisch ein Sachfehler oder Identitätsnachweis. |
| Ort | Ostseebad Göhren | 18586 Ostseebad Göhren | MD-Zeilen 122-128 | Göhren | abweichender_text | Nur Textvergleich, keine geografische Korrektur. |
| Straße | Poststraße 9 (im Haus des Gastes) | Poststraße 9 (im Haus des Gastes) | MD-Zeilen 122-128 |  -  | nicht_strukturiert |  -  |
| PLZ | 18586 | 18586 Ostseebad Göhren | MD-Zeilen 122-128 |  -  | nicht_strukturiert |  -  |
| Telefon | +49 38308 66790 | (03 83 08) 6 67 90 | MD, Zeilen 122-128 |  -  | nicht_strukturiert |  -  |
| Fax | 038308667932 | (03 83 08) 66 79 32 | MD, Zeilen 122-128 |  -  | nicht_strukturiert |  -  |
| Web | www.goehren-ruegen.de | www.goehren-ruegen.de | MD, Zeilen 122-128 |  -  | nicht_strukturiert |  -  |
| E-Mail 1 | kv@goehren-ruegen.de | kv@goehren-ruegen.de | MD, Zeilen 122-128 | kv@goehren-ruegen.de | gleich | Bestand hat nur EMAIL_TELEFON; keine getrennten Kanal-/Zweckspalten. |
| E-Mail 2 |  -  |  -  | MD-Zeilen 122-128 | kv@goehren-ruegen.de | quelle_offen | Bestand hat nur EMAIL_TELEFON; keine getrennten Kanal-/Zweckspalten. |
| Ortsteil |  -  |  -  |  -  |  -  | quelle_offen |  -  |
| Geografischer Parent | ORT07 | Ostseebad Göhren | MD-Gliederung + explizite Nutzerregeln; Parent: MD-Gliederung: ### |  -  | nicht_strukturiert |  -  |
| Organisatorischer Parent |  -  |  -  |  -  |  -  | quelle_offen |  -  |

### KV15 · Fremdenverkehrs-und Gewerbeverein Göhren e. V.

Nur der Kontaktkanal stimmt. Gemeinsame E-Mail kann mehrere Einrichtungen bedienen; Identität nicht nachgewiesen.
Fundstelle: Kurverwaltungen_2025.md:L130-136. Hierarchie: 3.3.2.
Fehlend im MD-Original:  - ; fehlend im Arbeitsstand:  - . Nutzerergänzung: nein.

#### Kandidat K12 · Fremdenverkehrsverein Göhren
Fundstelle: public/data/spp7-datasets.json#/datasets/contacts/11.
Namenshinweis:  - . Kanalhinweis: email:mail@info-goehren.de.
Gleicher Kanal auch bei Referenzen:  - .

| Feld | Referenz-Arbeitswert | MD-Original | Herkunft | Bestand | Vergleich | Hinweis |
|---|---|---|---|---|---|---|
| Name | Fremdenverkehrs-und Gewerbeverein Göhren e. V. | Fremdenverkehrs-und Gewerbeverein Göhren e. V. | MD-Zeilen 130-136 | Fremdenverkehrsverein Göhren | abweichender_text | Abweichende Schreibweise ist nicht automatisch ein Sachfehler oder Identitätsnachweis. |
| Ort | Ostseebad Göhren | 18586 Ostseebad Göhren | MD-Zeilen 130-136 | Göhren | abweichender_text | Nur Textvergleich, keine geografische Korrektur. |
| Straße | Poststraße 6 | Poststraße 6 | MD-Zeilen 130-136 |  -  | nicht_strukturiert |  -  |
| PLZ | 18586 | 18586 Ostseebad Göhren | MD-Zeilen 130-136 |  -  | nicht_strukturiert |  -  |
| Telefon | +49 38308 25940 | (03 83 08) 2 59 40 | MD, Zeilen 130-136 |  -  | nicht_strukturiert |  -  |
| Fax | 03830825930 | (03 83 08) 2 59 30 | MD, Zeilen 130-136 |  -  | nicht_strukturiert |  -  |
| Web | www.info-goehren.de | www.info-goehren.de | MD, Zeilen 130-136 |  -  | nicht_strukturiert |  -  |
| E-Mail 1 | mail@info-goehren.de | mail@info-goehren.de | MD, Zeilen 130-136 | mail@info-goehren.de | gleich | Bestand hat nur EMAIL_TELEFON; keine getrennten Kanal-/Zweckspalten. |
| E-Mail 2 |  -  |  -  | MD-Zeilen 130-136 | mail@info-goehren.de | quelle_offen | Bestand hat nur EMAIL_TELEFON; keine getrennten Kanal-/Zweckspalten. |
| Ortsteil |  -  |  -  |  -  |  -  | quelle_offen |  -  |
| Geografischer Parent | ORT07 | Ostseebad Göhren | MD-Gliederung + explizite Nutzerregeln; Parent: MD-Gliederung: ### |  -  | nicht_strukturiert |  -  |
| Organisatorischer Parent |  -  |  -  |  -  |  -  | quelle_offen |  -  |

### KV16 · Tourist-Infostelle/Gemeinde Glowe

Nur der Kontaktkanal stimmt. Gemeinsame E-Mail kann mehrere Einrichtungen bedienen; Identität nicht nachgewiesen.
Fundstelle: Kurverwaltungen_2025.md:L142-148. Hierarchie: 4.1.1.
Fehlend im MD-Original:  - ; fehlend im Arbeitsstand:  - . Nutzerergänzung: nein.

#### Kandidat K13 · Tourist-Info Glowe
Fundstelle: public/data/spp7-datasets.json#/datasets/contacts/12.
Namenshinweis:  - . Kanalhinweis: email:info@glowe.de.
Gleicher Kanal auch bei Referenzen:  - .

| Feld | Referenz-Arbeitswert | MD-Original | Herkunft | Bestand | Vergleich | Hinweis |
|---|---|---|---|---|---|---|
| Name | Tourist-Infostelle/Gemeinde Glowe | Tourist-Infostelle/Gemeinde Glowe | MD-Zeilen 142-148 | Tourist-Info Glowe | abweichender_text | Abweichende Schreibweise ist nicht automatisch ein Sachfehler oder Identitätsnachweis. |
| Ort | Glowe | 18551 Glowe | MD-Zeilen 142-148 | Glowe | gleich | Nur Textvergleich, keine geografische Korrektur. |
| Straße | Boddenmarkt 1 | Boddenmarkt 1 | MD-Zeilen 142-148 |  -  | nicht_strukturiert |  -  |
| PLZ | 18551 | 18551 Glowe | MD-Zeilen 142-148 |  -  | nicht_strukturiert |  -  |
| Telefon | +49 38302 5221 | (03 83 02) 52 21 | MD, Zeilen 142-148 |  -  | nicht_strukturiert |  -  |
| Fax | 0383025252 | (03 83 02) 52 52 | MD, Zeilen 142-148 |  -  | nicht_strukturiert |  -  |
| Web | www.glowe.de | www.glowe.de | MD, Zeilen 142-148 |  -  | nicht_strukturiert |  -  |
| E-Mail 1 | info@glowe.de | info@glowe.de | MD, Zeilen 142-148 | info@glowe.de | gleich | Bestand hat nur EMAIL_TELEFON; keine getrennten Kanal-/Zweckspalten. |
| E-Mail 2 |  -  |  -  | MD-Zeilen 142-148 | info@glowe.de | quelle_offen | Bestand hat nur EMAIL_TELEFON; keine getrennten Kanal-/Zweckspalten. |
| Ortsteil |  -  |  -  |  -  |  -  | quelle_offen |  -  |
| Geografischer Parent | ORT08 | Glowe | MD-Gliederung + explizite Nutzerregeln; Parent: MD-Gliederung: ### |  -  | nicht_strukturiert |  -  |
| Organisatorischer Parent |  -  |  -  |  -  |  -  | quelle_offen |  -  |

### KV17 · Touristik Lohme GmbH

Nur der Kontaktkanal stimmt. Gemeinsame E-Mail kann mehrere Einrichtungen bedienen; Identität nicht nachgewiesen.
Fundstelle: Kurverwaltungen_2025.md:L152-158. Hierarchie: 4.2.1.
Fehlend im MD-Original:  - ; fehlend im Arbeitsstand:  - . Nutzerergänzung: nein.

#### Kandidat K53 · Gemeinde Lohme
Fundstelle: public/data/spp7-datasets.json#/datasets/contacts/52.
Namenshinweis:  - . Kanalhinweis: email:info@lohme.de.
Gleicher Kanal auch bei Referenzen:  - .

| Feld | Referenz-Arbeitswert | MD-Original | Herkunft | Bestand | Vergleich | Hinweis |
|---|---|---|---|---|---|---|
| Name | Touristik Lohme GmbH | Touristik Lohme GmbH | MD-Zeilen 152-158 | Gemeinde Lohme | abweichender_text | Abweichende Schreibweise ist nicht automatisch ein Sachfehler oder Identitätsnachweis. |
| Ort | Lohme | 18551 Lohme | MD-Zeilen 152-158 | Lohme | gleich | Nur Textvergleich, keine geografische Korrektur. |
| Straße | Arkonastr. 31 (Haus Linde) | Arkonastr. 31 (Haus Linde) | MD-Zeilen 152-158 |  -  | nicht_strukturiert |  -  |
| PLZ | 18551 | 18551 Lohme | MD-Zeilen 152-158 |  -  | nicht_strukturiert |  -  |
| Telefon | +49 38302 88855 | (03 83 02) 88 85 5 | MD, Zeilen 152-158 |  -  | nicht_strukturiert |  -  |
| Fax | 03830288857 | (03 83 02) 88 85 7 | MD, Zeilen 152-158 |  -  | nicht_strukturiert |  -  |
| Web | www.lohme.de | www.lohme.de | MD, Zeilen 152-158 |  -  | nicht_strukturiert |  -  |
| E-Mail 1 | info@lohme.de | info@lohme.de | MD, Zeilen 152-158 | info@lohme.de | gleich | Bestand hat nur EMAIL_TELEFON; keine getrennten Kanal-/Zweckspalten. |
| E-Mail 2 |  -  |  -  | MD-Zeilen 152-158 | info@lohme.de | quelle_offen | Bestand hat nur EMAIL_TELEFON; keine getrennten Kanal-/Zweckspalten. |
| Ortsteil |  -  |  -  |  -  |  -  | quelle_offen |  -  |
| Geografischer Parent | ORT09 | Lohme | MD-Gliederung + explizite Nutzerregeln; Parent: MD-Gliederung: ### |  -  | nicht_strukturiert |  -  |
| Organisatorischer Parent |  -  |  -  |  -  |  -  | quelle_offen |  -  |

### KV18 · Tourist-Service der Stadt Sassnitz

Nur der Kontaktkanal stimmt. Gemeinsame E-Mail kann mehrere Einrichtungen bedienen; Identität nicht nachgewiesen.
Fundstelle: Kurverwaltungen_2025.md:L162-168. Hierarchie: 4.3.1.
Fehlend im MD-Original:  - ; fehlend im Arbeitsstand:  - . Nutzerergänzung: nein.

#### Kandidat K14 · Tourist-Service Sassnitz
Fundstelle: public/data/spp7-datasets.json#/datasets/contacts/13.
Namenshinweis:  - . Kanalhinweis: email:mail@insassnitz.de.
Gleicher Kanal auch bei Referenzen:  - .

| Feld | Referenz-Arbeitswert | MD-Original | Herkunft | Bestand | Vergleich | Hinweis |
|---|---|---|---|---|---|---|
| Name | Tourist-Service der Stadt Sassnitz | Tourist-Service der Stadt Sassnitz | MD-Zeilen 162-168 | Tourist-Service Sassnitz | abweichender_text | Abweichende Schreibweise ist nicht automatisch ein Sachfehler oder Identitätsnachweis. |
| Ort | Sassnitz | 18546 Sassnitz | MD-Zeilen 162-168 | Sassnitz | gleich | Nur Textvergleich, keine geografische Korrektur. |
| Straße | Strandpromenade 12 | Strandpromenade 12 | MD-Zeilen 162-168 |  -  | nicht_strukturiert |  -  |
| PLZ | 18546 | 18546 Sassnitz | MD-Zeilen 162-168 |  -  | nicht_strukturiert |  -  |
| Telefon | +49 38392 6490 | (03 83 92) 64 90 | MD, Zeilen 162-168 |  -  | nicht_strukturiert |  -  |
| Fax | 03839264920 | (03 83 92) 6 49 20 | MD, Zeilen 162-168 |  -  | nicht_strukturiert |  -  |
| Web | www.insassnitz.de | www.insassnitz.de | MD, Zeilen 162-168 |  -  | nicht_strukturiert |  -  |
| E-Mail 1 | mail@insassnitz.de | mail@insassnitz.de | MD, Zeilen 162-168 | mail@insassnitz.de | gleich | Bestand hat nur EMAIL_TELEFON; keine getrennten Kanal-/Zweckspalten. |
| E-Mail 2 |  -  |  -  | MD-Zeilen 162-168 | mail@insassnitz.de | quelle_offen | Bestand hat nur EMAIL_TELEFON; keine getrennten Kanal-/Zweckspalten. |
| Ortsteil |  -  |  -  |  -  |  -  | quelle_offen |  -  |
| Geografischer Parent | ORT10 | Sassnitz | MD-Gliederung + explizite Nutzerregeln; Parent: MD-Gliederung: ### |  -  | nicht_strukturiert |  -  |
| Organisatorischer Parent |  -  |  -  |  -  |  -  | quelle_offen |  -  |

#### Kandidat K47 · Stadt Sassnitz
Fundstelle: public/data/spp7-datasets.json#/datasets/contacts/46.
Namenshinweis: Wörtlich enthaltene Namenswortfolge: Tourist-Service der Stadt Sassnitz ↔ Stadt Sassnitz. Kanalhinweis:  - .
Gleicher Kanal auch bei Referenzen:  - .

| Feld | Referenz-Arbeitswert | MD-Original | Herkunft | Bestand | Vergleich | Hinweis |
|---|---|---|---|---|---|---|
| Name | Tourist-Service der Stadt Sassnitz | Tourist-Service der Stadt Sassnitz | MD-Zeilen 162-168 | Stadt Sassnitz | abweichender_text | Abweichende Schreibweise ist nicht automatisch ein Sachfehler oder Identitätsnachweis. |
| Ort | Sassnitz | 18546 Sassnitz | MD-Zeilen 162-168 | Sassnitz | gleich | Nur Textvergleich, keine geografische Korrektur. |
| Straße | Strandpromenade 12 | Strandpromenade 12 | MD-Zeilen 162-168 |  -  | nicht_strukturiert |  -  |
| PLZ | 18546 | 18546 Sassnitz | MD-Zeilen 162-168 |  -  | nicht_strukturiert |  -  |
| Telefon | +49 38392 6490 | (03 83 92) 64 90 | MD, Zeilen 162-168 |  -  | nicht_strukturiert |  -  |
| Fax | 03839264920 | (03 83 92) 6 49 20 | MD, Zeilen 162-168 |  -  | nicht_strukturiert |  -  |
| Web | www.insassnitz.de | www.insassnitz.de | MD, Zeilen 162-168 |  -  | nicht_strukturiert |  -  |
| E-Mail 1 | mail@insassnitz.de | mail@insassnitz.de | MD, Zeilen 162-168 | info@sassnitz.de | abweichender_text | Bestand hat nur EMAIL_TELEFON; keine getrennten Kanal-/Zweckspalten. |
| E-Mail 2 |  -  |  -  | MD-Zeilen 162-168 | info@sassnitz.de | quelle_offen | Bestand hat nur EMAIL_TELEFON; keine getrennten Kanal-/Zweckspalten. |
| Ortsteil |  -  |  -  |  -  |  -  | quelle_offen |  -  |
| Geografischer Parent | ORT10 | Sassnitz | MD-Gliederung + explizite Nutzerregeln; Parent: MD-Gliederung: ### |  -  | nicht_strukturiert |  -  |
| Organisatorischer Parent |  -  |  -  |  -  |  -  | quelle_offen |  -  |

### KV19 · Fremdenverkehrsamt Dranske

Namensbestandteile und Kontaktkanal passen wörtlich; Zuordnung trotzdem nicht entschieden und Datenmodell unvollständig.
Fundstelle: Kurverwaltungen_2025.md:L174-180. Hierarchie: 5.1.1.
Fehlend im MD-Original:  - ; fehlend im Arbeitsstand:  - . Nutzerergänzung: nein.

#### Kandidat K15 · Fremdenverkehrsamt Dranske
Fundstelle: public/data/spp7-datasets.json#/datasets/contacts/14.
Namenshinweis: Namenswortfolge gleich (Interpunktion/Rechtsformkürzel/Info-Schreibung vereinheitlicht): Fremdenverkehrsamt Dranske. Kanalhinweis: email:info@gemeinde-dranske.de.
Gleicher Kanal auch bei Referenzen:  - .

| Feld | Referenz-Arbeitswert | MD-Original | Herkunft | Bestand | Vergleich | Hinweis |
|---|---|---|---|---|---|---|
| Name | Fremdenverkehrsamt Dranske | Fremdenverkehrsamt Dranske | MD-Zeilen 174-180 | Fremdenverkehrsamt Dranske | gleich | Abweichende Schreibweise ist nicht automatisch ein Sachfehler oder Identitätsnachweis. |
| Ort | Dranske | 18556 Dranske | MD-Zeilen 174-180 | Dranske | gleich | Nur Textvergleich, keine geografische Korrektur. |
| Straße | Schulstraße 19 | Schulstraße 19 | MD-Zeilen 174-180 |  -  | nicht_strukturiert |  -  |
| PLZ | 18556 | 18556 Dranske | MD-Zeilen 174-180 |  -  | nicht_strukturiert |  -  |
| Telefon | +49 38391 89007 | (03 83 91) 8 90 07 | MD, Zeilen 174-180 |  -  | nicht_strukturiert |  -  |
| Fax | 03839189424 | (03 83 91) 8 94 24 | MD, Zeilen 174-180 |  -  | nicht_strukturiert |  -  |
| Web | www.gemeinde-dranske.de | www.gemeinde-dranske.de | MD, Zeilen 174-180 |  -  | nicht_strukturiert |  -  |
| E-Mail 1 | info@gemeinde-dranske.de | info@gemeinde-dranske.de | MD, Zeilen 174-180 | info@gemeinde-dranske.de | gleich | Bestand hat nur EMAIL_TELEFON; keine getrennten Kanal-/Zweckspalten. |
| E-Mail 2 |  -  |  -  | MD-Zeilen 174-180 | info@gemeinde-dranske.de | quelle_offen | Bestand hat nur EMAIL_TELEFON; keine getrennten Kanal-/Zweckspalten. |
| Ortsteil |  -  |  -  |  -  |  -  | quelle_offen |  -  |
| Geografischer Parent | ORT11 | Dranske | MD-Gliederung + explizite Nutzerregeln; Parent: MD-Gliederung: ### |  -  | nicht_strukturiert |  -  |
| Organisatorischer Parent |  -  |  -  |  -  |  -  | quelle_offen |  -  |

### KV20 · Informationsamt Seebad Breege-Juliusruh

Nur der Kontaktkanal stimmt. Gemeinsame E-Mail kann mehrere Einrichtungen bedienen; Identität nicht nachgewiesen.
Fundstelle: Kurverwaltungen_2025.md:L184-190. Hierarchie: 5.2.1.
Fehlend im MD-Original:  - ; fehlend im Arbeitsstand:  - . Nutzerergänzung: nein.

#### Kandidat K16 · Infoamt Breege-Juliusruh
Fundstelle: public/data/spp7-datasets.json#/datasets/contacts/15.
Namenshinweis:  - . Kanalhinweis: email:info@breege.de.
Gleicher Kanal auch bei Referenzen:  - .

| Feld | Referenz-Arbeitswert | MD-Original | Herkunft | Bestand | Vergleich | Hinweis |
|---|---|---|---|---|---|---|
| Name | Informationsamt Seebad Breege-Juliusruh | Informationsamt Seebad Breege-Juliusruh | MD-Zeilen 184-190 | Infoamt Breege-Juliusruh | abweichender_text | Abweichende Schreibweise ist nicht automatisch ein Sachfehler oder Identitätsnachweis. |
| Ort | Seebad Juliusruh | 18556 Seebad Juliusruh | MD-Zeilen 184-190 | Breege | abweichender_text | Nur Textvergleich, keine geografische Korrektur. |
| Straße | Wittower Straße 5 | Wittower Straße 5 | MD-Zeilen 184-190 |  -  | nicht_strukturiert |  -  |
| PLZ | 18556 | 18556 Seebad Juliusruh | MD-Zeilen 184-190 |  -  | nicht_strukturiert |  -  |
| Telefon | +49 38391 311 | (03 83 91) 3 11 | MD, Zeilen 184-190 |  -  | nicht_strukturiert |  -  |
| Fax | 03839113235 | (03 83 91) 1 32 35 | MD, Zeilen 184-190 |  -  | nicht_strukturiert |  -  |
| Web | www.breege.de | www.breege.de | MD, Zeilen 184-190 |  -  | nicht_strukturiert |  -  |
| E-Mail 1 | info@breege.de | info@breege.de | MD, Zeilen 184-190 | info@breege.de | gleich | Bestand hat nur EMAIL_TELEFON; keine getrennten Kanal-/Zweckspalten. |
| E-Mail 2 |  -  |  -  | MD-Zeilen 184-190 | info@breege.de | quelle_offen | Bestand hat nur EMAIL_TELEFON; keine getrennten Kanal-/Zweckspalten. |
| Ortsteil |  -  |  -  |  -  |  -  | quelle_offen |  -  |
| Geografischer Parent | ORT12 | Juliusruh | MD-Gliederung + explizite Nutzerregeln; Parent: MD-Gliederung: ### |  -  | nicht_strukturiert |  -  |
| Organisatorischer Parent |  -  |  -  |  -  |  -  | quelle_offen |  -  |

### KV21 · Tourismusgesellschaft mbH Kap Arkona

Nur der Kontaktkanal stimmt. Gemeinsame E-Mail kann mehrere Einrichtungen bedienen; Identität nicht nachgewiesen.
Fundstelle: Kurverwaltungen_2025.md:L194-200. Hierarchie: 5.3.1.
Fehlend im MD-Original:  - ; fehlend im Arbeitsstand:  - . Nutzerergänzung: nein.

#### Kandidat K17 · Tourismus Kap Arkona
Fundstelle: public/data/spp7-datasets.json#/datasets/contacts/16.
Namenshinweis:  - . Kanalhinweis: email:info@kap-arkona.de.
Gleicher Kanal auch bei Referenzen:  - .

| Feld | Referenz-Arbeitswert | MD-Original | Herkunft | Bestand | Vergleich | Hinweis |
|---|---|---|---|---|---|---|
| Name | Tourismusgesellschaft mbH Kap Arkona | Tourismusgesellschaft mbH Kap Arkona | MD-Zeilen 194-200 | Tourismus Kap Arkona | abweichender_text | Abweichende Schreibweise ist nicht automatisch ein Sachfehler oder Identitätsnachweis. |
| Ort | Putgarten | 18556 Putgarten | MD-Zeilen 194-200 | Putgarten (Kap Arkona) | abweichender_text | Nur Textvergleich, keine geografische Korrektur. |
| Straße | Am Parkplatz 1 | Am Parkplatz 1 | MD-Zeilen 194-200 |  -  | nicht_strukturiert |  -  |
| PLZ | 18556 | 18556 Putgarten | MD-Zeilen 194-200 |  -  | nicht_strukturiert |  -  |
| Telefon | +49 38391 13037 | (03 83 91) 1 30 37 | MD, Zeilen 194-200 |  -  | nicht_strukturiert |  -  |
| Fax | 03839141917 | (03 83 91) 4 19 17 | MD, Zeilen 194-200 |  -  | nicht_strukturiert |  -  |
| Web | www.kap-arkona.de | www.kap-arkona.de | MD, Zeilen 194-200 |  -  | nicht_strukturiert |  -  |
| E-Mail 1 | info@kap-arkona.de | info@kap-arkona.de | MD, Zeilen 194-200 | info@kap-arkona.de | gleich | Bestand hat nur EMAIL_TELEFON; keine getrennten Kanal-/Zweckspalten. |
| E-Mail 2 |  -  |  -  | MD-Zeilen 194-200 | info@kap-arkona.de | quelle_offen | Bestand hat nur EMAIL_TELEFON; keine getrennten Kanal-/Zweckspalten. |
| Ortsteil |  -  |  -  |  -  |  -  | quelle_offen |  -  |
| Geografischer Parent | ORT13 | Putgarten/Kap Arkona | MD-Gliederung + explizite Nutzerregeln; Parent: MD-Gliederung: ### |  -  | nicht_strukturiert |  -  |
| Organisatorischer Parent |  -  |  -  |  -  |  -  | quelle_offen |  -  |

### KV22 · Tourismusinformation Wiek

Nur der Kontaktkanal stimmt. Gemeinsame E-Mail kann mehrere Einrichtungen bedienen; Identität nicht nachgewiesen.
Fundstelle: Kurverwaltungen_2025.md:L204-210. Hierarchie: 5.4.1.
Fehlend im MD-Original:  - ; fehlend im Arbeitsstand:  - . Nutzerergänzung: nein.

#### Kandidat K18 · Tourismus Wiek
Fundstelle: public/data/spp7-datasets.json#/datasets/contacts/17.
Namenshinweis:  - . Kanalhinweis: email:info@wiek-ruegen.de.
Gleicher Kanal auch bei Referenzen:  - .

| Feld | Referenz-Arbeitswert | MD-Original | Herkunft | Bestand | Vergleich | Hinweis |
|---|---|---|---|---|---|---|
| Name | Tourismusinformation Wiek | Tourismusinformation Wiek | MD-Zeilen 204-210 | Tourismus Wiek | abweichender_text | Abweichende Schreibweise ist nicht automatisch ein Sachfehler oder Identitätsnachweis. |
| Ort | Wiek | 18556 Wiek | MD-Zeilen 204-210 | Wiek | gleich | Nur Textvergleich, keine geografische Korrektur. |
| Straße | Am Markt 5 | Am Markt 5 | MD-Zeilen 204-210 |  -  | nicht_strukturiert |  -  |
| PLZ | 18556 | 18556 Wiek | MD-Zeilen 204-210 |  -  | nicht_strukturiert |  -  |
| Telefon | +49 38391 76870 | (03 83 91) 7 68 70 | MD, Zeilen 204-210 |  -  | nicht_strukturiert |  -  |
| Fax | 03839176871 | (03 83 91) 7 68 71 | MD, Zeilen 204-210 |  -  | nicht_strukturiert |  -  |
| Web | www.wiek-ruegen.de | www.wiek-ruegen.de | MD, Zeilen 204-210 |  -  | nicht_strukturiert |  -  |
| E-Mail 1 | info@wiek-ruegen.de | info@wiek-ruegen.de | MD, Zeilen 204-210 | info@wiek-ruegen.de | gleich | Bestand hat nur EMAIL_TELEFON; keine getrennten Kanal-/Zweckspalten. |
| E-Mail 2 |  -  |  -  | MD-Zeilen 204-210 | info@wiek-ruegen.de | quelle_offen | Bestand hat nur EMAIL_TELEFON; keine getrennten Kanal-/Zweckspalten. |
| Ortsteil |  -  |  -  |  -  |  -  | quelle_offen |  -  |
| Geografischer Parent | ORT14 | Wiek | MD-Gliederung + explizite Nutzerregeln; Parent: MD-Gliederung: ### |  -  | nicht_strukturiert |  -  |
| Organisatorischer Parent |  -  |  -  |  -  |  -  | quelle_offen |  -  |

### KV23 · Tourismusverein West-Rügen e. V. / Info-Stube Gingst

Namensbestandteile und Kontaktkanal passen wörtlich; Zuordnung trotzdem nicht entschieden und Datenmodell unvollständig.
Fundstelle: Kurverwaltungen_2025.md:L216-223. Hierarchie: 6.1.1.
Fehlend im MD-Original:  - ; fehlend im Arbeitsstand:  - . Nutzerergänzung: nein.

#### Kandidat K19 · Tourismusverein West Rügen – Gingst
Fundstelle: public/data/spp7-datasets.json#/datasets/contacts/18.
Namenshinweis: Wörtlich enthaltene Namenswortfolge: Tourismusverein West-Rügen e. V. ↔ Tourismusverein West Rügen – Gingst. Kanalhinweis: email:info@westruegen.net.
Gleicher Kanal auch bei Referenzen:  - .

| Feld | Referenz-Arbeitswert | MD-Original | Herkunft | Bestand | Vergleich | Hinweis |
|---|---|---|---|---|---|---|
| Name | Tourismusverein West-Rügen e. V. / Info-Stube Gingst | Tourismusverein West-Rügen e. V. | MD-Zeilen 216-223 | Tourismusverein West Rügen – Gingst | abweichender_text | Abweichende Schreibweise ist nicht automatisch ein Sachfehler oder Identitätsnachweis. |
| Ort | Gingst | 18569 Gingst | MD-Zeilen 216-223 | Gingst | gleich | Nur Textvergleich, keine geografische Korrektur. |
| Straße | Karl-Marx-Straße 19 | Karl-Marx-Straße 19 | MD-Zeilen 216-223 |  -  | nicht_strukturiert |  -  |
| PLZ | 18569 | 18569 Gingst | MD-Zeilen 216-223 |  -  | nicht_strukturiert |  -  |
| Telefon | +49 38305 535862 | (03 83 05) 53 58 62 | MD, Zeilen 216-223 |  -  | nicht_strukturiert |  -  |
| Fax | 038305535862 | (03 83 05) 53 58 62 | MD, Zeilen 216-223 |  -  | nicht_strukturiert |  -  |
| Web | www.westruegen.net | www.westruegen.net | MD, Zeilen 216-223 |  -  | nicht_strukturiert |  -  |
| E-Mail 1 | info@westruegen.net | info@westruegen.net | MD, Zeilen 216-223 | info@westruegen.net | gleich | Bestand hat nur EMAIL_TELEFON; keine getrennten Kanal-/Zweckspalten. |
| E-Mail 2 |  -  |  -  | MD-Zeilen 216-223 | info@westruegen.net | quelle_offen | Bestand hat nur EMAIL_TELEFON; keine getrennten Kanal-/Zweckspalten. |
| Ortsteil |  -  |  -  |  -  |  -  | quelle_offen |  -  |
| Geografischer Parent | ORT15 | Gingst | MD-Gliederung + explizite Nutzerregeln; Parent: MD-Gliederung: ### |  -  | nicht_strukturiert |  -  |
| Organisatorischer Parent |  -  |  -  |  -  |  -  | quelle_offen |  -  |

### KV24 · Zimmervermittlung Rügen

Nur der Kontaktkanal stimmt. Gemeinsame E-Mail kann mehrere Einrichtungen bedienen; Identität nicht nachgewiesen.
Fundstelle: Kurverwaltungen_2025.md:L227-233. Hierarchie: 6.2.1.
Fehlend im MD-Original:  - ; fehlend im Arbeitsstand:  - . Nutzerergänzung: nein.

#### Kandidat K57 · Personenkontakt · Name ausgeblendet
Fundstelle: public/data/spp7-datasets.json#/datasets/contacts/56.
Namenshinweis:  - . Kanalhinweis: email-Kanal intern identisch; Personendaten ausgeblendet.
Gleicher Kanal auch bei Referenzen:  - .

| Feld | Referenz-Arbeitswert | MD-Original | Herkunft | Bestand | Vergleich | Hinweis |
|---|---|---|---|---|---|---|
| Name | Zimmervermittlung Rügen | Zimmervermittlung Rügen | MD-Zeilen 227-233 | Personenkontakt · Name ausgeblendet | nicht_vergleichbar | Abweichende Schreibweise ist nicht automatisch ein Sachfehler oder Identitätsnachweis. |
| Ort | Neuenkirchen | 18569 Neuenkirchen | MD-Zeilen 227-233 |  -  | fehlt | Nur Textvergleich, keine geografische Korrektur. |
| Straße | OT Grubnow 1 | OT Grubnow 1 | MD-Zeilen 227-233 |  -  | nicht_strukturiert |  -  |
| PLZ | 18569 | 18569 Neuenkirchen | MD-Zeilen 227-233 |  -  | nicht_strukturiert |  -  |
| Telefon | +49 38309 88001 | (03 83 09) 8 80 01 | MD, Zeilen 227-233 | Personenkanal · ausgeblendet | nicht_strukturiert |  -  |
| Fax | 03830988002 | (03 83 09) 8 80 02 | MD, Zeilen 227-233 |  -  | nicht_strukturiert |  -  |
| Web | www.zv-ruegen.de | www.zv-ruegen.de | MD, Zeilen 227-233 |  -  | nicht_strukturiert |  -  |
| E-Mail 1 | sschoenke@t-online.de | sschoenke@t-online.de | MD, Zeilen 227-233 | Personenkanal · ausgeblendet | nicht_vergleichbar | Bestand hat nur EMAIL_TELEFON; keine getrennten Kanal-/Zweckspalten. |
| E-Mail 2 |  -  |  -  | MD-Zeilen 227-233 | Personenkanal · ausgeblendet | nicht_vergleichbar | Bestand hat nur EMAIL_TELEFON; keine getrennten Kanal-/Zweckspalten. |
| Ortsteil | Grubnow | Grubnow | MD, Zeilen 227-233: explizites OT in der Adresszeile |  -  | nicht_strukturiert |  -  |
| Geografischer Parent | ORT16 | Neuenkirchen | MD-Gliederung + explizite Nutzerregeln; Parent: MD-Gliederung: ### |  -  | nicht_strukturiert |  -  |
| Organisatorischer Parent |  -  |  -  |  -  |  -  | quelle_offen |  -  |

### KV25 · Ummanz-Information

Namensbestandteile und Kontaktkanal passen wörtlich; Zuordnung trotzdem nicht entschieden und Datenmodell unvollständig.
Fundstelle: Kurverwaltungen_2025.md:L237-243. Hierarchie: 6.3.1.
Fehlend im MD-Original:  - ; fehlend im Arbeitsstand:  - . Nutzerergänzung: nein.

#### Kandidat K20 · Ummanz-Information
Fundstelle: public/data/spp7-datasets.json#/datasets/contacts/19.
Namenshinweis: Namenswortfolge gleich (Interpunktion/Rechtsformkürzel/Info-Schreibung vereinheitlicht): Ummanz-Information. Kanalhinweis: email:kontakt@ruegeninsel-ummanz.de.
Gleicher Kanal auch bei Referenzen:  - .

| Feld | Referenz-Arbeitswert | MD-Original | Herkunft | Bestand | Vergleich | Hinweis |
|---|---|---|---|---|---|---|
| Name | Ummanz-Information | Ummanz-Information | MD-Zeilen 237-243 | Ummanz-Information | gleich | Abweichende Schreibweise ist nicht automatisch ein Sachfehler oder Identitätsnachweis. |
| Ort | Waase/Ummanz | 18569 Waase/Ummanz | MD-Zeilen 237-243 | Ummanz | abweichender_text | Nur Textvergleich, keine geografische Korrektur. |
| Straße | Neue Straße 63 a | Neue Straße 63 a | MD-Zeilen 237-243 |  -  | nicht_strukturiert |  -  |
| PLZ | 18569 | 18569 Waase/Ummanz | MD-Zeilen 237-243 |  -  | nicht_strukturiert |  -  |
| Telefon | +49 38305 53481 | (03 83 05) 5 34 81 | MD, Zeilen 237-243 |  -  | nicht_strukturiert |  -  |
| Fax | 03830553483 | (03 83 05) 5 34 83 | MD, Zeilen 237-243 |  -  | nicht_strukturiert |  -  |
| Web | www.ruegeninsel-ummanz.de | www.ruegeninsel-ummanz.de | MD, Zeilen 237-243 |  -  | nicht_strukturiert |  -  |
| E-Mail 1 | kontakt@ruegeninsel-ummanz.de | kontakt@ruegeninsel-ummanz.de | MD, Zeilen 237-243 | kontakt@ruegeninsel-ummanz.de | gleich | Bestand hat nur EMAIL_TELEFON; keine getrennten Kanal-/Zweckspalten. |
| E-Mail 2 |  -  |  -  | MD-Zeilen 237-243 | kontakt@ruegeninsel-ummanz.de | quelle_offen | Bestand hat nur EMAIL_TELEFON; keine getrennten Kanal-/Zweckspalten. |
| Ortsteil |  -  |  -  |  -  |  -  | quelle_offen |  -  |
| Geografischer Parent | ORT17 | Ummanz | MD-Gliederung + explizite Nutzerregeln; Parent: MD-Gliederung: ### |  -  | nicht_strukturiert |  -  |
| Organisatorischer Parent |  -  |  -  |  -  |  -  | quelle_offen |  -  |

### KV26 · Gemeinde Seebad Altefähr / Eigenbetrieb Hafen-und Tourismuswirtschaft Altefähr

Nur der Kontaktkanal stimmt. Gemeinsame E-Mail kann mehrere Einrichtungen bedienen; Identität nicht nachgewiesen.
Fundstelle: Kurverwaltungen_2025.md:L249-256. Hierarchie: 7.1.1.
Fehlend im MD-Original:  - ; fehlend im Arbeitsstand:  - . Nutzerergänzung: nein.

#### Kandidat K21 · Info Seebad Altefähr
Fundstelle: public/data/spp7-datasets.json#/datasets/contacts/20.
Namenshinweis:  - . Kanalhinweis: email:info@altefaehr.de.
Gleicher Kanal auch bei Referenzen:  - .

| Feld | Referenz-Arbeitswert | MD-Original | Herkunft | Bestand | Vergleich | Hinweis |
|---|---|---|---|---|---|---|
| Name | Gemeinde Seebad Altefähr / Eigenbetrieb Hafen-und Tourismuswirtschaft Altefähr | Gemeinde Seebad Altefähr | MD-Zeilen 249-256 | Info Seebad Altefähr | abweichender_text | Abweichende Schreibweise ist nicht automatisch ein Sachfehler oder Identitätsnachweis. |
| Ort | Altefähr | 18573 Altefähr | MD-Zeilen 249-256 | Altefähr | gleich | Nur Textvergleich, keine geografische Korrektur. |
| Straße | Am Fährberg 9 | Am Fährberg 9 | MD-Zeilen 249-256 |  -  | nicht_strukturiert |  -  |
| PLZ | 18573 | 18573 Altefähr | MD-Zeilen 249-256 |  -  | nicht_strukturiert |  -  |
| Telefon | +49 38306 75037 | (03 83 06) 7 50 37 | MD, Zeilen 249-256 |  -  | nicht_strukturiert |  -  |
| Fax | 03830675056 | (03 83 06) 7 50 56 | MD, Zeilen 249-256 |  -  | nicht_strukturiert |  -  |
| Web | www.altefaehr.de | www.altefaehr.de | MD, Zeilen 249-256 |  -  | nicht_strukturiert |  -  |
| E-Mail 1 | info@altefaehr.de | info@altefaehr.de | MD, Zeilen 249-256 | info@altefaehr.de | gleich | Bestand hat nur EMAIL_TELEFON; keine getrennten Kanal-/Zweckspalten. |
| E-Mail 2 |  -  |  -  | MD-Zeilen 249-256 | info@altefaehr.de | quelle_offen | Bestand hat nur EMAIL_TELEFON; keine getrennten Kanal-/Zweckspalten. |
| Ortsteil |  -  |  -  |  -  |  -  | quelle_offen |  -  |
| Geografischer Parent | ORT18 | Altefähr | MD-Gliederung + explizite Nutzerregeln; Parent: MD-Gliederung: ### |  -  | nicht_strukturiert |  -  |
| Organisatorischer Parent |  -  |  -  |  -  |  -  | quelle_offen |  -  |

### KV27 · Kurverwaltung Putbus/Stadtinformation

Namensbestandteile und Kontaktkanal passen wörtlich; Zuordnung trotzdem nicht entschieden und Datenmodell unvollständig.
Fundstelle: Kurverwaltungen_2025.md:L260-266. Hierarchie: 7.2.1.
Fehlend im MD-Original:  - ; fehlend im Arbeitsstand:  - . Nutzerergänzung: nein.

#### Kandidat K22 · Kurverwaltung Putbus
Fundstelle: public/data/spp7-datasets.json#/datasets/contacts/21.
Namenshinweis: Namenswortfolge gleich (Interpunktion/Rechtsformkürzel/Info-Schreibung vereinheitlicht): Kurverwaltung Putbus. Kanalhinweis:  - .
Gleicher Kanal auch bei Referenzen:  - .

| Feld | Referenz-Arbeitswert | MD-Original | Herkunft | Bestand | Vergleich | Hinweis |
|---|---|---|---|---|---|---|
| Name | Kurverwaltung Putbus/Stadtinformation | Kurverwaltung Putbus/Stadtinformation | MD-Zeilen 260-266 | Kurverwaltung Putbus | abweichender_text | Abweichende Schreibweise ist nicht automatisch ein Sachfehler oder Identitätsnachweis. |
| Ort | Putbus | 18581 Putbus | MD-Zeilen 260-266 | Putbus | gleich | Nur Textvergleich, keine geografische Korrektur. |
| Straße | Alleestraße 2 | Alleestraße 2 | MD-Zeilen 260-266 |  -  | nicht_strukturiert |  -  |
| PLZ | 18581 | 18581 Putbus | MD-Zeilen 260-266 |  -  | nicht_strukturiert |  -  |
| Telefon | +49 38301 60964 | (03 83 01) 6 09 64 | MD, Zeilen 260-266 |  -  | nicht_strukturiert |  -  |
| Fax | 03830160963 | (03 83 01) 6 09 63 | MD, Zeilen 260-266 |  -  | nicht_strukturiert |  -  |
| Web | www.ruegen-putbus.de | www.ruegen-putbus.de | MD, Zeilen 260-266 |  -  | nicht_strukturiert |  -  |
| E-Mail 1 | info.putbus@putbus.de | info.putbus@putbus.de | MD, Zeilen 260-266 | service@ruegen-putbus.de | abweichender_text | Bestand hat nur EMAIL_TELEFON; keine getrennten Kanal-/Zweckspalten. |
| E-Mail 2 |  -  |  -  | MD-Zeilen 260-266 | service@ruegen-putbus.de | quelle_offen | Bestand hat nur EMAIL_TELEFON; keine getrennten Kanal-/Zweckspalten. |
| Ortsteil |  -  |  -  |  -  |  -  | quelle_offen |  -  |
| Geografischer Parent | ORT19 | Putbus | MD-Gliederung + explizite Nutzerregeln; Parent: MD-Gliederung: ### |  -  | nicht_strukturiert |  -  |
| Organisatorischer Parent |  -  |  -  |  -  |  -  | quelle_offen |  -  |

#### Kandidat K23 · Kurverwaltung Putbus
Fundstelle: public/data/spp7-datasets.json#/datasets/contacts/22.
Namenshinweis: Namenswortfolge gleich (Interpunktion/Rechtsformkürzel/Info-Schreibung vereinheitlicht): Kurverwaltung Putbus. Kanalhinweis:  - .
Gleicher Kanal auch bei Referenzen:  - .

| Feld | Referenz-Arbeitswert | MD-Original | Herkunft | Bestand | Vergleich | Hinweis |
|---|---|---|---|---|---|---|
| Name | Kurverwaltung Putbus/Stadtinformation | Kurverwaltung Putbus/Stadtinformation | MD-Zeilen 260-266 | Kurverwaltung Putbus | abweichender_text | Abweichende Schreibweise ist nicht automatisch ein Sachfehler oder Identitätsnachweis. |
| Ort | Putbus | 18581 Putbus | MD-Zeilen 260-266 | Putbus | gleich | Nur Textvergleich, keine geografische Korrektur. |
| Straße | Alleestraße 2 | Alleestraße 2 | MD-Zeilen 260-266 |  -  | nicht_strukturiert |  -  |
| PLZ | 18581 | 18581 Putbus | MD-Zeilen 260-266 |  -  | nicht_strukturiert |  -  |
| Telefon | +49 38301 60964 | (03 83 01) 6 09 64 | MD, Zeilen 260-266 |  -  | nicht_strukturiert |  -  |
| Fax | 03830160963 | (03 83 01) 6 09 63 | MD, Zeilen 260-266 |  -  | nicht_strukturiert |  -  |
| Web | www.ruegen-putbus.de | www.ruegen-putbus.de | MD, Zeilen 260-266 |  -  | nicht_strukturiert |  -  |
| E-Mail 1 | info.putbus@putbus.de | info.putbus@putbus.de | MD, Zeilen 260-266 | kurverwaltung@ruegen-putbus.de | abweichender_text | Bestand hat nur EMAIL_TELEFON; keine getrennten Kanal-/Zweckspalten. |
| E-Mail 2 |  -  |  -  | MD-Zeilen 260-266 | kurverwaltung@ruegen-putbus.de | quelle_offen | Bestand hat nur EMAIL_TELEFON; keine getrennten Kanal-/Zweckspalten. |
| Ortsteil |  -  |  -  |  -  |  -  | quelle_offen |  -  |
| Geografischer Parent | ORT19 | Putbus | MD-Gliederung + explizite Nutzerregeln; Parent: MD-Gliederung: ### |  -  | nicht_strukturiert |  -  |
| Organisatorischer Parent |  -  |  -  |  -  |  -  | quelle_offen |  -  |

#### Kandidat K70 · Kurverwaltung Putbus/Stadtinformation
Fundstelle: public/data/spp7-datasets.json#/datasets/contacts/69.
Namenshinweis: Namenswortfolge gleich (Interpunktion/Rechtsformkürzel/Info-Schreibung vereinheitlicht): Kurverwaltung Putbus/Stadtinformation. Kanalhinweis: email:info.putbus@putbus.de.
Gleicher Kanal auch bei Referenzen:  - .

| Feld | Referenz-Arbeitswert | MD-Original | Herkunft | Bestand | Vergleich | Hinweis |
|---|---|---|---|---|---|---|
| Name | Kurverwaltung Putbus/Stadtinformation | Kurverwaltung Putbus/Stadtinformation | MD-Zeilen 260-266 | Kurverwaltung Putbus/Stadtinformation | gleich | Abweichende Schreibweise ist nicht automatisch ein Sachfehler oder Identitätsnachweis. |
| Ort | Putbus | 18581 Putbus | MD-Zeilen 260-266 | Putbus | gleich | Nur Textvergleich, keine geografische Korrektur. |
| Straße | Alleestraße 2 | Alleestraße 2 | MD-Zeilen 260-266 |  -  | nicht_strukturiert | Referenzwert wörtlich im NOTIZ-Text vorhanden; bleibt Freitext, kein strukturiertes Feld. |
| PLZ | 18581 | 18581 Putbus | MD-Zeilen 260-266 |  -  | nicht_strukturiert | Referenzwert wörtlich im NOTIZ-Text vorhanden; bleibt Freitext, kein strukturiertes Feld. |
| Telefon | +49 38301 60964 | (03 83 01) 6 09 64 | MD, Zeilen 260-266 |  -  | nicht_strukturiert | Referenz-Ziffernfolge in ausdrücklich als Telefon bezeichnetem NOTIZ-Teil vorhanden; bleibt Freitext, kein strukturiertes Feld. |
| Fax | 03830160963 | (03 83 01) 6 09 63 | MD, Zeilen 260-266 |  -  | nicht_strukturiert |  -  |
| Web | www.ruegen-putbus.de | www.ruegen-putbus.de | MD, Zeilen 260-266 |  -  | nicht_strukturiert |  -  |
| E-Mail 1 | info.putbus@putbus.de | info.putbus@putbus.de | MD, Zeilen 260-266 | info.putbus@putbus.de | gleich | Bestand hat nur EMAIL_TELEFON; keine getrennten Kanal-/Zweckspalten. |
| E-Mail 2 |  -  |  -  | MD-Zeilen 260-266 | info.putbus@putbus.de | quelle_offen | Bestand hat nur EMAIL_TELEFON; keine getrennten Kanal-/Zweckspalten. |
| Ortsteil |  -  |  -  |  -  |  -  | quelle_offen |  -  |
| Geografischer Parent | ORT19 | Putbus | MD-Gliederung + explizite Nutzerregeln; Parent: MD-Gliederung: ### |  -  | nicht_strukturiert |  -  |
| Organisatorischer Parent |  -  |  -  |  -  |  -  | quelle_offen |  -  |

### KV28 · Tourismus-und Gewerbeverein Putbus e. V.

Namensbestandteile und Kontaktkanal passen wörtlich; Zuordnung trotzdem nicht entschieden und Datenmodell unvollständig.
Fundstelle: Kurverwaltungen_2025.md:L270-277. Hierarchie: 7.3.1.
Fehlend im MD-Original:  - ; fehlend im Arbeitsstand:  - . Nutzerergänzung: nein.

#### Kandidat K71 · Tourismus- und Gewerbeverein Putbus e. V.
Fundstelle: public/data/spp7-datasets.json#/datasets/contacts/70.
Namenshinweis: Namenswortfolge gleich (Interpunktion/Rechtsformkürzel/Info-Schreibung vereinheitlicht): Tourismus-und Gewerbeverein Putbus e. V.. Kanalhinweis: email:tgv-putbus@gmx.de.
Gleicher Kanal auch bei Referenzen:  - .

| Feld | Referenz-Arbeitswert | MD-Original | Herkunft | Bestand | Vergleich | Hinweis |
|---|---|---|---|---|---|---|
| Name | Tourismus-und Gewerbeverein Putbus e. V. | Tourismus-und Gewerbeverein Putbus e. V. | MD-Zeilen 270-277 | Tourismus- und Gewerbeverein Putbus e. V. | gleich | Abweichende Schreibweise ist nicht automatisch ein Sachfehler oder Identitätsnachweis. |
| Ort | Lauterbach | 18581 Lauterbach | MD-Zeilen 270-277 | Lauterbach (Putbus) | abweichender_text | Nur Textvergleich, keine geografische Korrektur. |
| Straße | Pappelweg 7 | Pappelweg 7 | MD-Zeilen 270-277 |  -  | nicht_strukturiert | Referenzwert wörtlich im NOTIZ-Text vorhanden; bleibt Freitext, kein strukturiertes Feld. |
| PLZ | 18581 | 18581 Lauterbach | MD-Zeilen 270-277 |  -  | nicht_strukturiert | Referenzwert wörtlich im NOTIZ-Text vorhanden; bleibt Freitext, kein strukturiertes Feld. |
| Telefon | +49 38301 60467 | (03 83 01) 6 04 67 | MD, Zeilen 270-277 |  -  | nicht_strukturiert | Referenz-Ziffernfolge in ausdrücklich als Telefon bezeichnetem NOTIZ-Teil vorhanden; bleibt Freitext, kein strukturiertes Feld. |
| Fax | 03830160377 | (03 83 01) 6 03 77 | MD, Zeilen 270-277 |  -  | nicht_strukturiert |  -  |
| Web | www.gastgeber-putbus.de | www.gastgeber-putbus.de | MD, Zeilen 270-277 |  -  | nicht_strukturiert |  -  |
| E-Mail 1 | tgv-putbus@gmx.de | tgv-putbus@gmx.de | MD, Zeilen 270-277 | tgv-putbus@gmx.de | gleich | Bestand hat nur EMAIL_TELEFON; keine getrennten Kanal-/Zweckspalten. |
| E-Mail 2 |  -  |  -  | MD-Zeilen 270-277 | tgv-putbus@gmx.de | quelle_offen | Bestand hat nur EMAIL_TELEFON; keine getrennten Kanal-/Zweckspalten. |
| Ortsteil |  -  |  -  |  -  |  -  | quelle_offen |  -  |
| Geografischer Parent | ORT20 | Lauterbach (Putbus) | MD-Gliederung + explizite Nutzerregeln; Parent: MD-Gliederung: ### |  -  | nicht_strukturiert |  -  |
| Organisatorischer Parent |  -  |  -  |  -  |  -  | quelle_offen |  -  |

### KV29 · Stadtinformation Bergen auf Rügen / Bergen Touristik Service UG

Namensbestandteile und Kontaktkanal passen wörtlich; Zuordnung trotzdem nicht entschieden und Datenmodell unvollständig.
Fundstelle: Kurverwaltungen_2025.md:L283-290. Hierarchie: 8.1.1.
Fehlend im MD-Original:  - ; fehlend im Arbeitsstand:  - . Nutzerergänzung: nein.

#### Kandidat K29 · Stadtinformation Bergen
Fundstelle: public/data/spp7-datasets.json#/datasets/contacts/28.
Namenshinweis: Wörtlich enthaltene Namenswortfolge: Stadtinformation Bergen auf Rügen ↔ Stadtinformation Bergen. Kanalhinweis: email:post@stadtinfo-bergen-ruegen.de.
Gleicher Kanal auch bei Referenzen:  - .

| Feld | Referenz-Arbeitswert | MD-Original | Herkunft | Bestand | Vergleich | Hinweis |
|---|---|---|---|---|---|---|
| Name | Stadtinformation Bergen auf Rügen / Bergen Touristik Service UG | Stadtinformation Bergen auf Rügen | MD-Zeilen 283-290 | Stadtinformation Bergen | abweichender_text | Abweichende Schreibweise ist nicht automatisch ein Sachfehler oder Identitätsnachweis. |
| Ort | Bergen auf Rügen | 18528 Bergen auf Rügen | MD-Zeilen 283-290 | Bergen auf Rügen | gleich | Nur Textvergleich, keine geografische Korrektur. |
| Straße | Markt 23 | Markt 23 | MD-Zeilen 283-290 |  -  | nicht_strukturiert |  -  |
| PLZ | 18528 | 18528 Bergen auf Rügen | MD-Zeilen 283-290 |  -  | nicht_strukturiert |  -  |
| Telefon | +49 3838 3152838 | (0 38 38) 3 15 28 38 | MD, Zeilen 283-290 |  -  | nicht_strukturiert |  -  |
| Fax | 038383152839 | (0 38 38) 3 15 28 39 | MD, Zeilen 283-290 |  -  | nicht_strukturiert |  -  |
| Web | www.stadtinfo-bergen-ruegen.de | www.stadtinfo-bergen-ruegen.de | MD, Zeilen 283-290 |  -  | nicht_strukturiert |  -  |
| E-Mail 1 | post@stadtinfo-bergen-ruegen.de | post@stadtinfo-bergen-ruegen.de | MD, Zeilen 283-290 | post@stadtinfo-bergen-ruegen.de | gleich | Bestand hat nur EMAIL_TELEFON; keine getrennten Kanal-/Zweckspalten. |
| E-Mail 2 |  -  |  -  | MD-Zeilen 283-290 | post@stadtinfo-bergen-ruegen.de | quelle_offen | Bestand hat nur EMAIL_TELEFON; keine getrennten Kanal-/Zweckspalten. |
| Ortsteil |  -  |  -  |  -  |  -  | quelle_offen |  -  |
| Geografischer Parent | ORT21 | Bergen auf Rügen | MD-Gliederung + explizite Nutzerregeln; Parent: MD-Gliederung: ### |  -  | nicht_strukturiert |  -  |
| Organisatorischer Parent |  -  |  -  |  -  |  -  | quelle_offen |  -  |

### KV30 · Insel Information Hiddensee

Namensbestandteile und Kontaktkanal passen wörtlich; Zuordnung trotzdem nicht entschieden und Datenmodell unvollständig.
Fundstelle: Kurverwaltungen_2025.md:L296-302. Hierarchie: 9.1.1.
Fehlend im MD-Original:  - ; fehlend im Arbeitsstand:  - . Nutzerergänzung: nein.

#### Kandidat K31 · Insel-Information Hiddensee
Fundstelle: public/data/spp7-datasets.json#/datasets/contacts/30.
Namenshinweis: Namenswortfolge gleich (Interpunktion/Rechtsformkürzel/Info-Schreibung vereinheitlicht): Insel Information Hiddensee. Kanalhinweis: email:info@seebad-hiddensee.de.
Gleicher Kanal auch bei Referenzen:  - .

| Feld | Referenz-Arbeitswert | MD-Original | Herkunft | Bestand | Vergleich | Hinweis |
|---|---|---|---|---|---|---|
| Name | Insel Information Hiddensee | Insel Information Hiddensee | MD-Zeilen 296-302 | Insel-Information Hiddensee | gleich | Abweichende Schreibweise ist nicht automatisch ein Sachfehler oder Identitätsnachweis. |
| Ort | Vitte | 18565 Vitte | MD-Zeilen 296-302 | Vitte (Hiddensee) | abweichender_text | Nur Textvergleich, keine geografische Korrektur. |
| Straße | Achtern Diek 18a | Achtern Diek 18a | MD-Zeilen 296-302 |  -  | nicht_strukturiert |  -  |
| PLZ | 18565 | 18565 Vitte | MD-Zeilen 296-302 |  -  | nicht_strukturiert |  -  |
| Telefon | +49 38300 608685 | (03 83 00) 60 86 85 | MD, Zeilen 296-302 |  -  | nicht_strukturiert |  -  |
| Fax | 038300608689 | (03 83 00) 60 86 89 | MD, Zeilen 296-302 |  -  | nicht_strukturiert |  -  |
| Web | www.seebad-hiddensee.de | www.seebad-hiddensee.de | MD, Zeilen 296-302 |  -  | nicht_strukturiert |  -  |
| E-Mail 1 | info@seebad-hiddensee.de | info@seebad-hiddensee.de | MD, Zeilen 296-302 | info@seebad-hiddensee.de | gleich | Bestand hat nur EMAIL_TELEFON; keine getrennten Kanal-/Zweckspalten. |
| E-Mail 2 |  -  |  -  | MD-Zeilen 296-302 | info@seebad-hiddensee.de | quelle_offen | Bestand hat nur EMAIL_TELEFON; keine getrennten Kanal-/Zweckspalten. |
| Ortsteil |  -  |  -  |  -  |  -  | quelle_offen |  -  |
| Geografischer Parent | ORT22 | Vitte | MD-Gliederung + explizite Nutzerregeln; Parent: MD-Fundstellen + nutzerangabe: Auftraggeber-Beispiel: Seebad Insel Hiddensee → Vitte → Insel Information Hiddensee und HTS; Kloster bleibt separat |  -  | nicht_strukturiert |  -  |
| Organisatorischer Parent |  -  |  -  |  -  |  -  | quelle_offen |  -  |

### KV31 · Tourist Information im Hafencenter Kloster

Nur der Kontaktkanal stimmt. Gemeinsame E-Mail kann mehrere Einrichtungen bedienen; Identität nicht nachgewiesen.
Fundstelle: Kurverwaltungen_2025.md:L306-311. Hierarchie: 9.2.1.
Fehlend im MD-Original: web; fehlend im Arbeitsstand: web. Nutzerergänzung: nein.

#### Kandidat K32 · Hafencenter Kloster (Hiddensee)
Fundstelle: public/data/spp7-datasets.json#/datasets/contacts/31.
Namenshinweis:  - . Kanalhinweis: email:hafencenter@seebad-hiddensee.de.
Gleicher Kanal auch bei Referenzen:  - .

| Feld | Referenz-Arbeitswert | MD-Original | Herkunft | Bestand | Vergleich | Hinweis |
|---|---|---|---|---|---|---|
| Name | Tourist Information im Hafencenter Kloster | Tourist Information im Hafencenter Kloster | MD-Zeilen 306-311 | Hafencenter Kloster (Hiddensee) | abweichender_text | Abweichende Schreibweise ist nicht automatisch ein Sachfehler oder Identitätsnachweis. |
| Ort | Kloster | 18565 Kloster | MD-Zeilen 306-311 | Kloster (Hiddensee) | abweichender_text | Nur Textvergleich, keine geografische Korrektur. |
| Straße | Hafenweg 15 | Hafenweg 15 | MD-Zeilen 306-311 |  -  | nicht_strukturiert |  -  |
| PLZ | 18565 | 18565 Kloster | MD-Zeilen 306-311 |  -  | nicht_strukturiert |  -  |
| Telefon | +49 38300 60654 | (03 83 00) 60 65 4 | MD, Zeilen 306-311 |  -  | nicht_strukturiert |  -  |
| Fax | 03830060791 | (03 83 00) 60 79 1 | MD, Zeilen 306-311 |  -  | nicht_strukturiert |  -  |
| Web |  -  |  -  |  -  |  -  | quelle_offen |  -  |
| E-Mail 1 | hafencenter@seebad-hiddensee.de | hafencenter@seebad-hiddensee.de | MD, Zeilen 306-311 | hafencenter@seebad-hiddensee.de | gleich | Bestand hat nur EMAIL_TELEFON; keine getrennten Kanal-/Zweckspalten. |
| E-Mail 2 |  -  |  -  | MD-Zeilen 306-311 | hafencenter@seebad-hiddensee.de | quelle_offen | Bestand hat nur EMAIL_TELEFON; keine getrennten Kanal-/Zweckspalten. |
| Ortsteil |  -  |  -  |  -  |  -  | quelle_offen |  -  |
| Geografischer Parent | ORT23 | Kloster | MD-Gliederung + explizite Nutzerregeln; Parent: MD-Gliederung: ### |  -  | nicht_strukturiert |  -  |
| Organisatorischer Parent |  -  |  -  |  -  |  -  | quelle_offen |  -  |

### KV32 · HTS / Hiddensee Touristik & Service

Namensbestandteile und Kontaktkanal passen wörtlich; Zuordnung trotzdem nicht entschieden und Datenmodell unvollständig.
Fundstelle: Kurverwaltungen_2025.md:L315-321. Hierarchie: 9.1.2.
Fehlend im MD-Original:  - ; fehlend im Arbeitsstand:  - . Nutzerergänzung: ja.

#### Kandidat K72 · HTS Hiddensee Touristik Service
Fundstelle: public/data/spp7-datasets.json#/datasets/contacts/71.
Namenshinweis: Wörtlich enthaltene Namenswortfolge: Hiddensee Touristik & Service ↔ HTS Hiddensee Touristik Service. Kanalhinweis: email:mail@hiddensee-touristik.de.
Gleicher Kanal auch bei Referenzen:  - .

| Feld | Referenz-Arbeitswert | MD-Original | Herkunft | Bestand | Vergleich | Hinweis |
|---|---|---|---|---|---|---|
| Name | HTS / Hiddensee Touristik & Service | HTS | nutzerangabe: Aktuelle Auftraggeber-Ergänzung des ausgeschriebenen HTS-Namens im Hiddensee-Beispiel | HTS Hiddensee Touristik Service | gleich | Abweichende Schreibweise ist nicht automatisch ein Sachfehler oder Identitätsnachweis. |
| Ort | Vitte | 18565 Vitte | MD-Zeilen 315-321 | Vitte (Hiddensee) | abweichender_text | Nur Textvergleich, keine geografische Korrektur. |
| Straße | Wiesenweg 21a | Wiesenweg 21a | MD-Zeilen 315-321 |  -  | nicht_strukturiert | Referenzwert wörtlich im NOTIZ-Text vorhanden; bleibt Freitext, kein strukturiertes Feld. |
| PLZ | 18565 | 18565 Vitte | MD-Zeilen 315-321 |  -  | nicht_strukturiert | Referenzwert wörtlich im NOTIZ-Text vorhanden; bleibt Freitext, kein strukturiertes Feld. |
| Telefon | +49 38300 60497 | (03 83 00) 60 49 7 | MD, Zeilen 315-321 |  -  | nicht_strukturiert | Referenz-Ziffernfolge in ausdrücklich als Telefon bezeichnetem NOTIZ-Teil vorhanden; bleibt Freitext, kein strukturiertes Feld. |
| Fax | 03830060498 | (03 83 00) 60 49 8 | MD, Zeilen 315-321 |  -  | nicht_strukturiert |  -  |
| Web | www.hiddensee-touristik.de | www.hiddensee-touristik.de | MD, Zeilen 315-321 |  -  | nicht_strukturiert | Referenzwert wörtlich im NOTIZ-Text vorhanden; bleibt Freitext, kein strukturiertes Feld. |
| E-Mail 1 | mail@hiddensee-touristik.de | mail@hiddensee-touristik.de | MD, Zeilen 315-321 | mail@hiddensee-touristik.de | gleich | Bestand hat nur EMAIL_TELEFON; keine getrennten Kanal-/Zweckspalten. |
| E-Mail 2 |  -  |  -  | MD-Zeilen 315-321 | mail@hiddensee-touristik.de | quelle_offen | Bestand hat nur EMAIL_TELEFON; keine getrennten Kanal-/Zweckspalten. |
| Ortsteil |  -  |  -  |  -  |  -  | quelle_offen |  -  |
| Geografischer Parent | ORT22 | Vitte | MD-Gliederung + explizite Nutzerregeln; Parent: MD-Fundstellen + nutzerangabe: Auftraggeber-Beispiel: Seebad Insel Hiddensee → Vitte → Insel Information Hiddensee und HTS; Kloster bleibt separat |  -  | nicht_strukturiert |  -  |
| Organisatorischer Parent |  -  |  -  |  -  |  -  | quelle_offen |  -  |

## Alle 54 Referenzterminzeilen

| Referenz | Jahr | Originaldatum | Veranstaltung | Ort | Status | Kandidaten |
|---|---|---|---|---|---|---|
| SF01 | 2026 | 3. - 4. Oktober 2026 | Thüringer Ritterturnier | 99448 Kranichfeld | Nur Ortsbezug | K15, M42, M44 |
| SF02 | 2026 | 9. - 11. Oktober 2026 | 373. Zwiebelmarkt | 99423 Weimar | Kein Kandidat nach Regel |  -  |
| SF03 | 2026 | 10. - 11. Oktober 2026* | 29. Burgfest | 06543 Burg Falkenstein / Harz | Datum + Ort | M14 |
| SF04 | 2026 | 17. - 18. Oktober 2026 | 5. Mittelalter- Markttage | 44575 Castrop- Rauxel | Kein Kandidat nach Regel |  -  |
| SF05 | 2026 | 1. - 4. Advent 2026 | Mittelalter- Advent (Do. - So.) | 44629 Herne/ Schloss Strünkede | Kein Kandidat nach Regel |  -  |
| SF06 | 2026 | 25. 11. - 23. Dezember 2026* | Mittelalter- Weihnacht | 01067 Dresden / Stallhof | Nur Ortsbezug | S02 |
| SF07 | 2026 | 26. 11. - 30. Dezember 2026* | Felsenkeller- Weihnachtsmarkt | 04229 Leipzig / Plagwitz | Nur Ortsbezug | F01, F23, F26, F27, F35, C14, K36, S01 |
| SF08 | 2026 | 27. 11. - 23. Dezember 2026** | Kloster- Weihnacht | 09111 Chemnitz | Kein Kandidat nach Regel |  -  |
| SF09 | 2026 | 27. - 30. Dezember 2026 | Rauhnächte | 01067 Dresden / Stallhof | Datum + Ort | S02 |
| SF10 | 2027 | 2.- 6. Januar 2027 | Rauhnächte | 01067 Dresden /Stallhof | Datum + Ort | S02 |
| SF11 | 2027 | 6. - 7. März 2027 | 18. Leipziger Umschlag | 04107 Leipzig / agra Messepark Halle 1 | Datum + Ort | F01, F23, F26, F27, F35, C14, K36, S01 |
| SF12 | 2027 | 13. - 14. März 2027 | Mittelalterfest Burgfrühling | 97877 Wertheim/ Burg | Kein Kandidat nach Regel |  -  |
| SF13 | 2027 | 20. - 21. März 2027 | Ritterturnier und Mittelaltermarkt | 01683 Altzella / Nossen | Kein Kandidat nach Regel |  -  |
| SF14 | 2027 | 27. - 29. März 2027 | Oster- Ritterturnier | 56346 Loreley/ St. Goarshausen | Kein Kandidat nach Regel |  -  |
| SF15 | 2027 | 27. - 29. März 2027 | Ritter und Drachen- Spektakel | 99448 Kranichfeld/ Niederburg | Datum + Ort | K15, M42, M44 |
| SF16 | 2027 | 27. - 29. März 2027 | Oster- Ritterturnier | 44286 Dorsten/ Schloss Lembeck | Kein Kandidat nach Regel |  -  |
| SF17 | 2027 | 3.- 4. April 2027 | noch offen | xxxxx | Referenz-Ort offen |  -  |
| SF18 | 2027 | 10. - 11. April 2027 | Die Wikinger kommen! | 07929 Saalburg/ Bleilochtalsperre | Kein Kandidat nach Regel |  -  |
| SF19 | 2027 | 10. - 11. April 2027 | Turnierspiele | 96178 Schloss Weissenstein/ Pommersfelden | Kein Kandidat nach Regel |  -  |
| SF20 | 2027 | 17.- 18. April 2027 | Mittealterspektakel | 04519 Rackwitz, Schladitzer Bucht | Kein Kandidat nach Regel |  -  |
| SF21 | 2027 | 17. - 18. April 2027 | Mittelalterspektakel | 41844 Wegberg/ Schloss Tüschenbroich | Kein Kandidat nach Regel |  -  |
| SF22 | 2027 | 24. - 25. April 2027 | Mittelalterfest Löwenburg | 34131 Kassel | Kein Kandidat nach Regel |  -  |
| SF23 | 2027 | 24. - 25. April 2027 | Mittelaltermarkt | 90513 Zirndorf b. Nürnberg | Kein Kandidat nach Regel |  -  |
| SF24 | 2027 | 30. April - 2. Mai 2027 | Ritterturnier & Walpurgisnacht | 06632 Freyburg/ Neuenburg | Datum + Ort | M21 |
| SF25 | 2027 | 1. - 2. Mai 2027 | Ritterturnier Schloss Lauersfort | 47447 Moers | Kein Kandidat nach Regel |  -  |
| SF26 | 2027 | 6. - 9. Mai 2027 | 23. Siegfriedspektakel | 46509 Xanten | Kein Kandidat nach Regel |  -  |
| SF27 | 2027 | 6. - 9. Mai 2027 | Mittealter- Burgfest | 06543 Burg Falkenstein/ Harz | Nur andere Jahresdaten | M14 |
| SF28 | 2027 | 15. - 17. Mai 2027 | Wikingerfest | 99885 Weißensee/Thür. | Kein Kandidat nach Regel |  -  |
| SF29 | 2027 | 15. - 17. Mai 2027 | Ritterturnier & Mittelalterspektakel | 85399 Hallbergmoos | Kein Kandidat nach Regel |  -  |
| SF30 | 2027 | 22. - 23. Mai 2027 | Mittelalterspektakel | 58455 Witten /Kemnader See | Kein Kandidat nach Regel |  -  |
| SF31 | 2027 | 27.- 30. Mai 2027* | Gaudium Schloss Horst* | 45899 Gelsenkirchen* | Nur Ortsbezug | R01 |
| SF32 | 2027 | 29. - 30. Mai 2027 | Mittelalterspektakel | 02829 Königshain | Kein Kandidat nach Regel |  -  |
| SF33 | 2027 | 5. - 6. Juni 2027 | Mittelalterspektakel | 34346 Hann. Münden | Kein Kandidat nach Regel |  -  |
| SF34 | 2027 | 11. - 13. Juni 2027 | Annamarkt und Stadtfest | 52349 Düren | Kein Kandidat nach Regel |  -  |
| SF35 | 2027 | 16. - 18. Juli 2027 | Mittelalterspektakel | 23999 Insel Poel | Datum + Ort | S04 |
| SF36 | 2027 | 22. - 25. Juli 2027 | Wallensteintage | 18439 Stralsund /Alter Markt | Datum + Ort | S03 |
| SF37 | 2027 | 14. - 15. August 2027 | Fantasy- und Mittelalterfest | 01833 Stolpen (Burg) | Datum + Ort | S06 |
| SF38 | 2027 | 28. - 29. August 2027 | Burgfest* | xxxx | Referenz-Ort offen |  -  |
| SF39 | 2027 | 3. - 5. September 2027 | 20. Mittelalterspektakel | 44629 Herne / Schloss Strünkede | Kein Kandidat nach Regel |  -  |
| SF40 | 2027 | 11. - 12. September 2027 | Mittelalterfest* | 99707 Kyffhäuser* | Kein Kandidat nach Regel |  -  |
| SF41 | 2027 | 18. - 19. September 2027 | Die Wikinger kommen! | 46509 Xanten | Kein Kandidat nach Regel |  -  |
| SF42 | 2027 | 18. - 19. September 2027 | Ritterturnier und Mittelalterspektakel | 93186 Adlersberg/ Pettendorf | Kein Kandidat nach Regel |  -  |
| SF43 | 2027 | 24. - 26. September 2027* | Zwiebelmarkt Apolda | 99510 Apolda | Kein Kandidat nach Regel |  -  |
| SF44 | 2027 | 25. - 26. September 2027 | 56. Heidelberger Herbst | 69120 Heidelberg | Kein Kandidat nach Regel |  -  |
| SF45 | 2027 | 2. - 3. Oktober 2027 | Mittelalter & Fantasytage mit Drachen | 56346 Loreley/ St. Goarshausen | Kein Kandidat nach Regel |  -  |
| SF46 | 2027 | 2. - 3. Oktober 2027 | Thüringer Ritterturnier | 99448 Kranichfeld | Nur Ortsbezug | K15, M42, M44 |
| SF47 | 2027 | 8. - 10. Oktober 2027 | 374. Zwiebelmarkt | 99423 Weimar | Kein Kandidat nach Regel |  -  |
| SF48 | 2027 | 9.- 10. Oktober 2027* | 30. Burgfest | 06543 Burg Falkenstein/ Harz | Nur andere Jahresdaten | M14 |
| SF49 | 2027 | 16. - 17. Oktober 2027* | 6. Mittelalter- Markttage | 44575 Castrop- Rauxel | Kein Kandidat nach Regel |  -  |
| SF50 | 2027 | 1. - 4. Advent 2027* | Mittelalter- Advent (Fr.- So.) | 44629 Herne/ Schloss Strünkede | Kein Kandidat nach Regel |  -  |
| SF51 | 2027 | 24.11. - 23. Dezember 2027* | Mittelalter- Weihnacht | 01067 Dresden / Stallhof | Nur Ortsbezug | S02 |
| SF52 | 2027 | 25.11. - 30. Dezember 2027* | Felsenkeller- Weihnachtsmarkt | 04229 Leipzig / Plagwitz | Nur Ortsbezug | F01, F23, F26, F27, F35, C14, K36, S01 |
| SF53 | 2027 | 26.11. - 23. Dezember 2027** | Kloster- Weihnacht | 09111 Chemnitz | Kein Kandidat nach Regel |  -  |
| SF54 | 2027 | 27. - 30. Dezember 2027 | Rauhnächte | 01067 Dresden / Stallhof | Datum + Ort | S02 |

### SF01 · Thüringer Ritterturnier · 2026

Fundstelle: Termine_2027_suendenfrei.txt:L3. 3. - 4. Oktober 2026 · 99448 Kranichfeld.
Zeitfenster: 2026-10-03/2026-10-04. Datumsherkunft: aus_quelle; Quellstatus: nicht_markiert.
Nur Ortswortfolge gefunden, kein Name-/Termin-Nachweis. Nicht als vorhandener Referenztermin zählen.

- K15 · Sternenklang Festival · Kranichfeld · Quelle: Chat.
  - Beleg: public/data/spp7-datasets.json#/datasets/events/78; Hinweisart: nur_ort; vollständige Fenster: false; passende Fenster 0/1; DATE_ID:  - .
  - Name:  - ; Ort: Ortstext identisch.; gleiche PLZ: false.
  - Bestands-Datumszeilen: D67 2026-06-11/2026-06-13 (Festivaltermin (KI-Liste); public/data/spp7-datasets.json#/datasets/event_dates/65).
  - Name: Referenz „Thüringer Ritterturnier“ ↔ Bestand „Sternenklang Festival“ → abweichender_text. Literalvergleich; keine automatische Korrektur oder Zuordnung.
  - Ort/Location: Referenz „Kranichfeld“ ↔ Bestand „Kranichfeld“ → gleich. Literalvergleich; keine automatische Korrektur oder Zuordnung.
  - PLZ: Referenz „99448“ ↔ Bestand „ - “ → fehlt. Literalvergleich; keine automatische Korrektur oder Zuordnung.
  - Zeitfenster: Referenz „2026-10-03/2026-10-04“ ↔ Bestand „2026-06-11/2026-06-13“ → abweichender_text. Literalvergleich; keine automatische Korrektur oder Zuordnung.
  - Bestätigungsstatus: Referenz „nicht_markiert“ ↔ Bestand „ - “ → nicht_strukturiert. App-Events speichern Bewerbungs-/Gagenstatus, aber keinen unabhängigen Terminbestätigungsstatus.

- M42 · Phantastisches Zauberdorf · Kranichfeld · Quelle: Chat (KI-Liste).
  - Beleg: public/data/spp7-datasets.json#/datasets/events/148; Hinweisart: nur_ort; vollständige Fenster: false; passende Fenster 0/1; DATE_ID:  - .
  - Name:  - ; Ort: Ortstext identisch.; gleiche PLZ: false.
  - Bestands-Datumszeilen:  - .
  - Name: Referenz „Thüringer Ritterturnier“ ↔ Bestand „Phantastisches Zauberdorf“ → abweichender_text. Literalvergleich; keine automatische Korrektur oder Zuordnung.
  - Ort/Location: Referenz „Kranichfeld“ ↔ Bestand „Kranichfeld“ → gleich. Literalvergleich; keine automatische Korrektur oder Zuordnung.
  - PLZ: Referenz „99448“ ↔ Bestand „ - “ → fehlt. Literalvergleich; keine automatische Korrektur oder Zuordnung.
  - Zeitfenster: Referenz „2026-10-03/2026-10-04“ ↔ Bestand „ - “ → fehlt. Literalvergleich; keine automatische Korrektur oder Zuordnung.
  - Bestätigungsstatus: Referenz „nicht_markiert“ ↔ Bestand „ - “ → nicht_strukturiert. App-Events speichern Bewerbungs-/Gagenstatus, aber keinen unabhängigen Terminbestätigungsstatus.

- M44 · Ritter und Drachen-Spektakel · Kranichfeld · Quelle: Chat (KI-Liste).
  - Beleg: public/data/spp7-datasets.json#/datasets/events/150; Hinweisart: nur_ort; vollständige Fenster: false; passende Fenster 0/1; DATE_ID:  - .
  - Name:  - ; Ort: Ortstext identisch.; gleiche PLZ: false.
  - Bestands-Datumszeilen: D200 2026-04-04/2026-04-06 (Sündenfrei 2026; public/data/spp7-datasets.json#/datasets/event_dates/198); D201 2027-03-27/2027-03-29 (Sündenfrei 2027; public/data/spp7-datasets.json#/datasets/event_dates/199).
  - Name: Referenz „Thüringer Ritterturnier“ ↔ Bestand „Ritter und Drachen-Spektakel“ → abweichender_text. Literalvergleich; keine automatische Korrektur oder Zuordnung.
  - Ort/Location: Referenz „Kranichfeld“ ↔ Bestand „Kranichfeld“ → gleich. Literalvergleich; keine automatische Korrektur oder Zuordnung.
  - PLZ: Referenz „99448“ ↔ Bestand „ - “ → fehlt. Literalvergleich; keine automatische Korrektur oder Zuordnung.
  - Zeitfenster: Referenz „2026-10-03/2026-10-04“ ↔ Bestand „2026-04-04/2026-04-06;2027-03-27/2027-03-29“ → abweichender_text. Literalvergleich; keine automatische Korrektur oder Zuordnung.
  - Bestätigungsstatus: Referenz „nicht_markiert“ ↔ Bestand „ - “ → nicht_strukturiert. App-Events speichern Bewerbungs-/Gagenstatus, aber keinen unabhängigen Terminbestätigungsstatus.

### SF02 · 373. Zwiebelmarkt · 2026

Fundstelle: Termine_2027_suendenfrei.txt:L4. 9. - 11. Oktober 2026 · 99423 Weimar.
Zeitfenster: 2026-10-09/2026-10-11. Datumsherkunft: aus_quelle; Quellstatus: nicht_markiert.
Kein Hinweis nach den beschriebenen Regeln im App-Datensatz. Kein Nachweis, dass die Veranstaltung extern nicht existiert.

### SF03 · 29. Burgfest · 2026

Fundstelle: Termine_2027_suendenfrei.txt:L5. 10. - 11. Oktober 2026* · 06543 Burg Falkenstein / Harz.
Zeitfenster: 2026-10-10/2026-10-11. Datumsherkunft: aus_quelle; Quellstatus: unbestaetigt.
Alle Referenzzeitfenster und der Ortstext sind im selben Bestands-Event belegbar. Name, PLZ, Quelltyp und Verifikation separat prüfen; kein automatischer Merge.

- M14 · Burgfest · Falkenstein · Quelle: Chat (KI-Liste).
  - Beleg: public/data/spp7-datasets.json#/datasets/events/120; Hinweisart: datum_ort; vollständige Fenster: true; passende Fenster 1/1; DATE_ID: D105.
  - Name: Namenswortfolge identisch (Großschreibung, Interpunktion, führende Ausgabennummer ausgenommen).; Ort: Bestands-Ortstext „Falkenstein“ vollständig im Referenz-Ort/Location-Text enthalten.; gleiche PLZ: false.
  - Bestands-Datumszeilen: D105 2026-10-10/2026-10-11 (Festivaltermin (KI-Liste); public/data/spp7-datasets.json#/datasets/event_dates/103); D106 2026-05-14/2026-05-17 (Festivaltermin (KI-Liste); public/data/spp7-datasets.json#/datasets/event_dates/104).
  - Name: Referenz „29. Burgfest“ ↔ Bestand „Burgfest“ → abweichender_text. Literalvergleich; keine automatische Korrektur oder Zuordnung.
  - Ort/Location: Referenz „Burg Falkenstein/Harz“ ↔ Bestand „Falkenstein“ → abweichender_text. Literalvergleich; keine automatische Korrektur oder Zuordnung.
  - PLZ: Referenz „06543“ ↔ Bestand „ - “ → fehlt. Literalvergleich; keine automatische Korrektur oder Zuordnung.
  - Zeitfenster: Referenz „2026-10-10/2026-10-11“ ↔ Bestand „2026-10-10/2026-10-11;2026-05-14/2026-05-17“ → enthalten. Alle Referenzfenster im Bestand enthalten; Bestand hat zusätzliche oder mehrfach erfasste Zeitfenster. Keine Gleichheit der vollständigen Listen und keine Löschfreigabe.
  - Bestätigungsstatus: Referenz „unbestaetigt“ ↔ Bestand „ - “ → nicht_strukturiert. App-Events speichern Bewerbungs-/Gagenstatus, aber keinen unabhängigen Terminbestätigungsstatus.

### SF04 · 5. Mittelalter- Markttage · 2026

Fundstelle: Termine_2027_suendenfrei.txt:L6. 17. - 18. Oktober 2026 · 44575 Castrop- Rauxel.
Zeitfenster: 2026-10-17/2026-10-18. Datumsherkunft: aus_quelle; Quellstatus: nicht_markiert.
Kein Hinweis nach den beschriebenen Regeln im App-Datensatz. Kein Nachweis, dass die Veranstaltung extern nicht existiert.

### SF05 · Mittelalter- Advent (Do. - So.) · 2026

Fundstelle: Termine_2027_suendenfrei.txt:L7. 1. - 4. Advent 2026 · 44629 Herne/ Schloss Strünkede.
Zeitfenster: 2026-11-26/2026-11-29; 2026-12-03/2026-12-06; 2026-12-10/2026-12-13; 2026-12-17/2026-12-20. Datumsherkunft: berechnet; Quellstatus: nicht_markiert.
Kein Hinweis nach den beschriebenen Regeln im App-Datensatz. Kein Nachweis, dass die Veranstaltung extern nicht existiert.

### SF06 · Mittelalter- Weihnacht · 2026

Fundstelle: Termine_2027_suendenfrei.txt:L8. 25. 11. - 23. Dezember 2026* · 01067 Dresden / Stallhof.
Zeitfenster: 2026-11-25/2026-12-23. Datumsherkunft: aus_quelle; Quellstatus: unbestaetigt.
Nur Ortswortfolge gefunden, kein Name-/Termin-Nachweis. Nicht als vorhandener Referenztermin zählen.

- S02 · Rauhnächte Dresden · Dresden · Quelle: Sündenfrei.
  - Beleg: public/data/spp7-datasets.json#/datasets/events/199; Hinweisart: nur_ort; vollständige Fenster: false; passende Fenster 0/1; DATE_ID:  - .
  - Name:  - ; Ort: Bestands-Ortstext „Dresden“ vollständig im Referenz-Ort/Location-Text enthalten.; gleiche PLZ: true.
  - Bestands-Datumszeilen: D187 2026-01-02/2026-01-06 (Markt 2026; public/data/spp7-datasets.json#/datasets/event_dates/185); D188 2026-12-27/2026-12-30 (Markt 2026; public/data/spp7-datasets.json#/datasets/event_dates/186); D189 2027-01-02/2027-01-06 (Markt 2027; public/data/spp7-datasets.json#/datasets/event_dates/187); D190 2027-12-27/2027-12-30 (Markt 2027; public/data/spp7-datasets.json#/datasets/event_dates/188).
  - Name: Referenz „Mittelalter- Weihnacht“ ↔ Bestand „Rauhnächte Dresden“ → abweichender_text. Literalvergleich; keine automatische Korrektur oder Zuordnung.
  - Ort/Location: Referenz „Dresden/Stallhof“ ↔ Bestand „Dresden / Stallhof“ → gleich. Literalvergleich; keine automatische Korrektur oder Zuordnung.
  - PLZ: Referenz „01067“ ↔ Bestand „01067“ → gleich. Literalvergleich; keine automatische Korrektur oder Zuordnung.
  - Zeitfenster: Referenz „2026-11-25/2026-12-23“ ↔ Bestand „2026-01-02/2026-01-06;2026-12-27/2026-12-30;2027-01-02/2027-01-06;2027-12-27/2027-12-30“ → abweichender_text. Literalvergleich; keine automatische Korrektur oder Zuordnung.
  - Bestätigungsstatus: Referenz „unbestaetigt“ ↔ Bestand „ - “ → nicht_strukturiert. App-Events speichern Bewerbungs-/Gagenstatus, aber keinen unabhängigen Terminbestätigungsstatus.

### SF07 · Felsenkeller- Weihnachtsmarkt · 2026

Fundstelle: Termine_2027_suendenfrei.txt:L9. 26. 11. - 30. Dezember 2026* · 04229 Leipzig / Plagwitz.
Zeitfenster: 2026-11-26/2026-12-30. Datumsherkunft: aus_quelle; Quellstatus: unbestaetigt.
Nur Ortswortfolge gefunden, kein Name-/Termin-Nachweis. Nicht als vorhandener Referenztermin zählen.

- F01 · NEXUS Festival · Leipzig · Quelle: Flyer.
  - Beleg: public/data/spp7-datasets.json#/datasets/events/0; Hinweisart: nur_ort; vollständige Fenster: false; passende Fenster 0/1; DATE_ID:  - .
  - Name:  - ; Ort: Bestands-Ortstext „Leipzig“ vollständig im Referenz-Ort/Location-Text enthalten.; gleiche PLZ: false.
  - Bestands-Datumszeilen: D01 2026-09-18/2026-09-20 (Haupttermin; public/data/spp7-datasets.json#/datasets/event_dates/0).
  - Name: Referenz „Felsenkeller- Weihnachtsmarkt“ ↔ Bestand „NEXUS Festival“ → abweichender_text. Literalvergleich; keine automatische Korrektur oder Zuordnung.
  - Ort/Location: Referenz „Leipzig/Plagwitz“ ↔ Bestand „Leipzig / Agra Messepark“ → abweichender_text. Literalvergleich; keine automatische Korrektur oder Zuordnung.
  - PLZ: Referenz „04229“ ↔ Bestand „ - “ → fehlt. Literalvergleich; keine automatische Korrektur oder Zuordnung.
  - Zeitfenster: Referenz „2026-11-26/2026-12-30“ ↔ Bestand „2026-09-18/2026-09-20“ → abweichender_text. Literalvergleich; keine automatische Korrektur oder Zuordnung.
  - Bestätigungsstatus: Referenz „unbestaetigt“ ↔ Bestand „ - “ → nicht_strukturiert. App-Events speichern Bewerbungs-/Gagenstatus, aber keinen unabhängigen Terminbestätigungsstatus.

- F23 · Bülow Straßenmusik Festival · Leipzig · Quelle: Flyer.
  - Beleg: public/data/spp7-datasets.json#/datasets/events/18; Hinweisart: nur_ort; vollständige Fenster: false; passende Fenster 0/1; DATE_ID:  - .
  - Name:  - ; Ort: Bestands-Ortstext „Leipzig“ vollständig im Referenz-Ort/Location-Text enthalten.; gleiche PLZ: false.
  - Bestands-Datumszeilen: D26 2026-08-22/ -  (Haupttermin; public/data/spp7-datasets.json#/datasets/event_dates/24).
  - Name: Referenz „Felsenkeller- Weihnachtsmarkt“ ↔ Bestand „Bülow Straßenmusik Festival“ → abweichender_text. Literalvergleich; keine automatische Korrektur oder Zuordnung.
  - Ort/Location: Referenz „Leipzig/Plagwitz“ ↔ Bestand „Leipzig / Bülowstraße / Ecke Paulinenstraße“ → abweichender_text. Literalvergleich; keine automatische Korrektur oder Zuordnung.
  - PLZ: Referenz „04229“ ↔ Bestand „ - “ → fehlt. Literalvergleich; keine automatische Korrektur oder Zuordnung.
  - Zeitfenster: Referenz „2026-11-26/2026-12-30“ ↔ Bestand „ - “ → fehlt. Literalvergleich; keine automatische Korrektur oder Zuordnung.
  - Bestätigungsstatus: Referenz „unbestaetigt“ ↔ Bestand „ - “ → nicht_strukturiert. App-Events speichern Bewerbungs-/Gagenstatus, aber keinen unabhängigen Terminbestätigungsstatus.

- F26 · Fockebergfest · Leipzig · Quelle: Flyer.
  - Beleg: public/data/spp7-datasets.json#/datasets/events/21; Hinweisart: nur_ort; vollständige Fenster: false; passende Fenster 0/1; DATE_ID:  - .
  - Name:  - ; Ort: Bestands-Ortstext „Leipzig“ vollständig im Referenz-Ort/Location-Text enthalten.; gleiche PLZ: false.
  - Bestands-Datumszeilen: D29 2026-08-23/ -  (Haupttermin; public/data/spp7-datasets.json#/datasets/event_dates/27).
  - Name: Referenz „Felsenkeller- Weihnachtsmarkt“ ↔ Bestand „Fockebergfest“ → abweichender_text. Literalvergleich; keine automatische Korrektur oder Zuordnung.
  - Ort/Location: Referenz „Leipzig/Plagwitz“ ↔ Bestand „Leipzig / Fockeberg, Südvorstadt“ → abweichender_text. Literalvergleich; keine automatische Korrektur oder Zuordnung.
  - PLZ: Referenz „04229“ ↔ Bestand „ - “ → fehlt. Literalvergleich; keine automatische Korrektur oder Zuordnung.
  - Zeitfenster: Referenz „2026-11-26/2026-12-30“ ↔ Bestand „ - “ → fehlt. Literalvergleich; keine automatische Korrektur oder Zuordnung.
  - Bestätigungsstatus: Referenz „unbestaetigt“ ↔ Bestand „ - “ → nicht_strukturiert. App-Events speichern Bewerbungs-/Gagenstatus, aber keinen unabhängigen Terminbestätigungsstatus.

- F27 · Tapetenwerkfest 36.0 · Leipzig · Quelle: Flyer.
  - Beleg: public/data/spp7-datasets.json#/datasets/events/22; Hinweisart: nur_ort; vollständige Fenster: false; passende Fenster 0/1; DATE_ID:  - .
  - Name:  - ; Ort: Bestands-Ortstext „Leipzig“ vollständig im Referenz-Ort/Location-Text enthalten.; gleiche PLZ: false.
  - Bestands-Datumszeilen: D30 2026-09-04/ -  (Haupttermin; public/data/spp7-datasets.json#/datasets/event_dates/28); D31 2026-08-21/ -  (Post-Datum; public/data/spp7-datasets.json#/datasets/event_dates/29).
  - Name: Referenz „Felsenkeller- Weihnachtsmarkt“ ↔ Bestand „Tapetenwerkfest 36.0“ → abweichender_text. Literalvergleich; keine automatische Korrektur oder Zuordnung.
  - Ort/Location: Referenz „Leipzig/Plagwitz“ ↔ Bestand „Leipzig / Tapetenwerk (Kunstareal), Sommerhof“ → abweichender_text. Literalvergleich; keine automatische Korrektur oder Zuordnung.
  - PLZ: Referenz „04229“ ↔ Bestand „ - “ → fehlt. Literalvergleich; keine automatische Korrektur oder Zuordnung.
  - Zeitfenster: Referenz „2026-11-26/2026-12-30“ ↔ Bestand „ - “ → fehlt. Literalvergleich; keine automatische Korrektur oder Zuordnung.
  - Bestätigungsstatus: Referenz „unbestaetigt“ ↔ Bestand „ - “ → nicht_strukturiert. App-Events speichern Bewerbungs-/Gagenstatus, aber keinen unabhängigen Terminbestätigungsstatus.

- F35 · unreleaseD Tour 2026 – Leipzig Wildcard · Leipzig · Quelle: Flyer.
  - Beleg: public/data/spp7-datasets.json#/datasets/events/27; Hinweisart: nur_ort; vollständige Fenster: false; passende Fenster 0/1; DATE_ID:  - .
  - Name:  - ; Ort: Bestands-Ortstext „Leipzig“ vollständig im Referenz-Ort/Location-Text enthalten.; gleiche PLZ: false.
  - Bestands-Datumszeilen: D38  - / -  (Tour; public/data/spp7-datasets.json#/datasets/event_dates/36).
  - Name: Referenz „Felsenkeller- Weihnachtsmarkt“ ↔ Bestand „unreleaseD Tour 2026 – Leipzig Wildcard“ → abweichender_text. Literalvergleich; keine automatische Korrektur oder Zuordnung.
  - Ort/Location: Referenz „Leipzig/Plagwitz“ ↔ Bestand „Leipzig“ → abweichender_text. Literalvergleich; keine automatische Korrektur oder Zuordnung.
  - PLZ: Referenz „04229“ ↔ Bestand „ - “ → fehlt. Literalvergleich; keine automatische Korrektur oder Zuordnung.
  - Zeitfenster: Referenz „2026-11-26/2026-12-30“ ↔ Bestand „ - “ → fehlt. Literalvergleich; keine automatische Korrektur oder Zuordnung.
  - Bestätigungsstatus: Referenz „unbestaetigt“ ↔ Bestand „ - “ → nicht_strukturiert. App-Events speichern Bewerbungs-/Gagenstatus, aber keinen unabhängigen Terminbestätigungsstatus.

- C14 · Taverne „Wankende Hydra“ – Torhaus Dölitz · Leipzig · Quelle: Chat.
  - Beleg: public/data/spp7-datasets.json#/datasets/events/41; Hinweisart: nur_ort; vollständige Fenster: false; passende Fenster 0/1; DATE_ID:  - .
  - Name:  - ; Ort: Bestands-Ortstext „Leipzig“ vollständig im Referenz-Ort/Location-Text enthalten.; gleiche PLZ: false.
  - Bestands-Datumszeilen:  - .
  - Name: Referenz „Felsenkeller- Weihnachtsmarkt“ ↔ Bestand „Taverne „Wankende Hydra“ – Torhaus Dölitz“ → abweichender_text. Literalvergleich; keine automatische Korrektur oder Zuordnung.
  - Ort/Location: Referenz „Leipzig/Plagwitz“ ↔ Bestand „Leipzig / Torhaus Dölitz“ → abweichender_text. Literalvergleich; keine automatische Korrektur oder Zuordnung.
  - PLZ: Referenz „04229“ ↔ Bestand „ - “ → fehlt. Literalvergleich; keine automatische Korrektur oder Zuordnung.
  - Zeitfenster: Referenz „2026-11-26/2026-12-30“ ↔ Bestand „ - “ → fehlt. Literalvergleich; keine automatische Korrektur oder Zuordnung.
  - Bestätigungsstatus: Referenz „unbestaetigt“ ↔ Bestand „ - “ → nicht_strukturiert. App-Events speichern Bewerbungs-/Gagenstatus, aber keinen unabhängigen Terminbestätigungsstatus.

- K36 · Peterskirche Leipzig – IN ECCLESIA · Leipzig · Quelle: Chat.
  - Beleg: public/data/spp7-datasets.json#/datasets/events/96; Hinweisart: nur_ort; vollständige Fenster: false; passende Fenster 0/1; DATE_ID:  - .
  - Name:  - ; Ort: Bestands-Ortstext „Leipzig“ vollständig im Referenz-Ort/Location-Text enthalten.; gleiche PLZ: false.
  - Bestands-Datumszeilen: D85 2026-12-30/ -  (Auftritt Corvus Corax; public/data/spp7-datasets.json#/datasets/event_dates/83).
  - Name: Referenz „Felsenkeller- Weihnachtsmarkt“ ↔ Bestand „Peterskirche Leipzig – IN ECCLESIA“ → abweichender_text. Literalvergleich; keine automatische Korrektur oder Zuordnung.
  - Ort/Location: Referenz „Leipzig/Plagwitz“ ↔ Bestand „Leipzig“ → abweichender_text. Literalvergleich; keine automatische Korrektur oder Zuordnung.
  - PLZ: Referenz „04229“ ↔ Bestand „ - “ → fehlt. Literalvergleich; keine automatische Korrektur oder Zuordnung.
  - Zeitfenster: Referenz „2026-11-26/2026-12-30“ ↔ Bestand „ - “ → fehlt. Literalvergleich; keine automatische Korrektur oder Zuordnung.
  - Bestätigungsstatus: Referenz „unbestaetigt“ ↔ Bestand „ - “ → nicht_strukturiert. App-Events speichern Bewerbungs-/Gagenstatus, aber keinen unabhängigen Terminbestätigungsstatus.

- S01 · Leipziger Umschlag · Leipzig · Quelle: Sündenfrei.
  - Beleg: public/data/spp7-datasets.json#/datasets/events/198; Hinweisart: nur_ort; vollständige Fenster: false; passende Fenster 0/1; DATE_ID:  - .
  - Name:  - ; Ort: Bestands-Ortstext „Leipzig“ vollständig im Referenz-Ort/Location-Text enthalten.; gleiche PLZ: false.
  - Bestands-Datumszeilen: D185 2026-03-07/2026-03-08 (Messe 2026; public/data/spp7-datasets.json#/datasets/event_dates/183); D186 2027-03-06/2027-03-07 (Messe 2027; public/data/spp7-datasets.json#/datasets/event_dates/184).
  - Name: Referenz „Felsenkeller- Weihnachtsmarkt“ ↔ Bestand „Leipziger Umschlag“ → abweichender_text. Literalvergleich; keine automatische Korrektur oder Zuordnung.
  - Ort/Location: Referenz „Leipzig/Plagwitz“ ↔ Bestand „Leipzig / agra Messepark Halle 1“ → abweichender_text. Literalvergleich; keine automatische Korrektur oder Zuordnung.
  - PLZ: Referenz „04229“ ↔ Bestand „04107“ → abweichender_text. Literalvergleich; keine automatische Korrektur oder Zuordnung.
  - Zeitfenster: Referenz „2026-11-26/2026-12-30“ ↔ Bestand „2026-03-07/2026-03-08;2027-03-06/2027-03-07“ → abweichender_text. Literalvergleich; keine automatische Korrektur oder Zuordnung.
  - Bestätigungsstatus: Referenz „unbestaetigt“ ↔ Bestand „ - “ → nicht_strukturiert. App-Events speichern Bewerbungs-/Gagenstatus, aber keinen unabhängigen Terminbestätigungsstatus.

### SF08 · Kloster- Weihnacht · 2026

Fundstelle: Termine_2027_suendenfrei.txt:L10. 27. 11. - 23. Dezember 2026** · 09111 Chemnitz.
Zeitfenster: 2026-11-27/2026-12-23. Datumsherkunft: aus_quelle; Quellstatus: unbestaetigt.
Kein Hinweis nach den beschriebenen Regeln im App-Datensatz. Kein Nachweis, dass die Veranstaltung extern nicht existiert.

### SF09 · Rauhnächte · 2026

Fundstelle: Termine_2027_suendenfrei.txt:L11. 27. - 30. Dezember 2026 · 01067 Dresden / Stallhof.
Zeitfenster: 2026-12-27/2026-12-30. Datumsherkunft: aus_quelle; Quellstatus: nicht_markiert.
Alle Referenzzeitfenster und der Ortstext sind im selben Bestands-Event belegbar. Name, PLZ, Quelltyp und Verifikation separat prüfen; kein automatischer Merge.

- S02 · Rauhnächte Dresden · Dresden · Quelle: Sündenfrei.
  - Beleg: public/data/spp7-datasets.json#/datasets/events/199; Hinweisart: datum_ort; vollständige Fenster: true; passende Fenster 1/1; DATE_ID: D188.
  - Name: Namenswortfolge wörtlich im anderen Namen enthalten; kein Identitätsbeweis.; Ort: Bestands-Ortstext „Dresden“ vollständig im Referenz-Ort/Location-Text enthalten.; gleiche PLZ: true.
  - Bestands-Datumszeilen: D187 2026-01-02/2026-01-06 (Markt 2026; public/data/spp7-datasets.json#/datasets/event_dates/185); D188 2026-12-27/2026-12-30 (Markt 2026; public/data/spp7-datasets.json#/datasets/event_dates/186); D189 2027-01-02/2027-01-06 (Markt 2027; public/data/spp7-datasets.json#/datasets/event_dates/187); D190 2027-12-27/2027-12-30 (Markt 2027; public/data/spp7-datasets.json#/datasets/event_dates/188).
  - Name: Referenz „Rauhnächte“ ↔ Bestand „Rauhnächte Dresden“ → abweichender_text. Literalvergleich; keine automatische Korrektur oder Zuordnung.
  - Ort/Location: Referenz „Dresden/Stallhof“ ↔ Bestand „Dresden / Stallhof“ → gleich. Literalvergleich; keine automatische Korrektur oder Zuordnung.
  - PLZ: Referenz „01067“ ↔ Bestand „01067“ → gleich. Literalvergleich; keine automatische Korrektur oder Zuordnung.
  - Zeitfenster: Referenz „2026-12-27/2026-12-30“ ↔ Bestand „2026-01-02/2026-01-06;2026-12-27/2026-12-30;2027-01-02/2027-01-06;2027-12-27/2027-12-30“ → enthalten. Alle Referenzfenster im Bestand enthalten; Bestand hat zusätzliche oder mehrfach erfasste Zeitfenster. Keine Gleichheit der vollständigen Listen und keine Löschfreigabe.
  - Bestätigungsstatus: Referenz „nicht_markiert“ ↔ Bestand „ - “ → nicht_strukturiert. App-Events speichern Bewerbungs-/Gagenstatus, aber keinen unabhängigen Terminbestätigungsstatus.

### SF10 · Rauhnächte · 2027

Fundstelle: Termine_2027_suendenfrei.txt:L16. 2.- 6. Januar 2027 · 01067 Dresden /Stallhof.
Zeitfenster: 2027-01-02/2027-01-06. Datumsherkunft: aus_quelle; Quellstatus: nicht_markiert.
Alle Referenzzeitfenster und der Ortstext sind im selben Bestands-Event belegbar. Name, PLZ, Quelltyp und Verifikation separat prüfen; kein automatischer Merge.

- S02 · Rauhnächte Dresden · Dresden · Quelle: Sündenfrei.
  - Beleg: public/data/spp7-datasets.json#/datasets/events/199; Hinweisart: datum_ort; vollständige Fenster: true; passende Fenster 1/1; DATE_ID: D189.
  - Name: Namenswortfolge wörtlich im anderen Namen enthalten; kein Identitätsbeweis.; Ort: Bestands-Ortstext „Dresden“ vollständig im Referenz-Ort/Location-Text enthalten.; gleiche PLZ: true.
  - Bestands-Datumszeilen: D187 2026-01-02/2026-01-06 (Markt 2026; public/data/spp7-datasets.json#/datasets/event_dates/185); D188 2026-12-27/2026-12-30 (Markt 2026; public/data/spp7-datasets.json#/datasets/event_dates/186); D189 2027-01-02/2027-01-06 (Markt 2027; public/data/spp7-datasets.json#/datasets/event_dates/187); D190 2027-12-27/2027-12-30 (Markt 2027; public/data/spp7-datasets.json#/datasets/event_dates/188).
  - Name: Referenz „Rauhnächte“ ↔ Bestand „Rauhnächte Dresden“ → abweichender_text. Literalvergleich; keine automatische Korrektur oder Zuordnung.
  - Ort/Location: Referenz „Dresden/Stallhof“ ↔ Bestand „Dresden / Stallhof“ → gleich. Literalvergleich; keine automatische Korrektur oder Zuordnung.
  - PLZ: Referenz „01067“ ↔ Bestand „01067“ → gleich. Literalvergleich; keine automatische Korrektur oder Zuordnung.
  - Zeitfenster: Referenz „2027-01-02/2027-01-06“ ↔ Bestand „2026-01-02/2026-01-06;2026-12-27/2026-12-30;2027-01-02/2027-01-06;2027-12-27/2027-12-30“ → enthalten. Alle Referenzfenster im Bestand enthalten; Bestand hat zusätzliche oder mehrfach erfasste Zeitfenster. Keine Gleichheit der vollständigen Listen und keine Löschfreigabe.
  - Bestätigungsstatus: Referenz „nicht_markiert“ ↔ Bestand „ - “ → nicht_strukturiert. App-Events speichern Bewerbungs-/Gagenstatus, aber keinen unabhängigen Terminbestätigungsstatus.

### SF11 · 18. Leipziger Umschlag · 2027

Fundstelle: Termine_2027_suendenfrei.txt:L17. 6. - 7. März 2027 · 04107 Leipzig / agra Messepark Halle 1.
Zeitfenster: 2027-03-06/2027-03-07. Datumsherkunft: aus_quelle; Quellstatus: nicht_markiert.
Alle Referenzzeitfenster und der Ortstext sind im selben Bestands-Event belegbar. Name, PLZ, Quelltyp und Verifikation separat prüfen; kein automatischer Merge.

- F01 · NEXUS Festival · Leipzig · Quelle: Flyer.
  - Beleg: public/data/spp7-datasets.json#/datasets/events/0; Hinweisart: nur_ort; vollständige Fenster: false; passende Fenster 0/1; DATE_ID:  - .
  - Name:  - ; Ort: Bestands-Ortstext „Leipzig“ vollständig im Referenz-Ort/Location-Text enthalten.; gleiche PLZ: false.
  - Bestands-Datumszeilen: D01 2026-09-18/2026-09-20 (Haupttermin; public/data/spp7-datasets.json#/datasets/event_dates/0).
  - Name: Referenz „18. Leipziger Umschlag“ ↔ Bestand „NEXUS Festival“ → abweichender_text. Literalvergleich; keine automatische Korrektur oder Zuordnung.
  - Ort/Location: Referenz „Leipzig/agra Messepark Halle 1“ ↔ Bestand „Leipzig / Agra Messepark“ → abweichender_text. Literalvergleich; keine automatische Korrektur oder Zuordnung.
  - PLZ: Referenz „04107“ ↔ Bestand „ - “ → fehlt. Literalvergleich; keine automatische Korrektur oder Zuordnung.
  - Zeitfenster: Referenz „2027-03-06/2027-03-07“ ↔ Bestand „2026-09-18/2026-09-20“ → abweichender_text. Literalvergleich; keine automatische Korrektur oder Zuordnung.
  - Bestätigungsstatus: Referenz „nicht_markiert“ ↔ Bestand „ - “ → nicht_strukturiert. App-Events speichern Bewerbungs-/Gagenstatus, aber keinen unabhängigen Terminbestätigungsstatus.

- F23 · Bülow Straßenmusik Festival · Leipzig · Quelle: Flyer.
  - Beleg: public/data/spp7-datasets.json#/datasets/events/18; Hinweisart: nur_ort; vollständige Fenster: false; passende Fenster 0/1; DATE_ID:  - .
  - Name:  - ; Ort: Bestands-Ortstext „Leipzig“ vollständig im Referenz-Ort/Location-Text enthalten.; gleiche PLZ: false.
  - Bestands-Datumszeilen: D26 2026-08-22/ -  (Haupttermin; public/data/spp7-datasets.json#/datasets/event_dates/24).
  - Name: Referenz „18. Leipziger Umschlag“ ↔ Bestand „Bülow Straßenmusik Festival“ → abweichender_text. Literalvergleich; keine automatische Korrektur oder Zuordnung.
  - Ort/Location: Referenz „Leipzig/agra Messepark Halle 1“ ↔ Bestand „Leipzig / Bülowstraße / Ecke Paulinenstraße“ → abweichender_text. Literalvergleich; keine automatische Korrektur oder Zuordnung.
  - PLZ: Referenz „04107“ ↔ Bestand „ - “ → fehlt. Literalvergleich; keine automatische Korrektur oder Zuordnung.
  - Zeitfenster: Referenz „2027-03-06/2027-03-07“ ↔ Bestand „ - “ → fehlt. Literalvergleich; keine automatische Korrektur oder Zuordnung.
  - Bestätigungsstatus: Referenz „nicht_markiert“ ↔ Bestand „ - “ → nicht_strukturiert. App-Events speichern Bewerbungs-/Gagenstatus, aber keinen unabhängigen Terminbestätigungsstatus.

- F26 · Fockebergfest · Leipzig · Quelle: Flyer.
  - Beleg: public/data/spp7-datasets.json#/datasets/events/21; Hinweisart: nur_ort; vollständige Fenster: false; passende Fenster 0/1; DATE_ID:  - .
  - Name:  - ; Ort: Bestands-Ortstext „Leipzig“ vollständig im Referenz-Ort/Location-Text enthalten.; gleiche PLZ: false.
  - Bestands-Datumszeilen: D29 2026-08-23/ -  (Haupttermin; public/data/spp7-datasets.json#/datasets/event_dates/27).
  - Name: Referenz „18. Leipziger Umschlag“ ↔ Bestand „Fockebergfest“ → abweichender_text. Literalvergleich; keine automatische Korrektur oder Zuordnung.
  - Ort/Location: Referenz „Leipzig/agra Messepark Halle 1“ ↔ Bestand „Leipzig / Fockeberg, Südvorstadt“ → abweichender_text. Literalvergleich; keine automatische Korrektur oder Zuordnung.
  - PLZ: Referenz „04107“ ↔ Bestand „ - “ → fehlt. Literalvergleich; keine automatische Korrektur oder Zuordnung.
  - Zeitfenster: Referenz „2027-03-06/2027-03-07“ ↔ Bestand „ - “ → fehlt. Literalvergleich; keine automatische Korrektur oder Zuordnung.
  - Bestätigungsstatus: Referenz „nicht_markiert“ ↔ Bestand „ - “ → nicht_strukturiert. App-Events speichern Bewerbungs-/Gagenstatus, aber keinen unabhängigen Terminbestätigungsstatus.

- F27 · Tapetenwerkfest 36.0 · Leipzig · Quelle: Flyer.
  - Beleg: public/data/spp7-datasets.json#/datasets/events/22; Hinweisart: nur_ort; vollständige Fenster: false; passende Fenster 0/1; DATE_ID:  - .
  - Name:  - ; Ort: Bestands-Ortstext „Leipzig“ vollständig im Referenz-Ort/Location-Text enthalten.; gleiche PLZ: false.
  - Bestands-Datumszeilen: D30 2026-09-04/ -  (Haupttermin; public/data/spp7-datasets.json#/datasets/event_dates/28); D31 2026-08-21/ -  (Post-Datum; public/data/spp7-datasets.json#/datasets/event_dates/29).
  - Name: Referenz „18. Leipziger Umschlag“ ↔ Bestand „Tapetenwerkfest 36.0“ → abweichender_text. Literalvergleich; keine automatische Korrektur oder Zuordnung.
  - Ort/Location: Referenz „Leipzig/agra Messepark Halle 1“ ↔ Bestand „Leipzig / Tapetenwerk (Kunstareal), Sommerhof“ → abweichender_text. Literalvergleich; keine automatische Korrektur oder Zuordnung.
  - PLZ: Referenz „04107“ ↔ Bestand „ - “ → fehlt. Literalvergleich; keine automatische Korrektur oder Zuordnung.
  - Zeitfenster: Referenz „2027-03-06/2027-03-07“ ↔ Bestand „ - “ → fehlt. Literalvergleich; keine automatische Korrektur oder Zuordnung.
  - Bestätigungsstatus: Referenz „nicht_markiert“ ↔ Bestand „ - “ → nicht_strukturiert. App-Events speichern Bewerbungs-/Gagenstatus, aber keinen unabhängigen Terminbestätigungsstatus.

- F35 · unreleaseD Tour 2026 – Leipzig Wildcard · Leipzig · Quelle: Flyer.
  - Beleg: public/data/spp7-datasets.json#/datasets/events/27; Hinweisart: nur_ort; vollständige Fenster: false; passende Fenster 0/1; DATE_ID:  - .
  - Name:  - ; Ort: Bestands-Ortstext „Leipzig“ vollständig im Referenz-Ort/Location-Text enthalten.; gleiche PLZ: false.
  - Bestands-Datumszeilen: D38  - / -  (Tour; public/data/spp7-datasets.json#/datasets/event_dates/36).
  - Name: Referenz „18. Leipziger Umschlag“ ↔ Bestand „unreleaseD Tour 2026 – Leipzig Wildcard“ → abweichender_text. Literalvergleich; keine automatische Korrektur oder Zuordnung.
  - Ort/Location: Referenz „Leipzig/agra Messepark Halle 1“ ↔ Bestand „Leipzig“ → abweichender_text. Literalvergleich; keine automatische Korrektur oder Zuordnung.
  - PLZ: Referenz „04107“ ↔ Bestand „ - “ → fehlt. Literalvergleich; keine automatische Korrektur oder Zuordnung.
  - Zeitfenster: Referenz „2027-03-06/2027-03-07“ ↔ Bestand „ - “ → fehlt. Literalvergleich; keine automatische Korrektur oder Zuordnung.
  - Bestätigungsstatus: Referenz „nicht_markiert“ ↔ Bestand „ - “ → nicht_strukturiert. App-Events speichern Bewerbungs-/Gagenstatus, aber keinen unabhängigen Terminbestätigungsstatus.

- C14 · Taverne „Wankende Hydra“ – Torhaus Dölitz · Leipzig · Quelle: Chat.
  - Beleg: public/data/spp7-datasets.json#/datasets/events/41; Hinweisart: nur_ort; vollständige Fenster: false; passende Fenster 0/1; DATE_ID:  - .
  - Name:  - ; Ort: Bestands-Ortstext „Leipzig“ vollständig im Referenz-Ort/Location-Text enthalten.; gleiche PLZ: false.
  - Bestands-Datumszeilen:  - .
  - Name: Referenz „18. Leipziger Umschlag“ ↔ Bestand „Taverne „Wankende Hydra“ – Torhaus Dölitz“ → abweichender_text. Literalvergleich; keine automatische Korrektur oder Zuordnung.
  - Ort/Location: Referenz „Leipzig/agra Messepark Halle 1“ ↔ Bestand „Leipzig / Torhaus Dölitz“ → abweichender_text. Literalvergleich; keine automatische Korrektur oder Zuordnung.
  - PLZ: Referenz „04107“ ↔ Bestand „ - “ → fehlt. Literalvergleich; keine automatische Korrektur oder Zuordnung.
  - Zeitfenster: Referenz „2027-03-06/2027-03-07“ ↔ Bestand „ - “ → fehlt. Literalvergleich; keine automatische Korrektur oder Zuordnung.
  - Bestätigungsstatus: Referenz „nicht_markiert“ ↔ Bestand „ - “ → nicht_strukturiert. App-Events speichern Bewerbungs-/Gagenstatus, aber keinen unabhängigen Terminbestätigungsstatus.

- K36 · Peterskirche Leipzig – IN ECCLESIA · Leipzig · Quelle: Chat.
  - Beleg: public/data/spp7-datasets.json#/datasets/events/96; Hinweisart: nur_ort; vollständige Fenster: false; passende Fenster 0/1; DATE_ID:  - .
  - Name:  - ; Ort: Bestands-Ortstext „Leipzig“ vollständig im Referenz-Ort/Location-Text enthalten.; gleiche PLZ: false.
  - Bestands-Datumszeilen: D85 2026-12-30/ -  (Auftritt Corvus Corax; public/data/spp7-datasets.json#/datasets/event_dates/83).
  - Name: Referenz „18. Leipziger Umschlag“ ↔ Bestand „Peterskirche Leipzig – IN ECCLESIA“ → abweichender_text. Literalvergleich; keine automatische Korrektur oder Zuordnung.
  - Ort/Location: Referenz „Leipzig/agra Messepark Halle 1“ ↔ Bestand „Leipzig“ → abweichender_text. Literalvergleich; keine automatische Korrektur oder Zuordnung.
  - PLZ: Referenz „04107“ ↔ Bestand „ - “ → fehlt. Literalvergleich; keine automatische Korrektur oder Zuordnung.
  - Zeitfenster: Referenz „2027-03-06/2027-03-07“ ↔ Bestand „ - “ → fehlt. Literalvergleich; keine automatische Korrektur oder Zuordnung.
  - Bestätigungsstatus: Referenz „nicht_markiert“ ↔ Bestand „ - “ → nicht_strukturiert. App-Events speichern Bewerbungs-/Gagenstatus, aber keinen unabhängigen Terminbestätigungsstatus.

- S01 · Leipziger Umschlag · Leipzig · Quelle: Sündenfrei.
  - Beleg: public/data/spp7-datasets.json#/datasets/events/198; Hinweisart: datum_ort; vollständige Fenster: true; passende Fenster 1/1; DATE_ID: D186.
  - Name: Namenswortfolge identisch (Großschreibung, Interpunktion, führende Ausgabennummer ausgenommen).; Ort: Bestands-Ortstext „Leipzig“ vollständig im Referenz-Ort/Location-Text enthalten.; gleiche PLZ: true.
  - Bestands-Datumszeilen: D185 2026-03-07/2026-03-08 (Messe 2026; public/data/spp7-datasets.json#/datasets/event_dates/183); D186 2027-03-06/2027-03-07 (Messe 2027; public/data/spp7-datasets.json#/datasets/event_dates/184).
  - Name: Referenz „18. Leipziger Umschlag“ ↔ Bestand „Leipziger Umschlag“ → abweichender_text. Literalvergleich; keine automatische Korrektur oder Zuordnung.
  - Ort/Location: Referenz „Leipzig/agra Messepark Halle 1“ ↔ Bestand „Leipzig / agra Messepark Halle 1“ → gleich. Literalvergleich; keine automatische Korrektur oder Zuordnung.
  - PLZ: Referenz „04107“ ↔ Bestand „04107“ → gleich. Literalvergleich; keine automatische Korrektur oder Zuordnung.
  - Zeitfenster: Referenz „2027-03-06/2027-03-07“ ↔ Bestand „2026-03-07/2026-03-08;2027-03-06/2027-03-07“ → enthalten. Alle Referenzfenster im Bestand enthalten; Bestand hat zusätzliche oder mehrfach erfasste Zeitfenster. Keine Gleichheit der vollständigen Listen und keine Löschfreigabe.
  - Bestätigungsstatus: Referenz „nicht_markiert“ ↔ Bestand „ - “ → nicht_strukturiert. App-Events speichern Bewerbungs-/Gagenstatus, aber keinen unabhängigen Terminbestätigungsstatus.

### SF12 · Mittelalterfest Burgfrühling · 2027

Fundstelle: Termine_2027_suendenfrei.txt:L18. 13. - 14. März 2027 · 97877 Wertheim/ Burg.
Zeitfenster: 2027-03-13/2027-03-14. Datumsherkunft: aus_quelle; Quellstatus: nicht_markiert.
Kein Hinweis nach den beschriebenen Regeln im App-Datensatz. Kein Nachweis, dass die Veranstaltung extern nicht existiert.

### SF13 · Ritterturnier und Mittelaltermarkt · 2027

Fundstelle: Termine_2027_suendenfrei.txt:L19. 20. - 21. März 2027 · 01683 Altzella / Nossen.
Zeitfenster: 2027-03-20/2027-03-21. Datumsherkunft: aus_quelle; Quellstatus: nicht_markiert.
Kein Hinweis nach den beschriebenen Regeln im App-Datensatz. Kein Nachweis, dass die Veranstaltung extern nicht existiert.

### SF14 · Oster- Ritterturnier · 2027

Fundstelle: Termine_2027_suendenfrei.txt:L20. 27. - 29. März 2027 · 56346 Loreley/ St. Goarshausen.
Zeitfenster: 2027-03-27/2027-03-29. Datumsherkunft: aus_quelle; Quellstatus: nicht_markiert.
Kein Hinweis nach den beschriebenen Regeln im App-Datensatz. Kein Nachweis, dass die Veranstaltung extern nicht existiert.

### SF15 · Ritter und Drachen- Spektakel · 2027

Fundstelle: Termine_2027_suendenfrei.txt:L21. 27. - 29. März 2027 · 99448 Kranichfeld/ Niederburg.
Zeitfenster: 2027-03-27/2027-03-29. Datumsherkunft: aus_quelle; Quellstatus: nicht_markiert.
Alle Referenzzeitfenster und der Ortstext sind im selben Bestands-Event belegbar. Name, PLZ, Quelltyp und Verifikation separat prüfen; kein automatischer Merge.

- K15 · Sternenklang Festival · Kranichfeld · Quelle: Chat.
  - Beleg: public/data/spp7-datasets.json#/datasets/events/78; Hinweisart: nur_ort; vollständige Fenster: false; passende Fenster 0/1; DATE_ID:  - .
  - Name:  - ; Ort: Bestands-Ortstext „Kranichfeld“ vollständig im Referenz-Ort/Location-Text enthalten.; gleiche PLZ: false.
  - Bestands-Datumszeilen: D67 2026-06-11/2026-06-13 (Festivaltermin (KI-Liste); public/data/spp7-datasets.json#/datasets/event_dates/65).
  - Name: Referenz „Ritter und Drachen- Spektakel“ ↔ Bestand „Sternenklang Festival“ → abweichender_text. Literalvergleich; keine automatische Korrektur oder Zuordnung.
  - Ort/Location: Referenz „Kranichfeld/Niederburg“ ↔ Bestand „Kranichfeld“ → abweichender_text. Literalvergleich; keine automatische Korrektur oder Zuordnung.
  - PLZ: Referenz „99448“ ↔ Bestand „ - “ → fehlt. Literalvergleich; keine automatische Korrektur oder Zuordnung.
  - Zeitfenster: Referenz „2027-03-27/2027-03-29“ ↔ Bestand „2026-06-11/2026-06-13“ → abweichender_text. Literalvergleich; keine automatische Korrektur oder Zuordnung.
  - Bestätigungsstatus: Referenz „nicht_markiert“ ↔ Bestand „ - “ → nicht_strukturiert. App-Events speichern Bewerbungs-/Gagenstatus, aber keinen unabhängigen Terminbestätigungsstatus.

- M42 · Phantastisches Zauberdorf · Kranichfeld · Quelle: Chat (KI-Liste).
  - Beleg: public/data/spp7-datasets.json#/datasets/events/148; Hinweisart: nur_ort; vollständige Fenster: false; passende Fenster 0/1; DATE_ID:  - .
  - Name:  - ; Ort: Bestands-Ortstext „Kranichfeld“ vollständig im Referenz-Ort/Location-Text enthalten.; gleiche PLZ: false.
  - Bestands-Datumszeilen:  - .
  - Name: Referenz „Ritter und Drachen- Spektakel“ ↔ Bestand „Phantastisches Zauberdorf“ → abweichender_text. Literalvergleich; keine automatische Korrektur oder Zuordnung.
  - Ort/Location: Referenz „Kranichfeld/Niederburg“ ↔ Bestand „Kranichfeld“ → abweichender_text. Literalvergleich; keine automatische Korrektur oder Zuordnung.
  - PLZ: Referenz „99448“ ↔ Bestand „ - “ → fehlt. Literalvergleich; keine automatische Korrektur oder Zuordnung.
  - Zeitfenster: Referenz „2027-03-27/2027-03-29“ ↔ Bestand „ - “ → fehlt. Literalvergleich; keine automatische Korrektur oder Zuordnung.
  - Bestätigungsstatus: Referenz „nicht_markiert“ ↔ Bestand „ - “ → nicht_strukturiert. App-Events speichern Bewerbungs-/Gagenstatus, aber keinen unabhängigen Terminbestätigungsstatus.

- M44 · Ritter und Drachen-Spektakel · Kranichfeld · Quelle: Chat (KI-Liste).
  - Beleg: public/data/spp7-datasets.json#/datasets/events/150; Hinweisart: datum_ort; vollständige Fenster: true; passende Fenster 1/1; DATE_ID: D201.
  - Name: Namenswortfolge identisch (Großschreibung, Interpunktion, führende Ausgabennummer ausgenommen).; Ort: Bestands-Ortstext „Kranichfeld“ vollständig im Referenz-Ort/Location-Text enthalten.; gleiche PLZ: false.
  - Bestands-Datumszeilen: D200 2026-04-04/2026-04-06 (Sündenfrei 2026; public/data/spp7-datasets.json#/datasets/event_dates/198); D201 2027-03-27/2027-03-29 (Sündenfrei 2027; public/data/spp7-datasets.json#/datasets/event_dates/199).
  - Name: Referenz „Ritter und Drachen- Spektakel“ ↔ Bestand „Ritter und Drachen-Spektakel“ → gleich. Literalvergleich; keine automatische Korrektur oder Zuordnung.
  - Ort/Location: Referenz „Kranichfeld/Niederburg“ ↔ Bestand „Kranichfeld“ → abweichender_text. Literalvergleich; keine automatische Korrektur oder Zuordnung.
  - PLZ: Referenz „99448“ ↔ Bestand „ - “ → fehlt. Literalvergleich; keine automatische Korrektur oder Zuordnung.
  - Zeitfenster: Referenz „2027-03-27/2027-03-29“ ↔ Bestand „2026-04-04/2026-04-06;2027-03-27/2027-03-29“ → enthalten. Alle Referenzfenster im Bestand enthalten; Bestand hat zusätzliche oder mehrfach erfasste Zeitfenster. Keine Gleichheit der vollständigen Listen und keine Löschfreigabe.
  - Bestätigungsstatus: Referenz „nicht_markiert“ ↔ Bestand „ - “ → nicht_strukturiert. App-Events speichern Bewerbungs-/Gagenstatus, aber keinen unabhängigen Terminbestätigungsstatus.

### SF16 · Oster- Ritterturnier · 2027

Fundstelle: Termine_2027_suendenfrei.txt:L22. 27. - 29. März 2027 · 44286 Dorsten/ Schloss Lembeck.
Zeitfenster: 2027-03-27/2027-03-29. Datumsherkunft: aus_quelle; Quellstatus: nicht_markiert.
Kein Hinweis nach den beschriebenen Regeln im App-Datensatz. Kein Nachweis, dass die Veranstaltung extern nicht existiert.

### SF17 · noch offen · 2027

Fundstelle: Termine_2027_suendenfrei.txt:L23. 3.- 4. April 2027 · xxxxx.
Zeitfenster: 2027-04-03/2027-04-04. Datumsherkunft: aus_quelle; Quellstatus: nicht_markiert.
Referenz selbst enthält xxxx/xxxxx (Ort unbekannt); keine Zuordnung erraten.

### SF18 · Die Wikinger kommen! · 2027

Fundstelle: Termine_2027_suendenfrei.txt:L24. 10. - 11. April 2027 · 07929 Saalburg/ Bleilochtalsperre.
Zeitfenster: 2027-04-10/2027-04-11. Datumsherkunft: aus_quelle; Quellstatus: nicht_markiert.
Kein Hinweis nach den beschriebenen Regeln im App-Datensatz. Kein Nachweis, dass die Veranstaltung extern nicht existiert.

### SF19 · Turnierspiele · 2027

Fundstelle: Termine_2027_suendenfrei.txt:L25. 10. - 11. April 2027 · 96178 Schloss Weissenstein/ Pommersfelden.
Zeitfenster: 2027-04-10/2027-04-11. Datumsherkunft: aus_quelle; Quellstatus: nicht_markiert.
Kein Hinweis nach den beschriebenen Regeln im App-Datensatz. Kein Nachweis, dass die Veranstaltung extern nicht existiert.

### SF20 · Mittealterspektakel · 2027

Fundstelle: Termine_2027_suendenfrei.txt:L26. 17.- 18. April 2027 · 04519 Rackwitz, Schladitzer Bucht.
Zeitfenster: 2027-04-17/2027-04-18. Datumsherkunft: aus_quelle; Quellstatus: nicht_markiert.
Kein Hinweis nach den beschriebenen Regeln im App-Datensatz. Kein Nachweis, dass die Veranstaltung extern nicht existiert.

### SF21 · Mittelalterspektakel · 2027

Fundstelle: Termine_2027_suendenfrei.txt:L27. 17. - 18. April 2027 · 41844 Wegberg/ Schloss Tüschenbroich.
Zeitfenster: 2027-04-17/2027-04-18. Datumsherkunft: aus_quelle; Quellstatus: nicht_markiert.
Kein Hinweis nach den beschriebenen Regeln im App-Datensatz. Kein Nachweis, dass die Veranstaltung extern nicht existiert.

### SF22 · Mittelalterfest Löwenburg · 2027

Fundstelle: Termine_2027_suendenfrei.txt:L28. 24. - 25. April 2027 · 34131 Kassel.
Zeitfenster: 2027-04-24/2027-04-25. Datumsherkunft: aus_quelle; Quellstatus: nicht_markiert.
Kein Hinweis nach den beschriebenen Regeln im App-Datensatz. Kein Nachweis, dass die Veranstaltung extern nicht existiert.

### SF23 · Mittelaltermarkt · 2027

Fundstelle: Termine_2027_suendenfrei.txt:L29. 24. - 25. April 2027 · 90513 Zirndorf b. Nürnberg.
Zeitfenster: 2027-04-24/2027-04-25. Datumsherkunft: aus_quelle; Quellstatus: nicht_markiert.
Kein Hinweis nach den beschriebenen Regeln im App-Datensatz. Kein Nachweis, dass die Veranstaltung extern nicht existiert.

### SF24 · Ritterturnier & Walpurgisnacht · 2027

Fundstelle: Termine_2027_suendenfrei.txt:L30. 30. April - 2. Mai 2027 · 06632 Freyburg/ Neuenburg.
Zeitfenster: 2027-04-30/2027-05-02. Datumsherkunft: aus_quelle; Quellstatus: nicht_markiert.
Alle Referenzzeitfenster und der Ortstext sind im selben Bestands-Event belegbar. Name, PLZ, Quelltyp und Verifikation separat prüfen; kein automatischer Merge.

- M21 · Ritterturnier · Freyburg · Quelle: Chat (KI-Liste).
  - Beleg: public/data/spp7-datasets.json#/datasets/events/127; Hinweisart: datum_ort; vollständige Fenster: true; passende Fenster 1/1; DATE_ID: D199.
  - Name: Namenswortfolge wörtlich im anderen Namen enthalten; kein Identitätsbeweis.; Ort: Bestands-Ortstext „Freyburg“ vollständig im Referenz-Ort/Location-Text enthalten.; gleiche PLZ: false.
  - Bestands-Datumszeilen: D113 2026-05-01/2026-05-03 (Festivaltermin (KI-Liste); public/data/spp7-datasets.json#/datasets/event_dates/111); D198 2026-05-01/2026-05-03 (Sündenfrei 2026; public/data/spp7-datasets.json#/datasets/event_dates/196); D199 2027-04-30/2027-05-02 (Sündenfrei 2027; public/data/spp7-datasets.json#/datasets/event_dates/197).
  - Name: Referenz „Ritterturnier & Walpurgisnacht“ ↔ Bestand „Ritterturnier“ → abweichender_text. Literalvergleich; keine automatische Korrektur oder Zuordnung.
  - Ort/Location: Referenz „Freyburg/Neuenburg“ ↔ Bestand „Freyburg“ → abweichender_text. Literalvergleich; keine automatische Korrektur oder Zuordnung.
  - PLZ: Referenz „06632“ ↔ Bestand „ - “ → fehlt. Literalvergleich; keine automatische Korrektur oder Zuordnung.
  - Zeitfenster: Referenz „2027-04-30/2027-05-02“ ↔ Bestand „2026-05-01/2026-05-03;2026-05-01/2026-05-03;2027-04-30/2027-05-02“ → enthalten. Alle Referenzfenster im Bestand enthalten; Bestand hat zusätzliche oder mehrfach erfasste Zeitfenster. Keine Gleichheit der vollständigen Listen und keine Löschfreigabe.
  - Bestätigungsstatus: Referenz „nicht_markiert“ ↔ Bestand „ - “ → nicht_strukturiert. App-Events speichern Bewerbungs-/Gagenstatus, aber keinen unabhängigen Terminbestätigungsstatus.

### SF25 · Ritterturnier Schloss Lauersfort · 2027

Fundstelle: Termine_2027_suendenfrei.txt:L31. 1. - 2. Mai 2027 · 47447 Moers.
Zeitfenster: 2027-05-01/2027-05-02. Datumsherkunft: aus_quelle; Quellstatus: nicht_markiert.
Kein Hinweis nach den beschriebenen Regeln im App-Datensatz. Kein Nachweis, dass die Veranstaltung extern nicht existiert.

### SF26 · 23. Siegfriedspektakel · 2027

Fundstelle: Termine_2027_suendenfrei.txt:L32. 6. - 9. Mai 2027 · 46509 Xanten.
Zeitfenster: 2027-05-06/2027-05-09. Datumsherkunft: aus_quelle; Quellstatus: nicht_markiert.
Kein Hinweis nach den beschriebenen Regeln im App-Datensatz. Kein Nachweis, dass die Veranstaltung extern nicht existiert.

### SF27 · Mittealter- Burgfest · 2027

Fundstelle: Termine_2027_suendenfrei.txt:L33. 6. - 9. Mai 2027 · 06543 Burg Falkenstein/ Harz.
Zeitfenster: 2027-05-06/2027-05-09. Datumsherkunft: aus_quelle; Quellstatus: nicht_markiert.
Ort und Namensbestandteile sind vorhanden, jedoch kein passender Referenzzeitraum. Ältere Jahresdaten niemals auf 2027 übertragen.

- M14 · Burgfest · Falkenstein · Quelle: Chat (KI-Liste).
  - Beleg: public/data/spp7-datasets.json#/datasets/events/120; Hinweisart: ort_name; vollständige Fenster: false; passende Fenster 0/1; DATE_ID:  - .
  - Name: Namenswortfolge wörtlich im anderen Namen enthalten; kein Identitätsbeweis.; Ort: Bestands-Ortstext „Falkenstein“ vollständig im Referenz-Ort/Location-Text enthalten.; gleiche PLZ: false.
  - Bestands-Datumszeilen: D105 2026-10-10/2026-10-11 (Festivaltermin (KI-Liste); public/data/spp7-datasets.json#/datasets/event_dates/103); D106 2026-05-14/2026-05-17 (Festivaltermin (KI-Liste); public/data/spp7-datasets.json#/datasets/event_dates/104).
  - Name: Referenz „Mittealter- Burgfest“ ↔ Bestand „Burgfest“ → abweichender_text. Literalvergleich; keine automatische Korrektur oder Zuordnung.
  - Ort/Location: Referenz „Burg Falkenstein/Harz“ ↔ Bestand „Falkenstein“ → abweichender_text. Literalvergleich; keine automatische Korrektur oder Zuordnung.
  - PLZ: Referenz „06543“ ↔ Bestand „ - “ → fehlt. Literalvergleich; keine automatische Korrektur oder Zuordnung.
  - Zeitfenster: Referenz „2027-05-06/2027-05-09“ ↔ Bestand „2026-10-10/2026-10-11;2026-05-14/2026-05-17“ → abweichender_text. Literalvergleich; keine automatische Korrektur oder Zuordnung.
  - Bestätigungsstatus: Referenz „nicht_markiert“ ↔ Bestand „ - “ → nicht_strukturiert. App-Events speichern Bewerbungs-/Gagenstatus, aber keinen unabhängigen Terminbestätigungsstatus.

### SF28 · Wikingerfest · 2027

Fundstelle: Termine_2027_suendenfrei.txt:L34. 15. - 17. Mai 2027 · 99885 Weißensee/Thür..
Zeitfenster: 2027-05-15/2027-05-17. Datumsherkunft: aus_quelle; Quellstatus: nicht_markiert.
Kein Hinweis nach den beschriebenen Regeln im App-Datensatz. Kein Nachweis, dass die Veranstaltung extern nicht existiert.

### SF29 · Ritterturnier & Mittelalterspektakel · 2027

Fundstelle: Termine_2027_suendenfrei.txt:L35. 15. - 17. Mai 2027 · 85399 Hallbergmoos.
Zeitfenster: 2027-05-15/2027-05-17. Datumsherkunft: aus_quelle; Quellstatus: nicht_markiert.
Kein Hinweis nach den beschriebenen Regeln im App-Datensatz. Kein Nachweis, dass die Veranstaltung extern nicht existiert.

### SF30 · Mittelalterspektakel · 2027

Fundstelle: Termine_2027_suendenfrei.txt:L36. 22. - 23. Mai 2027 · 58455 Witten /Kemnader See.
Zeitfenster: 2027-05-22/2027-05-23. Datumsherkunft: aus_quelle; Quellstatus: nicht_markiert.
Kein Hinweis nach den beschriebenen Regeln im App-Datensatz. Kein Nachweis, dass die Veranstaltung extern nicht existiert.

### SF31 · Gaudium Schloss Horst* · 2027

Fundstelle: Termine_2027_suendenfrei.txt:L37. 27.- 30. Mai 2027* · 45899 Gelsenkirchen*.
Zeitfenster: 2027-05-27/2027-05-30. Datumsherkunft: aus_quelle; Quellstatus: unbestaetigt.
Nur Ortswortfolge gefunden, kein Name-/Termin-Nachweis. Nicht als vorhandener Referenztermin zählen.

- R01 · Folkfield Festival · Gelsenkirchen · Quelle: Chat.
  - Beleg: public/data/spp7-datasets.json#/datasets/events/102; Hinweisart: nur_ort; vollständige Fenster: false; passende Fenster 0/1; DATE_ID:  - .
  - Name:  - ; Ort: Ortstext identisch.; gleiche PLZ: false.
  - Bestands-Datumszeilen:  - .
  - Name: Referenz „Gaudium Schloss Horst*“ ↔ Bestand „Folkfield Festival“ → abweichender_text. Literalvergleich; keine automatische Korrektur oder Zuordnung.
  - Ort/Location: Referenz „Gelsenkirchen“ ↔ Bestand „Gelsenkirchen“ → gleich. Literalvergleich; keine automatische Korrektur oder Zuordnung.
  - PLZ: Referenz „45899“ ↔ Bestand „ - “ → fehlt. Literalvergleich; keine automatische Korrektur oder Zuordnung.
  - Zeitfenster: Referenz „2027-05-27/2027-05-30“ ↔ Bestand „ - “ → fehlt. Literalvergleich; keine automatische Korrektur oder Zuordnung.
  - Bestätigungsstatus: Referenz „unbestaetigt“ ↔ Bestand „ - “ → nicht_strukturiert. App-Events speichern Bewerbungs-/Gagenstatus, aber keinen unabhängigen Terminbestätigungsstatus.

### SF32 · Mittelalterspektakel · 2027

Fundstelle: Termine_2027_suendenfrei.txt:L38. 29. - 30. Mai 2027 · 02829 Königshain.
Zeitfenster: 2027-05-29/2027-05-30. Datumsherkunft: aus_quelle; Quellstatus: nicht_markiert.
Kein Hinweis nach den beschriebenen Regeln im App-Datensatz. Kein Nachweis, dass die Veranstaltung extern nicht existiert.

### SF33 · Mittelalterspektakel · 2027

Fundstelle: Termine_2027_suendenfrei.txt:L39. 5. - 6. Juni 2027 · 34346 Hann. Münden.
Zeitfenster: 2027-06-05/2027-06-06. Datumsherkunft: aus_quelle; Quellstatus: nicht_markiert.
Kein Hinweis nach den beschriebenen Regeln im App-Datensatz. Kein Nachweis, dass die Veranstaltung extern nicht existiert.

### SF34 · Annamarkt und Stadtfest · 2027

Fundstelle: Termine_2027_suendenfrei.txt:L40. 11. - 13. Juni 2027 · 52349 Düren.
Zeitfenster: 2027-06-11/2027-06-13. Datumsherkunft: aus_quelle; Quellstatus: nicht_markiert.
Kein Hinweis nach den beschriebenen Regeln im App-Datensatz. Kein Nachweis, dass die Veranstaltung extern nicht existiert.

### SF35 · Mittelalterspektakel · 2027

Fundstelle: Termine_2027_suendenfrei.txt:L41. 16. - 18. Juli 2027 · 23999 Insel Poel.
Zeitfenster: 2027-07-16/2027-07-18. Datumsherkunft: aus_quelle; Quellstatus: nicht_markiert.
Alle Referenzzeitfenster und der Ortstext sind im selben Bestands-Event belegbar. Name, PLZ, Quelltyp und Verifikation separat prüfen; kein automatischer Merge.

- S04 · Insel Poel – Mittelalterspektakel · Insel Poel · Quelle: Sündenfrei.
  - Beleg: public/data/spp7-datasets.json#/datasets/events/201; Hinweisart: datum_ort; vollständige Fenster: true; passende Fenster 1/1; DATE_ID: D194.
  - Name: Namenswortfolge wörtlich im anderen Namen enthalten; kein Identitätsbeweis.; Ort: Ortstext identisch.; gleiche PLZ: true.
  - Bestands-Datumszeilen: D193 2026-07-17/2026-07-19 (Festivaltermin 2026; public/data/spp7-datasets.json#/datasets/event_dates/191); D194 2027-07-16/2027-07-18 (Festivaltermin 2027; public/data/spp7-datasets.json#/datasets/event_dates/192).
  - Name: Referenz „Mittelalterspektakel“ ↔ Bestand „Insel Poel – Mittelalterspektakel“ → abweichender_text. Literalvergleich; keine automatische Korrektur oder Zuordnung.
  - Ort/Location: Referenz „Insel Poel“ ↔ Bestand „Insel Poel“ → gleich. Literalvergleich; keine automatische Korrektur oder Zuordnung.
  - PLZ: Referenz „23999“ ↔ Bestand „23999“ → gleich. Literalvergleich; keine automatische Korrektur oder Zuordnung.
  - Zeitfenster: Referenz „2027-07-16/2027-07-18“ ↔ Bestand „2026-07-17/2026-07-19;2027-07-16/2027-07-18“ → enthalten. Alle Referenzfenster im Bestand enthalten; Bestand hat zusätzliche oder mehrfach erfasste Zeitfenster. Keine Gleichheit der vollständigen Listen und keine Löschfreigabe.
  - Bestätigungsstatus: Referenz „nicht_markiert“ ↔ Bestand „ - “ → nicht_strukturiert. App-Events speichern Bewerbungs-/Gagenstatus, aber keinen unabhängigen Terminbestätigungsstatus.

### SF36 · Wallensteintage · 2027

Fundstelle: Termine_2027_suendenfrei.txt:L42. 22. - 25. Juli 2027 · 18439 Stralsund /Alter Markt.
Zeitfenster: 2027-07-22/2027-07-25. Datumsherkunft: aus_quelle; Quellstatus: nicht_markiert.
Alle Referenzzeitfenster und der Ortstext sind im selben Bestands-Event belegbar. Name, PLZ, Quelltyp und Verifikation separat prüfen; kein automatischer Merge.

- S03 · Wallensteintage Stralsund · Stralsund · Quelle: Sündenfrei.
  - Beleg: public/data/spp7-datasets.json#/datasets/events/200; Hinweisart: datum_ort; vollständige Fenster: true; passende Fenster 1/1; DATE_ID: D192.
  - Name: Namenswortfolge wörtlich im anderen Namen enthalten; kein Identitätsbeweis.; Ort: Bestands-Ortstext „Stralsund“ vollständig im Referenz-Ort/Location-Text enthalten.; gleiche PLZ: true.
  - Bestands-Datumszeilen: D191 2026-07-23/2026-07-26 (Festivaltermin 2026; public/data/spp7-datasets.json#/datasets/event_dates/189); D192 2027-07-22/2027-07-25 (Festivaltermin 2027; public/data/spp7-datasets.json#/datasets/event_dates/190).
  - Name: Referenz „Wallensteintage“ ↔ Bestand „Wallensteintage Stralsund“ → abweichender_text. Literalvergleich; keine automatische Korrektur oder Zuordnung.
  - Ort/Location: Referenz „Stralsund/Alter Markt“ ↔ Bestand „Stralsund / Alter Markt“ → gleich. Literalvergleich; keine automatische Korrektur oder Zuordnung.
  - PLZ: Referenz „18439“ ↔ Bestand „18439“ → gleich. Literalvergleich; keine automatische Korrektur oder Zuordnung.
  - Zeitfenster: Referenz „2027-07-22/2027-07-25“ ↔ Bestand „2026-07-23/2026-07-26;2027-07-22/2027-07-25“ → enthalten. Alle Referenzfenster im Bestand enthalten; Bestand hat zusätzliche oder mehrfach erfasste Zeitfenster. Keine Gleichheit der vollständigen Listen und keine Löschfreigabe.
  - Bestätigungsstatus: Referenz „nicht_markiert“ ↔ Bestand „ - “ → nicht_strukturiert. App-Events speichern Bewerbungs-/Gagenstatus, aber keinen unabhängigen Terminbestätigungsstatus.

### SF37 · Fantasy- und Mittelalterfest · 2027

Fundstelle: Termine_2027_suendenfrei.txt:L43. 14. - 15. August 2027 · 01833 Stolpen (Burg).
Zeitfenster: 2027-08-14/2027-08-15. Datumsherkunft: aus_quelle; Quellstatus: nicht_markiert.
Alle Referenzzeitfenster und der Ortstext sind im selben Bestands-Event belegbar. Name, PLZ, Quelltyp und Verifikation separat prüfen; kein automatischer Merge.

- S06 · Drachen und Ritter Stolpen · Stolpen · Quelle: Sündenfrei.
  - Beleg: public/data/spp7-datasets.json#/datasets/events/203; Hinweisart: datum_ort; vollständige Fenster: true; passende Fenster 1/1; DATE_ID: D197.
  - Name:  - ; Ort: Bestands-Ortstext „Stolpen“ vollständig im Referenz-Ort/Location-Text enthalten.; gleiche PLZ: true.
  - Bestands-Datumszeilen: D196 2026-08-08/2026-08-09 (Festivaltermin 2026; public/data/spp7-datasets.json#/datasets/event_dates/194); D197 2027-08-14/2027-08-15 (Festivaltermin 2027; public/data/spp7-datasets.json#/datasets/event_dates/195).
  - Name: Referenz „Fantasy- und Mittelalterfest“ ↔ Bestand „Drachen und Ritter Stolpen“ → abweichender_text. Literalvergleich; keine automatische Korrektur oder Zuordnung.
  - Ort/Location: Referenz „Stolpen (Burg)“ ↔ Bestand „Stolpen / Burg“ → gleich. Literalvergleich; keine automatische Korrektur oder Zuordnung.
  - PLZ: Referenz „01833“ ↔ Bestand „01833“ → gleich. Literalvergleich; keine automatische Korrektur oder Zuordnung.
  - Zeitfenster: Referenz „2027-08-14/2027-08-15“ ↔ Bestand „2026-08-08/2026-08-09;2027-08-14/2027-08-15“ → enthalten. Alle Referenzfenster im Bestand enthalten; Bestand hat zusätzliche oder mehrfach erfasste Zeitfenster. Keine Gleichheit der vollständigen Listen und keine Löschfreigabe.
  - Bestätigungsstatus: Referenz „nicht_markiert“ ↔ Bestand „ - “ → nicht_strukturiert. App-Events speichern Bewerbungs-/Gagenstatus, aber keinen unabhängigen Terminbestätigungsstatus.

### SF38 · Burgfest* · 2027

Fundstelle: Termine_2027_suendenfrei.txt:L44. 28. - 29. August 2027 · xxxx.
Zeitfenster: 2027-08-28/2027-08-29. Datumsherkunft: aus_quelle; Quellstatus: unbestaetigt.
Referenz selbst enthält xxxx/xxxxx (Ort unbekannt); keine Zuordnung erraten.

### SF39 · 20. Mittelalterspektakel · 2027

Fundstelle: Termine_2027_suendenfrei.txt:L45. 3. - 5. September 2027 · 44629 Herne / Schloss Strünkede.
Zeitfenster: 2027-09-03/2027-09-05. Datumsherkunft: aus_quelle; Quellstatus: nicht_markiert.
Kein Hinweis nach den beschriebenen Regeln im App-Datensatz. Kein Nachweis, dass die Veranstaltung extern nicht existiert.

### SF40 · Mittelalterfest* · 2027

Fundstelle: Termine_2027_suendenfrei.txt:L46. 11. - 12. September 2027 · 99707 Kyffhäuser*.
Zeitfenster: 2027-09-11/2027-09-12. Datumsherkunft: aus_quelle; Quellstatus: unbestaetigt.
Kein Hinweis nach den beschriebenen Regeln im App-Datensatz. Kein Nachweis, dass die Veranstaltung extern nicht existiert.

### SF41 · Die Wikinger kommen! · 2027

Fundstelle: Termine_2027_suendenfrei.txt:L47. 18. - 19. September 2027 · 46509 Xanten.
Zeitfenster: 2027-09-18/2027-09-19. Datumsherkunft: aus_quelle; Quellstatus: nicht_markiert.
Kein Hinweis nach den beschriebenen Regeln im App-Datensatz. Kein Nachweis, dass die Veranstaltung extern nicht existiert.

### SF42 · Ritterturnier und Mittelalterspektakel · 2027

Fundstelle: Termine_2027_suendenfrei.txt:L48. 18. - 19. September 2027 · 93186 Adlersberg/ Pettendorf.
Zeitfenster: 2027-09-18/2027-09-19. Datumsherkunft: aus_quelle; Quellstatus: nicht_markiert.
Kein Hinweis nach den beschriebenen Regeln im App-Datensatz. Kein Nachweis, dass die Veranstaltung extern nicht existiert.

### SF43 · Zwiebelmarkt Apolda · 2027

Fundstelle: Termine_2027_suendenfrei.txt:L49. 24. - 26. September 2027* · 99510 Apolda.
Zeitfenster: 2027-09-24/2027-09-26. Datumsherkunft: aus_quelle; Quellstatus: unbestaetigt.
Kein Hinweis nach den beschriebenen Regeln im App-Datensatz. Kein Nachweis, dass die Veranstaltung extern nicht existiert.

### SF44 · 56. Heidelberger Herbst · 2027

Fundstelle: Termine_2027_suendenfrei.txt:L50. 25. - 26. September 2027 · 69120 Heidelberg.
Zeitfenster: 2027-09-25/2027-09-26. Datumsherkunft: aus_quelle; Quellstatus: nicht_markiert.
Kein Hinweis nach den beschriebenen Regeln im App-Datensatz. Kein Nachweis, dass die Veranstaltung extern nicht existiert.

### SF45 · Mittelalter & Fantasytage mit Drachen · 2027

Fundstelle: Termine_2027_suendenfrei.txt:L51. 2. - 3. Oktober 2027 · 56346 Loreley/ St. Goarshausen.
Zeitfenster: 2027-10-02/2027-10-03. Datumsherkunft: aus_quelle; Quellstatus: nicht_markiert.
Kein Hinweis nach den beschriebenen Regeln im App-Datensatz. Kein Nachweis, dass die Veranstaltung extern nicht existiert.

### SF46 · Thüringer Ritterturnier · 2027

Fundstelle: Termine_2027_suendenfrei.txt:L52. 2. - 3. Oktober 2027 · 99448 Kranichfeld.
Zeitfenster: 2027-10-02/2027-10-03. Datumsherkunft: aus_quelle; Quellstatus: nicht_markiert.
Nur Ortswortfolge gefunden, kein Name-/Termin-Nachweis. Nicht als vorhandener Referenztermin zählen.

- K15 · Sternenklang Festival · Kranichfeld · Quelle: Chat.
  - Beleg: public/data/spp7-datasets.json#/datasets/events/78; Hinweisart: nur_ort; vollständige Fenster: false; passende Fenster 0/1; DATE_ID:  - .
  - Name:  - ; Ort: Ortstext identisch.; gleiche PLZ: false.
  - Bestands-Datumszeilen: D67 2026-06-11/2026-06-13 (Festivaltermin (KI-Liste); public/data/spp7-datasets.json#/datasets/event_dates/65).
  - Name: Referenz „Thüringer Ritterturnier“ ↔ Bestand „Sternenklang Festival“ → abweichender_text. Literalvergleich; keine automatische Korrektur oder Zuordnung.
  - Ort/Location: Referenz „Kranichfeld“ ↔ Bestand „Kranichfeld“ → gleich. Literalvergleich; keine automatische Korrektur oder Zuordnung.
  - PLZ: Referenz „99448“ ↔ Bestand „ - “ → fehlt. Literalvergleich; keine automatische Korrektur oder Zuordnung.
  - Zeitfenster: Referenz „2027-10-02/2027-10-03“ ↔ Bestand „2026-06-11/2026-06-13“ → abweichender_text. Literalvergleich; keine automatische Korrektur oder Zuordnung.
  - Bestätigungsstatus: Referenz „nicht_markiert“ ↔ Bestand „ - “ → nicht_strukturiert. App-Events speichern Bewerbungs-/Gagenstatus, aber keinen unabhängigen Terminbestätigungsstatus.

- M42 · Phantastisches Zauberdorf · Kranichfeld · Quelle: Chat (KI-Liste).
  - Beleg: public/data/spp7-datasets.json#/datasets/events/148; Hinweisart: nur_ort; vollständige Fenster: false; passende Fenster 0/1; DATE_ID:  - .
  - Name:  - ; Ort: Ortstext identisch.; gleiche PLZ: false.
  - Bestands-Datumszeilen:  - .
  - Name: Referenz „Thüringer Ritterturnier“ ↔ Bestand „Phantastisches Zauberdorf“ → abweichender_text. Literalvergleich; keine automatische Korrektur oder Zuordnung.
  - Ort/Location: Referenz „Kranichfeld“ ↔ Bestand „Kranichfeld“ → gleich. Literalvergleich; keine automatische Korrektur oder Zuordnung.
  - PLZ: Referenz „99448“ ↔ Bestand „ - “ → fehlt. Literalvergleich; keine automatische Korrektur oder Zuordnung.
  - Zeitfenster: Referenz „2027-10-02/2027-10-03“ ↔ Bestand „ - “ → fehlt. Literalvergleich; keine automatische Korrektur oder Zuordnung.
  - Bestätigungsstatus: Referenz „nicht_markiert“ ↔ Bestand „ - “ → nicht_strukturiert. App-Events speichern Bewerbungs-/Gagenstatus, aber keinen unabhängigen Terminbestätigungsstatus.

- M44 · Ritter und Drachen-Spektakel · Kranichfeld · Quelle: Chat (KI-Liste).
  - Beleg: public/data/spp7-datasets.json#/datasets/events/150; Hinweisart: nur_ort; vollständige Fenster: false; passende Fenster 0/1; DATE_ID:  - .
  - Name:  - ; Ort: Ortstext identisch.; gleiche PLZ: false.
  - Bestands-Datumszeilen: D200 2026-04-04/2026-04-06 (Sündenfrei 2026; public/data/spp7-datasets.json#/datasets/event_dates/198); D201 2027-03-27/2027-03-29 (Sündenfrei 2027; public/data/spp7-datasets.json#/datasets/event_dates/199).
  - Name: Referenz „Thüringer Ritterturnier“ ↔ Bestand „Ritter und Drachen-Spektakel“ → abweichender_text. Literalvergleich; keine automatische Korrektur oder Zuordnung.
  - Ort/Location: Referenz „Kranichfeld“ ↔ Bestand „Kranichfeld“ → gleich. Literalvergleich; keine automatische Korrektur oder Zuordnung.
  - PLZ: Referenz „99448“ ↔ Bestand „ - “ → fehlt. Literalvergleich; keine automatische Korrektur oder Zuordnung.
  - Zeitfenster: Referenz „2027-10-02/2027-10-03“ ↔ Bestand „2026-04-04/2026-04-06;2027-03-27/2027-03-29“ → abweichender_text. Literalvergleich; keine automatische Korrektur oder Zuordnung.
  - Bestätigungsstatus: Referenz „nicht_markiert“ ↔ Bestand „ - “ → nicht_strukturiert. App-Events speichern Bewerbungs-/Gagenstatus, aber keinen unabhängigen Terminbestätigungsstatus.

### SF47 · 374. Zwiebelmarkt · 2027

Fundstelle: Termine_2027_suendenfrei.txt:L53. 8. - 10. Oktober 2027 · 99423 Weimar.
Zeitfenster: 2027-10-08/2027-10-10. Datumsherkunft: aus_quelle; Quellstatus: nicht_markiert.
Kein Hinweis nach den beschriebenen Regeln im App-Datensatz. Kein Nachweis, dass die Veranstaltung extern nicht existiert.

### SF48 · 30. Burgfest · 2027

Fundstelle: Termine_2027_suendenfrei.txt:L54. 9.- 10. Oktober 2027* · 06543 Burg Falkenstein/ Harz.
Zeitfenster: 2027-10-09/2027-10-10. Datumsherkunft: aus_quelle; Quellstatus: unbestaetigt.
Ort und Namensbestandteile sind vorhanden, jedoch kein passender Referenzzeitraum. Ältere Jahresdaten niemals auf 2027 übertragen.

- M14 · Burgfest · Falkenstein · Quelle: Chat (KI-Liste).
  - Beleg: public/data/spp7-datasets.json#/datasets/events/120; Hinweisart: ort_name; vollständige Fenster: false; passende Fenster 0/1; DATE_ID:  - .
  - Name: Namenswortfolge identisch (Großschreibung, Interpunktion, führende Ausgabennummer ausgenommen).; Ort: Bestands-Ortstext „Falkenstein“ vollständig im Referenz-Ort/Location-Text enthalten.; gleiche PLZ: false.
  - Bestands-Datumszeilen: D105 2026-10-10/2026-10-11 (Festivaltermin (KI-Liste); public/data/spp7-datasets.json#/datasets/event_dates/103); D106 2026-05-14/2026-05-17 (Festivaltermin (KI-Liste); public/data/spp7-datasets.json#/datasets/event_dates/104).
  - Name: Referenz „30. Burgfest“ ↔ Bestand „Burgfest“ → abweichender_text. Literalvergleich; keine automatische Korrektur oder Zuordnung.
  - Ort/Location: Referenz „Burg Falkenstein/Harz“ ↔ Bestand „Falkenstein“ → abweichender_text. Literalvergleich; keine automatische Korrektur oder Zuordnung.
  - PLZ: Referenz „06543“ ↔ Bestand „ - “ → fehlt. Literalvergleich; keine automatische Korrektur oder Zuordnung.
  - Zeitfenster: Referenz „2027-10-09/2027-10-10“ ↔ Bestand „2026-10-10/2026-10-11;2026-05-14/2026-05-17“ → abweichender_text. Literalvergleich; keine automatische Korrektur oder Zuordnung.
  - Bestätigungsstatus: Referenz „unbestaetigt“ ↔ Bestand „ - “ → nicht_strukturiert. App-Events speichern Bewerbungs-/Gagenstatus, aber keinen unabhängigen Terminbestätigungsstatus.

### SF49 · 6. Mittelalter- Markttage · 2027

Fundstelle: Termine_2027_suendenfrei.txt:L55. 16. - 17. Oktober 2027* · 44575 Castrop- Rauxel.
Zeitfenster: 2027-10-16/2027-10-17. Datumsherkunft: aus_quelle; Quellstatus: unbestaetigt.
Kein Hinweis nach den beschriebenen Regeln im App-Datensatz. Kein Nachweis, dass die Veranstaltung extern nicht existiert.

### SF50 · Mittelalter- Advent (Fr.- So.) · 2027

Fundstelle: Termine_2027_suendenfrei.txt:L56. 1. - 4. Advent 2027* · 44629 Herne/ Schloss Strünkede.
Zeitfenster: 2027-11-26/2027-11-28; 2027-12-03/2027-12-05; 2027-12-10/2027-12-12; 2027-12-17/2027-12-19. Datumsherkunft: berechnet; Quellstatus: unbestaetigt.
Kein Hinweis nach den beschriebenen Regeln im App-Datensatz. Kein Nachweis, dass die Veranstaltung extern nicht existiert.

### SF51 · Mittelalter- Weihnacht · 2027

Fundstelle: Termine_2027_suendenfrei.txt:L57. 24.11. - 23. Dezember 2027* · 01067 Dresden / Stallhof.
Zeitfenster: 2027-11-24/2027-12-23. Datumsherkunft: aus_quelle; Quellstatus: unbestaetigt.
Nur Ortswortfolge gefunden, kein Name-/Termin-Nachweis. Nicht als vorhandener Referenztermin zählen.

- S02 · Rauhnächte Dresden · Dresden · Quelle: Sündenfrei.
  - Beleg: public/data/spp7-datasets.json#/datasets/events/199; Hinweisart: nur_ort; vollständige Fenster: false; passende Fenster 0/1; DATE_ID:  - .
  - Name:  - ; Ort: Bestands-Ortstext „Dresden“ vollständig im Referenz-Ort/Location-Text enthalten.; gleiche PLZ: true.
  - Bestands-Datumszeilen: D187 2026-01-02/2026-01-06 (Markt 2026; public/data/spp7-datasets.json#/datasets/event_dates/185); D188 2026-12-27/2026-12-30 (Markt 2026; public/data/spp7-datasets.json#/datasets/event_dates/186); D189 2027-01-02/2027-01-06 (Markt 2027; public/data/spp7-datasets.json#/datasets/event_dates/187); D190 2027-12-27/2027-12-30 (Markt 2027; public/data/spp7-datasets.json#/datasets/event_dates/188).
  - Name: Referenz „Mittelalter- Weihnacht“ ↔ Bestand „Rauhnächte Dresden“ → abweichender_text. Literalvergleich; keine automatische Korrektur oder Zuordnung.
  - Ort/Location: Referenz „Dresden/Stallhof“ ↔ Bestand „Dresden / Stallhof“ → gleich. Literalvergleich; keine automatische Korrektur oder Zuordnung.
  - PLZ: Referenz „01067“ ↔ Bestand „01067“ → gleich. Literalvergleich; keine automatische Korrektur oder Zuordnung.
  - Zeitfenster: Referenz „2027-11-24/2027-12-23“ ↔ Bestand „2026-01-02/2026-01-06;2026-12-27/2026-12-30;2027-01-02/2027-01-06;2027-12-27/2027-12-30“ → abweichender_text. Literalvergleich; keine automatische Korrektur oder Zuordnung.
  - Bestätigungsstatus: Referenz „unbestaetigt“ ↔ Bestand „ - “ → nicht_strukturiert. App-Events speichern Bewerbungs-/Gagenstatus, aber keinen unabhängigen Terminbestätigungsstatus.

### SF52 · Felsenkeller- Weihnachtsmarkt · 2027

Fundstelle: Termine_2027_suendenfrei.txt:L58. 25.11. - 30. Dezember 2027* · 04229 Leipzig / Plagwitz.
Zeitfenster: 2027-11-25/2027-12-30. Datumsherkunft: aus_quelle; Quellstatus: unbestaetigt.
Nur Ortswortfolge gefunden, kein Name-/Termin-Nachweis. Nicht als vorhandener Referenztermin zählen.

- F01 · NEXUS Festival · Leipzig · Quelle: Flyer.
  - Beleg: public/data/spp7-datasets.json#/datasets/events/0; Hinweisart: nur_ort; vollständige Fenster: false; passende Fenster 0/1; DATE_ID:  - .
  - Name:  - ; Ort: Bestands-Ortstext „Leipzig“ vollständig im Referenz-Ort/Location-Text enthalten.; gleiche PLZ: false.
  - Bestands-Datumszeilen: D01 2026-09-18/2026-09-20 (Haupttermin; public/data/spp7-datasets.json#/datasets/event_dates/0).
  - Name: Referenz „Felsenkeller- Weihnachtsmarkt“ ↔ Bestand „NEXUS Festival“ → abweichender_text. Literalvergleich; keine automatische Korrektur oder Zuordnung.
  - Ort/Location: Referenz „Leipzig/Plagwitz“ ↔ Bestand „Leipzig / Agra Messepark“ → abweichender_text. Literalvergleich; keine automatische Korrektur oder Zuordnung.
  - PLZ: Referenz „04229“ ↔ Bestand „ - “ → fehlt. Literalvergleich; keine automatische Korrektur oder Zuordnung.
  - Zeitfenster: Referenz „2027-11-25/2027-12-30“ ↔ Bestand „2026-09-18/2026-09-20“ → abweichender_text. Literalvergleich; keine automatische Korrektur oder Zuordnung.
  - Bestätigungsstatus: Referenz „unbestaetigt“ ↔ Bestand „ - “ → nicht_strukturiert. App-Events speichern Bewerbungs-/Gagenstatus, aber keinen unabhängigen Terminbestätigungsstatus.

- F23 · Bülow Straßenmusik Festival · Leipzig · Quelle: Flyer.
  - Beleg: public/data/spp7-datasets.json#/datasets/events/18; Hinweisart: nur_ort; vollständige Fenster: false; passende Fenster 0/1; DATE_ID:  - .
  - Name:  - ; Ort: Bestands-Ortstext „Leipzig“ vollständig im Referenz-Ort/Location-Text enthalten.; gleiche PLZ: false.
  - Bestands-Datumszeilen: D26 2026-08-22/ -  (Haupttermin; public/data/spp7-datasets.json#/datasets/event_dates/24).
  - Name: Referenz „Felsenkeller- Weihnachtsmarkt“ ↔ Bestand „Bülow Straßenmusik Festival“ → abweichender_text. Literalvergleich; keine automatische Korrektur oder Zuordnung.
  - Ort/Location: Referenz „Leipzig/Plagwitz“ ↔ Bestand „Leipzig / Bülowstraße / Ecke Paulinenstraße“ → abweichender_text. Literalvergleich; keine automatische Korrektur oder Zuordnung.
  - PLZ: Referenz „04229“ ↔ Bestand „ - “ → fehlt. Literalvergleich; keine automatische Korrektur oder Zuordnung.
  - Zeitfenster: Referenz „2027-11-25/2027-12-30“ ↔ Bestand „ - “ → fehlt. Literalvergleich; keine automatische Korrektur oder Zuordnung.
  - Bestätigungsstatus: Referenz „unbestaetigt“ ↔ Bestand „ - “ → nicht_strukturiert. App-Events speichern Bewerbungs-/Gagenstatus, aber keinen unabhängigen Terminbestätigungsstatus.

- F26 · Fockebergfest · Leipzig · Quelle: Flyer.
  - Beleg: public/data/spp7-datasets.json#/datasets/events/21; Hinweisart: nur_ort; vollständige Fenster: false; passende Fenster 0/1; DATE_ID:  - .
  - Name:  - ; Ort: Bestands-Ortstext „Leipzig“ vollständig im Referenz-Ort/Location-Text enthalten.; gleiche PLZ: false.
  - Bestands-Datumszeilen: D29 2026-08-23/ -  (Haupttermin; public/data/spp7-datasets.json#/datasets/event_dates/27).
  - Name: Referenz „Felsenkeller- Weihnachtsmarkt“ ↔ Bestand „Fockebergfest“ → abweichender_text. Literalvergleich; keine automatische Korrektur oder Zuordnung.
  - Ort/Location: Referenz „Leipzig/Plagwitz“ ↔ Bestand „Leipzig / Fockeberg, Südvorstadt“ → abweichender_text. Literalvergleich; keine automatische Korrektur oder Zuordnung.
  - PLZ: Referenz „04229“ ↔ Bestand „ - “ → fehlt. Literalvergleich; keine automatische Korrektur oder Zuordnung.
  - Zeitfenster: Referenz „2027-11-25/2027-12-30“ ↔ Bestand „ - “ → fehlt. Literalvergleich; keine automatische Korrektur oder Zuordnung.
  - Bestätigungsstatus: Referenz „unbestaetigt“ ↔ Bestand „ - “ → nicht_strukturiert. App-Events speichern Bewerbungs-/Gagenstatus, aber keinen unabhängigen Terminbestätigungsstatus.

- F27 · Tapetenwerkfest 36.0 · Leipzig · Quelle: Flyer.
  - Beleg: public/data/spp7-datasets.json#/datasets/events/22; Hinweisart: nur_ort; vollständige Fenster: false; passende Fenster 0/1; DATE_ID:  - .
  - Name:  - ; Ort: Bestands-Ortstext „Leipzig“ vollständig im Referenz-Ort/Location-Text enthalten.; gleiche PLZ: false.
  - Bestands-Datumszeilen: D30 2026-09-04/ -  (Haupttermin; public/data/spp7-datasets.json#/datasets/event_dates/28); D31 2026-08-21/ -  (Post-Datum; public/data/spp7-datasets.json#/datasets/event_dates/29).
  - Name: Referenz „Felsenkeller- Weihnachtsmarkt“ ↔ Bestand „Tapetenwerkfest 36.0“ → abweichender_text. Literalvergleich; keine automatische Korrektur oder Zuordnung.
  - Ort/Location: Referenz „Leipzig/Plagwitz“ ↔ Bestand „Leipzig / Tapetenwerk (Kunstareal), Sommerhof“ → abweichender_text. Literalvergleich; keine automatische Korrektur oder Zuordnung.
  - PLZ: Referenz „04229“ ↔ Bestand „ - “ → fehlt. Literalvergleich; keine automatische Korrektur oder Zuordnung.
  - Zeitfenster: Referenz „2027-11-25/2027-12-30“ ↔ Bestand „ - “ → fehlt. Literalvergleich; keine automatische Korrektur oder Zuordnung.
  - Bestätigungsstatus: Referenz „unbestaetigt“ ↔ Bestand „ - “ → nicht_strukturiert. App-Events speichern Bewerbungs-/Gagenstatus, aber keinen unabhängigen Terminbestätigungsstatus.

- F35 · unreleaseD Tour 2026 – Leipzig Wildcard · Leipzig · Quelle: Flyer.
  - Beleg: public/data/spp7-datasets.json#/datasets/events/27; Hinweisart: nur_ort; vollständige Fenster: false; passende Fenster 0/1; DATE_ID:  - .
  - Name:  - ; Ort: Bestands-Ortstext „Leipzig“ vollständig im Referenz-Ort/Location-Text enthalten.; gleiche PLZ: false.
  - Bestands-Datumszeilen: D38  - / -  (Tour; public/data/spp7-datasets.json#/datasets/event_dates/36).
  - Name: Referenz „Felsenkeller- Weihnachtsmarkt“ ↔ Bestand „unreleaseD Tour 2026 – Leipzig Wildcard“ → abweichender_text. Literalvergleich; keine automatische Korrektur oder Zuordnung.
  - Ort/Location: Referenz „Leipzig/Plagwitz“ ↔ Bestand „Leipzig“ → abweichender_text. Literalvergleich; keine automatische Korrektur oder Zuordnung.
  - PLZ: Referenz „04229“ ↔ Bestand „ - “ → fehlt. Literalvergleich; keine automatische Korrektur oder Zuordnung.
  - Zeitfenster: Referenz „2027-11-25/2027-12-30“ ↔ Bestand „ - “ → fehlt. Literalvergleich; keine automatische Korrektur oder Zuordnung.
  - Bestätigungsstatus: Referenz „unbestaetigt“ ↔ Bestand „ - “ → nicht_strukturiert. App-Events speichern Bewerbungs-/Gagenstatus, aber keinen unabhängigen Terminbestätigungsstatus.

- C14 · Taverne „Wankende Hydra“ – Torhaus Dölitz · Leipzig · Quelle: Chat.
  - Beleg: public/data/spp7-datasets.json#/datasets/events/41; Hinweisart: nur_ort; vollständige Fenster: false; passende Fenster 0/1; DATE_ID:  - .
  - Name:  - ; Ort: Bestands-Ortstext „Leipzig“ vollständig im Referenz-Ort/Location-Text enthalten.; gleiche PLZ: false.
  - Bestands-Datumszeilen:  - .
  - Name: Referenz „Felsenkeller- Weihnachtsmarkt“ ↔ Bestand „Taverne „Wankende Hydra“ – Torhaus Dölitz“ → abweichender_text. Literalvergleich; keine automatische Korrektur oder Zuordnung.
  - Ort/Location: Referenz „Leipzig/Plagwitz“ ↔ Bestand „Leipzig / Torhaus Dölitz“ → abweichender_text. Literalvergleich; keine automatische Korrektur oder Zuordnung.
  - PLZ: Referenz „04229“ ↔ Bestand „ - “ → fehlt. Literalvergleich; keine automatische Korrektur oder Zuordnung.
  - Zeitfenster: Referenz „2027-11-25/2027-12-30“ ↔ Bestand „ - “ → fehlt. Literalvergleich; keine automatische Korrektur oder Zuordnung.
  - Bestätigungsstatus: Referenz „unbestaetigt“ ↔ Bestand „ - “ → nicht_strukturiert. App-Events speichern Bewerbungs-/Gagenstatus, aber keinen unabhängigen Terminbestätigungsstatus.

- K36 · Peterskirche Leipzig – IN ECCLESIA · Leipzig · Quelle: Chat.
  - Beleg: public/data/spp7-datasets.json#/datasets/events/96; Hinweisart: nur_ort; vollständige Fenster: false; passende Fenster 0/1; DATE_ID:  - .
  - Name:  - ; Ort: Bestands-Ortstext „Leipzig“ vollständig im Referenz-Ort/Location-Text enthalten.; gleiche PLZ: false.
  - Bestands-Datumszeilen: D85 2026-12-30/ -  (Auftritt Corvus Corax; public/data/spp7-datasets.json#/datasets/event_dates/83).
  - Name: Referenz „Felsenkeller- Weihnachtsmarkt“ ↔ Bestand „Peterskirche Leipzig – IN ECCLESIA“ → abweichender_text. Literalvergleich; keine automatische Korrektur oder Zuordnung.
  - Ort/Location: Referenz „Leipzig/Plagwitz“ ↔ Bestand „Leipzig“ → abweichender_text. Literalvergleich; keine automatische Korrektur oder Zuordnung.
  - PLZ: Referenz „04229“ ↔ Bestand „ - “ → fehlt. Literalvergleich; keine automatische Korrektur oder Zuordnung.
  - Zeitfenster: Referenz „2027-11-25/2027-12-30“ ↔ Bestand „ - “ → fehlt. Literalvergleich; keine automatische Korrektur oder Zuordnung.
  - Bestätigungsstatus: Referenz „unbestaetigt“ ↔ Bestand „ - “ → nicht_strukturiert. App-Events speichern Bewerbungs-/Gagenstatus, aber keinen unabhängigen Terminbestätigungsstatus.

- S01 · Leipziger Umschlag · Leipzig · Quelle: Sündenfrei.
  - Beleg: public/data/spp7-datasets.json#/datasets/events/198; Hinweisart: nur_ort; vollständige Fenster: false; passende Fenster 0/1; DATE_ID:  - .
  - Name:  - ; Ort: Bestands-Ortstext „Leipzig“ vollständig im Referenz-Ort/Location-Text enthalten.; gleiche PLZ: false.
  - Bestands-Datumszeilen: D185 2026-03-07/2026-03-08 (Messe 2026; public/data/spp7-datasets.json#/datasets/event_dates/183); D186 2027-03-06/2027-03-07 (Messe 2027; public/data/spp7-datasets.json#/datasets/event_dates/184).
  - Name: Referenz „Felsenkeller- Weihnachtsmarkt“ ↔ Bestand „Leipziger Umschlag“ → abweichender_text. Literalvergleich; keine automatische Korrektur oder Zuordnung.
  - Ort/Location: Referenz „Leipzig/Plagwitz“ ↔ Bestand „Leipzig / agra Messepark Halle 1“ → abweichender_text. Literalvergleich; keine automatische Korrektur oder Zuordnung.
  - PLZ: Referenz „04229“ ↔ Bestand „04107“ → abweichender_text. Literalvergleich; keine automatische Korrektur oder Zuordnung.
  - Zeitfenster: Referenz „2027-11-25/2027-12-30“ ↔ Bestand „2026-03-07/2026-03-08;2027-03-06/2027-03-07“ → abweichender_text. Literalvergleich; keine automatische Korrektur oder Zuordnung.
  - Bestätigungsstatus: Referenz „unbestaetigt“ ↔ Bestand „ - “ → nicht_strukturiert. App-Events speichern Bewerbungs-/Gagenstatus, aber keinen unabhängigen Terminbestätigungsstatus.

### SF53 · Kloster- Weihnacht · 2027

Fundstelle: Termine_2027_suendenfrei.txt:L59. 26.11. - 23. Dezember 2027** · 09111 Chemnitz.
Zeitfenster: 2027-11-26/2027-12-23. Datumsherkunft: aus_quelle; Quellstatus: unbestaetigt.
Kein Hinweis nach den beschriebenen Regeln im App-Datensatz. Kein Nachweis, dass die Veranstaltung extern nicht existiert.

### SF54 · Rauhnächte · 2027

Fundstelle: Termine_2027_suendenfrei.txt:L60. 27. - 30. Dezember 2027 · 01067 Dresden / Stallhof.
Zeitfenster: 2027-12-27/2027-12-30. Datumsherkunft: aus_quelle; Quellstatus: nicht_markiert.
Alle Referenzzeitfenster und der Ortstext sind im selben Bestands-Event belegbar. Name, PLZ, Quelltyp und Verifikation separat prüfen; kein automatischer Merge.

- S02 · Rauhnächte Dresden · Dresden · Quelle: Sündenfrei.
  - Beleg: public/data/spp7-datasets.json#/datasets/events/199; Hinweisart: datum_ort; vollständige Fenster: true; passende Fenster 1/1; DATE_ID: D190.
  - Name: Namenswortfolge wörtlich im anderen Namen enthalten; kein Identitätsbeweis.; Ort: Bestands-Ortstext „Dresden“ vollständig im Referenz-Ort/Location-Text enthalten.; gleiche PLZ: true.
  - Bestands-Datumszeilen: D187 2026-01-02/2026-01-06 (Markt 2026; public/data/spp7-datasets.json#/datasets/event_dates/185); D188 2026-12-27/2026-12-30 (Markt 2026; public/data/spp7-datasets.json#/datasets/event_dates/186); D189 2027-01-02/2027-01-06 (Markt 2027; public/data/spp7-datasets.json#/datasets/event_dates/187); D190 2027-12-27/2027-12-30 (Markt 2027; public/data/spp7-datasets.json#/datasets/event_dates/188).
  - Name: Referenz „Rauhnächte“ ↔ Bestand „Rauhnächte Dresden“ → abweichender_text. Literalvergleich; keine automatische Korrektur oder Zuordnung.
  - Ort/Location: Referenz „Dresden/Stallhof“ ↔ Bestand „Dresden / Stallhof“ → gleich. Literalvergleich; keine automatische Korrektur oder Zuordnung.
  - PLZ: Referenz „01067“ ↔ Bestand „01067“ → gleich. Literalvergleich; keine automatische Korrektur oder Zuordnung.
  - Zeitfenster: Referenz „2027-12-27/2027-12-30“ ↔ Bestand „2026-01-02/2026-01-06;2026-12-27/2026-12-30;2027-01-02/2027-01-06;2027-12-27/2027-12-30“ → enthalten. Alle Referenzfenster im Bestand enthalten; Bestand hat zusätzliche oder mehrfach erfasste Zeitfenster. Keine Gleichheit der vollständigen Listen und keine Löschfreigabe.
  - Bestätigungsstatus: Referenz „nicht_markiert“ ↔ Bestand „ - “ → nicht_strukturiert. App-Events speichern Bewerbungs-/Gagenstatus, aber keinen unabhängigen Terminbestätigungsstatus.

## Entscheidungsliste — alles offen

### K-01 · Putbus: gleiche Institution, mehrere abweichende E-Mail-Kanäle

Bereich: kontakte; Hinweisart: konflikt; Entscheidung: offen.
Referenz: KV27; Bestand: K22, K23, K70.
**Beleg:** K22/K23 heißen Kurverwaltung Putbus; K70 und MD KV27 Kurverwaltung Putbus/Stadtinformation. Drei unterschiedliche E-Mail-Werte; nur K70 enthält die Referenz-Mail. Verschiedene Kanäle sind nicht automatisch doppelte Institutionen.
**Vorschlag, nicht ausgeführt:** Institution und ihre Kanäle getrennt entscheiden; Referenz-Mail neben Altkanälen erhalten, nichts ungefragt entfernen.
**Frage:** Soll später ein Institut mit getrennt belegten Alt-/Referenzkanälen geführt werden, statt drei Institutionen? Keine Entscheidung vorweggenommen.

### K-02 · Rügen-Verband und Tourismuszentrale: Zuordnung offen

Bereich: kontakte; Hinweisart: pruefen; Entscheidung: offen.
Referenz: KV01; Bestand: K01, K02, K33, K65.
**Beleg:** K01/K02 haben gleichen Organisationsnamen, aber verschiedene Kanäle. K33 trägt Tourismusverband Rügen (Kampagne); K65 hat den MD-Namen und die MD-Mail. Gemeinsame Domain oder Region reicht nicht zur Identität.
**Vorschlag, nicht ausgeführt:** K65 als Referenzkandidat getrennt belegen; K01/K02/K33 nicht pauschal zusammenführen.
**Frage:** Welche Organisationszuordnung soll für K01/K02/K33 gegenüber KV01 gelten?

### K-03 · Infopoint Sellin: zwei E-Mails auf zwei Bestandszeilen

Bereich: kontakte; Hinweisart: pruefen; Entscheidung: offen.
Referenz: KV07; Bestand: K07, K68.
**Beleg:** Die MD KV07 liefert zwei E-Mails in einem Adressblock; diese stehen im Bestand getrennt auf K07 und K68 (Zimmervermittlung). Beide Kanäle sind wortgleich mit der Referenz.
**Vorschlag, nicht ausgeführt:** Einrichtung und Kanalzweck getrennt führen; keine Adresse oder Mail verlieren.
**Frage:** Soll der eine Referenzblock später zwei getrennt benannte Kontaktkanäle erhalten?

### K-04 · Baabe: gemeinsamer Kanal ist kein Merge-Beweis

Bereich: kontakte; Hinweisart: pruefen; Entscheidung: offen.
Referenz: KV09, KV10; Bestand: K08.
**Beleg:** KV09 Kurverwaltung und KV10 Infopavillon sind verschiedene Referenzeinrichtungen. KV10 erhält dieselbe E-Mail ausdrücklich per Nutzerangabe. Die App hat K08 Kurverwaltung; daraus ist kein eigener Pavillon-Eintrag bewiesen.
**Vorschlag, nicht ausgeführt:** Zwei Einrichtungen behalten; gemeinsamen Kanal als explizite Angabe dokumentieren.
**Frage:** Soll der Infopavillon beim späteren Import als eigene Einrichtung mit diesem ausdrücklich freigegebenen Kanal ergänzt werden?

### K-05 · Lohme: gleiche E-Mail, anderer Organisationstyp

Bereich: kontakte; Hinweisart: konflikt; Entscheidung: offen.
Referenz: KV17; Bestand: K53.
**Beleg:** MD KV17 bezeichnet Touristik Lohme GmbH; K53 bezeichnet Gemeinde Lohme. info@lohme.de stimmt, der Name und der Typ nicht.
**Vorschlag, nicht ausgeführt:** Keine Gleichsetzung allein wegen E-Mail; organisatorische Zuständigkeit prüfen.
**Frage:** Gemeinde und Touristik getrennt lassen oder eine belegte Zuordnung liefern?

### K-06 · Neuenkirchen: Referenz-Firma trifft auf Personenkontakt

Bereich: kontakte; Hinweisart: konflikt; Entscheidung: offen.
Referenz: KV24; Bestand: K57.
**Beleg:** Die Referenz KV24 nennt Zimmervermittlung Rügen in Neuenkirchen/OT Grubnow. Der wortgleiche E-Mail-Kanal steht im Bestand K57 als Person ohne Ort. Persönliche Angaben werden im Bericht nicht neu veröffentlicht.
**Vorschlag, nicht ausgeführt:** Keine stille Umbenennung; Firmenkontakt und Personenzuordnung separat entscheiden.
**Frage:** Soll K57 separat erhalten bleiben und ein Unternehmenskontakt KV24 ergänzt werden?

### K-07 · Middelhagen: Platzhalter statt Kontaktkanal

Bereich: kontakte; Hinweisart: luecke; Entscheidung: offen.
Referenz: KV12, KV13; Bestand: K09, K10.
**Beleg:** K09 Tourist-Info Middelhagen hat EMAIL_TELEFON=(nicht genannt). Referenz KV12 liefert Telefon/Fax und Nutzerergänzung Web/E-Mail. Der ergänzte Kanal stimmt auch mit K10 Thiessow überein, das beweist keine Identität von Middelhagen und Thiessow.
**Vorschlag, nicht ausgeführt:** Middelhagen und Thiessow getrennt führen; Feldherkunft bewahren.
**Frage:** Soll KV12 den K09-Referenzhinweis erhalten, ohne K10/Thiessow zu verschmelzen?

### K-08 · Kontaktdatenmodell bildet die Referenz nicht vollständig ab

Bereich: kontakte; Hinweisart: luecke; Entscheidung: offen.
Referenz: KV01, KV02, KV03, KV04, KV05, KV06, KV07, KV08, KV09, KV10, KV11, KV12, KV13, KV14, KV15, KV16, KV17, KV18, KV19, KV20, KV21, KV22, KV23, KV24, KV25, KV26, KV27, KV28, KV29, KV30, KV31, KV32; Bestand:  - .
**Beleg:** App-Kontakte haben nur ORGANISATION/TYP/EMAIL_TELEFON/ORT/REGION/Koordinaten/MSG/NOTIZ. Straße, PLZ, Telefon, Fax, Web, Ortsteil und Parent sind keine getrennten Felder. Werte in NOTIZ bleiben Freitext.
**Vorschlag, nicht ausgeführt:** Vorsicht: spätere getrennte Kontakt-/Adress-/Strukturfelder verändern das Datenmodell (E4). Stufe 3 schreibt keine Datenbank.
**Frage:** E4 vor einem Import klären: Welches Schema soll die belegten Einzelwerte aufnehmen?

### K-09 · Bestandsnotizen nennen PDF statt der bereitgestellten MD

Bereich: kontakte; Hinweisart: pruefen; Entscheidung: offen.
Referenz:  - ; Bestand: K65, K66, K67, K68, K69, K70, K71, K72.
**Beleg:** NOTIZ enthält Kurverwaltungen_2025.pdf; geprüft wurde die vorliegende Kurverwaltungen_2025.md. Das beweist keinen falschen Wert, aber der genaue ursprüngliche PDF-Nachweis fehlt hier.
**Vorschlag, nicht ausgeführt:** Herkunft auf genaue Datei/Fundstelle beziehen, alte Herkunftsangabe erhalten.
**Frage:** Soll die MD als neuer belegter Nachweis neben der historischen PDF-Notiz geführt werden?

### T-SF01 · SF01: kein vollständiger Datum-/Ort-Nachweis

Bereich: termine; Hinweisart: luecke; Entscheidung: offen.
Referenz: SF01; Bestand: K15, M42, M44.
**Beleg:** 3. - 4. Oktober 2026 · Thüringer Ritterturnier · 99448 Kranichfeld. Nur Ortswortfolge gefunden, kein Name-/Termin-Nachweis. Nicht als vorhandener Referenztermin zählen.
**Vorschlag, nicht ausgeführt:** Originalzeile mit Herkunft, Fensterliste und Sternchenstatus erhalten; keine Jahresdaten, Orte oder Veranstaltungsnamen erfinden.
**Frage:** Referenztermin später als eigenen, quellgebundenen Datensatz vorbereiten; Kandidatenzuordnung erst nach Einzelentscheidung?

### T-SF02 · SF02: kein vollständiger Datum-/Ort-Nachweis

Bereich: termine; Hinweisart: luecke; Entscheidung: offen.
Referenz: SF02; Bestand:  - .
**Beleg:** 9. - 11. Oktober 2026 · 373. Zwiebelmarkt · 99423 Weimar. Kein Hinweis nach den beschriebenen Regeln im App-Datensatz. Kein Nachweis, dass die Veranstaltung extern nicht existiert.
**Vorschlag, nicht ausgeführt:** Originalzeile mit Herkunft, Fensterliste und Sternchenstatus erhalten; keine Jahresdaten, Orte oder Veranstaltungsnamen erfinden.
**Frage:** Referenztermin später als eigenen, quellgebundenen Datensatz vorbereiten; Kandidatenzuordnung erst nach Einzelentscheidung?

### T-SF04 · SF04: kein vollständiger Datum-/Ort-Nachweis

Bereich: termine; Hinweisart: luecke; Entscheidung: offen.
Referenz: SF04; Bestand:  - .
**Beleg:** 17. - 18. Oktober 2026 · 5. Mittelalter- Markttage · 44575 Castrop- Rauxel. Kein Hinweis nach den beschriebenen Regeln im App-Datensatz. Kein Nachweis, dass die Veranstaltung extern nicht existiert.
**Vorschlag, nicht ausgeführt:** Originalzeile mit Herkunft, Fensterliste und Sternchenstatus erhalten; keine Jahresdaten, Orte oder Veranstaltungsnamen erfinden.
**Frage:** Referenztermin später als eigenen, quellgebundenen Datensatz vorbereiten; Kandidatenzuordnung erst nach Einzelentscheidung?

### T-SF05 · SF05: kein vollständiger Datum-/Ort-Nachweis

Bereich: termine; Hinweisart: luecke; Entscheidung: offen.
Referenz: SF05; Bestand:  - .
**Beleg:** 1. - 4. Advent 2026 · Mittelalter- Advent (Do. - So.) · 44629 Herne/ Schloss Strünkede. Kein Hinweis nach den beschriebenen Regeln im App-Datensatz. Kein Nachweis, dass die Veranstaltung extern nicht existiert.
**Vorschlag, nicht ausgeführt:** Originalzeile mit Herkunft, Fensterliste und Sternchenstatus erhalten; keine Jahresdaten, Orte oder Veranstaltungsnamen erfinden.
**Frage:** Referenztermin später als eigenen, quellgebundenen Datensatz vorbereiten; Kandidatenzuordnung erst nach Einzelentscheidung?

### T-SF06 · SF06: kein vollständiger Datum-/Ort-Nachweis

Bereich: termine; Hinweisart: luecke; Entscheidung: offen.
Referenz: SF06; Bestand: S02.
**Beleg:** 25. 11. - 23. Dezember 2026* · Mittelalter- Weihnacht · 01067 Dresden / Stallhof. Nur Ortswortfolge gefunden, kein Name-/Termin-Nachweis. Nicht als vorhandener Referenztermin zählen.
**Vorschlag, nicht ausgeführt:** Originalzeile mit Herkunft, Fensterliste und Sternchenstatus erhalten; keine Jahresdaten, Orte oder Veranstaltungsnamen erfinden.
**Frage:** Referenztermin später als eigenen, quellgebundenen Datensatz vorbereiten; Kandidatenzuordnung erst nach Einzelentscheidung?

### T-SF07 · SF07: kein vollständiger Datum-/Ort-Nachweis

Bereich: termine; Hinweisart: luecke; Entscheidung: offen.
Referenz: SF07; Bestand: F01, F23, F26, F27, F35, C14, K36, S01.
**Beleg:** 26. 11. - 30. Dezember 2026* · Felsenkeller- Weihnachtsmarkt · 04229 Leipzig / Plagwitz. Nur Ortswortfolge gefunden, kein Name-/Termin-Nachweis. Nicht als vorhandener Referenztermin zählen.
**Vorschlag, nicht ausgeführt:** Originalzeile mit Herkunft, Fensterliste und Sternchenstatus erhalten; keine Jahresdaten, Orte oder Veranstaltungsnamen erfinden.
**Frage:** Referenztermin später als eigenen, quellgebundenen Datensatz vorbereiten; Kandidatenzuordnung erst nach Einzelentscheidung?

### T-SF08 · SF08: kein vollständiger Datum-/Ort-Nachweis

Bereich: termine; Hinweisart: luecke; Entscheidung: offen.
Referenz: SF08; Bestand:  - .
**Beleg:** 27. 11. - 23. Dezember 2026** · Kloster- Weihnacht · 09111 Chemnitz. Kein Hinweis nach den beschriebenen Regeln im App-Datensatz. Kein Nachweis, dass die Veranstaltung extern nicht existiert.
**Vorschlag, nicht ausgeführt:** Originalzeile mit Herkunft, Fensterliste und Sternchenstatus erhalten; keine Jahresdaten, Orte oder Veranstaltungsnamen erfinden.
**Frage:** Referenztermin später als eigenen, quellgebundenen Datensatz vorbereiten; Kandidatenzuordnung erst nach Einzelentscheidung?

### T-SF12 · SF12: kein vollständiger Datum-/Ort-Nachweis

Bereich: termine; Hinweisart: luecke; Entscheidung: offen.
Referenz: SF12; Bestand:  - .
**Beleg:** 13. - 14. März 2027 · Mittelalterfest Burgfrühling · 97877 Wertheim/ Burg. Kein Hinweis nach den beschriebenen Regeln im App-Datensatz. Kein Nachweis, dass die Veranstaltung extern nicht existiert.
**Vorschlag, nicht ausgeführt:** Originalzeile mit Herkunft, Fensterliste und Sternchenstatus erhalten; keine Jahresdaten, Orte oder Veranstaltungsnamen erfinden.
**Frage:** Referenztermin später als eigenen, quellgebundenen Datensatz vorbereiten; Kandidatenzuordnung erst nach Einzelentscheidung?

### T-SF13 · SF13: kein vollständiger Datum-/Ort-Nachweis

Bereich: termine; Hinweisart: luecke; Entscheidung: offen.
Referenz: SF13; Bestand:  - .
**Beleg:** 20. - 21. März 2027 · Ritterturnier und Mittelaltermarkt · 01683 Altzella / Nossen. Kein Hinweis nach den beschriebenen Regeln im App-Datensatz. Kein Nachweis, dass die Veranstaltung extern nicht existiert.
**Vorschlag, nicht ausgeführt:** Originalzeile mit Herkunft, Fensterliste und Sternchenstatus erhalten; keine Jahresdaten, Orte oder Veranstaltungsnamen erfinden.
**Frage:** Referenztermin später als eigenen, quellgebundenen Datensatz vorbereiten; Kandidatenzuordnung erst nach Einzelentscheidung?

### T-SF14 · SF14: kein vollständiger Datum-/Ort-Nachweis

Bereich: termine; Hinweisart: luecke; Entscheidung: offen.
Referenz: SF14; Bestand:  - .
**Beleg:** 27. - 29. März 2027 · Oster- Ritterturnier · 56346 Loreley/ St. Goarshausen. Kein Hinweis nach den beschriebenen Regeln im App-Datensatz. Kein Nachweis, dass die Veranstaltung extern nicht existiert.
**Vorschlag, nicht ausgeführt:** Originalzeile mit Herkunft, Fensterliste und Sternchenstatus erhalten; keine Jahresdaten, Orte oder Veranstaltungsnamen erfinden.
**Frage:** Referenztermin später als eigenen, quellgebundenen Datensatz vorbereiten; Kandidatenzuordnung erst nach Einzelentscheidung?

### T-SF16 · SF16: kein vollständiger Datum-/Ort-Nachweis

Bereich: termine; Hinweisart: luecke; Entscheidung: offen.
Referenz: SF16; Bestand:  - .
**Beleg:** 27. - 29. März 2027 · Oster- Ritterturnier · 44286 Dorsten/ Schloss Lembeck. Kein Hinweis nach den beschriebenen Regeln im App-Datensatz. Kein Nachweis, dass die Veranstaltung extern nicht existiert.
**Vorschlag, nicht ausgeführt:** Originalzeile mit Herkunft, Fensterliste und Sternchenstatus erhalten; keine Jahresdaten, Orte oder Veranstaltungsnamen erfinden.
**Frage:** Referenztermin später als eigenen, quellgebundenen Datensatz vorbereiten; Kandidatenzuordnung erst nach Einzelentscheidung?

### T-SF17 · SF17: kein vollständiger Datum-/Ort-Nachweis

Bereich: termine; Hinweisart: pruefen; Entscheidung: offen.
Referenz: SF17; Bestand:  - .
**Beleg:** 3.- 4. April 2027 · noch offen · xxxxx. Referenz selbst enthält xxxx/xxxxx (Ort unbekannt); keine Zuordnung erraten.
**Vorschlag, nicht ausgeführt:** Originalzeile mit Herkunft, Fensterliste und Sternchenstatus erhalten; keine Jahresdaten, Orte oder Veranstaltungsnamen erfinden.
**Frage:** Platzhalter offen lassen, bis eine echte Orts-/Namensquelle vorliegt?

### T-SF18 · SF18: kein vollständiger Datum-/Ort-Nachweis

Bereich: termine; Hinweisart: luecke; Entscheidung: offen.
Referenz: SF18; Bestand:  - .
**Beleg:** 10. - 11. April 2027 · Die Wikinger kommen! · 07929 Saalburg/ Bleilochtalsperre. Kein Hinweis nach den beschriebenen Regeln im App-Datensatz. Kein Nachweis, dass die Veranstaltung extern nicht existiert.
**Vorschlag, nicht ausgeführt:** Originalzeile mit Herkunft, Fensterliste und Sternchenstatus erhalten; keine Jahresdaten, Orte oder Veranstaltungsnamen erfinden.
**Frage:** Referenztermin später als eigenen, quellgebundenen Datensatz vorbereiten; Kandidatenzuordnung erst nach Einzelentscheidung?

### T-SF19 · SF19: kein vollständiger Datum-/Ort-Nachweis

Bereich: termine; Hinweisart: luecke; Entscheidung: offen.
Referenz: SF19; Bestand:  - .
**Beleg:** 10. - 11. April 2027 · Turnierspiele · 96178 Schloss Weissenstein/ Pommersfelden. Kein Hinweis nach den beschriebenen Regeln im App-Datensatz. Kein Nachweis, dass die Veranstaltung extern nicht existiert.
**Vorschlag, nicht ausgeführt:** Originalzeile mit Herkunft, Fensterliste und Sternchenstatus erhalten; keine Jahresdaten, Orte oder Veranstaltungsnamen erfinden.
**Frage:** Referenztermin später als eigenen, quellgebundenen Datensatz vorbereiten; Kandidatenzuordnung erst nach Einzelentscheidung?

### T-SF20 · SF20: kein vollständiger Datum-/Ort-Nachweis

Bereich: termine; Hinweisart: luecke; Entscheidung: offen.
Referenz: SF20; Bestand:  - .
**Beleg:** 17.- 18. April 2027 · Mittealterspektakel · 04519 Rackwitz, Schladitzer Bucht. Kein Hinweis nach den beschriebenen Regeln im App-Datensatz. Kein Nachweis, dass die Veranstaltung extern nicht existiert.
**Vorschlag, nicht ausgeführt:** Originalzeile mit Herkunft, Fensterliste und Sternchenstatus erhalten; keine Jahresdaten, Orte oder Veranstaltungsnamen erfinden.
**Frage:** Referenztermin später als eigenen, quellgebundenen Datensatz vorbereiten; Kandidatenzuordnung erst nach Einzelentscheidung?

### T-SF21 · SF21: kein vollständiger Datum-/Ort-Nachweis

Bereich: termine; Hinweisart: luecke; Entscheidung: offen.
Referenz: SF21; Bestand:  - .
**Beleg:** 17. - 18. April 2027 · Mittelalterspektakel · 41844 Wegberg/ Schloss Tüschenbroich. Kein Hinweis nach den beschriebenen Regeln im App-Datensatz. Kein Nachweis, dass die Veranstaltung extern nicht existiert.
**Vorschlag, nicht ausgeführt:** Originalzeile mit Herkunft, Fensterliste und Sternchenstatus erhalten; keine Jahresdaten, Orte oder Veranstaltungsnamen erfinden.
**Frage:** Referenztermin später als eigenen, quellgebundenen Datensatz vorbereiten; Kandidatenzuordnung erst nach Einzelentscheidung?

### T-SF22 · SF22: kein vollständiger Datum-/Ort-Nachweis

Bereich: termine; Hinweisart: luecke; Entscheidung: offen.
Referenz: SF22; Bestand:  - .
**Beleg:** 24. - 25. April 2027 · Mittelalterfest Löwenburg · 34131 Kassel. Kein Hinweis nach den beschriebenen Regeln im App-Datensatz. Kein Nachweis, dass die Veranstaltung extern nicht existiert.
**Vorschlag, nicht ausgeführt:** Originalzeile mit Herkunft, Fensterliste und Sternchenstatus erhalten; keine Jahresdaten, Orte oder Veranstaltungsnamen erfinden.
**Frage:** Referenztermin später als eigenen, quellgebundenen Datensatz vorbereiten; Kandidatenzuordnung erst nach Einzelentscheidung?

### T-SF23 · SF23: kein vollständiger Datum-/Ort-Nachweis

Bereich: termine; Hinweisart: luecke; Entscheidung: offen.
Referenz: SF23; Bestand:  - .
**Beleg:** 24. - 25. April 2027 · Mittelaltermarkt · 90513 Zirndorf b. Nürnberg. Kein Hinweis nach den beschriebenen Regeln im App-Datensatz. Kein Nachweis, dass die Veranstaltung extern nicht existiert.
**Vorschlag, nicht ausgeführt:** Originalzeile mit Herkunft, Fensterliste und Sternchenstatus erhalten; keine Jahresdaten, Orte oder Veranstaltungsnamen erfinden.
**Frage:** Referenztermin später als eigenen, quellgebundenen Datensatz vorbereiten; Kandidatenzuordnung erst nach Einzelentscheidung?

### T-SF25 · SF25: kein vollständiger Datum-/Ort-Nachweis

Bereich: termine; Hinweisart: luecke; Entscheidung: offen.
Referenz: SF25; Bestand:  - .
**Beleg:** 1. - 2. Mai 2027 · Ritterturnier Schloss Lauersfort · 47447 Moers. Kein Hinweis nach den beschriebenen Regeln im App-Datensatz. Kein Nachweis, dass die Veranstaltung extern nicht existiert.
**Vorschlag, nicht ausgeführt:** Originalzeile mit Herkunft, Fensterliste und Sternchenstatus erhalten; keine Jahresdaten, Orte oder Veranstaltungsnamen erfinden.
**Frage:** Referenztermin später als eigenen, quellgebundenen Datensatz vorbereiten; Kandidatenzuordnung erst nach Einzelentscheidung?

### T-SF26 · SF26: kein vollständiger Datum-/Ort-Nachweis

Bereich: termine; Hinweisart: luecke; Entscheidung: offen.
Referenz: SF26; Bestand:  - .
**Beleg:** 6. - 9. Mai 2027 · 23. Siegfriedspektakel · 46509 Xanten. Kein Hinweis nach den beschriebenen Regeln im App-Datensatz. Kein Nachweis, dass die Veranstaltung extern nicht existiert.
**Vorschlag, nicht ausgeführt:** Originalzeile mit Herkunft, Fensterliste und Sternchenstatus erhalten; keine Jahresdaten, Orte oder Veranstaltungsnamen erfinden.
**Frage:** Referenztermin später als eigenen, quellgebundenen Datensatz vorbereiten; Kandidatenzuordnung erst nach Einzelentscheidung?

### T-SF27 · SF27: kein vollständiger Datum-/Ort-Nachweis

Bereich: termine; Hinweisart: luecke; Entscheidung: offen.
Referenz: SF27; Bestand: M14.
**Beleg:** 6. - 9. Mai 2027 · Mittealter- Burgfest · 06543 Burg Falkenstein/ Harz. Ort und Namensbestandteile sind vorhanden, jedoch kein passender Referenzzeitraum. Ältere Jahresdaten niemals auf 2027 übertragen.
**Vorschlag, nicht ausgeführt:** Originalzeile mit Herkunft, Fensterliste und Sternchenstatus erhalten; keine Jahresdaten, Orte oder Veranstaltungsnamen erfinden.
**Frage:** Referenztermin später als eigenen, quellgebundenen Datensatz vorbereiten; Kandidatenzuordnung erst nach Einzelentscheidung?

### T-SF28 · SF28: kein vollständiger Datum-/Ort-Nachweis

Bereich: termine; Hinweisart: luecke; Entscheidung: offen.
Referenz: SF28; Bestand:  - .
**Beleg:** 15. - 17. Mai 2027 · Wikingerfest · 99885 Weißensee/Thür.. Kein Hinweis nach den beschriebenen Regeln im App-Datensatz. Kein Nachweis, dass die Veranstaltung extern nicht existiert.
**Vorschlag, nicht ausgeführt:** Originalzeile mit Herkunft, Fensterliste und Sternchenstatus erhalten; keine Jahresdaten, Orte oder Veranstaltungsnamen erfinden.
**Frage:** Referenztermin später als eigenen, quellgebundenen Datensatz vorbereiten; Kandidatenzuordnung erst nach Einzelentscheidung?

### T-SF29 · SF29: kein vollständiger Datum-/Ort-Nachweis

Bereich: termine; Hinweisart: luecke; Entscheidung: offen.
Referenz: SF29; Bestand:  - .
**Beleg:** 15. - 17. Mai 2027 · Ritterturnier & Mittelalterspektakel · 85399 Hallbergmoos. Kein Hinweis nach den beschriebenen Regeln im App-Datensatz. Kein Nachweis, dass die Veranstaltung extern nicht existiert.
**Vorschlag, nicht ausgeführt:** Originalzeile mit Herkunft, Fensterliste und Sternchenstatus erhalten; keine Jahresdaten, Orte oder Veranstaltungsnamen erfinden.
**Frage:** Referenztermin später als eigenen, quellgebundenen Datensatz vorbereiten; Kandidatenzuordnung erst nach Einzelentscheidung?

### T-SF30 · SF30: kein vollständiger Datum-/Ort-Nachweis

Bereich: termine; Hinweisart: luecke; Entscheidung: offen.
Referenz: SF30; Bestand:  - .
**Beleg:** 22. - 23. Mai 2027 · Mittelalterspektakel · 58455 Witten /Kemnader See. Kein Hinweis nach den beschriebenen Regeln im App-Datensatz. Kein Nachweis, dass die Veranstaltung extern nicht existiert.
**Vorschlag, nicht ausgeführt:** Originalzeile mit Herkunft, Fensterliste und Sternchenstatus erhalten; keine Jahresdaten, Orte oder Veranstaltungsnamen erfinden.
**Frage:** Referenztermin später als eigenen, quellgebundenen Datensatz vorbereiten; Kandidatenzuordnung erst nach Einzelentscheidung?

### T-SF31 · SF31: kein vollständiger Datum-/Ort-Nachweis

Bereich: termine; Hinweisart: luecke; Entscheidung: offen.
Referenz: SF31; Bestand: R01.
**Beleg:** 27.- 30. Mai 2027* · Gaudium Schloss Horst* · 45899 Gelsenkirchen*. Nur Ortswortfolge gefunden, kein Name-/Termin-Nachweis. Nicht als vorhandener Referenztermin zählen.
**Vorschlag, nicht ausgeführt:** Originalzeile mit Herkunft, Fensterliste und Sternchenstatus erhalten; keine Jahresdaten, Orte oder Veranstaltungsnamen erfinden.
**Frage:** Referenztermin später als eigenen, quellgebundenen Datensatz vorbereiten; Kandidatenzuordnung erst nach Einzelentscheidung?

### T-SF32 · SF32: kein vollständiger Datum-/Ort-Nachweis

Bereich: termine; Hinweisart: luecke; Entscheidung: offen.
Referenz: SF32; Bestand:  - .
**Beleg:** 29. - 30. Mai 2027 · Mittelalterspektakel · 02829 Königshain. Kein Hinweis nach den beschriebenen Regeln im App-Datensatz. Kein Nachweis, dass die Veranstaltung extern nicht existiert.
**Vorschlag, nicht ausgeführt:** Originalzeile mit Herkunft, Fensterliste und Sternchenstatus erhalten; keine Jahresdaten, Orte oder Veranstaltungsnamen erfinden.
**Frage:** Referenztermin später als eigenen, quellgebundenen Datensatz vorbereiten; Kandidatenzuordnung erst nach Einzelentscheidung?

### T-SF33 · SF33: kein vollständiger Datum-/Ort-Nachweis

Bereich: termine; Hinweisart: luecke; Entscheidung: offen.
Referenz: SF33; Bestand:  - .
**Beleg:** 5. - 6. Juni 2027 · Mittelalterspektakel · 34346 Hann. Münden. Kein Hinweis nach den beschriebenen Regeln im App-Datensatz. Kein Nachweis, dass die Veranstaltung extern nicht existiert.
**Vorschlag, nicht ausgeführt:** Originalzeile mit Herkunft, Fensterliste und Sternchenstatus erhalten; keine Jahresdaten, Orte oder Veranstaltungsnamen erfinden.
**Frage:** Referenztermin später als eigenen, quellgebundenen Datensatz vorbereiten; Kandidatenzuordnung erst nach Einzelentscheidung?

### T-SF34 · SF34: kein vollständiger Datum-/Ort-Nachweis

Bereich: termine; Hinweisart: luecke; Entscheidung: offen.
Referenz: SF34; Bestand:  - .
**Beleg:** 11. - 13. Juni 2027 · Annamarkt und Stadtfest · 52349 Düren. Kein Hinweis nach den beschriebenen Regeln im App-Datensatz. Kein Nachweis, dass die Veranstaltung extern nicht existiert.
**Vorschlag, nicht ausgeführt:** Originalzeile mit Herkunft, Fensterliste und Sternchenstatus erhalten; keine Jahresdaten, Orte oder Veranstaltungsnamen erfinden.
**Frage:** Referenztermin später als eigenen, quellgebundenen Datensatz vorbereiten; Kandidatenzuordnung erst nach Einzelentscheidung?

### T-SF37 · SF37: Datum und Ort passen, Name weicht ab

Bereich: termine; Hinweisart: konflikt; Entscheidung: offen.
Referenz: SF37; Bestand: S06.
**Beleg:** 14. - 15. August 2027 · Fantasy- und Mittelalterfest · 01833 Stolpen (Burg). Kandidat stimmt in Zeitraum und Ort, nicht in der Namenswortfolge.
**Vorschlag, nicht ausgeführt:** Als Zuordnungsfrage behandeln, nicht automatisch überschreiben.
**Frage:** Soll nach Quellenentscheidung der Referenzname mit dem abweichend benannten Bestands-Event verknüpft werden?

### T-SF38 · SF38: kein vollständiger Datum-/Ort-Nachweis

Bereich: termine; Hinweisart: pruefen; Entscheidung: offen.
Referenz: SF38; Bestand:  - .
**Beleg:** 28. - 29. August 2027 · Burgfest* · xxxx. Referenz selbst enthält xxxx/xxxxx (Ort unbekannt); keine Zuordnung erraten.
**Vorschlag, nicht ausgeführt:** Originalzeile mit Herkunft, Fensterliste und Sternchenstatus erhalten; keine Jahresdaten, Orte oder Veranstaltungsnamen erfinden.
**Frage:** Platzhalter offen lassen, bis eine echte Orts-/Namensquelle vorliegt?

### T-SF39 · SF39: kein vollständiger Datum-/Ort-Nachweis

Bereich: termine; Hinweisart: luecke; Entscheidung: offen.
Referenz: SF39; Bestand:  - .
**Beleg:** 3. - 5. September 2027 · 20. Mittelalterspektakel · 44629 Herne / Schloss Strünkede. Kein Hinweis nach den beschriebenen Regeln im App-Datensatz. Kein Nachweis, dass die Veranstaltung extern nicht existiert.
**Vorschlag, nicht ausgeführt:** Originalzeile mit Herkunft, Fensterliste und Sternchenstatus erhalten; keine Jahresdaten, Orte oder Veranstaltungsnamen erfinden.
**Frage:** Referenztermin später als eigenen, quellgebundenen Datensatz vorbereiten; Kandidatenzuordnung erst nach Einzelentscheidung?

### T-SF40 · SF40: kein vollständiger Datum-/Ort-Nachweis

Bereich: termine; Hinweisart: luecke; Entscheidung: offen.
Referenz: SF40; Bestand:  - .
**Beleg:** 11. - 12. September 2027 · Mittelalterfest* · 99707 Kyffhäuser*. Kein Hinweis nach den beschriebenen Regeln im App-Datensatz. Kein Nachweis, dass die Veranstaltung extern nicht existiert.
**Vorschlag, nicht ausgeführt:** Originalzeile mit Herkunft, Fensterliste und Sternchenstatus erhalten; keine Jahresdaten, Orte oder Veranstaltungsnamen erfinden.
**Frage:** Referenztermin später als eigenen, quellgebundenen Datensatz vorbereiten; Kandidatenzuordnung erst nach Einzelentscheidung?

### T-SF41 · SF41: kein vollständiger Datum-/Ort-Nachweis

Bereich: termine; Hinweisart: luecke; Entscheidung: offen.
Referenz: SF41; Bestand:  - .
**Beleg:** 18. - 19. September 2027 · Die Wikinger kommen! · 46509 Xanten. Kein Hinweis nach den beschriebenen Regeln im App-Datensatz. Kein Nachweis, dass die Veranstaltung extern nicht existiert.
**Vorschlag, nicht ausgeführt:** Originalzeile mit Herkunft, Fensterliste und Sternchenstatus erhalten; keine Jahresdaten, Orte oder Veranstaltungsnamen erfinden.
**Frage:** Referenztermin später als eigenen, quellgebundenen Datensatz vorbereiten; Kandidatenzuordnung erst nach Einzelentscheidung?

### T-SF42 · SF42: kein vollständiger Datum-/Ort-Nachweis

Bereich: termine; Hinweisart: luecke; Entscheidung: offen.
Referenz: SF42; Bestand:  - .
**Beleg:** 18. - 19. September 2027 · Ritterturnier und Mittelalterspektakel · 93186 Adlersberg/ Pettendorf. Kein Hinweis nach den beschriebenen Regeln im App-Datensatz. Kein Nachweis, dass die Veranstaltung extern nicht existiert.
**Vorschlag, nicht ausgeführt:** Originalzeile mit Herkunft, Fensterliste und Sternchenstatus erhalten; keine Jahresdaten, Orte oder Veranstaltungsnamen erfinden.
**Frage:** Referenztermin später als eigenen, quellgebundenen Datensatz vorbereiten; Kandidatenzuordnung erst nach Einzelentscheidung?

### T-SF43 · SF43: kein vollständiger Datum-/Ort-Nachweis

Bereich: termine; Hinweisart: luecke; Entscheidung: offen.
Referenz: SF43; Bestand:  - .
**Beleg:** 24. - 26. September 2027* · Zwiebelmarkt Apolda · 99510 Apolda. Kein Hinweis nach den beschriebenen Regeln im App-Datensatz. Kein Nachweis, dass die Veranstaltung extern nicht existiert.
**Vorschlag, nicht ausgeführt:** Originalzeile mit Herkunft, Fensterliste und Sternchenstatus erhalten; keine Jahresdaten, Orte oder Veranstaltungsnamen erfinden.
**Frage:** Referenztermin später als eigenen, quellgebundenen Datensatz vorbereiten; Kandidatenzuordnung erst nach Einzelentscheidung?

### T-SF44 · SF44: kein vollständiger Datum-/Ort-Nachweis

Bereich: termine; Hinweisart: luecke; Entscheidung: offen.
Referenz: SF44; Bestand:  - .
**Beleg:** 25. - 26. September 2027 · 56. Heidelberger Herbst · 69120 Heidelberg. Kein Hinweis nach den beschriebenen Regeln im App-Datensatz. Kein Nachweis, dass die Veranstaltung extern nicht existiert.
**Vorschlag, nicht ausgeführt:** Originalzeile mit Herkunft, Fensterliste und Sternchenstatus erhalten; keine Jahresdaten, Orte oder Veranstaltungsnamen erfinden.
**Frage:** Referenztermin später als eigenen, quellgebundenen Datensatz vorbereiten; Kandidatenzuordnung erst nach Einzelentscheidung?

### T-SF45 · SF45: kein vollständiger Datum-/Ort-Nachweis

Bereich: termine; Hinweisart: luecke; Entscheidung: offen.
Referenz: SF45; Bestand:  - .
**Beleg:** 2. - 3. Oktober 2027 · Mittelalter & Fantasytage mit Drachen · 56346 Loreley/ St. Goarshausen. Kein Hinweis nach den beschriebenen Regeln im App-Datensatz. Kein Nachweis, dass die Veranstaltung extern nicht existiert.
**Vorschlag, nicht ausgeführt:** Originalzeile mit Herkunft, Fensterliste und Sternchenstatus erhalten; keine Jahresdaten, Orte oder Veranstaltungsnamen erfinden.
**Frage:** Referenztermin später als eigenen, quellgebundenen Datensatz vorbereiten; Kandidatenzuordnung erst nach Einzelentscheidung?

### T-SF46 · SF46: kein vollständiger Datum-/Ort-Nachweis

Bereich: termine; Hinweisart: luecke; Entscheidung: offen.
Referenz: SF46; Bestand: K15, M42, M44.
**Beleg:** 2. - 3. Oktober 2027 · Thüringer Ritterturnier · 99448 Kranichfeld. Nur Ortswortfolge gefunden, kein Name-/Termin-Nachweis. Nicht als vorhandener Referenztermin zählen.
**Vorschlag, nicht ausgeführt:** Originalzeile mit Herkunft, Fensterliste und Sternchenstatus erhalten; keine Jahresdaten, Orte oder Veranstaltungsnamen erfinden.
**Frage:** Referenztermin später als eigenen, quellgebundenen Datensatz vorbereiten; Kandidatenzuordnung erst nach Einzelentscheidung?

### T-SF47 · SF47: kein vollständiger Datum-/Ort-Nachweis

Bereich: termine; Hinweisart: luecke; Entscheidung: offen.
Referenz: SF47; Bestand:  - .
**Beleg:** 8. - 10. Oktober 2027 · 374. Zwiebelmarkt · 99423 Weimar. Kein Hinweis nach den beschriebenen Regeln im App-Datensatz. Kein Nachweis, dass die Veranstaltung extern nicht existiert.
**Vorschlag, nicht ausgeführt:** Originalzeile mit Herkunft, Fensterliste und Sternchenstatus erhalten; keine Jahresdaten, Orte oder Veranstaltungsnamen erfinden.
**Frage:** Referenztermin später als eigenen, quellgebundenen Datensatz vorbereiten; Kandidatenzuordnung erst nach Einzelentscheidung?

### T-SF48 · SF48: kein vollständiger Datum-/Ort-Nachweis

Bereich: termine; Hinweisart: luecke; Entscheidung: offen.
Referenz: SF48; Bestand: M14.
**Beleg:** 9.- 10. Oktober 2027* · 30. Burgfest · 06543 Burg Falkenstein/ Harz. Ort und Namensbestandteile sind vorhanden, jedoch kein passender Referenzzeitraum. Ältere Jahresdaten niemals auf 2027 übertragen.
**Vorschlag, nicht ausgeführt:** Originalzeile mit Herkunft, Fensterliste und Sternchenstatus erhalten; keine Jahresdaten, Orte oder Veranstaltungsnamen erfinden.
**Frage:** Referenztermin später als eigenen, quellgebundenen Datensatz vorbereiten; Kandidatenzuordnung erst nach Einzelentscheidung?

### T-SF49 · SF49: kein vollständiger Datum-/Ort-Nachweis

Bereich: termine; Hinweisart: luecke; Entscheidung: offen.
Referenz: SF49; Bestand:  - .
**Beleg:** 16. - 17. Oktober 2027* · 6. Mittelalter- Markttage · 44575 Castrop- Rauxel. Kein Hinweis nach den beschriebenen Regeln im App-Datensatz. Kein Nachweis, dass die Veranstaltung extern nicht existiert.
**Vorschlag, nicht ausgeführt:** Originalzeile mit Herkunft, Fensterliste und Sternchenstatus erhalten; keine Jahresdaten, Orte oder Veranstaltungsnamen erfinden.
**Frage:** Referenztermin später als eigenen, quellgebundenen Datensatz vorbereiten; Kandidatenzuordnung erst nach Einzelentscheidung?

### T-SF50 · SF50: kein vollständiger Datum-/Ort-Nachweis

Bereich: termine; Hinweisart: luecke; Entscheidung: offen.
Referenz: SF50; Bestand:  - .
**Beleg:** 1. - 4. Advent 2027* · Mittelalter- Advent (Fr.- So.) · 44629 Herne/ Schloss Strünkede. Kein Hinweis nach den beschriebenen Regeln im App-Datensatz. Kein Nachweis, dass die Veranstaltung extern nicht existiert.
**Vorschlag, nicht ausgeführt:** Originalzeile mit Herkunft, Fensterliste und Sternchenstatus erhalten; keine Jahresdaten, Orte oder Veranstaltungsnamen erfinden.
**Frage:** Referenztermin später als eigenen, quellgebundenen Datensatz vorbereiten; Kandidatenzuordnung erst nach Einzelentscheidung?

### T-SF51 · SF51: kein vollständiger Datum-/Ort-Nachweis

Bereich: termine; Hinweisart: luecke; Entscheidung: offen.
Referenz: SF51; Bestand: S02.
**Beleg:** 24.11. - 23. Dezember 2027* · Mittelalter- Weihnacht · 01067 Dresden / Stallhof. Nur Ortswortfolge gefunden, kein Name-/Termin-Nachweis. Nicht als vorhandener Referenztermin zählen.
**Vorschlag, nicht ausgeführt:** Originalzeile mit Herkunft, Fensterliste und Sternchenstatus erhalten; keine Jahresdaten, Orte oder Veranstaltungsnamen erfinden.
**Frage:** Referenztermin später als eigenen, quellgebundenen Datensatz vorbereiten; Kandidatenzuordnung erst nach Einzelentscheidung?

### T-SF52 · SF52: kein vollständiger Datum-/Ort-Nachweis

Bereich: termine; Hinweisart: luecke; Entscheidung: offen.
Referenz: SF52; Bestand: F01, F23, F26, F27, F35, C14, K36, S01.
**Beleg:** 25.11. - 30. Dezember 2027* · Felsenkeller- Weihnachtsmarkt · 04229 Leipzig / Plagwitz. Nur Ortswortfolge gefunden, kein Name-/Termin-Nachweis. Nicht als vorhandener Referenztermin zählen.
**Vorschlag, nicht ausgeführt:** Originalzeile mit Herkunft, Fensterliste und Sternchenstatus erhalten; keine Jahresdaten, Orte oder Veranstaltungsnamen erfinden.
**Frage:** Referenztermin später als eigenen, quellgebundenen Datensatz vorbereiten; Kandidatenzuordnung erst nach Einzelentscheidung?

### T-SF53 · SF53: kein vollständiger Datum-/Ort-Nachweis

Bereich: termine; Hinweisart: luecke; Entscheidung: offen.
Referenz: SF53; Bestand:  - .
**Beleg:** 26.11. - 23. Dezember 2027** · Kloster- Weihnacht · 09111 Chemnitz. Kein Hinweis nach den beschriebenen Regeln im App-Datensatz. Kein Nachweis, dass die Veranstaltung extern nicht existiert.
**Vorschlag, nicht ausgeführt:** Originalzeile mit Herkunft, Fensterliste und Sternchenstatus erhalten; keine Jahresdaten, Orte oder Veranstaltungsnamen erfinden.
**Frage:** Referenztermin später als eigenen, quellgebundenen Datensatz vorbereiten; Kandidatenzuordnung erst nach Einzelentscheidung?

### T-KI · Wortgleiche Zeitdaten auf KI-Listenbasis

Bereich: termine; Hinweisart: pruefen; Entscheidung: offen.
Referenz: SF03, SF15, SF24; Bestand: M14, M44, M21.
**Beleg:** Auch passende Zeit-/Ortswerte ändern QUELLE_TYP=Chat (KI-Liste) nicht. Herkunft und Referenzverifikation müssen unabhängig gespeichert werden.
**Vorschlag, nicht ausgeführt:** Referenznachweis gesondert hinzufügen, niemals den gesamten KI-Datensatz als verifiziert markieren.
**Frage:** Soll ein separater Referenzbeleg an die später bestätigte Zuordnung angehängt werden?

### B-REL-feed_context-EVENT_ID · Verwaister Datensatzverweis

Bereich: bestand; Hinweisart: konflikt; Entscheidung: offen.
Referenz:  - ; Bestand: 20:F29.
**Beleg:** public/data/spp7-datasets.json#/datasets/feed_context/20.EVENT_ID=F29 (Ziel-ID fehlt)
**Vorschlag, nicht ausgeführt:** Einzeln belegen; kein automatisches Löschen oder Ersetzen.
**Frage:** Diesen Befund in Stufe 4 separat entscheiden?

### B-DATE-D113-D198 · Mehrere Datumszeilen für dasselbe Event/Intervall

Bereich: bestand; Hinweisart: pruefen; Entscheidung: offen.
Referenz:  - ; Bestand: D113, D198.
**Beleg:** M21|2026-05-01|2026-05-03; D113: Festivaltermin (KI-Liste); D198: Sündenfrei 2026. Unterschiedliche Arten können unterschiedliche Bedeutungen haben, nicht automatisch löschen.
**Vorschlag, nicht ausgeführt:** Einzeln belegen; kein automatisches Löschen oder Ersetzen.
**Frage:** Diesen Befund in Stufe 4 separat entscheiden?

### B-KANAL-K09 · Kontaktkanal ist kein echter Wert

Bereich: bestand; Hinweisart: pruefen; Entscheidung: offen.
Referenz:  - ; Bestand: K09.
**Beleg:** K09: EMAIL_TELEFON=(nicht genannt); kein auslesbarer E-Mail-/Telefonwert.
**Vorschlag, nicht ausgeführt:** Einzeln belegen; kein automatisches Löschen oder Ersetzen.
**Frage:** Diesen Befund in Stufe 4 separat entscheiden?

### B-CONTACT-NAME-K01-K02 · Gleicher Kontaktname und Ort, getrennte Bestandszeilen

Bereich: bestand; Hinweisart: pruefen; Entscheidung: offen.
Referenz:  - ; Bestand: K01, K02.
**Beleg:** K01: Tourismuszentrale Rügen (ruegen.de); K02: Tourismuszentrale Rügen (ruegen.de). Namenswortfolge und Ortswortfolge gleich; verschiedene Kanäle können eigene Zwecke haben. Keine automatische Zusammenführung.
**Vorschlag, nicht ausgeführt:** Einzeln belegen; kein automatisches Löschen oder Ersetzen.
**Frage:** Diesen Befund in Stufe 4 separat entscheiden?

### B-CONTACT-NAME-K22-K23 · Gleicher Kontaktname und Ort, getrennte Bestandszeilen

Bereich: bestand; Hinweisart: pruefen; Entscheidung: offen.
Referenz:  - ; Bestand: K22, K23.
**Beleg:** K22: Kurverwaltung Putbus; K23: Kurverwaltung Putbus. Namenswortfolge und Ortswortfolge gleich; verschiedene Kanäle können eigene Zwecke haben. Keine automatische Zusammenführung.
**Vorschlag, nicht ausgeführt:** Einzeln belegen; kein automatisches Löschen oder Ersetzen.
**Frage:** Diesen Befund in Stufe 4 separat entscheiden?

### B-CONTACT-CHANNEL-K64-K73 · Gemeinsamer Bestandskanal ohne Identitätsentscheidung

Bereich: bestand; Hinweisart: pruefen; Entscheidung: offen.
Referenz:  - ; Bestand: K64, K73.
**Beleg:** K64 / K73: auslesbarer Kanal identisch. Einrichtung und Person können denselben Kanal nutzen; keine Identitätsentscheidung, persönliche Kanalwerte nicht veröffentlicht.
**Vorschlag, nicht ausgeführt:** Einzeln belegen; kein automatisches Löschen oder Ersetzen.
**Frage:** Diesen Befund in Stufe 4 separat entscheiden?

### B-EVENTNAMEN · Gleichnamige Events an verschiedenen Orten sind keine bewiesenen Dubletten

Bereich: bestand; Hinweisart: pruefen; Entscheidung: offen.
Referenz:  - ; Bestand: M04, M06, M24, M27, M47, M11, M13, M14, M19, M22, M16, M29, M41, M28, M33, M42, M43.
**Beleg:** M04: Mittelaltermarkt — Weißenfels; M06: Mittelaltermarkt — Hohenmölsen; M24: Mittelaltermarkt — Breitungen; M27: Mittelaltermarkt — Vacha; M47: Mittelaltermarkt — Osnabrück | M11: Ritterfest — Jerichow; M13: Ritterfest — Thale | M14: Burgfest — Falkenstein; M19: Burgfest — Creuzburg; M22: Burgfest — Orlamünde | M16: Fantasy- & Mittelaltermarkt — Heldburg; M29: Fantasy- & Mittelaltermarkt — Veilsdorf; M41: Fantasy- & Mittelaltermarkt — Vacha | M28: Mittelalterfest — Ebeleben; M33: Mittelalterfest — Völpke | M42: Phantastisches Zauberdorf — Kranichfeld; M43: Phantastisches Zauberdorf — Römhild
**Vorschlag, nicht ausgeführt:** Niemals nach dem Namen allein zusammenführen. Nur mit Datum, Ort und Quellenbeleg entscheiden.
**Frage:** Diese Namensgruppen als getrennte Veranstaltungen behalten, soweit keine individuelle Identität belegt wird?

### B-GEO · Koordinaten vorhanden heißt nicht inhaltlich geprüft

Bereich: bestand; Hinweisart: pruefen; Entscheidung: offen.
Referenz:  - ; Bestand:  - .
**Beleg:** 180 Event-Einträge und 68 Kontakte besitzen LAT/LNG. GEO_STATUS enthält unter anderem offene/zu verifizierende Angaben. Keine Geocodierung wurde in Stufe 3 verifiziert.
**Vorschlag, nicht ausgeführt:** Geo-Quelle und Prüfstatus getrennt behalten.
**Frage:** Vor einem späteren Mapping-Import eine gesonderte Geo-Prüfliste vorsehen?

### B-MEDIEN · Bildverweise ohne Bilddateien in der App-ZIP

Bereich: bestand; Hinweisart: luecke; Entscheidung: offen.
Referenz:  - ; Bestand:  - .
**Beleg:** Die App-ZIP enthält flyer_sources mit 79 Einträgen, aber keinen public/flyers/-Ordner. Der separate Chat-Export wurde in diesem Abgleich nicht erneut geöffnet.
**Vorschlag, nicht ausgeführt:** Bildreparatur separat in Stufe 6; keine weitere Fotobewertung oder Rekonstruktion hier.
**Frage:** Später nur die belegten toten Bildverweise reparieren?

### B-SYNC · JSON-Synchronisation kann Datenbankkorrekturen überschreiben

Bereich: bestand; Hinweisart: konflikt; Entscheidung: offen.
Referenz:  - ; Bestand:  - .
**Beleg:** src/lib/spp7-repository.ts in der ursprünglichen App nutzt onConflictDoUpdate aus Archiv-JSON. Das Dashboard lädt JSON direkt; drei Datenbanktabellen dienen anderen Abfragen. Keine Reparatur ausgeführt.
**Vorschlag, nicht ausgeführt:** Vorsicht: Kuratierte Daten nicht ungeprüft in die synchronisierten Bestands-Tabellen schreiben. E3/E4/E5 separat klären.
**Frage:** Eigene kuratierte Ebene vor Stufe 5 verbindlich festlegen?

## Bestand außerhalb der Referenzzuordnung

Kein Löschvorschlag. Die Referenzen decken nur bestimmte Einrichtungen und Sündenfrei-Termine ab.

| Kontakt-ID | Bestandsbezeichnung | Typ | Fundstelle |
|---|---|---|---|
| K01 | Bestandskontakt außerhalb der Referenz · Name ausgeblendet | Tourismus | public/data/spp7-datasets.json#/datasets/contacts/0 |
| K02 | Bestandskontakt außerhalb der Referenz · Name ausgeblendet | Tourismus | public/data/spp7-datasets.json#/datasets/contacts/1 |
| K24 | Bestandskontakt außerhalb der Referenz · Name ausgeblendet | Stadt | public/data/spp7-datasets.json#/datasets/contacts/23 |
| K25 | Bestandskontakt außerhalb der Referenz · Name ausgeblendet | Stadt | public/data/spp7-datasets.json#/datasets/contacts/24 |
| K26 | Personenkontakt · Name ausgeblendet | Person | public/data/spp7-datasets.json#/datasets/contacts/25 |
| K27 | Personenkontakt · Name ausgeblendet | Person | public/data/spp7-datasets.json#/datasets/contacts/26 |
| K28 | Personenkontakt · Name ausgeblendet | Person | public/data/spp7-datasets.json#/datasets/contacts/27 |
| K30 | Bestandskontakt außerhalb der Referenz · Name ausgeblendet | Stadt | public/data/spp7-datasets.json#/datasets/contacts/29 |
| K34 | Bestandskontakt außerhalb der Referenz · Name ausgeblendet | Tourismus | public/data/spp7-datasets.json#/datasets/contacts/33 |
| K35 | Personenkontakt · Name ausgeblendet | Person | public/data/spp7-datasets.json#/datasets/contacts/34 |
| K36 | Personenkontakt · Name ausgeblendet | Person | public/data/spp7-datasets.json#/datasets/contacts/35 |
| K37 | Personenkontakt · Name ausgeblendet | Person | public/data/spp7-datasets.json#/datasets/contacts/36 |
| K38 | Personenkontakt · Name ausgeblendet | Person | public/data/spp7-datasets.json#/datasets/contacts/37 |
| K39 | Personenkontakt · Name ausgeblendet | Person | public/data/spp7-datasets.json#/datasets/contacts/38 |
| K40 | Bestandskontakt außerhalb der Referenz · Name ausgeblendet | Amt | public/data/spp7-datasets.json#/datasets/contacts/39 |
| K41 | Bestandskontakt außerhalb der Referenz · Name ausgeblendet | Amt | public/data/spp7-datasets.json#/datasets/contacts/40 |
| K42 | Personenkontakt · Name ausgeblendet | Person | public/data/spp7-datasets.json#/datasets/contacts/41 |
| K43 | Personenkontakt · Name ausgeblendet | Person | public/data/spp7-datasets.json#/datasets/contacts/42 |
| K44 | Personenkontakt · Name ausgeblendet | Person | public/data/spp7-datasets.json#/datasets/contacts/43 |
| K45 | Personenkontakt · Name ausgeblendet | Person | public/data/spp7-datasets.json#/datasets/contacts/44 |
| K46 | Bestandskontakt außerhalb der Referenz · Name ausgeblendet | Gemeinde | public/data/spp7-datasets.json#/datasets/contacts/45 |
| K48 | Bestandskontakt außerhalb der Referenz · Name ausgeblendet | Stadt | public/data/spp7-datasets.json#/datasets/contacts/47 |
| K49 | Bestandskontakt außerhalb der Referenz · Name ausgeblendet | Stadt | public/data/spp7-datasets.json#/datasets/contacts/48 |
| K50 | Bestandskontakt außerhalb der Referenz · Name ausgeblendet | Gemeinde | public/data/spp7-datasets.json#/datasets/contacts/49 |
| K51 | Bestandskontakt außerhalb der Referenz · Name ausgeblendet | Gemeinde | public/data/spp7-datasets.json#/datasets/contacts/50 |
| K52 | Bestandskontakt außerhalb der Referenz · Name ausgeblendet | Gemeinde | public/data/spp7-datasets.json#/datasets/contacts/51 |
| K54 | Bestandskontakt außerhalb der Referenz · Name ausgeblendet | Location | public/data/spp7-datasets.json#/datasets/contacts/53 |
| K55 | Bestandskontakt außerhalb der Referenz · Name ausgeblendet | Location/Verein | public/data/spp7-datasets.json#/datasets/contacts/54 |
| K56 | Bestandskontakt außerhalb der Referenz · Name ausgeblendet | Hotel/Resort | public/data/spp7-datasets.json#/datasets/contacts/55 |
| K58 | Bestandskontakt außerhalb der Referenz · Name ausgeblendet | Firma (Transport) | public/data/spp7-datasets.json#/datasets/contacts/57 |
| K59 | Bestandskontakt außerhalb der Referenz · Name ausgeblendet | Agentur | public/data/spp7-datasets.json#/datasets/contacts/58 |
| K60 | Bestandskontakt außerhalb der Referenz · Name ausgeblendet | Veranstalter | public/data/spp7-datasets.json#/datasets/contacts/59 |
| K61 | Bestandskontakt außerhalb der Referenz · Name ausgeblendet | Location | public/data/spp7-datasets.json#/datasets/contacts/60 |
| K62 | Bestandskontakt außerhalb der Referenz · Name ausgeblendet | Verein | public/data/spp7-datasets.json#/datasets/contacts/61 |
| K63 | Bestandskontakt außerhalb der Referenz · Name ausgeblendet | Firma | public/data/spp7-datasets.json#/datasets/contacts/62 |
| K64 | Bestandskontakt außerhalb der Referenz · Name ausgeblendet | Festival | public/data/spp7-datasets.json#/datasets/contacts/63 |
| K73 | Personenkontakt · Name ausgeblendet | Person | public/data/spp7-datasets.json#/datasets/contacts/72 |
| K74 | Personenkontakt · Name ausgeblendet | Person | public/data/spp7-datasets.json#/datasets/contacts/73 |

| Event-ID | Bestandsname | Quelltyp | Fundstelle |
|---|---|---|---|
| F02 | Bestands-Event außerhalb der Referenz · Bezeichnung ausgeblendet | Flyer | public/data/spp7-datasets.json#/datasets/events/1 |
| F03 | Bestands-Event außerhalb der Referenz · Bezeichnung ausgeblendet | Flyer | public/data/spp7-datasets.json#/datasets/events/2 |
| F04 | Bestands-Event außerhalb der Referenz · Bezeichnung ausgeblendet | Flyer | public/data/spp7-datasets.json#/datasets/events/3 |
| F05 | Bestands-Event außerhalb der Referenz · Bezeichnung ausgeblendet | Flyer | public/data/spp7-datasets.json#/datasets/events/4 |
| F06 | Bestands-Event außerhalb der Referenz · Bezeichnung ausgeblendet | Flyer | public/data/spp7-datasets.json#/datasets/events/5 |
| F07 | Bestands-Event außerhalb der Referenz · Bezeichnung ausgeblendet | Flyer | public/data/spp7-datasets.json#/datasets/events/6 |
| F09 | Bestands-Event außerhalb der Referenz · Bezeichnung ausgeblendet | Flyer | public/data/spp7-datasets.json#/datasets/events/7 |
| F10 | Bestands-Event außerhalb der Referenz · Bezeichnung ausgeblendet | Flyer | public/data/spp7-datasets.json#/datasets/events/8 |
| F11 | Bestands-Event außerhalb der Referenz · Bezeichnung ausgeblendet | Flyer | public/data/spp7-datasets.json#/datasets/events/9 |
| F12 | Bestands-Event außerhalb der Referenz · Bezeichnung ausgeblendet | Flyer | public/data/spp7-datasets.json#/datasets/events/10 |
| F13 | Bestands-Event außerhalb der Referenz · Bezeichnung ausgeblendet | Flyer | public/data/spp7-datasets.json#/datasets/events/11 |
| F14 | Bestands-Event außerhalb der Referenz · Bezeichnung ausgeblendet | Flyer | public/data/spp7-datasets.json#/datasets/events/12 |
| F15 | Bestands-Event außerhalb der Referenz · Bezeichnung ausgeblendet | Flyer | public/data/spp7-datasets.json#/datasets/events/13 |
| F16 | Bestands-Event außerhalb der Referenz · Bezeichnung ausgeblendet | Flyer | public/data/spp7-datasets.json#/datasets/events/14 |
| F17 | Bestands-Event außerhalb der Referenz · Bezeichnung ausgeblendet | Flyer | public/data/spp7-datasets.json#/datasets/events/15 |
| F18 | Bestands-Event außerhalb der Referenz · Bezeichnung ausgeblendet | Flyer | public/data/spp7-datasets.json#/datasets/events/16 |
| F22 | Bestands-Event außerhalb der Referenz · Bezeichnung ausgeblendet | Flyer | public/data/spp7-datasets.json#/datasets/events/17 |
| F24 | Bestands-Event außerhalb der Referenz · Bezeichnung ausgeblendet | Flyer | public/data/spp7-datasets.json#/datasets/events/19 |
| F25 | Bestands-Event außerhalb der Referenz · Bezeichnung ausgeblendet | Flyer | public/data/spp7-datasets.json#/datasets/events/20 |
| F28 | Bestands-Event außerhalb der Referenz · Bezeichnung ausgeblendet | Flyer | public/data/spp7-datasets.json#/datasets/events/23 |
| F30 | Bestands-Event außerhalb der Referenz · Bezeichnung ausgeblendet | Flyer | public/data/spp7-datasets.json#/datasets/events/24 |
| F33 | Bestands-Event außerhalb der Referenz · Bezeichnung ausgeblendet | Flyer | public/data/spp7-datasets.json#/datasets/events/25 |
| F34 | Bestands-Event außerhalb der Referenz · Bezeichnung ausgeblendet | Flyer | public/data/spp7-datasets.json#/datasets/events/26 |
| F73 | Bestands-Event außerhalb der Referenz · Bezeichnung ausgeblendet | Flyer | public/data/spp7-datasets.json#/datasets/events/28 |
| C01 | Bestands-Event außerhalb der Referenz · Bezeichnung ausgeblendet | Chat | public/data/spp7-datasets.json#/datasets/events/29 |
| C02 | Bestands-Event außerhalb der Referenz · Bezeichnung ausgeblendet | Chat | public/data/spp7-datasets.json#/datasets/events/30 |
| C03 | Bestands-Event außerhalb der Referenz · Bezeichnung ausgeblendet | Chat | public/data/spp7-datasets.json#/datasets/events/31 |
| C04 | Bestands-Event außerhalb der Referenz · Bezeichnung ausgeblendet | Chat | public/data/spp7-datasets.json#/datasets/events/32 |
| C05 | Bestands-Event außerhalb der Referenz · Bezeichnung ausgeblendet | Chat | public/data/spp7-datasets.json#/datasets/events/33 |
| C06 | Bestands-Event außerhalb der Referenz · Bezeichnung ausgeblendet | Chat | public/data/spp7-datasets.json#/datasets/events/34 |
| C07 | Bestands-Event außerhalb der Referenz · Bezeichnung ausgeblendet | Chat | public/data/spp7-datasets.json#/datasets/events/35 |
| C08 | Bestands-Event außerhalb der Referenz · Bezeichnung ausgeblendet | Chat | public/data/spp7-datasets.json#/datasets/events/36 |
| C09 | Bestands-Event außerhalb der Referenz · Bezeichnung ausgeblendet | Chat | public/data/spp7-datasets.json#/datasets/events/37 |
| C10 | Bestands-Event außerhalb der Referenz · Bezeichnung ausgeblendet | Chat | public/data/spp7-datasets.json#/datasets/events/38 |
| C11 | Bestands-Event außerhalb der Referenz · Bezeichnung ausgeblendet | Chat | public/data/spp7-datasets.json#/datasets/events/39 |
| C12 | Bestands-Event außerhalb der Referenz · Bezeichnung ausgeblendet | Chat | public/data/spp7-datasets.json#/datasets/events/40 |
| C16 | Bestands-Event außerhalb der Referenz · Bezeichnung ausgeblendet | Chat | public/data/spp7-datasets.json#/datasets/events/42 |
| C17 | Bestands-Event außerhalb der Referenz · Bezeichnung ausgeblendet | Chat | public/data/spp7-datasets.json#/datasets/events/43 |
| C18 | Bestands-Event außerhalb der Referenz · Bezeichnung ausgeblendet | Chat | public/data/spp7-datasets.json#/datasets/events/44 |
| C19 | Bestands-Event außerhalb der Referenz · Bezeichnung ausgeblendet | Chat | public/data/spp7-datasets.json#/datasets/events/45 |
| C20 | Bestands-Event außerhalb der Referenz · Bezeichnung ausgeblendet | Chat | public/data/spp7-datasets.json#/datasets/events/46 |
| C22 | Bestands-Event außerhalb der Referenz · Bezeichnung ausgeblendet | Chat | public/data/spp7-datasets.json#/datasets/events/47 |
| C23 | Bestands-Event außerhalb der Referenz · Bezeichnung ausgeblendet | Chat | public/data/spp7-datasets.json#/datasets/events/48 |
| C24 | Bestands-Event außerhalb der Referenz · Bezeichnung ausgeblendet | Chat | public/data/spp7-datasets.json#/datasets/events/49 |
| C25 | Bestands-Event außerhalb der Referenz · Bezeichnung ausgeblendet | Chat | public/data/spp7-datasets.json#/datasets/events/50 |
| C26 | Bestands-Event außerhalb der Referenz · Bezeichnung ausgeblendet | Chat | public/data/spp7-datasets.json#/datasets/events/51 |
| C27 | Bestands-Event außerhalb der Referenz · Bezeichnung ausgeblendet | Chat | public/data/spp7-datasets.json#/datasets/events/52 |
| C28 | Bestands-Event außerhalb der Referenz · Bezeichnung ausgeblendet | Chat | public/data/spp7-datasets.json#/datasets/events/53 |
| C29 | Bestands-Event außerhalb der Referenz · Bezeichnung ausgeblendet | Chat | public/data/spp7-datasets.json#/datasets/events/54 |
| C30 | Bestands-Event außerhalb der Referenz · Bezeichnung ausgeblendet | Chat | public/data/spp7-datasets.json#/datasets/events/55 |
| C31 | Bestands-Event außerhalb der Referenz · Bezeichnung ausgeblendet | Chat | public/data/spp7-datasets.json#/datasets/events/56 |
| T01 | Bestands-Event außerhalb der Referenz · Bezeichnung ausgeblendet | Chat | public/data/spp7-datasets.json#/datasets/events/57 |
| T02 | Bestands-Event außerhalb der Referenz · Bezeichnung ausgeblendet | Chat | public/data/spp7-datasets.json#/datasets/events/58 |
| T03 | Bestands-Event außerhalb der Referenz · Bezeichnung ausgeblendet | Chat | public/data/spp7-datasets.json#/datasets/events/59 |
| T04 | Bestands-Event außerhalb der Referenz · Bezeichnung ausgeblendet | Chat | public/data/spp7-datasets.json#/datasets/events/60 |
| T05 | Bestands-Event außerhalb der Referenz · Bezeichnung ausgeblendet | Chat | public/data/spp7-datasets.json#/datasets/events/61 |
| T06 | Bestands-Event außerhalb der Referenz · Bezeichnung ausgeblendet | Chat | public/data/spp7-datasets.json#/datasets/events/62 |
| T08 | Bestands-Event außerhalb der Referenz · Bezeichnung ausgeblendet | Chat | public/data/spp7-datasets.json#/datasets/events/63 |
| K01 | Bestands-Event außerhalb der Referenz · Bezeichnung ausgeblendet | Chat | public/data/spp7-datasets.json#/datasets/events/64 |
| K02 | Bestands-Event außerhalb der Referenz · Bezeichnung ausgeblendet | Chat | public/data/spp7-datasets.json#/datasets/events/65 |
| K03 | Bestands-Event außerhalb der Referenz · Bezeichnung ausgeblendet | Chat | public/data/spp7-datasets.json#/datasets/events/66 |
| K04 | Bestands-Event außerhalb der Referenz · Bezeichnung ausgeblendet | Chat | public/data/spp7-datasets.json#/datasets/events/67 |
| K05 | Bestands-Event außerhalb der Referenz · Bezeichnung ausgeblendet | Chat | public/data/spp7-datasets.json#/datasets/events/68 |
| K06 | Bestands-Event außerhalb der Referenz · Bezeichnung ausgeblendet | Chat | public/data/spp7-datasets.json#/datasets/events/69 |
| K07 | Bestands-Event außerhalb der Referenz · Bezeichnung ausgeblendet | Chat | public/data/spp7-datasets.json#/datasets/events/70 |
| K08 | Bestands-Event außerhalb der Referenz · Bezeichnung ausgeblendet | Chat | public/data/spp7-datasets.json#/datasets/events/71 |
| K09 | Bestands-Event außerhalb der Referenz · Bezeichnung ausgeblendet | Chat | public/data/spp7-datasets.json#/datasets/events/72 |
| K10 | Bestands-Event außerhalb der Referenz · Bezeichnung ausgeblendet | Chat | public/data/spp7-datasets.json#/datasets/events/73 |
| K11 | Bestands-Event außerhalb der Referenz · Bezeichnung ausgeblendet | Chat | public/data/spp7-datasets.json#/datasets/events/74 |
| K12 | Bestands-Event außerhalb der Referenz · Bezeichnung ausgeblendet | Chat | public/data/spp7-datasets.json#/datasets/events/75 |
| K13 | Bestands-Event außerhalb der Referenz · Bezeichnung ausgeblendet | Chat | public/data/spp7-datasets.json#/datasets/events/76 |
| K14 | Bestands-Event außerhalb der Referenz · Bezeichnung ausgeblendet | Chat | public/data/spp7-datasets.json#/datasets/events/77 |
| K16 | Bestands-Event außerhalb der Referenz · Bezeichnung ausgeblendet | Chat | public/data/spp7-datasets.json#/datasets/events/79 |
| K20 | Bestands-Event außerhalb der Referenz · Bezeichnung ausgeblendet | Chat | public/data/spp7-datasets.json#/datasets/events/80 |
| K21 | Bestands-Event außerhalb der Referenz · Bezeichnung ausgeblendet | Chat | public/data/spp7-datasets.json#/datasets/events/81 |
| K22 | Bestands-Event außerhalb der Referenz · Bezeichnung ausgeblendet | Chat | public/data/spp7-datasets.json#/datasets/events/82 |
| K23 | Bestands-Event außerhalb der Referenz · Bezeichnung ausgeblendet | Chat | public/data/spp7-datasets.json#/datasets/events/83 |
| K24 | Bestands-Event außerhalb der Referenz · Bezeichnung ausgeblendet | Chat | public/data/spp7-datasets.json#/datasets/events/84 |
| K25 | Bestands-Event außerhalb der Referenz · Bezeichnung ausgeblendet | Chat | public/data/spp7-datasets.json#/datasets/events/85 |
| K26 | Bestands-Event außerhalb der Referenz · Bezeichnung ausgeblendet | Chat | public/data/spp7-datasets.json#/datasets/events/86 |
| K27 | Bestands-Event außerhalb der Referenz · Bezeichnung ausgeblendet | Chat | public/data/spp7-datasets.json#/datasets/events/87 |
| K28 | Bestands-Event außerhalb der Referenz · Bezeichnung ausgeblendet | Chat | public/data/spp7-datasets.json#/datasets/events/88 |
| K29 | Bestands-Event außerhalb der Referenz · Bezeichnung ausgeblendet | Chat | public/data/spp7-datasets.json#/datasets/events/89 |
| K30 | Bestands-Event außerhalb der Referenz · Bezeichnung ausgeblendet | Chat | public/data/spp7-datasets.json#/datasets/events/90 |
| K31 | Bestands-Event außerhalb der Referenz · Bezeichnung ausgeblendet | Chat | public/data/spp7-datasets.json#/datasets/events/91 |
| K32 | Bestands-Event außerhalb der Referenz · Bezeichnung ausgeblendet | Chat | public/data/spp7-datasets.json#/datasets/events/92 |
| K33 | Bestands-Event außerhalb der Referenz · Bezeichnung ausgeblendet | Chat | public/data/spp7-datasets.json#/datasets/events/93 |
| K34 | Bestands-Event außerhalb der Referenz · Bezeichnung ausgeblendet | Chat | public/data/spp7-datasets.json#/datasets/events/94 |
| K35 | Bestands-Event außerhalb der Referenz · Bezeichnung ausgeblendet | Chat | public/data/spp7-datasets.json#/datasets/events/95 |
| K40 | Bestands-Event außerhalb der Referenz · Bezeichnung ausgeblendet | Chat | public/data/spp7-datasets.json#/datasets/events/97 |
| K41 | Bestands-Event außerhalb der Referenz · Bezeichnung ausgeblendet | Chat | public/data/spp7-datasets.json#/datasets/events/98 |
| K42 | Bestands-Event außerhalb der Referenz · Bezeichnung ausgeblendet | Chat | public/data/spp7-datasets.json#/datasets/events/99 |
| K43 | Bestands-Event außerhalb der Referenz · Bezeichnung ausgeblendet | Chat | public/data/spp7-datasets.json#/datasets/events/100 |
| K44 | Bestands-Event außerhalb der Referenz · Bezeichnung ausgeblendet | Chat | public/data/spp7-datasets.json#/datasets/events/101 |
| R02 | Bestands-Event außerhalb der Referenz · Bezeichnung ausgeblendet | Chat | public/data/spp7-datasets.json#/datasets/events/103 |
| R03 | Bestands-Event außerhalb der Referenz · Bezeichnung ausgeblendet | Chat | public/data/spp7-datasets.json#/datasets/events/104 |
| R04 | Bestands-Event außerhalb der Referenz · Bezeichnung ausgeblendet | Chat | public/data/spp7-datasets.json#/datasets/events/105 |
| R05 | Bestands-Event außerhalb der Referenz · Bezeichnung ausgeblendet | Chat | public/data/spp7-datasets.json#/datasets/events/106 |
| M01 | Bestands-Event außerhalb der Referenz · Bezeichnung ausgeblendet | Chat (KI-Liste) | public/data/spp7-datasets.json#/datasets/events/107 |
| M02 | Bestands-Event außerhalb der Referenz · Bezeichnung ausgeblendet | Chat (KI-Liste) | public/data/spp7-datasets.json#/datasets/events/108 |
| M03 | Bestands-Event außerhalb der Referenz · Bezeichnung ausgeblendet | Chat (KI-Liste) | public/data/spp7-datasets.json#/datasets/events/109 |
| M04 | Bestands-Event außerhalb der Referenz · Bezeichnung ausgeblendet | Chat (KI-Liste) | public/data/spp7-datasets.json#/datasets/events/110 |
| M05 | Bestands-Event außerhalb der Referenz · Bezeichnung ausgeblendet | Chat (KI-Liste) | public/data/spp7-datasets.json#/datasets/events/111 |
| M06 | Bestands-Event außerhalb der Referenz · Bezeichnung ausgeblendet | Chat (KI-Liste) | public/data/spp7-datasets.json#/datasets/events/112 |
| M07 | Bestands-Event außerhalb der Referenz · Bezeichnung ausgeblendet | Chat (KI-Liste) | public/data/spp7-datasets.json#/datasets/events/113 |
| M08 | Bestands-Event außerhalb der Referenz · Bezeichnung ausgeblendet | Chat (KI-Liste) | public/data/spp7-datasets.json#/datasets/events/114 |
| M09 | Bestands-Event außerhalb der Referenz · Bezeichnung ausgeblendet | Chat (KI-Liste) | public/data/spp7-datasets.json#/datasets/events/115 |
| M10 | Bestands-Event außerhalb der Referenz · Bezeichnung ausgeblendet | Chat (KI-Liste) | public/data/spp7-datasets.json#/datasets/events/116 |
| M11 | Bestands-Event außerhalb der Referenz · Bezeichnung ausgeblendet | Chat (KI-Liste) | public/data/spp7-datasets.json#/datasets/events/117 |
| M12 | Bestands-Event außerhalb der Referenz · Bezeichnung ausgeblendet | Chat (KI-Liste) | public/data/spp7-datasets.json#/datasets/events/118 |
| M13 | Bestands-Event außerhalb der Referenz · Bezeichnung ausgeblendet | Chat (KI-Liste) | public/data/spp7-datasets.json#/datasets/events/119 |
| M15 | Bestands-Event außerhalb der Referenz · Bezeichnung ausgeblendet | Chat (KI-Liste) | public/data/spp7-datasets.json#/datasets/events/121 |
| M16 | Bestands-Event außerhalb der Referenz · Bezeichnung ausgeblendet | Chat (KI-Liste) | public/data/spp7-datasets.json#/datasets/events/122 |
| M17 | Bestands-Event außerhalb der Referenz · Bezeichnung ausgeblendet | Chat (KI-Liste) | public/data/spp7-datasets.json#/datasets/events/123 |
| M18 | Bestands-Event außerhalb der Referenz · Bezeichnung ausgeblendet | Chat (KI-Liste) | public/data/spp7-datasets.json#/datasets/events/124 |
| M19 | Bestands-Event außerhalb der Referenz · Bezeichnung ausgeblendet | Chat (KI-Liste) | public/data/spp7-datasets.json#/datasets/events/125 |
| M20 | Bestands-Event außerhalb der Referenz · Bezeichnung ausgeblendet | Chat (KI-Liste) | public/data/spp7-datasets.json#/datasets/events/126 |
| M22 | Bestands-Event außerhalb der Referenz · Bezeichnung ausgeblendet | Chat (KI-Liste) | public/data/spp7-datasets.json#/datasets/events/128 |
| M23 | Bestands-Event außerhalb der Referenz · Bezeichnung ausgeblendet | Chat (KI-Liste) | public/data/spp7-datasets.json#/datasets/events/129 |
| M24 | Bestands-Event außerhalb der Referenz · Bezeichnung ausgeblendet | Chat (KI-Liste) | public/data/spp7-datasets.json#/datasets/events/130 |
| M25 | Bestands-Event außerhalb der Referenz · Bezeichnung ausgeblendet | Chat (KI-Liste) | public/data/spp7-datasets.json#/datasets/events/131 |
| M26 | Bestands-Event außerhalb der Referenz · Bezeichnung ausgeblendet | Chat (KI-Liste) | public/data/spp7-datasets.json#/datasets/events/132 |
| M27 | Bestands-Event außerhalb der Referenz · Bezeichnung ausgeblendet | Chat (KI-Liste) | public/data/spp7-datasets.json#/datasets/events/133 |
| M28 | Bestands-Event außerhalb der Referenz · Bezeichnung ausgeblendet | Chat (KI-Liste) | public/data/spp7-datasets.json#/datasets/events/134 |
| M29 | Bestands-Event außerhalb der Referenz · Bezeichnung ausgeblendet | Chat (KI-Liste) | public/data/spp7-datasets.json#/datasets/events/135 |
| M30 | Bestands-Event außerhalb der Referenz · Bezeichnung ausgeblendet | Chat (KI-Liste) | public/data/spp7-datasets.json#/datasets/events/136 |
| M31 | Bestands-Event außerhalb der Referenz · Bezeichnung ausgeblendet | Chat (KI-Liste) | public/data/spp7-datasets.json#/datasets/events/137 |
| M32 | Bestands-Event außerhalb der Referenz · Bezeichnung ausgeblendet | Chat (KI-Liste) | public/data/spp7-datasets.json#/datasets/events/138 |
| M33 | Bestands-Event außerhalb der Referenz · Bezeichnung ausgeblendet | Chat (KI-Liste) | public/data/spp7-datasets.json#/datasets/events/139 |
| M34 | Bestands-Event außerhalb der Referenz · Bezeichnung ausgeblendet | Chat (KI-Liste) | public/data/spp7-datasets.json#/datasets/events/140 |
| M35 | Bestands-Event außerhalb der Referenz · Bezeichnung ausgeblendet | Chat (KI-Liste) | public/data/spp7-datasets.json#/datasets/events/141 |
| M36 | Bestands-Event außerhalb der Referenz · Bezeichnung ausgeblendet | Chat (KI-Liste) | public/data/spp7-datasets.json#/datasets/events/142 |
| M37 | Bestands-Event außerhalb der Referenz · Bezeichnung ausgeblendet | Chat (KI-Liste) | public/data/spp7-datasets.json#/datasets/events/143 |
| M38 | Bestands-Event außerhalb der Referenz · Bezeichnung ausgeblendet | Chat (KI-Liste) | public/data/spp7-datasets.json#/datasets/events/144 |
| M39 | Bestands-Event außerhalb der Referenz · Bezeichnung ausgeblendet | Chat (KI-Liste) | public/data/spp7-datasets.json#/datasets/events/145 |
| M40 | Bestands-Event außerhalb der Referenz · Bezeichnung ausgeblendet | Chat (KI-Liste) | public/data/spp7-datasets.json#/datasets/events/146 |
| M41 | Bestands-Event außerhalb der Referenz · Bezeichnung ausgeblendet | Chat (KI-Liste) | public/data/spp7-datasets.json#/datasets/events/147 |
| M43 | Bestands-Event außerhalb der Referenz · Bezeichnung ausgeblendet | Chat (KI-Liste) | public/data/spp7-datasets.json#/datasets/events/149 |
| M45 | Bestands-Event außerhalb der Referenz · Bezeichnung ausgeblendet | Chat (KI-Liste) | public/data/spp7-datasets.json#/datasets/events/151 |
| M46 | Bestands-Event außerhalb der Referenz · Bezeichnung ausgeblendet | Chat (KI-Liste) | public/data/spp7-datasets.json#/datasets/events/152 |
| M47 | Bestands-Event außerhalb der Referenz · Bezeichnung ausgeblendet | Chat (KI-Liste) | public/data/spp7-datasets.json#/datasets/events/153 |
| F36 | Bestands-Event außerhalb der Referenz · Bezeichnung ausgeblendet | Flyer | public/data/spp7-datasets.json#/datasets/events/154 |
| F39 | Bestands-Event außerhalb der Referenz · Bezeichnung ausgeblendet | Flyer | public/data/spp7-datasets.json#/datasets/events/155 |
| F40 | Bestands-Event außerhalb der Referenz · Bezeichnung ausgeblendet | Flyer | public/data/spp7-datasets.json#/datasets/events/156 |
| F41 | Bestands-Event außerhalb der Referenz · Bezeichnung ausgeblendet | Flyer | public/data/spp7-datasets.json#/datasets/events/157 |
| F42 | Bestands-Event außerhalb der Referenz · Bezeichnung ausgeblendet | Flyer | public/data/spp7-datasets.json#/datasets/events/158 |
| F43 | Bestands-Event außerhalb der Referenz · Bezeichnung ausgeblendet | Flyer | public/data/spp7-datasets.json#/datasets/events/159 |
| F44 | Bestands-Event außerhalb der Referenz · Bezeichnung ausgeblendet | Flyer | public/data/spp7-datasets.json#/datasets/events/160 |
| F45 | Bestands-Event außerhalb der Referenz · Bezeichnung ausgeblendet | Flyer | public/data/spp7-datasets.json#/datasets/events/161 |
| F46 | Bestands-Event außerhalb der Referenz · Bezeichnung ausgeblendet | Flyer | public/data/spp7-datasets.json#/datasets/events/162 |
| F47 | Bestands-Event außerhalb der Referenz · Bezeichnung ausgeblendet | Flyer | public/data/spp7-datasets.json#/datasets/events/163 |
| F48 | Bestands-Event außerhalb der Referenz · Bezeichnung ausgeblendet | Flyer | public/data/spp7-datasets.json#/datasets/events/164 |
| F49 | Bestands-Event außerhalb der Referenz · Bezeichnung ausgeblendet | Flyer | public/data/spp7-datasets.json#/datasets/events/165 |
| F50 | Bestands-Event außerhalb der Referenz · Bezeichnung ausgeblendet | Flyer | public/data/spp7-datasets.json#/datasets/events/166 |
| F51 | Bestands-Event außerhalb der Referenz · Bezeichnung ausgeblendet | Flyer | public/data/spp7-datasets.json#/datasets/events/167 |
| F52 | Bestands-Event außerhalb der Referenz · Bezeichnung ausgeblendet | Flyer | public/data/spp7-datasets.json#/datasets/events/168 |
| F53 | Bestands-Event außerhalb der Referenz · Bezeichnung ausgeblendet | Flyer | public/data/spp7-datasets.json#/datasets/events/169 |
| F54 | Bestands-Event außerhalb der Referenz · Bezeichnung ausgeblendet | Flyer | public/data/spp7-datasets.json#/datasets/events/170 |
| F55 | Bestands-Event außerhalb der Referenz · Bezeichnung ausgeblendet | Flyer | public/data/spp7-datasets.json#/datasets/events/171 |
| F56 | Bestands-Event außerhalb der Referenz · Bezeichnung ausgeblendet | Flyer | public/data/spp7-datasets.json#/datasets/events/172 |
| F57 | Bestands-Event außerhalb der Referenz · Bezeichnung ausgeblendet | Flyer | public/data/spp7-datasets.json#/datasets/events/173 |
| F58 | Bestands-Event außerhalb der Referenz · Bezeichnung ausgeblendet | Flyer | public/data/spp7-datasets.json#/datasets/events/174 |
| F59 | Bestands-Event außerhalb der Referenz · Bezeichnung ausgeblendet | Flyer | public/data/spp7-datasets.json#/datasets/events/175 |
| F60 | Bestands-Event außerhalb der Referenz · Bezeichnung ausgeblendet | Flyer | public/data/spp7-datasets.json#/datasets/events/176 |
| F61 | Bestands-Event außerhalb der Referenz · Bezeichnung ausgeblendet | Flyer | public/data/spp7-datasets.json#/datasets/events/177 |
| F62 | Bestands-Event außerhalb der Referenz · Bezeichnung ausgeblendet | Flyer | public/data/spp7-datasets.json#/datasets/events/178 |
| F63 | Bestands-Event außerhalb der Referenz · Bezeichnung ausgeblendet | Flyer | public/data/spp7-datasets.json#/datasets/events/179 |
| F64 | Bestands-Event außerhalb der Referenz · Bezeichnung ausgeblendet | Flyer | public/data/spp7-datasets.json#/datasets/events/180 |
| F65 | Bestands-Event außerhalb der Referenz · Bezeichnung ausgeblendet | Flyer | public/data/spp7-datasets.json#/datasets/events/181 |
| F66 | Bestands-Event außerhalb der Referenz · Bezeichnung ausgeblendet | Flyer | public/data/spp7-datasets.json#/datasets/events/182 |
| F67 | Bestands-Event außerhalb der Referenz · Bezeichnung ausgeblendet | Flyer | public/data/spp7-datasets.json#/datasets/events/183 |
| F68 | Bestands-Event außerhalb der Referenz · Bezeichnung ausgeblendet | Flyer | public/data/spp7-datasets.json#/datasets/events/184 |
| F69 | Bestands-Event außerhalb der Referenz · Bezeichnung ausgeblendet | Flyer | public/data/spp7-datasets.json#/datasets/events/185 |
| F70 | Bestands-Event außerhalb der Referenz · Bezeichnung ausgeblendet | Flyer | public/data/spp7-datasets.json#/datasets/events/186 |
| F71 | Bestands-Event außerhalb der Referenz · Bezeichnung ausgeblendet | Flyer | public/data/spp7-datasets.json#/datasets/events/187 |
| F72 | Bestands-Event außerhalb der Referenz · Bezeichnung ausgeblendet | Flyer | public/data/spp7-datasets.json#/datasets/events/188 |
| F32 | Bestands-Event außerhalb der Referenz · Bezeichnung ausgeblendet | Flyer | public/data/spp7-datasets.json#/datasets/events/189 |
| F37 | Bestands-Event außerhalb der Referenz · Bezeichnung ausgeblendet | Flyer | public/data/spp7-datasets.json#/datasets/events/190 |
| F38 | Bestands-Event außerhalb der Referenz · Bezeichnung ausgeblendet | Flyer | public/data/spp7-datasets.json#/datasets/events/191 |
| F75 | Bestands-Event außerhalb der Referenz · Bezeichnung ausgeblendet | Flyer | public/data/spp7-datasets.json#/datasets/events/192 |
| F76 | Bestands-Event außerhalb der Referenz · Bezeichnung ausgeblendet | Flyer | public/data/spp7-datasets.json#/datasets/events/193 |
| F77 | Bestands-Event außerhalb der Referenz · Bezeichnung ausgeblendet | Flyer | public/data/spp7-datasets.json#/datasets/events/194 |
| F79 | Bestands-Event außerhalb der Referenz · Bezeichnung ausgeblendet | Flyer | public/data/spp7-datasets.json#/datasets/events/195 |
| C32 | Bestands-Event außerhalb der Referenz · Bezeichnung ausgeblendet | Chat | public/data/spp7-datasets.json#/datasets/events/196 |
| C33 | Bestands-Event außerhalb der Referenz · Bezeichnung ausgeblendet | Chat | public/data/spp7-datasets.json#/datasets/events/197 |
| S05 | Bestands-Event außerhalb der Referenz · Bezeichnung ausgeblendet | Sündenfrei | public/data/spp7-datasets.json#/datasets/events/202 |
| T09 | Bestands-Event außerhalb der Referenz · Bezeichnung ausgeblendet | Nutzer / Tourplanung | public/data/spp7-datasets.json#/datasets/events/204 |
| T10 | Bestands-Event außerhalb der Referenz · Bezeichnung ausgeblendet | Nutzer / Tourplanung | public/data/spp7-datasets.json#/datasets/events/205 |

## Technischer Bestand / Integrität

| Dataset | Zeilen |
|---|---|
| events | 206 |
| event_dates | 203 |
| event_acts | 270 |
| acts | 221 |
| event_partners | 46 |
| partners | 42 |
| event_features | 47 |
| event_channels | 80 |
| event_tags | 711 |
| timetable | 15 |
| feed_context | 22 |
| contacts | 74 |
| chat_items | 149 |
| flyer_sources | 79 |

Bestands-Events ohne irgendeine Datumszeile: 44 (kann bei Locations sinnvoll sein, kein pauschaler Fehler).
Datumszeilen ohne ISO-Beginn: 8; ohne ISO-Ende: 114 (einseitige Datums-/Post-/Fristangaben nicht als kompletten Zeitraum behandeln).
ISO-Beginnjahre: {"2026":183,"2027":12,"ohne ISO-Beginn":8}. Quelle-Typen: {"Chat":80,"Chat (KI-Liste)":47,"Flyer":71,"Nutzer / Tourplanung":2,"Sündenfrei":6}.
Geocodiert: 180 Events / 68 Kontakte; keine inhaltliche Geo-Prüfung. Aufbereitete Chat-Nachrichten: 121.

- REL-feed_context-EVENT_ID: verwaister_verweis (feed_context) — public/data/spp7-datasets.json#/datasets/feed_context/20.EVENT_ID=F29 (Ziel-ID fehlt)
- DATE-D113-D198: gleicher_zeitraum_unterschiedliche_art (event_dates) — M21|2026-05-01|2026-05-03; D113: Festivaltermin (KI-Liste); D198: Sündenfrei 2026. Unterschiedliche Arten können unterschiedliche Bedeutungen haben, nicht automatisch löschen.
- KANAL-K09: kontaktkanal_platzhalter (contacts) — K09: EMAIL_TELEFON=(nicht genannt); kein auslesbarer E-Mail-/Telefonwert.
- CONTACT-NAME-K01-K02: gleicher_kontaktname_ort (contacts) — K01: Tourismuszentrale Rügen (ruegen.de); K02: Tourismuszentrale Rügen (ruegen.de). Namenswortfolge und Ortswortfolge gleich; verschiedene Kanäle können eigene Zwecke haben. Keine automatische Zusammenführung.
- CONTACT-NAME-K22-K23: gleicher_kontaktname_ort (contacts) — K22: Kurverwaltung Putbus; K23: Kurverwaltung Putbus. Namenswortfolge und Ortswortfolge gleich; verschiedene Kanäle können eigene Zwecke haben. Keine automatische Zusammenführung.
- CONTACT-CHANNEL-K64-K73: gemeinsamer_bestandskanal (contacts) — K64 / K73: auslesbarer Kanal identisch. Einrichtung und Person können denselben Kanal nutzen; keine Identitätsentscheidung, persönliche Kanalwerte nicht veröffentlicht.
- NAME-M04-M06-M24-M27-M47: gleicher_name_kein_dublettenbeweis (events) — M04: Mittelaltermarkt — Weißenfels; M06: Mittelaltermarkt — Hohenmölsen; M24: Mittelaltermarkt — Breitungen; M27: Mittelaltermarkt — Vacha; M47: Mittelaltermarkt — Osnabrück
- NAME-M11-M13: gleicher_name_kein_dublettenbeweis (events) — M11: Ritterfest — Jerichow; M13: Ritterfest — Thale
- NAME-M14-M19-M22: gleicher_name_kein_dublettenbeweis (events) — M14: Burgfest — Falkenstein; M19: Burgfest — Creuzburg; M22: Burgfest — Orlamünde
- NAME-M16-M29-M41: gleicher_name_kein_dublettenbeweis (events) — M16: Fantasy- & Mittelaltermarkt — Heldburg; M29: Fantasy- & Mittelaltermarkt — Veilsdorf; M41: Fantasy- & Mittelaltermarkt — Vacha
- NAME-M28-M33: gleicher_name_kein_dublettenbeweis (events) — M28: Mittelalterfest — Ebeleben; M33: Mittelalterfest — Völpke
- NAME-M42-M43: gleicher_name_kein_dublettenbeweis (events) — M42: Phantastisches Zauberdorf — Kranichfeld; M43: Phantastisches Zauberdorf — Römhild

## Nächster Schritt

Stufe 4: nummerierte Befunde einzeln entscheiden. Dieser Bericht ist keine Importfreigabe. Originale, Normierung und Datenbank wurden nicht verändert.
