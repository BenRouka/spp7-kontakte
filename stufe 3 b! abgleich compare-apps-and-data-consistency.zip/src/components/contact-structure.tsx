"use client";

import { useEffect, useMemo, useState } from "react";
import type { ContactNode, ContactWorkspace, NormalizedContact } from "@/lib/contact-model";
import { Icon } from "@/components/icons";

export function ContactStructure() {
  const [data, setData] = useState<ContactWorkspace | null>(null);
  const [error, setError] = useState("");
  const [attempt, setAttempt] = useState(0);
  const [search, setSearch] = useState("");
  const [selectedRegion, setSelectedRegion] = useState("all");
  useEffect(() => {
    const controller = new AbortController();
    setError("");
    async function load() {
      try {
        const response = await fetch("/api/review/contacts", { cache: "no-store", signal: controller.signal });
        if (!response.ok) throw new Error("Quellstand konnte nicht geprüft werden.");
        const result = await response.json() as ContactWorkspace;
        if (controller.signal.aborted) return;
        setData(result);
        setSelectedRegion(result.nodes.find((node) => node.typ === "region" && node.name === "Halbinsel Mönchgut")?.id || "all");
      } catch {
        if (!controller.signal.aborted) setError("Die Kontaktstruktur ist momentan nicht verfügbar. Bitte erneut prüfen; es wurde nichts importiert.");
      }
    }
    load();
    return () => controller.abort();
  }, [attempt]);

  const visibleContacts = useMemo(() => data?.contacts.filter((contact) => {
    const text = [contact.name_haupt_original, contact.name_zusatz_original, contact.name_zusatz_normiert,
      contact.region_original, contact.region_anzeige, contact.ort_original, contact.ort_anzeige,
      contact.ort_normiert, contact.ortsteil_normiert, contact.plz_normiert, contact.kv_id].join(" ").toLocaleLowerCase("de-DE");
    return (selectedRegion === "all" || contact.region_id === selectedRegion) && text.includes(search.trim().toLocaleLowerCase("de-DE"));
  }) || [], [data, selectedRegion, search]);

  if (error) return <div className="error-notice" role="alert"><Icon name="info" size={18} /><span>{error}</span><button onClick={() => setAttempt((n) => n + 1)}>Erneut prüfen</button></div>;
  if (!data) return <div className="contact-loading" role="status"><Icon name="folder" size={20} /> Kontaktstruktur und Quellen-Prüfsummen werden gelesen …</div>;
  const regions = data.nodes.filter((node) => node.typ === "region" || node.typ === "gruppe");
  const missing = data.missingValue;
  const regionNodes = regions.filter((node) => visibleContacts.some((contact) => contact.region_id === node.id));

  function Field({ label, value, note }: { label: string; value: string; note?: string }) {
    return <div><dt>{label}</dt><dd><code className={value === missing ? "contact-missing" : "contact-value"}>{value}</code>{note && <small className="contact-field-origin">{note}</small>}</dd></div>;
  }
  function NodeOrigins({ node }: { node: ContactNode }) {
    if (node.typ !== "gruppe" && node.quellvorkommen.length < 2) return null;
    return <details className="contact-provenance"><summary><Icon name="file" size={14} /> Gliederung und Originalfundstellen</summary><div>
      <p>{node.typ === "gruppe" ? "Rügen Übergreifend ist eine übergreifende Quellgruppe, kein Ort. Die echte Postanschrift der Einrichtung bleibt unverändert." : "Vitte wird ausschließlich aufgrund deiner ausdrücklichen Zuordnung gemeinsam angezeigt. Die beiden MD-Fundstellen und alle Einrichtungen bleiben erhalten."}</p>
      {node.quellvorkommen.map((source) => <p key={source.id}><strong>MD-Zeile {source.quellzeile}:</strong> {source.name} · <code>{source.id}</code></p>)}
      <p><strong>Zuordnung:</strong> {node.herkunft}</p>
    </div></details>;
  }
  function ContactCard({ contact }: { contact: NormalizedContact }) {
    const supplemented = contact.quelle_ergaenzung !== missing;
    return <article className="contact-entry" id={`contact-${contact.kv_id}`} data-contact-id={contact.kv_id}>
      <div className="contact-entry-header"><span className="contact-path">{contact.hierarchie_pfad}.</span><div><h4>{contact.name_haupt_original}</h4>{contact.name_zusatz_normiert !== missing && <p>{contact.name_zusatz_normiert}</p>}{contact.name_zusatz_ergaenzung !== missing && <small className="contact-field-origin">Zusatzname · Nutzerangabe</small>}</div><span className="badge">{contact.kv_id}</span></div>
      <p className="contact-address">{contact.strasse_original}<br />{contact.plz_ort_original}</p>
      <dl className="contact-values">
        <Field label="Ort · Postanschrift" value={contact.ort_normiert} />
        <Field label="Ortsteil" value={contact.ortsteil_normiert} />
        <Field label="Telefon · normiert" value={contact.telefon_normiert} note={contact.telefon_ergaenzung !== missing ? "Nutzerergänzung" : undefined} />
        <Field label="Fax · normiert" value={contact.fax_normiert} />
        <Field label="Internet" value={contact.web_normiert} note={contact.web_ergaenzung !== missing ? "Nutzerergänzung" : undefined} />
        <Field label="E-Mail" value={contact.email_1_normiert} note={contact.email_1_ergaenzung !== missing ? "Nutzerergänzung" : undefined} />
        {contact.email_2_normiert !== missing && <Field label="E-Mail 2" value={contact.email_2_normiert} />}
      </dl>
      {contact.organisations_parent_id !== missing && <p className="contact-organization"><Icon name="layers" size={14} />Organisatorisch zugeordnet: <code>{contact.organisations_parent_id}</code> · nicht der geografische Parent</p>}
      <details className="contact-provenance"><summary><Icon name="file" size={14} /> Original und Herkunft {supplemented && <span className="badge badge-amber">Ergänzt</span>}</summary><div>
        <dl className="contact-values">
          <Field label="Telefon · MD-Original" value={contact.telefon_original} />
          <Field label="Fax · MD-Original" value={contact.fax_original} />
          <Field label="Internet · MD-Original" value={contact.web_original} />
          <Field label="E-Mail · MD-Original" value={contact.email_1_original} />
          {contact.name_zusatz_ergaenzung !== missing && <><Field label="Zusatzname · MD-Original" value={contact.name_zusatz_original} /><Field label="Zusatzname · Nutzerergänzung" value={contact.name_zusatz_ergaenzung} /></>}
        </dl>
        <p><strong>Originalfundstelle:</strong> MD-Zeilen {contact.quellzeile} · {contact.quelle_stand}</p>
        {contact.ortsteil_herkunft !== missing && <p><strong>Ortsteil:</strong> {contact.ortsteil_herkunft}</p>}
        {contact.name_zusatz_ergaenzung !== missing && <p><strong>Namenszusatz:</strong> {contact.name_zusatz_herkunft}</p>}
        {supplemented && <><p><strong>Ergänzung:</strong> {contact.quelle_ergaenzung}</p><p><strong>Keine automatische Vererbung:</strong> Website/E-Mail werden nur übernommen, wenn sie ausdrücklich für diese Einrichtung genannt wurden.</p></>}
        <p><strong>Fehlend in der MD:</strong> <code className={contact.felder_fehlend_quelle === missing ? "contact-missing" : ""}>{contact.felder_fehlend_quelle}</code></p>
        <p><strong>Fehlend im Arbeitsstand:</strong> <code className={contact.felder_fehlend_arbeitsstand === missing ? "contact-missing" : ""}>{contact.felder_fehlend_arbeitsstand}</code></p>
        <p><strong>Chat-MSG-ID:</strong> <code className="contact-missing">{contact.chat_msg_id}</code> · keine ID mitgeliefert; nicht unabhängig im Chatarchiv verifiziert.</p>
        <a className="text-button" href={`${data!.source.url}#L${contact.quellzeile.split("-")[0]}`} target="_blank" rel="noreferrer">MD-Original öffnen <Icon name="external" size={14} /></a>
      </div></details>
      <div className="contact-entry-footer"><span className="badge badge-amber">Nicht verifiziert</span><span className="contact-path">Parent: {contact.parent_id}</span></div>
    </article>;
  }
  function PlaceGroup({ node, contacts }: { node: ContactNode; contacts: NormalizedContact[] }) {
    return <details className="contact-place" open><summary><Icon name="chevronDown" size={16} /><span className="contact-path">{node.hierarchie_pfad}.</span><h3>{node.name}</h3><span className="contact-group-count">{contacts.length} Einrichtungen</span></summary><div className="contact-entry-list"><NodeOrigins node={node} />{contacts.map((contact) => <ContactCard key={contact.kv_id} contact={contact} />)}</div></details>;
  }

  return <section className="contact-workspace" role="tabpanel" aria-label="Geografische Kontaktstruktur">
    <div className="section-heading"><div><h2>Region → Ort → Einrichtung</h2><p>{data.counts.contacts} Einrichtungen aus {data.counts.rawBlocks} Rohblöcken · Ortsteil als eigenes Feld · nur lesender Normierungsentwurf.</p></div><span className="badge"><Icon name="lock" size={12} /> Kein Import</span></div>
    <div className="contact-toolbar"><label className="contact-region-filter"><span>Region / Quellgruppe</span><select aria-label="Kontaktregion auswählen" value={selectedRegion} onChange={(event) => setSelectedRegion(event.target.value)}><option value="all">Alle Regionen</option>{regions.map((node) => <option key={node.id} value={node.id}>{node.name}</option>)}</select></label><label className="search-input contact-search"><Icon name="search" size={16} /><input aria-label="Kontaktstruktur durchsuchen" placeholder="Ort, Ortsteil, Einrichtung …" value={search} onChange={(event) => setSearch(event.target.value)} />{search && <button aria-label="Kontaktsuche leeren" onClick={() => setSearch("")}><Icon name="close" size={14} /></button>}</label><span className="contact-group-count">{visibleContacts.length} / {data.counts.contacts} Einrichtungen</span></div>
    <div className="contact-downloads"><a className="secondary-button" href="/api/review/contacts?format=csv"><Icon name="download" size={15} /> Einrichtungen · CSV</a><a className="secondary-button" href="/api/review/contacts?format=tree"><Icon name="layers" size={15} /> Struktur · CSV</a><a className="secondary-button" href="/api/review/contacts?format=zip"><Icon name="folder" size={15} /> Normierungsentwurf · ZIP</a></div>
    <div className="contact-notice"><Icon name="info" size={18} /><p>Fehlende Angaben sind exakt <code className="contact-missing">{missing}</code> (Leerzeichen – Bindestrich – Leerzeichen). Region/Ort und organisatorische Zuordnung sind getrennt. Der Baabe-Infopavillon erhält Web/E-Mail aus deiner ausdrücklichen Ergänzung, nicht durch automatisches Erben.</p></div>
    {regionNodes.map((region) => <details className="contact-region" key={region.id} open><summary><Icon name="chevronDown" size={18} /><span className="contact-path">{region.hierarchie_pfad}.</span><h2>{region.name}</h2>{region.typ === "gruppe" && <span className="badge">Quellgruppe · kein Ort</span>}</summary><div className="contact-region-content">
      {region.typ === "gruppe" && <div className="contact-entry-list"><NodeOrigins node={region} />{visibleContacts.filter((contact) => contact.parent_id === region.id).map((contact) => <ContactCard key={contact.kv_id} contact={contact} />)}</div>}
      {data.nodes.filter((node) => node.typ === "ort" && node.parent_id === region.id).map((node) => { const contacts = visibleContacts.filter((contact) => contact.ort_id === node.id); return contacts.length ? <PlaceGroup key={node.id} node={node} contacts={contacts} /> : null; })}
    </div></details>)}
    {!visibleContacts.length && <div className="empty-state"><Icon name="search" size={30} /><h3>Keine passende Einrichtung</h3><p>Region ändern oder Suchbegriff entfernen.</p><button className="secondary-button" onClick={() => { setSearch(""); setSelectedRegion("all"); }}>Kontaktfilter zurücksetzen</button></div>}
    <p className="contact-footnote">Gliederungsnummern folgen der Quellreihenfolge, keine amtlichen Gebiets-IDs. „Rügen Übergreifend“ ist eine Gruppe, kein Ort. Vitte wird nur nach ausdrücklicher Freigabe gemeinsam angezeigt; beide Rohfundstellen bleiben erhalten. Ortsteil nur bei explizitem „OT“. Modell: <code>{data.version}</code></p>
  </section>;
}
