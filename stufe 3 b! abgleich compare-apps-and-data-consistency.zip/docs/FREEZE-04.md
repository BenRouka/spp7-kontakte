# SPP7 · FREEZE-04 — Alle Kleinbeschriftungen in normaler Schreibweise

**Status: eingefroren (Pause)** · 2026-10-01 UTC
**Aktueller Einstieg bei Wiederaufnahme.** Ergänzt FREEZE-03; FREEZE-01 bis FREEZE-03 bleiben als historische Prüfpunkte unverändert.

> Bis zur Wiederaufnahme: keine Code-, Layout-, Daten- oder Schemaänderung.
> Weiter erst nach ausdrücklicher Freigabe.

Begleitdateien:
- `docs/FREEZE-04-pruefprotokoll.txt` — Browser-, Regression-, Build- und Laufzeitprotokoll
- `docs/FREEZE-04.sha256` — Prüfsummen des aktuellen Arbeitsstands

## 1. Bestätigte Änderung („Ok leg los, alle bitte“)

Die restlichen sechs Kleinbeschriftungen stehen jetzt in normaler Groß-/Kleinschreibung. Schriftart, Größe (12 px), Farbe, Position und Abstände sind unverändert.

| Vorher | Nachher | Ort |
|---|---|---|
| ORIGINAL AUS DER QUELLE | Original aus der Quelle | Karten und Original-Boxen |
| BEVOR STUFE 2 BEGINNT | Bevor Stufe 2 beginnt | Karte „Nachvollziehbar normieren“ |
| SPP7 · PRÜFANSICHT | SPP7 · Prüfansicht | Dialog-Kopf |
| DATUMSHERKUNFT · BESTÄTIGUNGSSTATUS | Datumsherkunft · Bestätigungsstatus | Dialog „Zeitmodell“ |
| ZEITMODELL 2027 | Zeitmodell 2027 | Export-Menü |
| NOV 2027 · DEZ 2027 | Nov 2027 · Dez 2027 | Dresden-Karte |

**Fachbegriffe bleiben groß:** ZIP, MD, TXT, PDF, CSV, ICS sowie „SPP7“.

Damit sind alle Kleinbeschriftungen der Oberfläche einheitlich (zusammen mit „Tour Intelligence“, „Klärung vor Stufe 2 · Option A“ und „Arbeitsbereich“ aus FREEZE-03). Eine automatische Prüfung findet keine weiteren Großschreibungs-Labels außer den Fachbegriffen.

## 2. Unverändert

- Petrol-Dunkelschema, Sieben-Stufen-Schriftskala, Roboto Mono/Lime für technische Angaben.
- Zeitmodell `zeitmodell-2026-2027-v2`; A/B-Abgleich; Option-B-Paket; Rohquellen.
- Datenbank: keine Tabellen, kein Import, kein Schema.
- Pipeline-Stufe 2 (vollständige Normierung): **nicht begonnen**.
- Alle Entscheidungen und offenen Punkte aus FREEZE-01 bis FREEZE-03 bleiben gültig.

Vergleich zu `docs/FREEZE-03.sha256`: einzige erwartete Abweichung ist `src/components/workshop.tsx`.

## 3. Wiederaufnahme

1. Dieses Dokument lesen.
2. `sha256sum -c docs/FREEZE-04.sha256` aus der Projektwurzel.
3. `node scripts/check-time-model.mjs` und `cd werkstatt/01-roh && sha256sum -c PRUEFSUMMEN.sha256`.
4. Nächsten Schritt abstimmen. Vorschlag: Stufe 2 — Normierung der 32 Adressblöcke und 54 Terminzeilen nach `werkstatt/02-normiert/`, Original plus normiert, ohne Datenbank.
