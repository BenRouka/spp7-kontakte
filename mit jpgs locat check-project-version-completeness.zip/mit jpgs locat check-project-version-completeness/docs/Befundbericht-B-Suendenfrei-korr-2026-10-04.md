# Befundbericht B — Korrigierte Prio-1-Quelle „Termine 26-27 Veranstalter suendenfrei.txt"

**Stand:** 2026-10-04
**Art:** rein lesend. Keine Änderung an Freeze, Werkstatt-DB, Alt-App oder Mockup.
**Quelle:** `Termine 26-27 Veranstalter suendenfrei.txt` (Repo-Stand: ersetzt die alte Datei `Termine 2027 Veranstalter suendenfrei.txt`; die alte Datei ist im Repo nicht mehr vorhanden, Raw-Abruf = 404).
**Beigefügte Abgleichsmatrix:** `docs/Abgleichmatrix-Termine-2026-10-04.csv` (54 Zeilen, Semikolon-getrennt)

---

## 1. Aufbau der korrigierten Quelle

- **54 Termine gesamt: 9 × 2026 + 45 × 2027** — exakt die Sollzahlen des Werkstatt-Freezes (B-10/B-12-Struktur).
- Kopf: „Veranstalter Sündenfrei Mittelalteragentur", 2027-Abschnitt mit „Stand 22. September 2026".
- Sternchen-Legende: „* oder ** Sternchen: Termin oder Ort wahrscheinlich, jedoch noch unbestätigt".
- Adventszeilen mit je 4 expliziten Adventswochenenden (2026: Do.–So.; 2027: Fr.–So.).

## 2. Freeze ↔ korrigierte Quelle: 52/54 inhaltlich identisch

Vergleichsmethode: paarweise in Quelldatei-Reihenfolge, Name/Ort **leerzeichenunsensibel** (kleingeschrieben, alle Leerzeichen entfernt — „Mittelalter- Advent" = „Mittelalter-Advent"), Sternchen als separates Feld betrachtet, Zeitfenster ISO-tag-genau.

**Ergebnis: nur 2 Abweichungen — beide sind Tippfehler der ALTEN Quelle, die der Freeze bewusst konserviert:**

| SF | Freeze (Name) | Korrigierte Quelle | Hinweis im Freeze |
|---|---|---|---|
| SF20 | `Mittealterspektakel` (fehlt ein „l") | `Mittelalterspektakel` | „Schreibweise wie in Quelle" |
| SF27 | `Mittealter- Burgfest` (fehlt ein „l") | `Mittelalter-Burgfest` | „Schreibweise wie in Quelle" |

**Alle übrigen 52 Paare identisch** — inklusive:
- **Weimar (vom Benutzer vorab geklärt):** SF02 = `373. Zwiebelmarkt` (9.–11.10.2026) und SF47 = `374. Zwiebelmarkt` (8.–10.10.2027) — zwei korrekt getrennte Jahresausgaben, keine Abweichung.
- **Stolpen:** SF37 trägt bereits den offiziellen Namen `Fantasy- und Mittelalterfest`, 01833 Stolpen (Burg) — die O-04-Kuratierung ist im Freeze bereits abgebildet.
- **Advent Herne:** SF05 und SF50 = je 1 Quellzeile mit **4 Zeitfenstern**, fenster-tag-genau identisch mit den 4 Adventswochenenden der korrigierten Quelle (B-10 bestätigt).

## 3. Adventsdarstellung Herne — Abweichung BESTÄTIGT (wie vom Benutzer vorhergesehen)

| Darstellung | 2026 | 2027 |
|---|---|---|
| Korrigierte Quelle (Prio 1) | 4 Advents-WE: 26.–29.11. · 03.–06.12. · 10.–13.12. · 17.–20.12. | 4 Advents-WE: 26.–28.11. · 03.–05.12. · 10.–12.12. · 17.–19.12. |
| Werkstatt-Freeze | SF05: 1 Quellzeile, 4 Zeitfenster (identisch) | SF50: 1 Quellzeile, 4 Zeitfenster (identisch) |
| **Mockup (Alt-App)** | — (kein 2026er-Advent-Event vorhanden) | **S37 mit EINER Datumzeile D235: 2027-11-26 – 2027-12-19 (Gesamtbereich)**, KOMMENTAR „Mittelaltermarkt - Ort: Schloss Strünkede" |

**Befund:** Das Mockup hat den Advent 2027 als **einen einzigen Gesamtzeitraum** erfasst, nicht als 4 Wochenenden. Bei einer Übernahme aus dem Mockup würde damit die B-10/B-12-Struktur (4 Zeitfenster) **verloren gehen**. → Regel für die Migration: **Zeitfenster stammen immer aus der Prio-1-Quelle bzw. dem Freeze, nie aus der Alt-App-Datumzeile.** Der 2026er-Advent existiert im Mockup gar nicht als Event.

## 4. Matrix-Ergebnis: 54/54 Freeze-Termine zugeordnet

Die Abgleichsmatrix (`docs/Abgleichmatrix-Termine-2026-10-04.csv`) ordnet jedem der 54 Freeze-Termine das beste Mockup-Event zu (Scoring: PLZ +3 · Name-Containment +3 · Datumsüberschneidung im selben Jahr +3; ab Score ≥3). Wichtige Befunde:

### 4.1 Jahres-/Serien-Fälle (Mockup hat nur die 2027er-Ausgabe)
| Freeze | Mockup | Lage |
|---|---|---|
| SF01 Thüringer Ritterturnier 2026 | S34 (Termine nur 2027) | 2026er-Ausgabe ohne eigenes Mockup-Event; S34 gehört eigentlich zu SF46 |
| SF06/SF07/SF08 (Weihnachtsmärkte 2026) | S38/S39/S40 (nur 2027) | dito |

### 4.2 Ein Mockup-Event deckt mehrere Freeze-Quellzeilen (Serien-Events)
| Mockup | Freeze-Termine | Veranstaltung |
|---|---|---|
| S02 Rauhnächte Dresden | SF09 · SF10 · SF54 | Rauhnächte Dez 2026 + Jan 2027 + Dez 2027 |
| M14 Burgfest (Falkenstein) | SF03 · SF27 · SF48 (+ SF02 falsch, s. 4.4) | 29. Burgfest 2026 · Mittelalter-Burgfest 2027 · 30. Burgfest 2027 |

### 4.3 Namensabweichungen Mockup ↔ Freeze (Kuratierung liegt im Freeze)
- **S37** `Mittelalter-Advent Herne` ↔ SF50 `Mittelalter- Advent (Fr.- So.)` + Gesamtbereich statt 4 Fenster (s. §3)
- **S06** `Drachen und Ritter Stolpen` ↔ SF37 `Fantasy- und Mittelalterfest` (O-04: offizieller Name)
- **S26** `Burgfest August` ↔ SF38 `Burgfest` (Ort `xxxx` Platzhalter, O-05)
- **S11** `Offener Termin April` ↔ SF17 `noch offen` / `xxxxx` (T-SF17)
- S-Events tragen durchgehend den Ortsnamen im Event-Namen (z. B. S13 `Mittelalterspektakel Rackwitz` ↔ SF20 `Mittealterspektakel`), Freeze trennt Name und Ort.

### 4.4 Matrix-Fehlzuordnungen (bewusst ausgewiesen, nicht verschwiegen)
Drei Zuordnungen beruhen nur auf Datumsüberschneidung und sind **eindeutig falsch**, da Name und PLZ abweichen:
- SF02 (Weimar 2026) → M14 (Falkenstein) — Weimar 2026 hat **kein** Mockup-Event
- SF04 (Castrop-Rauxel 2026) → F66 (`Liedermacherabend Mittelhessen`)
- SF05 (Advent Herne 2026) → K33 (`Passionskirche Berlin`)

**Schlussfolgerung:** Die 2026er-Termine sind im Mockup nur unvollständig vertreten; die Zuordnung 2026 braucht zusätzliche Kriterien oder bleibt manuell.

### 4.5 Alt-App-Termine OHNE Prio-1-Beleg (O-6-Recherchebedarf, keine Bewertung)
- **S05 `Strandkorbsilvester Göhren`** (18586) — einziges S-Event ohne Freeze-Gegenstück; Rügen-Bezug, nicht in der Sündenfrei-Liste
- **D198** (M21 Ritterturnier, 01.–03.05.2026, „Sündenfrei 2026") — 2026er Freyburg-Termin steht nicht in der korrigierten Quelle (dort nur 2027, als SF24 an M21/D199)
- **D200** (M44 Ritter und Drachen-Spektakel, 04.–06.04.2026) — ebenso ohne 2026er-Prio-1-Zeile

Diese Zeilen werden **nicht** beurteilt; sie sind Beleg dafür, dass die Alt-App mehr 2026er-Termine führt als die Prio-1-Quelle.

## 5. Offene Entscheidung (Werkstatt-DB — Änderung nur nach „ja")

Die korrigierte Quelle behob zwei Tippfehler der alten Quelle (SF20, SF27). Der Freeze bleibt unangetastet (byteidentisch, dokumentierte Alt-Schreibweise). Für die **Werkstatt-Datenbank** stellt sich die Frage:

**Option 1:** DB belässt die überlieferte Schreibweise (`Mittealterspektakel`, `Mittealter- Burgfest`) mit dokumentiertem Hinweis.
**Option 2:** DB übernimmt die korrigierte Prio-1-Schreibweise (`Mittelalterspektakel`, `Mittelalter-Burgfest`) als Kuratierung; Herkunftsvermerk „Prio-1-korrigiert 2026-10-04".

Keine Option wurde ausgeführt.

## 6. Zusammengefasste Migrationsregeln (aus diesem Befund)

1. **Termine-Stammdaten (Name, Ort, PLZ, Sternchen):** aus Prio-1-Quelle bzw. Freeze — nie aus dem Mockup-Event-Namen.
2. **Zeitfenster:** aus Prio-1/Freeze (4 Adventsfenster!), nie aus der Alt-App-Datumzeile (Gesamtbereich).
3. **Serien-Events:** 1 Alt-Event kann mehrere Quellzeilen decken (S02→3, M14→3); Zuordnung über Jahr + Fenster.
4. **2026er-Termine:** im Mockup unvollständig — Zuordnung manuell/über Zusatzkriterien.
5. **Alt-Termine ohne Prio-1-Beleg** (S05, D198, D200): getrennt führen, gekennzeichnet, nicht automatisch übernehmen (O-6-Regel).

**Ende Befundbericht B.**
