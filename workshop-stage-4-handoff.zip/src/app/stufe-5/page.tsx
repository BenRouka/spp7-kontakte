import type { Metadata } from "next";
import {
  Ban,
  Database,
  DoorClosed,
  FileCode2,
  ListChecks,
  Park,
  ShieldAlert,
  Table2,
} from "lucide-react";
import { kontaktStats, loadFreeze, terminStats } from "@/lib/freeze";
import { Badge, FieldLabel, Panel, RefChip, Section } from "@/components/ui";

export const metadata: Metadata = {
  title: "Stufe 5 · Vorbereitung · Werkstatt",
};

const SCHEMA_ENTWURF = `// ════════════════════════════════════════════════════════════════
//  ENTWURF — NICHT ANGEWENDET
//  src/db/schema.ts bleibt unverändert · Datenbank: 0 Tabellen (B-20)
//  Kein "drizzle-kit push" · Kein Import · Kein INSERT
//
//  Leitlinie (Regel 7): Die Zielstruktur spiegelt das Freeze-Paket
//  1:1 — keine Umbenennung, keine Anreicherung, keine Aufspaltung
//  von Quellzeilen (B-10).
// ════════════════════════════════════════════════════════════════

tabelle arbeitsstand_kontakte            ← arbeitsstand-kontakte.csv
  kv_id              text   pk           -- auch "STADT-PUTBUS" (Sonderdatensatz)
  region             text                -- 9 Regionen, Reihenfolge extern vorgegeben
  ort, name          text
  anschrift          text
  telefon, fax       text                -- Originalformatierung, keine Normalisierung
  email_1            text                -- Regel 5: mehrere E-Mails = Spalten
  email_2            text
  email_3            text
  web, typ           text
  prio2_chat_hinweis text                -- überschreibt nie Prio 1 (B-15)

tabelle arbeitsstand_termine_quellzeilen ← arbeitsstand-termine.csv
  sf_id              text   pk           -- SF01 … SF54 (54 Zeilen, nicht 58)
  jahr               integer
  datum_original     text                -- Originalwortlaut inkl. Sternchen
  name_original      text                -- Schreibweise wie in Quelle
  plz_ort_original   text                -- Platzhalter "xxxxx"/"xxxx" bleiben
  zeitfenster_anzahl integer
  sternchen          text                -- Qualitätsmarker "kein" | "*" | "**" (B-11)
  hinweis            text

tabelle arbeitsstand_zeitfenster         ← Spalte zeitfenster_iso (variabel 1–4 Felder)
  sf_id              text   fk → arbeitsstand_termine_quellzeilen
  nr                 smallint            -- 1..4 (Herne-Advent: 4 Fenster, 1 Quellzeile)
  von                date
  bis                date
  -- 60 Zeilen gesamt: 12 (2026) + 48 (2027)

tabelle beschlussverzeichnis             ← beschlussverzeichnis.csv · VERBINDLICH
  beschluss_id       text   pk           -- B-01 … B-20
  bereich, titel     text
  prio_1_basis       text
  prio_2_ergaenzung  text
  massnahme          text
  status             text                -- "entschieden" | "provisorisch"`;

const IST_ZUSTAND = [
  "Datenbank: 0 Tabellen — unverändert (B-20).",
  "src/db/schema.ts: leerer Einstiegspunkt, keine pgTable-Definition angelegt.",
  "Kein drizzle-kit push, keine Migration, kein Importlauf, kein einziges INSERT.",
  "Quellen und Archive: byteidentisch, PRUEFSUMMEN.sha256 belegt es (B-13/B-14).",
];

const FREIGABE = [
  "Ohne mein ausdrückliches Ja wird nichts in Quellen, Archive oder Datenbank geschrieben. — Das Gate für Stufe 5:",
  "1. Schema steht (wohlüberlegt, ohne A/B-Varianten).",
  "2. Ausdrückliches Ja zur Schema-Definition.",
  "3. Ausdrückliches Ja zum Import der Freeze-Dateien.",
];

const GEPARKT = [
  { id: "B-08", text: "K34 Tourismus-Service Rügen — ohne Zuordnung, Parkplatz, keine Modelländerung (provisorisch)." },
  { id: "B-18", text: "41 weitere Befund-IDs aus der 65er-Liste der Variante A — nicht gelesen, nicht entschieden (provisorisch)." },
  { id: "B-19", text: "Flyer-Audit 79 ↔ 158 — Zahlen aus Variante B, nie nachgezählt (provisorisch)." },
  { id: "B-13", text: "Archiv A: 6 fehlende Manifest-Dateien, 8 CSVs ohne UTF-8-BOM — Option a: unangetastet lassen (entschieden)." },
  { id: "B-14", text: "ZIPs var a2 / var b2 — bewusst nicht geprüft, keine zweite A/B-Gabelung (entschieden)." },
];

export default function Stufe5Page() {
  const { header, kontakte, termine, beschluesse, pruefsummen } = loadFreeze();
  const kStats = kontaktStats(kontakte);
  const t26 = terminStats(termine, "2026");
  const t27 = terminStats(termine, "2027");
  const fensterGesamt = t26.zeitfenster + t27.zeitfenster;

  const lademengen = [
    {
      quelle: "arbeitsstand-kontakte.csv",
      ziel: "arbeitsstand_kontakte",
      menge: `${kStats.datensaetze} Zeilen`,
      detail: `${kStats.kvGekennzeichnet} KV + ${kStats.sonderdatensaetze} Sonder`,
    },
    {
      quelle: "arbeitsstand-termine.csv",
      ziel: "arbeitsstand_termine_quellzeilen",
      menge: `${termine.length} Zeilen`,
      detail: "B-10: keine Aufteilung — nicht 58",
    },
    {
      quelle: "arbeitsstand-termine.csv · zeitfenster_iso",
      ziel: "arbeitsstand_zeitfenster",
      menge: `${fensterGesamt} Zeilen`,
      detail: `2026: ${t26.zeitfenster} · 2027: ${t27.zeitfenster}`,
    },
    {
      quelle: "beschlussverzeichnis.csv",
      ziel: "beschlussverzeichnis",
      menge: `${beschluesse.length} Zeilen`,
      detail: "verbindlich",
    },
  ];

  return (
    <>
      <div className="border-b border-line pb-8">
        <p className="font-mono text-[10.5px] font-semibold uppercase tracking-[0.24em] text-amber">
          Nächster Schritt · §7.4 — vorbereiten, nicht ausführen
        </p>
        <h1 className="mt-3 flex flex-wrap items-center gap-3 text-[30px] font-semibold tracking-tight text-ink sm:text-[38px]">
          <Database className="h-7 w-7 text-lime" />
          Stufe 5 · Import — vorbereitet, nicht ausgeführt
        </h1>
        <div className="mt-4 flex flex-wrap gap-2">
          <Badge tone="warn">
            <DoorClosed className="h-3 w-3" />
            Gate geschlossen — wartet auf ausdrückliches Ja
          </Badge>
          <Badge tone="mute">Datenbank: 0 Tabellen</Badge>
          <Badge tone="mute">schema.ts: unangetastet</Badge>
        </div>
      </div>

      {/* GATE */}
      <Section
        eyebrow="Freigabebedingung"
        title="Das Gate — nichts schreibt ohne Ja"
        className="mt-10"
      >
        <Panel className="border-amber/30 bg-amber/[0.04]">
          <div className="flex items-start gap-3">
            <ShieldAlert className="mt-0.5 h-5 w-5 shrink-0 text-amber" />
            <div className="space-y-2 text-[13px] leading-relaxed text-ink-soft">
              {FREIGABE.map((line, i) => (
                <p key={i} className={i === 0 ? "font-semibold text-amber" : undefined}>
                  {line}
                </p>
              ))}
            </div>
          </div>
        </Panel>
      </Section>

      <div className="grid gap-6 lg:grid-cols-2">
        {/* IST-ZUSTAND */}
        <Section eyebrow="Befund" title="Ist-Zustand — belegt, nicht verändert">
          <Panel>
            <ul className="space-y-2.5">
              {IST_ZUSTAND.map((z, i) => (
                <li key={i} className="flex items-start gap-2.5 text-[12.5px] leading-relaxed text-ink-soft">
                  <Ban className="mt-0.5 h-3.5 w-3.5 shrink-0 text-muted" />
                  {z}
                </li>
              ))}
            </ul>
          </Panel>
        </Section>

        {/* INTEGRITÄT */}
        <Section eyebrow="sha256" title="Quelldateien — byteidentisch verifiziert">
          <Panel>
            <ul className="space-y-1.5">
              {pruefsummen.map((p) => (
                <li
                  key={p.file}
                  className="flex items-center justify-between gap-3 rounded border border-line-soft bg-base/50 px-2.5 py-1.5"
                >
                  <span className="truncate font-mono text-[11px] text-ink-soft">{p.file}</span>
                  <span className="flex items-center gap-2 font-mono text-[10px] text-muted">
                    {p.hash.slice(0, 16)}…
                    <span className="font-semibold uppercase text-lime">OK</span>
                  </span>
                </li>
              ))}
            </ul>
            <p className="mt-2.5 text-[11px] leading-relaxed text-muted">
              Live-Gegenprobe läuft auf der Übersichtsseite über /api/freeze/verify.
            </p>
          </Panel>
        </Section>
      </div>

      {/* SCHEMA-ENTWURF */}
      <Section
        eyebrow="Vorbereitet · nicht angewendet"
        title="Zielstruktur-Entwurf — spiegelt das Freeze-Paket 1:1"
        desc="Keine A/B-Varianten, keine Vorannahmen: eine Struktur, abgeleitet ausschließlich aus den vier Freeze-Dateien und den Beschlüssen B-10, B-11, B-15."
        aside={
          <Badge tone="warn" className="mb-1">
            <FileCode2 className="h-3 w-3" /> ENTWURF
          </Badge>
        }
      >
        <Panel className="p-0">
          <div className="border-b border-line px-4 py-2.5">
            <span className="font-mono text-[10.5px] uppercase tracking-[0.16em] text-muted">
              arbeitsentwurf.schema.ts — liegt NICHT in src/db/schema.ts
            </span>
          </div>
          <pre className="max-h-[560px] overflow-auto p-4 font-mono text-[11px] leading-[1.65] text-ink-soft">
            {SCHEMA_ENTWURF}
          </pre>
        </Panel>
      </Section>

      {/* MAPPING */}
      <Section
        eyebrow="Feldzuordnung"
        title="CSV-Köpfe → Zielspalten"
        desc="Direkt aus den Dateiköpfen gelesen — nichts umbenannt, nichts ergänzt."
      >
        <div className="grid gap-4 lg:grid-cols-3">
          {(
            [
              { name: "kontakte", kopf: header.kontakte, pk: "kv_id" },
              { name: "termine", kopf: header.termine, pk: "sf_id" },
              { name: "beschluesse", kopf: header.beschluesse, pk: "beschluss_id" },
            ] as const
          ).map((t) => (
            <Panel key={t.name}>
              <p className="mb-3 flex items-center gap-2 font-mono text-[11px] font-semibold uppercase tracking-[0.14em] text-lime">
                <Table2 className="h-3.5 w-3.5" />
                {t.name}
                <span className="text-muted">({t.kopf.length} Spalten)</span>
              </p>
              <ul className="space-y-1">
                {t.kopf.map((spalte) => (
                  <li
                    key={spalte}
                    className="flex items-center justify-between gap-2 rounded border border-line-soft bg-base/50 px-2 py-1"
                  >
                    <span className="font-mono text-[11px] text-ink-soft">{spalte}</span>
                    <span className="flex items-center gap-1.5">
                      {spalte === t.pk ? (
                        <span className="rounded bg-lime/15 px-1 font-mono text-[9px] font-semibold text-lime">
                          PK
                        </span>
                      ) : null}
                      <span className="font-mono text-[10px] text-muted">
                        {spalte === "jahr" || spalte === "zeitfenster_anzahl"
                          ? "integer"
                          : "text"}
                      </span>
                    </span>
                  </li>
                ))}
              </ul>
              {t.name === "termine" ? (
                <p className="mt-2.5 text-[10.5px] leading-relaxed text-muted">
                  <RefChip>zeitfenster_iso</RefChip> ist variabel (1–4 Felder je Zeile:
                  SF05, SF50) und wird in die Kindtabelle{" "}
                  <span className="font-mono text-amber-soft">arbeitsstand_zeitfenster
                  </span>{" "}
                  überführt (von/bis als date). Die Quellzeile bleibt eine Zeile (B-10).
                </p>
              ) : null}
            </Panel>
          ))}
        </div>
      </Section>

      {/* LADEMENGEN */}
      <Section
        eyebrow="Erwartete Lademengen"
        title="Was importiert würde — nach Freigabe"
        desc="Aus den Dateien gezählt, nicht geschätzt. Diese Zahlen werden beim Importlauf gegen die Zieltabelle geprobt."
      >
        <Panel className="p-0">
          <div className="overflow-x-auto">
            <table className="w-full min-w-[640px] text-left">
              <thead>
                <tr className="border-b border-line">
                  {["Quelldatei", "Zieltabelle", "Lademenge", "Bedingung / Detail"].map((h) => (
                    <th
                      key={h}
                      className="px-4 py-2.5 font-mono text-[9.5px] font-semibold uppercase tracking-[0.16em] text-muted"
                    >
                      {h}
                    </th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {lademengen.map((l) => (
                  <tr key={l.ziel} className="border-b border-line-soft last:border-b-0">
                    <td className="px-4 py-2.5 font-mono text-[11px] text-ink-soft">{l.quelle}</td>
                    <td className="px-4 py-2.5 font-mono text-[11px] text-lime-soft">{l.ziel}</td>
                    <td className="px-4 py-2.5 font-mono text-[11px] font-semibold text-lime">{l.menge}</td>
                    <td className="px-4 py-2.5 text-[11.5px] text-muted">{l.detail}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </Panel>
      </Section>

      {/* GEPARKT */}
      <Section
        eyebrow="Außerhalb von Stufe 5"
        title="Geparkte Punkte — bleiben geparkt"
        desc="Diese Punkte sind ausdrücklich ausgeschlossen und werden durch die Vorbereitung nicht angetastet."
      >
        <Panel className="border-line">
          <ul className="space-y-2.5">
            {GEPARKT.map((g) => (
              <li key={g.id} className="flex items-start gap-2.5 text-[12.5px] leading-relaxed text-ink-soft">
                <Park className="mt-0.5 h-4 w-4 shrink-0 text-muted" />
                <span>
                  <span className="font-mono text-[11px] font-semibold text-amber-soft">{g.id}</span>{" "}
                  {g.text}
                </span>
              </li>
            ))}
          </ul>
          <p className="mt-4 flex items-start gap-2 rounded border border-lime/25 bg-lime/[0.04] p-3 text-[12.5px] leading-relaxed text-lime-soft">
            <ListChecks className="mt-0.5 h-4 w-4 shrink-0 text-lime" />
            <span>
              Einziger nächster Schritt: Schema stehen lassen, Freigabe einholen. Erst nach
              dem ausdrücklichen Ja wird das Schema angewendet — und erst nach dem zweiten
              Ja importiert.
            </span>
          </p>
        </Panel>
      </Section>
    </>
  );
}
