import { contactClarifications, contactReviewVersion, missingContactMarker } from "@/lib/contact-hierarchy";

export type NormalizationFieldRole = "schluessel" | "herkunft" | "original" | "normiert" | "status" | "relation";
export type NormalizationField = {
  name: string;
  label: string;
  type: "text" | "integer" | "date" | "enum";
  required: boolean;
  role: NormalizationFieldRole;
  description: string;
  example: string;
  values?: string[];
};
export type NormalizationFile = {
  id: "gruppen" | "kurverwaltungen" | "kontaktwege" | "termine" | "zeitfenster";
  filename: string;
  label: string;
  kind: "kern" | "zuordnung";
  expectedRows: number;
  rowMeaning: string;
  purpose: string;
  fields: NormalizationField[];
};

const field = (
  name: string,
  label: string,
  type: NormalizationField["type"],
  required: boolean,
  role: NormalizationFieldRole,
  description: string,
  example: string,
  values?: string[],
): NormalizationField => ({ name, label, type, required, role, description, example, values });

export const normalizationFiles: NormalizationFile[] = [
  {
    id: "gruppen",
    filename: "kurverwaltungen-gruppen.csv",
    label: "Parent-Gruppen",
    kind: "kern",
    expectedRows: 2,
    rowMeaning: "bisher zwei ausdrücklich benannte Parent-Gruppen",
    purpose: "Ostseebad Mönchgut und Ostseebad Baabe als Standortgruppen aus Nutzervorgabe. Keine rechtliche Organisationshierarchie und keine automatisch abgeleiteten weiteren Parents.",
    fields: [
      field("gruppe_id", "Parent-ID", "text", true, "schluessel", "Stabile Gruppen-ID; die sichtbare Nummer ist kein Schlüssel.", "KVG01"),
      field("name_original", "Name · Nutzervorgabe", "text", true, "original", "Gruppenname aus der ausdrücklich gelieferten Zuordnung.", "Ostseebad Mönchgut"),
      field("name_normiert", "Name · normiert", "text", true, "normiert", "Zusätzliche Vergleichsschreibweise, Original unverändert.", "Ostseebad Mönchgut"),
      field("quelle_art", "Quellenart", "enum", true, "herkunft", "Herkunft der Parent-Zuordnung, nicht bloß gleicher Ortsname.", "nutzer", ["md", "nutzer"]),
      field("quelle_ref", "Quellenbeleg", "text", true, "herkunft", "Verweist auf die Nutzerklärung oder eine spätere ausdrücklich belegte Quelle.", contactClarifications.sourceId),
      field("normierungsstatus", "Normierungsstatus", "enum", true, "status", "Bearbeitungsstatus; keine rechtliche Verifikation.", "offen", ["offen", "normiert", "pruefen"]),
    ],
  },
  {
    id: "kurverwaltungen",
    filename: "kurverwaltungen.csv",
    label: "Kurverwaltungen",
    kind: "kern",
    expectedRows: 32,
    rowMeaning: "eine Zeile je Adressblock",
    purpose: "Bewahrt 32 MD-Standorte. Belegte Außenstellen werden über parent_id getrennt zugeordnet. Zwei Namen an derselben Adresse bleiben originale Namensfelder; unbekannte Beziehungen werden nicht erfunden.",
    fields: [
      field("kurverwaltung_id", "Standort-ID", "text", true, "schluessel", "Stabiler Schlüssel; Ortsnamen und Anzeigeordnungen sind nicht eindeutig.", "KV12"),
      field("parent_id", "Parent-ID", "text", false, "relation", "Verweist auf gruppe_id. Nur bei belegter Zuordnung; sonst - und Hierarchiestatus offen.", "KVG01"),
      field("parent_quelle_ref", "Zuordnungsbeleg", "text", false, "herkunft", "Herkunft der Parent/Child-Beziehung; nicht automatisch aus identischer E-Mail abgeleitet.", contactClarifications.sourceId),
      field("hierarchiestatus", "Hierarchiestatus", "enum", true, "status", "Zugeordnet, wenn ausdrücklich belegt; sonst offen.", "zugeordnet", ["zugeordnet", "offen"]),
      field("quelle_datei", "Quelldatei", "text", true, "herkunft", "Unveränderter Dateiname der Referenzquelle.", "Kurverwaltungen_2025.md"),
      field("quelle_zeile_von", "Quellzeile von", "integer", true, "herkunft", "Erste Zeile des Originalblocks.", "9"),
      field("quelle_zeile_bis", "Quellzeile bis", "integer", true, "herkunft", "Letzte Zeile des Originalblocks.", "15"),
      field("bereich_original", "Bereich · Original", "text", true, "original", "Übergeordnete Markdown-Überschrift unverändert.", "Rund um die Granitz"),
      field("ortsueberschrift_original", "Ortsüberschrift · Original", "text", true, "original", "Lokale Markdown-Überschrift unverändert; kann doppelt vorkommen.", "Vitte"),
      field("name_haupt_original", "Hauptname · Original", "text", true, "original", "Erste fett gesetzte Namenszeile unverändert.", "Kurverwaltung Mönchgut"),
      field("name_zusatz_original", "Zusatzname · Original", "text", false, "original", "Zweite fett gesetzte Namenszeile; leer, wenn nicht vorhanden.", "Tourist-Information Middelhagen"),
      field("strasse_original", "Straße · Original", "text", true, "original", "Vollständige Straßenzeile unverändert.", "Dorfstraße 4"),
      field("plz_ort_original", "PLZ / Ort · Original", "text", true, "original", "Vollständige PLZ-/Ortszeile unverändert.", "18586 Ostseebad Mönchgut OT Middelhagen"),
      field("hinweis_original", "Hinweis · Original", "text", false, "original", "Separater oder klar abtrennbarer Quellenhinweis; sonst leer.", "keine Zimmervermittlung"),
      field("name_haupt_normiert", "Hauptname · normiert", "text", true, "normiert", "Zusätzliche Vergleichsschreibweise; Original bleibt maßgeblich.", "Kurverwaltung Mönchgut"),
      field("name_zusatz_normiert", "Zusatzname · normiert", "text", false, "normiert", "Zusätzliche Vergleichsschreibweise des Zusatznamens.", "Tourist-Information Middelhagen"),
      field("strasse_normiert", "Straße · normiert", "text", true, "normiert", "Straßenname ohne stillschweigende Ergänzungen.", "Dorfstraße"),
      field("hausnummer_normiert", "Hausnummer · normiert", "text", false, "normiert", "Nur abtrennen, wenn die Quelle eindeutig ist.", "4"),
      field("adresszusatz_normiert", "Adresszusatz · normiert", "text", false, "normiert", "Klammer- oder Gebäudeteil; leer, wenn nicht vorhanden.", "Haus des Gastes"),
      field("plz_normiert", "PLZ · normiert", "text", true, "normiert", "Fünfstellige PLZ; als Text, damit führende Nullen erhalten bleiben.", "18586"),
      field("ort_normiert", "Ort · normiert", "text", true, "normiert", "Ort aus derselben Quellenzeile; keine externe Anreicherung.", "Ostseebad Mönchgut"),
      field("ortsteil_normiert", "Ortsteil · normiert", "text", false, "normiert", "Nur bei ausdrücklichem OT-Hinweis; Schrägstriche nicht automatisch deuten.", "Middelhagen"),
      field("hinweis_normiert", "Hinweis · normiert", "text", false, "normiert", "Lesbare Zusatzangabe, ohne den Sinn zu erweitern.", "keine Zimmervermittlung"),
      field("quellenstand", "Quellenstand", "text", true, "herkunft", "Standangabe aus der Quelle.", "2025"),
      field("haftungshinweis", "Haftungshinweis", "text", true, "herkunft", "Hinweis der Quelle unverändert.", "Alle Angaben ohne Gewähr"),
      field("normierungsstatus", "Normierungsstatus", "enum", true, "status", "Bearbeitungsstatus, keine Aussage zur fachlichen Richtigkeit.", "offen", ["offen", "normiert", "pruefen"]),
    ],
  },
  {
    id: "kontaktwege",
    filename: "kurverwaltungen-kontaktwege.csv",
    label: "Kontaktwege",
    kind: "zuordnung",
    expectedRows: 122,
    rowMeaning: "119 originale Kontaktwerte plus drei ausdrückliche Nutzerergänzungen",
    purpose: "Ein Wert je Standort und Kontaktweg: 119 MD-Werte bleiben erhalten; Website und E-Mail Middelhagen sowie Telefon Thiessow werden als Nutzerwerte geführt. - ist kein Kontaktwert und erzeugt keine Kontaktweg-Zeile.",
    fields: [
      field("kontaktweg_id", "Kontaktweg-ID", "text", true, "schluessel", "Stabiler Schlüssel für einen einzelnen Kanal.", "KW001"),
      field("kurverwaltung_id", "Standort-ID", "text", true, "relation", "Gehört zum konkreten Child-Standort, nicht automatisch zum Parent oder Nachbarstandort.", "KV13"),
      field("quelle_art", "Quellenart", "enum", true, "herkunft", "MD-Original oder ausdrücklich ergänzter Nutzerwert.", "nutzer", ["md", "nutzer"]),
      field("quelle_ref", "Quellenbeleg", "text", true, "herkunft", "Datei/Quellstelle oder dokumentierte Nutzerklärung.", contactClarifications.sourceId),
      field("quelle_zeile", "MD-Quellzeile", "integer", false, "herkunft", "Bei MD-Werten die ursprüngliche Zeile; bei einer Nutzerergänzung nicht vorhanden. Intern null, Anzeige -.", "15"),
      field("reihenfolge", "Reihenfolge", "integer", true, "herkunft", "Reihenfolge gleicher Kanäle derselben Stelle.", "1"),
      field("typ", "Typ", "enum", true, "normiert", "Kontaktart; kein Sammelfeld und keine Vererbung.", "telefon", ["telefon", "fax", "email", "internet"]),
      field("wert_original", "Wert · Herkunftsoriginal", "text", true, "original", "Originalwert seiner tatsächlichen Quelle, Nutzer oder MD.", "+49 38308 66010"),
      field("wert_md_original", "Wert · MD-Original", "text", false, "original", "Ergänzungen füllen dieses Feld nicht rückwirkend. Fehlte der Wert im MD, bleibt es intern leer.", "-"),
      field("wert_normiert", "Wert · normiert", "text", true, "normiert", "Zusätzlicher Vergleichswert; keine externe Verifikation.", "+493830866010"),
      field("telefon_international", "Telefon · international", "text", false, "normiert", "Zusätzliche +49-Form nur für die freigegebene DE-Quelle; kein blindes Ersetzen vorhandener Länderkennungen.", "+493838807780"),
      field("normalisierungsregel", "Normalisierungsregel", "enum", true, "status", "Dokumentiert die freigegebene Umrechnung; Original immer erhalten.", "de_49_freigegeben", ["de_49_freigegeben", "international_bereits_in_quelle", "international_00_zu_plus", "fax_original", "email_klein", "domain_klein"]),
      field("normierungsstatus", "Normierungsstatus", "enum", true, "status", "Bearbeitungsstatus des Werts, keine Erreichbarkeitsprüfung.", "offen", ["offen", "normiert", "pruefen"]),
    ],
  },
  {
    id: "termine",
    filename: "suendenfrei-termine.csv",
    label: "Sündenfrei-Termine",
    kind: "kern",
    expectedRows: 54,
    rowMeaning: "eine Zeile je TAB-getrennter Quellzeile",
    purpose: "Erhält exakt 9 Quellzeilen aus 2026 und 45 aus 2027; Sternchenpositionen bleiben nachvollziehbar.",
    fields: [
      field("termin_id", "Termin-ID", "text", true, "schluessel", "Stabiler Schlüssel in Quellenreihenfolge.", "ST01"),
      field("quelle_datei", "Quelldatei", "text", true, "herkunft", "Unveränderter Dateiname der Referenzquelle.", "Termine_2027_suendenfrei.txt"),
      field("quelle_zeile", "Quellzeile", "integer", true, "herkunft", "Physische Zeilennummer der Originaldatei.", "56"),
      field("quelljahr", "Quelljahr", "integer", true, "herkunft", "Jahr aus der Datumsangabe.", "2027"),
      field("datum_original", "Datum · Original", "text", true, "original", "Erste TAB-Spalte unverändert, einschließlich Sternchen.", "1. - 4. Advent 2027*"),
      field("veranstaltung_original", "Veranstaltung · Original", "text", true, "original", "Zweite TAB-Spalte unverändert, einschließlich Tippfehlern und Sternchen.", "Mittelalter- Advent (Fr.- So.)"),
      field("ort_original", "PLZ / Ort · Original", "text", true, "original", "Dritte TAB-Spalte unverändert, einschließlich Platzhaltern und Sternchen.", "44629 Herne/ Schloss Strünkede"),
      field("sternchen_datum", "Sternchen · Datum", "integer", true, "herkunft", "Anzahl der Sternchen in der Original-Datumsspalte.", "1"),
      field("sternchen_veranstaltung", "Sternchen · Veranstaltung", "integer", true, "herkunft", "Anzahl der Sternchen in der Original-Namensspalte.", "0"),
      field("sternchen_ort", "Sternchen · Ort", "integer", true, "herkunft", "Anzahl der Sternchen in der Original-Ortsspalte.", "0"),
      field("quellstatus", "Quellstatus", "enum", true, "status", "Aus Sternchen abgeleitet; nicht markiert bedeutet nicht bestätigt.", "unbestaetigt", ["nicht_markiert", "unbestaetigt"]),
      field("zeitmodell", "Zeitmodell", "enum", true, "normiert", "Verweist auf ein oder vier Einträge in der Zeitfensterdatei.", "vier_adventswochenenden", ["ein_zeitfenster", "vier_adventswochenenden"]),
      field("veranstaltung_normiert", "Veranstaltung · normiert", "text", true, "normiert", "Zusätzliche Vergleichsschreibweise; Original bleibt erhalten.", "Mittelalter-Advent (Fr.–So.)"),
      field("plz_normiert", "PLZ · normiert", "text", false, "normiert", "Fünfstellige PLZ als Text; leer bei xxxx/xxxxx.", "44629"),
      field("ort_normiert", "Ort · normiert", "text", false, "normiert", "Ort ohne stillschweigende Ergänzungen.", "Herne"),
      field("spielort_normiert", "Spielort · normiert", "text", false, "normiert", "Zusatz nach Schrägstrich oder eindeutigem Quellenhinweis.", "Schloss Strünkede"),
      field("veranstaltung_status", "Veranstaltungsstatus", "enum", true, "status", "Kennzeichnet den echten Platzhalter „noch offen“.", "vorhanden", ["vorhanden", "offen"]),
      field("ort_status", "Ortsstatus", "enum", true, "status", "Kennzeichnet xxxx/xxxxx als offen; keine erfundene PLZ.", "vorhanden", ["vorhanden", "offen"]),
      field("quellenstand", "Quellenstand", "text", false, "herkunft", "Standangabe der 2027-Liste; für 2026 bleibt das Feld leer, weil dort kein Stand genannt ist.", "22. September 2026"),
      field("normierungsstatus", "Normierungsstatus", "enum", true, "status", "Bearbeitungsstatus, getrennt vom Quellstatus.", "offen", ["offen", "normiert", "pruefen"]),
    ],
  },
  {
    id: "zeitfenster",
    filename: "suendenfrei-zeitfenster.csv",
    label: "Termin-Zeitfenster",
    kind: "zuordnung",
    expectedRows: 60,
    rowMeaning: "eine Zeile je durchgehendem Zeitraum oder Adventswochenende",
    purpose: "Hält einen Quelltermin mit mehreren Zeitfenstern korrekt abbildbar; 52 normale Zeilen plus 8 Adventsfenster.",
    fields: [
      field("zeitfenster_id", "Zeitfenster-ID", "text", true, "schluessel", "Aus Termin-ID und laufender Nummer gebildet.", "ST45-Z01"),
      field("termin_id", "Termin-ID", "text", true, "relation", "Verweist auf genau eine der 54 Terminzeilen.", "ST45"),
      field("laufnummer", "Laufnummer", "integer", true, "relation", "1 bei normalen Terminen, 1–4 beim Advent.", "1"),
      field("beginn", "Beginn", "date", true, "normiert", "ISO-Datum YYYY-MM-DD.", "2027-11-26"),
      field("ende", "Ende", "date", true, "normiert", "Inklusives ISO-Enddatum YYYY-MM-DD.", "2027-11-28"),
      field("zeitraum_typ", "Zeitraumtyp", "enum", true, "normiert", "Durchgehender Quellzeitraum oder getrenntes Adventswochenende.", "adventswochenende", ["durchgehend", "adventswochenende"]),
      field("datumsherkunft", "Datumsherkunft", "enum", true, "status", "Unterscheidet Quellenübertragung und Kalenderberechnung.", "berechnet", ["quelle", "berechnet"]),
      field("berechnungsregel", "Berechnungsregel", "enum", false, "status", "Nur für berechnete Adventsfenster; sonst leer.", "kirchenregel_advent", ["kirchenregel_advent"]),
      field("wochentage_original", "Wochentage · Original", "text", false, "original", "Do.–So. oder Fr.–So. aus der Advents-Quellzeile; sonst leer.", "Fr.- So."),
      field("normierungsstatus", "Normierungsstatus", "enum", true, "status", "Bearbeitungsstatus des Zeitfensters; bestätigt nicht den Termin.", "offen", ["offen", "normiert", "pruefen"]),
    ],
  },
];

export const normalizationRules = [
  "MD-Originale werden nie überschrieben. Nutzerkorrekturen tragen eigene Herkunft; Telefonableitungen eine eigene Regel.",
  "Belegte Parents und Child-Standorte werden getrennt geführt. Getrennte Adressen bleiben eigenständige Children, auch bei gleicher E-Mail oder Telefonnummer.",
  "Zwei Namenszeilen an derselben Adresse allein beweisen keine Außenstelle. Andere Hierarchien bleiben offen statt aus Ortsnamen geraten zu werden.",
  "Fehlende Angaben erscheinen als -. Intern bleiben sie null mit Fehlstatus; originale Abwesenheit wird nicht als Quellenwert umgeschrieben.",
  "Keine automatische Kontaktvererbung: Baabes Infopavillion erhält weder E-Mail noch Fax noch Internet von der Kurverwaltung.",
  "Für diese deutsche/Rügen-Quelle ist die zusätzliche +49-Telefonform freigegeben. Die führende nationale 0 entfällt; Original bleibt erhalten. Keine Erreichbarkeitsprüfung.",
  "www-Adressen behalten ihre ursprüngliche Form; http/https wird weiterhin nicht angenommen.",
  "Nicht markiert ist kein Verifikationsnachweis; Quellen-/Ergänzungsstatus und Normierungsstatus bleiben getrennt.",
  "Ein Quelltermin bleibt ein Termin, auch wenn vier getrennte Adventszeitfenster dazugehören.",
  "Straße, Hausnummer, Ort und Spielort werden nur bei eindeutiger Quelle getrennt; sonst Status pruefen.",
] as const;

export const normalizationDecisions = [
  {
    id: "S2-1",
    title: "Fünf CSV-Dateien mit getrennten Parents",
    recommendation: "ja", status: "vorschlag",
    reason: "Zusätzliche Gruppen-Datei zu den vier bisherigen Vorlagen. 32 Standorte und 54 Termine bleiben erhalten; bisher zwei Parents sind ausdrücklich benannt. Vollständiger Aufbau noch zu bestätigen.",
  },
  {
    id: "S2-2",
    title: "ASCII-Feldnamen in snake_case",
    recommendation: "ja", status: "vorschlag",
    reason: "Technische Feldnamen konsistent führen; sichtbare deutsche Bezeichnungen bleiben in Dokumentation und App.",
  },
  {
    id: "S2-3",
    title: "Zusätzliche internationale Telefonform +49",
    recommendation: "ja", status: "bestaetigt",
    reason: "Das Nutzer-ja gilt für die zusätzliche DE-Form: (0 38 38) 80 77 80 → +49 3838 807780. Keine globale Länderannahme und kein Überschreiben des Originals.",
  },
  {
    id: "S2-4",
    title: "URL-Protokoll nicht automatisch ergänzen",
    recommendation: "ja", status: "vorschlag",
    reason: "Die Telefonfreigabe bestätigt nicht zugleich https. www-Adressen bleiben vorerst so wie geliefert.",
  },
  {
    id: "S2-5",
    title: "Fehlende Werte als - anzeigen",
    recommendation: "ja", status: "bestaetigt",
    reason: "In Anzeige und späteren normierten CSV-Feldern -, intern null und Fehlstatus. - wird kein Kontaktwert und Originalquellen bleiben leer, wenn nichts genannt war.",
  },
  {
    id: "S2-6",
    title: "Parent/Child für Mönchgut und Baabe",
    recommendation: "ja", status: "bestaetigt",
    reason: "Zwei Parent-Gruppen, jeweils zwei getrennte Standorte. Keine automatische Wertvererbung an Außenstellen.",
  },
] as const;

export const normalizationProposal = {
  version: "spaltenvorschlag-v2",
  status: "vorschlag",
  generatedFrom: ["Kurverwaltungen_2025.md", "Termine_2027_suendenfrei.txt", contactClarifications.sourceId],
  databaseChanged: false,
  originalSourcesChanged: false,
  stage2Started: false,
  coreRows: { gruppen: 2, kurverwaltungen: 32, termine: 54 },
  relationRows: { kontaktwege: 122, zeitfenster: 60 },
  contactClarification: {
    version: contactReviewVersion,
    scope: "vier_beispielstandorte",
    sourceId: contactClarifications.sourceId,
    addedValues: 3,
    remainingMissingEmails: ["Infopavillion KV Baabe (außer Winter)"],
    groups: contactClarifications.groups,
    missingMarker: missingContactMarker,
    phoneInternationalApproved: true,
    phoneRegion: "DE",
    contactInheritance: false,
    unprovenHierarchy: "offen",
  },
  sourceAudit: {
    addressBlocks: 32,
    boldNameLines: 36,
    twoNameBlocks: 4,
    contactChannels: { telefon: 31, fax: 29, internet: 28, email: 31, total: 119 },
    missingEmailBlocks: ["Infopavillion KV Baabe (außer Winter)", "Kurverwaltung Mönchgut / Tourist-Information Middelhagen"],
    discrepancy: "Der alte Handoff nannte fünf Doppel-Namensblöcke, nur eine fehlende E-Mail und daraus 120 Kontaktwege. Die Rohquelle belegt vier Doppel-Namensblöcke, zwei Blöcke ohne E-Mail und 119 Kontaktwege.",
  },
  files: normalizationFiles,
  rules: normalizationRules,
  decisions: normalizationDecisions,
} as const;

export function getNormalizationFile(id: string | null) {
  return normalizationFiles.find((file) => file.id === id) ?? null;
}

function csvCell(value: string) {
  const protectedValue = /^[=+@-]/.test(value) ? `'${value}` : value;
  return `"${protectedValue.replaceAll('"', '""')}"`;
}

export function normalizationHeaderCsv(file: NormalizationFile) {
  return "\uFEFF" + file.fields.map((item) => csvCell(item.name)).join(";") + "\r\n";
}

export function normalizationMarkdown() {
  const lines = [
    "# Stufe 2 · Vorschlag zum CSV-Spaltenaufbau",
    "",
    "**Status: nur Vorschlag — keine Datenzeilen erzeugt, keine Datenbankänderung.**",
    "",
    "> Vorsicht: Parent/Child ergänzt den vorgeschlagenen Aufbau um eine fünfte CSV-Datei. Das Datenbankschema bleibt unverändert; vollständige Normierung ist noch nicht gestartet.",
    "",
    "## Fünf vorgeschlagene Dateien",
    "",
    "- `kurverwaltungen-gruppen.csv`: bisher zwei ausdrücklich benannte Parents (Mönchgut und Baabe); andere Parents nicht geraten.",
    "- `kurverwaltungen.csv`: 32 Adressblöcke bleiben 32 Standortzeilen mit parent_id und Hierarchie-Beleg.",
    "- `kurverwaltungen-kontaktwege.csv`: 119 MD-Werte plus Website und E-Mail Middelhagen sowie Telefon Thiessow = 122. Keine Übertragung gleicher Werte auf andere Standorte.",
    "- `suendenfrei-termine.csv`: 54 TAB-getrennte Quellzeilen bleiben 54 Kernzeilen.",
    "- `suendenfrei-zeitfenster.csv`: 60 Zeitfenster; insbesondere je vier Wochenenden für die zwei Adventszeilen.",
    "",
    "## Korrigierte Quellenzählung", "",
    "- 32 Adressblöcke aus 36 fett gesetzten Namenszeilen; vier Blöcke haben einen direkt folgenden Zusatznamen.",
    "- 119 Kontaktwege: 31 Telefon, 29 Fax, 28 Internet und 31 E-Mail.",
    "- Im MD sind zwei Blöcke ohne E-Mail: Infopavillion KV Baabe sowie Mönchgut/Middelhagen. Der Infopoint Sellin enthält zwei E-Mail-Zeilen.",
    "- Deine Ergänzung liefert Middelhagens E-Mail und Website sowie Thiessows Telefon. Nur in der ergänzten Arbeitsebene bleibt eine E-Mail-Lücke: Infopavillion KV Baabe. Keine automatische Übernahme von willkommen@baabe.de.",
    "- Die Nutzerzuordnung und vier Beispielstandorte sind in KONTAKTKLAERUNG.md / kontaktklaerung-beispiele.json dokumentiert. Die vollständigen CSV-Datenzeilen sind noch nicht erzeugt.",
    "- Damit sind die alten Angaben ‚fünf Doppel-Namensblöcke‘, ‚nur eine fehlende E-Mail‘ und ‚120 Kontaktwege‘ überholt.",
    "",
    "## Grundregeln",
    "",
    ...normalizationRules.map((rule) => `- ${rule}`),
    "",
  ];
  for (const file of normalizationFiles) {
    lines.push(`## ${file.filename}`, "", `**${file.expectedRows} Zeilen erwartet · ${file.rowMeaning}.**`, "", file.purpose, "", "| Feld | Typ | Pflicht | Rolle | Bedeutung | Beispiel |", "|---|---|---|---|---|---|");
    for (const item of file.fields) {
      lines.push(`| \`${item.name}\` | ${item.type}${item.values ? ` (${item.values.join(" / ")})` : ""} | ${item.required ? "ja" : "nein"} | ${item.role} | ${item.description} | ${item.example || "—"} |`);
    }
    lines.push("");
  }
  lines.push("## Freigaben und offene Vorschlagspunkte", "", ...normalizationDecisions.map((item) => `- **${item.id} · ${item.title}: ${item.status === "bestaetigt" ? "bestätigt" : `Vorschlag (Empfehlung ${item.recommendation})`}.** ${item.reason}`), "", "Nur die vier konkret benannten Standorte werden als Kontaktklärung gezeigt. Erst nach Freigabe des vollständigen Aufbaus werden die 32 + 54 CSV-Kernzeilen und ihre Zuordnungen erzeugt.", "");
  return lines.join("\n");
}
