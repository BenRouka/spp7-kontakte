import type { Metadata } from "next";
import {
  AlertCircle,
  Building2,
  Globe,
  History,
  Mail,
  MapPin,
  Phone,
  Printer,
  UserRound,
} from "lucide-react";
import {
  KontaktRow,
  groupByOrt,
  groupByRegion,
  kontaktStats,
  loadFreeze,
} from "@/lib/freeze";
import { Badge, FieldLabel, Panel, RefChip, Section, cx } from "@/components/ui";

export const metadata: Metadata = {
  title: "Kontakte · Werkstatt Stufe 4",
};

/** Beschluss-Verweise je Datensatz (reine Anzeige, aus beschlussverzeichnis.csv). */
const REFS: Record<string, string[]> = {
  KV01: ["B-02"],
  "KV01.1": ["B-02"],
  "KV01.2": ["B-02"],
  KV12: ["B-05"],
  KV07: ["B-06"],
  KV10: ["B-07"],
  KV24: ["B-04"],
  KV27: ["B-01"],
  "STADT-PUTBUS": ["B-01"],
  KV28: ["B-01"],
};

const REGION_NOTES: Record<
  string,
  { tone: "lime" | "amber"; title: string; text: string }[]
> = {
  Übergreifend: [
    {
      tone: "lime",
      title: "Markt 25 · Kombiblock KV01 — drei Datensätze (B-02)",
      text: "Als MD-Block ist KV01 ein Kombiblock und bleibt in der eingefrorenen Normierung ungeteilt (32 Einträge). Die Dreierteilung — KV01 Verband · KV01.1 Baltic Project GmbH · KV01.2 Kampagne — ist die Arbeitsansicht.",
    },
    {
      tone: "amber",
      title: "Tourismuszentrale Rügen GmbH — existiert nicht mehr (B-03)",
      text: "Am 20.01.2021 zur Infrastrukturgesellschaft Mönchgut-Granitz GmbH (Sellin, HRB 5368) umfirmiert. Nicht als aktiven Eintrag anlegen; Ringstraße 113–115 / Bahnhofstraße 15 / Circus 16 Putbus sind historische Phasen derselben Gesellschaft.",
    },
  ],
  "Süd-Rügen": [
    {
      tone: "lime",
      title: "Putbus — drei Träger, getrennt geführt (B-01)",
      text: "KV27 Kurverwaltung · STADT-PUTBUS Rathaus (nur aus Chat, kein MD-Block) · KV28 Tourismus- und Gewerbeverein. K26–K28 gehören wegen der Domain @ruegen-putbus.de zur Kurverwaltung, nicht zum Rathaus.",
    },
  ],
};

function MailLine({ slot, value }: { slot: string; value: string }) {
  return (
    <div className="flex items-baseline gap-2">
      <span className="w-14 shrink-0 font-mono text-[9.5px] uppercase tracking-[0.12em] text-muted">
        {slot}
      </span>
      {value ? (
        <span className="break-all font-mono text-[11.5px] text-lime-soft">{value}</span>
      ) : (
        <span className="font-mono text-[11.5px] text-muted/50">—</span>
      )}
    </div>
  );
}

function KontaktCard({ k }: { k: KontaktRow }) {
  const refs = REFS[k.kvId] ?? [];
  return (
    <Panel
      className={cx(
        "flex flex-col gap-3 p-4",
        k.kvId.startsWith("KV01") && "border-lime/25",
        (k.kvId === "STADT-PUTBUS" || k.kvId === "KV27" || k.kvId === "KV28") &&
          "border-lime/25"
      )}
    >
      <div className="flex items-start justify-between gap-3">
        <span className="inline-flex items-center gap-1.5 rounded-md bg-lime/10 px-2 py-1 font-mono text-[11px] font-semibold text-lime">
          <Building2 className="h-3 w-3" />
          {k.kvId}
        </span>
        <span className="flex flex-wrap items-center justify-end gap-1">
          {refs.map((r) => (
            <RefChip key={r}>{r}</RefChip>
          ))}
          <Badge tone="line">{k.typ || "—"}</Badge>
        </span>
      </div>

      <div>
        <h3 className="text-[14.5px] font-semibold leading-snug text-ink">{k.name}</h3>
        <p className="mt-1 text-[12px] leading-relaxed text-muted">{k.anschrift || "—"}</p>
      </div>

      <div className="grid gap-1 text-[12px] text-ink-soft sm:grid-cols-2">
        <span className="flex items-center gap-1.5">
          <Phone className="h-3 w-3 text-muted" />
          <span className="font-mono text-[11.5px]">{k.telefon || "—"}</span>
        </span>
        <span className="flex items-center gap-1.5">
          <Printer className="h-3 w-3 text-muted" />
          <span className="font-mono text-[11.5px]">{k.fax || "—"}</span>
        </span>
      </div>

      <div className="rounded-lg border border-line-soft bg-base/50 px-3 py-2">
        <p className="mb-1 flex items-center gap-1.5 font-mono text-[9.5px] uppercase tracking-[0.16em] text-muted">
          <Mail className="h-3 w-3" /> E-Mail-Spalten · Regel 5
        </p>
        <div className="space-y-0.5">
          <MailLine slot="email_1" value={k.email1} />
          <MailLine slot="email_2" value={k.email2} />
          <MailLine slot="email_3" value={k.email3} />
        </div>
      </div>

      {k.web ? (
        <span className="flex items-center gap-1.5 font-mono text-[11.5px] text-ink-soft">
          <Globe className="h-3 w-3 text-muted" />
          {k.web}
        </span>
      ) : null}

      {k.hinweis ? (
        <div className="mt-auto flex items-start gap-2 rounded border border-line-soft bg-raised2/50 px-3 py-1.5 text-[11px] text-muted">
          <span className="font-semibold text-amber">Prio 2 Chat-Abgleich:</span>
          <span>{k.hinweis}</span>
        </div>
      ) : null}

      {k.felder !== 13 ? (
        <p className="flex items-start gap-1.5 font-mono text-[10px] leading-relaxed text-muted">
          <AlertCircle className="mt-0.5 h-3 w-3 shrink-0 text-amber" />
          Dateibefund: {k.felder} Felder (Kopf 13) — Rohzeile unverändert im Freeze.
        </p>
      ) : null}
    </Panel>
  );
}

export default function KontaktePage() {
  const { kontakte } = loadFreeze();
  const stats = kontaktStats(kontakte);
  const regionen = groupByRegion(kontakte);

  return (
    <>
      <div className="border-b border-line pb-8">
        <p className="font-mono text-[10.5px] font-semibold uppercase tracking-[0.24em] text-lime">
          Arbeitsstand · arbeitsstand-kontakte.csv
        </p>
        <h1 className="mt-3 text-[30px] font-semibold tracking-tight text-ink sm:text-[38px]">
          Kontakte — 9 Regionen, Hierarchie Region → Ort → Einrichtung
        </h1>
        <div className="mt-4 flex flex-wrap gap-2">
          <Badge tone="a">{stats.regionen} Regionen · Übergreifend zuerst</Badge>
          <Badge tone="mute">{stats.kvGekennzeichnet} KV-Datensätze</Badge>
          <Badge tone="mute">
            +{stats.sonderdatensaetze} Sonderdatensatz (STADT-PUTBUS)
          </Badge>
          <Badge tone="mute">
            E-Mail belegt: _1 × {stats.email1} · _2 × {stats.email2} · _3 × {stats.email3}
          </Badge>
        </div>
        <p className="mt-4 max-w-3xl text-[13px] leading-relaxed text-muted">
          Regel 4: ein Datensatz pro echter Einrichtung — andere Rechtsform, anderer Zweck
          oder eigener Standort = eigener Datensatz. Regel 5: mehrere E-Mails werden
          Spalten. Regel 7: nicht genauer als das Basismaterial.
        </p>
      </div>

      {regionen.map(({ region, rows }, ri) => (
        <Section
          key={region}
          eyebrow={`Region ${String(ri + 1).padStart(2, "0")} / ${String(regionen.length).padStart(2, "0")}`}
          title={region}
          aside={<Badge tone="mute">{rows.length} Datensätze</Badge>}
        >
          {REGION_NOTES[region]?.map((n) => (
            <div
              key={n.title}
              className={cx(
                "mb-4 flex items-start gap-3 rounded-lg border p-3.5",
                n.tone === "lime"
                  ? "border-lime/25 bg-lime/[0.03]"
                  : "border-amber/25 bg-amber/[0.03]"
              )}
            >
              <History
                className={cx(
                  "mt-0.5 h-4 w-4 shrink-0",
                  n.tone === "lime" ? "text-lime" : "text-amber"
                )}
              />
              <div>
                <p
                  className={cx(
                    "text-[12.5px] font-semibold",
                    n.tone === "lime" ? "text-lime" : "text-amber"
                  )}
                >
                  {n.title}
                </p>
                <p className="mt-1 text-[12px] leading-relaxed text-ink-soft">{n.text}</p>
              </div>
            </div>
          ))}

          <div className="space-y-6">
            {groupByOrt(rows).map(({ ort, rows: ortRows }) => (
              <div key={ort}>
                <p className="mb-3 flex items-center gap-1.5 font-mono text-[11px] font-semibold uppercase tracking-[0.18em] text-muted">
                  <MapPin className="h-3.5 w-3.5 text-lime" />
                  {ort}
                </p>
                <div className="grid gap-3 lg:grid-cols-2">
                  {ortRows.map((k) => (
                    <KontaktCard key={k.kvId} k={k} />
                  ))}
                </div>
              </div>
            ))}
          </div>
        </Section>
      ))}

      {/* Nicht in dieser Datei — Beschluss-Ausnahmen */}
      <Section
        eyebrow="Bewusst kein Eintrag"
        title="Personenkontakte & Parkplatz — nicht in der KV-Datei"
        desc="Ein Datensatz pro echter Einrichtung (Regel 4). Diese Fälle bleiben eigenständig — kein Merge, kein Typwechsel, kein Rätselraten."
      >
        <div className="grid gap-3 md:grid-cols-2">
          <Panel className="border-amber/25">
            <div className="flex items-start gap-3">
              <UserRound className="mt-0.5 h-4 w-4 shrink-0 text-amber" />
              <div>
                <p className="flex flex-wrap items-center gap-2 text-[13.5px] font-semibold text-ink">
                  K57 · eigenständiger Personenkontakt
                  <RefChip>B-04 · entschieden</RefChip>
                </p>
                <p className="mt-1.5 text-[12px] leading-relaxed text-muted">
                  Bleibt separater Datensatz mit unverifiziertem Prüfverweis auf{" "}
                  <span className="font-mono text-amber-soft">KV24</span> Zimmervermittlung
                  Rügen. Kein Merge, keine Umbenennung, kein Typwechsel.
                </p>
              </div>
            </div>
          </Panel>
          <Panel className="border-amber/25">
            <div className="flex items-start gap-3">
              <UserRound className="mt-0.5 h-4 w-4 shrink-0 text-amber" />
              <div>
                <p className="flex flex-wrap items-center gap-2 text-[13.5px] font-semibold text-ink">
                  K34 · Tourismus-Service Rügen — ohne Zuordnung
                  <RefChip>B-08 · provisorisch</RefChip>
                </p>
                <p className="mt-1.5 text-[12px] leading-relaxed text-muted">
                  Keine passende Prio-1-Quelle gefunden. Eigenständiger Datensatz ohne
                  Organisationszuordnung — Parkplatz, keine Modelländerung.
                </p>
              </div>
            </div>
          </Panel>
        </div>
        <p className="mt-4 flex items-start gap-2 text-[12px] leading-relaxed text-muted">
          <FieldLabel>Hinweis</FieldLabel>
          <span>
            Diese Ansicht ist eine Ausblend-Ansicht über das Freeze-Paket — sie ist keine
            Zugriffskontrolle (B-17). Die Datei bleibt byteidentisch und enthält die Werte.
          </span>
        </p>
      </Section>
    </>
  );
}
