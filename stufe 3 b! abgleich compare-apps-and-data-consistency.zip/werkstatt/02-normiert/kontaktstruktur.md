# Kontaktstruktur · Region → Ort → Einrichtung

Stand: kontaktstruktur-region-ort-einrichtung-v4.
32 Einrichtungen aus 32 Rohblöcken; 8 Regionen + 1 übergreifende Quellgruppe; 22 angezeigte Orte; insgesamt 63 Knoten.
Die 24 ursprünglichen H3-Fundstellen bleiben nachweisbar. Rügen Übergreifend ist kein Ort; Vitte wird nur nach ausdrücklicher Nutzerfreigabe zusammengeführt.
Fehlende Werte sind exakt " - " (Leerzeichen–Bindestrich–Leerzeichen), keine Minus-Zahl.
Baabe-Web/E-Mail und Middelhagens frühere Angaben sind ausdrücklich bestätigt, keine allgemeine Kontaktvererbung.

## 1. Rügen Übergreifend

Übergreifende Quellgruppe, ausdrücklich kein Ort.

Quellfundstellen: REG01: „Kurverwaltungen, Fremdenverkehrsvereine, Tourismusinformationen und Zimmervermittlungen“, MD-Zeile 5; ORT01: „Übergreifend“, MD-Zeile 7.
Zuordnung: MD-Gliederung + nutzerangabe: Auftraggeber-Klarstellung: Übergreifend ist kein Ort; schreibe hier Rügen Übergreifend

#### 1.1. Baltic Project GmbH / Tourismusverband Rügen e. V.

- Straße: Markt 25
- PLZ/Ort · Original: 18528 Bergen auf Rügen
- Ort: Bergen auf Rügen
- Ortsteil: ` - `
- Telefon · normiert: +49 3838 807780
- Fax · normiert: `03838807781`
- Internet: www.ruegen.de
- E-Mail: inselexperten@ruegen.de
- E-Mail 2: ` - `
- Originalfundstelle: MD-Zeilen 9-15
- Verifikation: nicht verifiziert

## 2. Rund um die Granitz

### 2.1. Ostseebad Binz

#### 2.1.1. Kurverwaltung Binz

- Straße: Heinrich-Heine-Straße 7 (Haus des Gastes)
- PLZ/Ort · Original: 18609 Ostseebad Binz
- Ort: Ostseebad Binz
- Ortsteil: ` - `
- Telefon · normiert: +49 38393 148148
- Fax · normiert: `038393148145`
- Internet: www.ostseebad-binz.de
- E-Mail: info@binzer-bucht.de
- E-Mail 2: ` - `
- Originalfundstelle: MD-Zeilen 21-27
- Verifikation: nicht verifiziert

#### 2.1.2. Fremdenverkehrsverein Binz/Rügen e. V.

- Straße: Wylichstraße 11
- PLZ/Ort · Original: 18609 Ostseebad Binz
- Ort: Ostseebad Binz
- Ortsteil: ` - `
- Telefon · normiert: +49 38393 665740
- Fax · normiert: `038393665750`
- Internet: www.gastgeber-binz.de
- E-Mail: info@gastgeber-binz.de
- E-Mail 2: ` - `
- Originalfundstelle: MD-Zeilen 29-35
- Verifikation: nicht verifiziert

#### 2.1.3. Rujana Immobilien GmbH

- Straße: Wylichstraße 11
- PLZ/Ort · Original: 18609 Ostseebad Binz
- Ort: Ostseebad Binz
- Ortsteil: ` - `
- Telefon · normiert: +49 38393 66640
- Fax · normiert: `038393666414`
- Internet: www.rujana.de
- E-Mail: urlaub@rujana.de
- E-Mail 2: ` - `
- Originalfundstelle: MD-Zeilen 37-43
- Verifikation: nicht verifiziert

### 2.2. Lancken-Granitz

#### 2.2.1. Tourist-Info Lancken-Granitz

- Straße: Dorfstraße 8
- PLZ/Ort · Original: 18586 Lancken-Granitz
- Ort: Lancken-Granitz
- Ortsteil: ` - `
- Telefon · normiert: +49 38303 95678
- Fax · normiert: ` - `
- Internet:  - 
- E-Mail: lancken-granitz@ruegen.de
- E-Mail 2: ` - `
- Originalfundstelle: MD-Zeilen 47-51
- Verifikation: nicht verifiziert

### 2.3. Ostseebad Sellin

#### 2.3.1. Kurverwaltung Sellin

- Straße: Warmbadstraße 4 (Haus des Gastes)
- PLZ/Ort · Original: 18586 Ostseebad Sellin
- Ort: Ostseebad Sellin
- Ortsteil: ` - `
- Telefon · normiert: +49 38303 160
- Fax · normiert: `03830316100`
- Internet: www.ostseebad-sellin.de
- E-Mail: kv@ostseebad-sellin.de
- E-Mail 2: ` - `
- Originalfundstelle: MD-Zeilen 55-61
- Verifikation: nicht verifiziert

#### 2.3.2. Infopoint Sellin

- Straße: Seeparkpromenade 1
- PLZ/Ort · Original: 18586 Ostseebad Sellin
- Ort: Ostseebad Sellin
- Ortsteil: ` - `
- Telefon · normiert: +49 38303 16222
- Fax · normiert: `03830316200`
- Internet: www.ostseebad-sellin.de
- E-Mail: info@ostseebad-sellin.de
- E-Mail 2: `zimmervermittlung@ostseebad-sellin.de`
- Originalfundstelle: MD-Zeilen 63-70
- Verifikation: nicht verifiziert

#### 2.3.3. Ostseeappartements Rügen Vermarktungs-GmbH & Co.KG

- Straße: Granitzer Straße 8
- PLZ/Ort · Original: 18586 Ostseebad Sellin
- Ort: Ostseebad Sellin
- Ortsteil: ` - `
- Telefon · normiert: +49 38303 90940
- Fax · normiert: `03830390944`
- Internet: www.oar1.de
- E-Mail: info@oar1.de
- E-Mail 2: ` - `
- Originalfundstelle: MD-Zeilen 72-78
- Verifikation: nicht verifiziert

## 3. Halbinsel Mönchgut

### 3.1. Ostseebad Baabe

#### 3.1.1. Kurverwaltung Baabe

- Straße: Am Kurpark 9 (Haus des Gastes)
- PLZ/Ort · Original: 18586 Ostseebad Baabe
- Ort: Ostseebad Baabe
- Ortsteil: ` - `
- Telefon · normiert: +49 38303 1420
- Fax · normiert: `03830314299`
- Internet: www.baabe.de
- E-Mail: willkommen@baabe.de
- E-Mail 2: ` - `
- Originalfundstelle: MD-Zeilen 84-90
- Ergänzungsherkunft: Auftraggeber zitiert den Chat im Gespräch zur Telefon-Normierung und Parent/Child-Struktur
- Verifikation: nicht verifiziert

#### 3.1.2. Infopavillion KV Baabe (außer Winter)

- Straße: Strandstraße
- PLZ/Ort · Original: 18586 Ostseebad Baabe
- Ort: Ostseebad Baabe
- Ortsteil: ` - `
- Telefon · normiert: +49 38303 14241
- Fax · normiert: ` - `
- Internet: www.baabe.de
- E-Mail: willkommen@baabe.de
- E-Mail 2: ` - `
- Originalfundstelle: MD-Zeilen 92-95
- Ergänzungsherkunft: Explizite Nutzerangabe x.1.2; anschließend bestätigt: wo ich es hinschreibe, nimm das. Nur für diesen Infopavillon, keine allgemeine Vererbung
- Verifikation: nicht verifiziert

#### 3.1.3. Mönchguter Zimmervermittlung

- Straße: Göhrener Chaussee 22
- PLZ/Ort · Original: 18586 Ostseebad Baabe
- Ort: Ostseebad Baabe
- Ortsteil: ` - `
- Telefon · normiert: +49 38303 9560500
- Fax · normiert: `038303909932`
- Internet: www.moenchguter-zimmervermittlung.de
- E-Mail: info@moenchguter-zimmervermittlung.de
- E-Mail 2: ` - `
- Originalfundstelle: MD-Zeilen 97-103
- Verifikation: nicht verifiziert

### 3.2. Ostseebad Mönchgut

#### 3.2.1. Kurverwaltung Mönchgut
Tourist-Information Middelhagen

- Straße: Dorfstraße 4
- PLZ/Ort · Original: 18586 Ostseebad Mönchgut OT Middelhagen
- Ort: Ostseebad Mönchgut
- Ortsteil: `Middelhagen`
- Telefon · normiert: +49 38308 66010
- Fax · normiert: `038308660110`
- Internet: www.ostseebad-moenchgut.de
- E-Mail: info@ostseebad-moenchgut.de
- E-Mail 2: ` - `
- Originalfundstelle: MD-Zeilen 107-112
- Ergänzungsherkunft: Frühere explizite Nutzerergänzung für Middelhagen; jetzt ausdrücklich bestätigt: ja die erste Angabe
- Verifikation: nicht verifiziert

#### 3.2.2. Tourist-Information Thiessow (Außenstelle)

- Straße: Hauptstraße 36
- PLZ/Ort · Original: 18586 Ostseebad Mönchgut OT Thiessow
- Ort: Ostseebad Mönchgut
- Ortsteil: `Thiessow`
- Telefon · normiert: +49 38308 66010
- Fax · normiert: ` - `
- Internet: www.ostseebad-moenchgut.de
- E-Mail: info@ostseebad-moenchgut.de
- E-Mail 2: ` - `
- Originalfundstelle: MD-Zeilen 114-118
- Ergänzungsherkunft: Auftraggeber zitiert den Chat und ergänzt separat Telefon +49 38308 66010 sowie fehlendes Fax
- Organisatorische Zuordnung (separat vom Ort): KV12
- Verifikation: nicht verifiziert

### 3.3. Ostseebad Göhren

#### 3.3.1. Kurverwaltung Göhren

- Straße: Poststraße 9 (im Haus des Gastes)
- PLZ/Ort · Original: 18586 Ostseebad Göhren
- Ort: Ostseebad Göhren
- Ortsteil: ` - `
- Telefon · normiert: +49 38308 66790
- Fax · normiert: `038308667932`
- Internet: www.goehren-ruegen.de
- E-Mail: kv@goehren-ruegen.de
- E-Mail 2: ` - `
- Originalfundstelle: MD-Zeilen 122-128
- Verifikation: nicht verifiziert

#### 3.3.2. Fremdenverkehrs-und Gewerbeverein Göhren e. V.

- Straße: Poststraße 6
- PLZ/Ort · Original: 18586 Ostseebad Göhren
- Ort: Ostseebad Göhren
- Ortsteil: ` - `
- Telefon · normiert: +49 38308 25940
- Fax · normiert: `03830825930`
- Internet: www.info-goehren.de
- E-Mail: mail@info-goehren.de
- E-Mail 2: ` - `
- Originalfundstelle: MD-Zeilen 130-136
- Verifikation: nicht verifiziert

## 4. Halbinsel Jasmund

### 4.1. Glowe

#### 4.1.1. Tourist-Infostelle/Gemeinde Glowe

- Straße: Boddenmarkt 1
- PLZ/Ort · Original: 18551 Glowe
- Ort: Glowe
- Ortsteil: ` - `
- Telefon · normiert: +49 38302 5221
- Fax · normiert: `0383025252`
- Internet: www.glowe.de
- E-Mail: info@glowe.de
- E-Mail 2: ` - `
- Originalfundstelle: MD-Zeilen 142-148
- Verifikation: nicht verifiziert

### 4.2. Lohme

#### 4.2.1. Touristik Lohme GmbH

- Straße: Arkonastr. 31 (Haus Linde)
- PLZ/Ort · Original: 18551 Lohme
- Ort: Lohme
- Ortsteil: ` - `
- Telefon · normiert: +49 38302 88855
- Fax · normiert: `03830288857`
- Internet: www.lohme.de
- E-Mail: info@lohme.de
- E-Mail 2: ` - `
- Originalfundstelle: MD-Zeilen 152-158
- Verifikation: nicht verifiziert

### 4.3. Sassnitz

#### 4.3.1. Tourist-Service der Stadt Sassnitz

- Straße: Strandpromenade 12
- PLZ/Ort · Original: 18546 Sassnitz
- Ort: Sassnitz
- Ortsteil: ` - `
- Telefon · normiert: +49 38392 6490
- Fax · normiert: `03839264920`
- Internet: www.insassnitz.de
- E-Mail: mail@insassnitz.de
- E-Mail 2: ` - `
- Originalfundstelle: MD-Zeilen 162-168
- Verifikation: nicht verifiziert

## 5. Halbinsel Wittow

### 5.1. Dranske

#### 5.1.1. Fremdenverkehrsamt Dranske

- Straße: Schulstraße 19
- PLZ/Ort · Original: 18556 Dranske
- Ort: Dranske
- Ortsteil: ` - `
- Telefon · normiert: +49 38391 89007
- Fax · normiert: `03839189424`
- Internet: www.gemeinde-dranske.de
- E-Mail: info@gemeinde-dranske.de
- E-Mail 2: ` - `
- Originalfundstelle: MD-Zeilen 174-180
- Verifikation: nicht verifiziert

### 5.2. Juliusruh

#### 5.2.1. Informationsamt Seebad Breege-Juliusruh

- Straße: Wittower Straße 5
- PLZ/Ort · Original: 18556 Seebad Juliusruh
- Ort: Seebad Juliusruh
- Ortsteil: ` - `
- Telefon · normiert: +49 38391 311
- Fax · normiert: `03839113235`
- Internet: www.breege.de
- E-Mail: info@breege.de
- E-Mail 2: ` - `
- Originalfundstelle: MD-Zeilen 184-190
- Verifikation: nicht verifiziert

### 5.3. Putgarten/Kap Arkona

#### 5.3.1. Tourismusgesellschaft mbH Kap Arkona

- Straße: Am Parkplatz 1
- PLZ/Ort · Original: 18556 Putgarten
- Ort: Putgarten
- Ortsteil: ` - `
- Telefon · normiert: +49 38391 13037
- Fax · normiert: `03839141917`
- Internet: www.kap-arkona.de
- E-Mail: info@kap-arkona.de
- E-Mail 2: ` - `
- Originalfundstelle: MD-Zeilen 194-200
- Verifikation: nicht verifiziert

### 5.4. Wiek

#### 5.4.1. Tourismusinformation Wiek

- Straße: Am Markt 5
- PLZ/Ort · Original: 18556 Wiek
- Ort: Wiek
- Ortsteil: ` - `
- Telefon · normiert: +49 38391 76870
- Fax · normiert: `03839176871`
- Internet: www.wiek-ruegen.de
- E-Mail: info@wiek-ruegen.de
- E-Mail 2: ` - `
- Originalfundstelle: MD-Zeilen 204-210
- Verifikation: nicht verifiziert

## 6. Nord-West-Rügen

### 6.1. Gingst

#### 6.1.1. Tourismusverein West-Rügen e. V.
Info-Stube Gingst

- Straße: Karl-Marx-Straße 19
- PLZ/Ort · Original: 18569 Gingst
- Ort: Gingst
- Ortsteil: ` - `
- Telefon · normiert: +49 38305 535862
- Fax · normiert: `038305535862`
- Internet: www.westruegen.net
- E-Mail: info@westruegen.net
- E-Mail 2: ` - `
- Originalfundstelle: MD-Zeilen 216-223
- Verifikation: nicht verifiziert

### 6.2. Neuenkirchen

#### 6.2.1. Zimmervermittlung Rügen

- Straße: OT Grubnow 1
- PLZ/Ort · Original: 18569 Neuenkirchen
- Ort: Neuenkirchen
- Ortsteil: `Grubnow`
- Telefon · normiert: +49 38309 88001
- Fax · normiert: `03830988002`
- Internet: www.zv-ruegen.de
- E-Mail: sschoenke@t-online.de
- E-Mail 2: ` - `
- Originalfundstelle: MD-Zeilen 227-233
- Verifikation: nicht verifiziert

### 6.3. Ummanz

#### 6.3.1. Ummanz-Information

- Straße: Neue Straße 63 a
- PLZ/Ort · Original: 18569 Waase/Ummanz
- Ort: Waase/Ummanz
- Ortsteil: ` - `
- Telefon · normiert: +49 38305 53481
- Fax · normiert: `03830553483`
- Internet: www.ruegeninsel-ummanz.de
- E-Mail: kontakt@ruegeninsel-ummanz.de
- E-Mail 2: ` - `
- Originalfundstelle: MD-Zeilen 237-243
- Verifikation: nicht verifiziert

## 7. Süd-Rügen

### 7.1. Altefähr

#### 7.1.1. Gemeinde Seebad Altefähr
Eigenbetrieb Hafen-und Tourismuswirtschaft Altefähr

- Straße: Am Fährberg 9
- PLZ/Ort · Original: 18573 Altefähr
- Ort: Altefähr
- Ortsteil: ` - `
- Telefon · normiert: +49 38306 75037
- Fax · normiert: `03830675056`
- Internet: www.altefaehr.de
- E-Mail: info@altefaehr.de
- E-Mail 2: ` - `
- Originalfundstelle: MD-Zeilen 249-256
- Verifikation: nicht verifiziert

### 7.2. Putbus

#### 7.2.1. Kurverwaltung Putbus/Stadtinformation

- Straße: Alleestraße 2
- PLZ/Ort · Original: 18581 Putbus
- Ort: Putbus
- Ortsteil: ` - `
- Telefon · normiert: +49 38301 60964
- Fax · normiert: `03830160963`
- Internet: www.ruegen-putbus.de
- E-Mail: info.putbus@putbus.de
- E-Mail 2: ` - `
- Originalfundstelle: MD-Zeilen 260-266
- Verifikation: nicht verifiziert

### 7.3. Lauterbach (Putbus)

#### 7.3.1. Tourismus-und Gewerbeverein Putbus e. V.

- Straße: Pappelweg 7
- PLZ/Ort · Original: 18581 Lauterbach
- Ort: Lauterbach
- Ortsteil: ` - `
- Telefon · normiert: +49 38301 60467
- Fax · normiert: `03830160377`
- Internet: www.gastgeber-putbus.de
- E-Mail: tgv-putbus@gmx.de
- E-Mail 2: ` - `
- Originalfundstelle: MD-Zeilen 270-277
- Verifikation: nicht verifiziert

## 8. Zentralrügen

### 8.1. Bergen auf Rügen

#### 8.1.1. Stadtinformation Bergen auf Rügen
Bergen Touristik Service UG

- Straße: Markt 23
- PLZ/Ort · Original: 18528 Bergen auf Rügen
- Ort: Bergen auf Rügen
- Ortsteil: ` - `
- Telefon · normiert: +49 3838 3152838
- Fax · normiert: `038383152839`
- Internet: www.stadtinfo-bergen-ruegen.de
- E-Mail: post@stadtinfo-bergen-ruegen.de
- E-Mail 2: ` - `
- Originalfundstelle: MD-Zeilen 283-290
- Verifikation: nicht verifiziert

## 9. Seebad Insel Hiddensee

### 9.1. Vitte

Quellfundstellen: ORT22: „Vitte“, MD-Zeile 294; ORT24: „Vitte“, MD-Zeile 313.
Zuordnung: MD-Fundstellen + nutzerangabe: Auftraggeber-Beispiel: Seebad Insel Hiddensee → Vitte → Insel Information Hiddensee und HTS; Kloster bleibt separat

#### 9.1.1. Insel Information Hiddensee

- Straße: Achtern Diek 18a
- PLZ/Ort · Original: 18565 Vitte
- Ort: Vitte
- Ortsteil: ` - `
- Telefon · normiert: +49 38300 608685
- Fax · normiert: `038300608689`
- Internet: www.seebad-hiddensee.de
- E-Mail: info@seebad-hiddensee.de
- E-Mail 2: ` - `
- Originalfundstelle: MD-Zeilen 296-302
- Verifikation: nicht verifiziert

#### 9.1.2. HTS
Hiddensee Touristik & Service
Namenszusatz-Herkunft: nutzerangabe: Aktuelle Auftraggeber-Ergänzung des ausgeschriebenen HTS-Namens im Hiddensee-Beispiel

- Straße: Wiesenweg 21a
- PLZ/Ort · Original: 18565 Vitte
- Ort: Vitte
- Ortsteil: ` - `
- Telefon · normiert: +49 38300 60497
- Fax · normiert: `03830060498`
- Internet: www.hiddensee-touristik.de
- E-Mail: mail@hiddensee-touristik.de
- E-Mail 2: ` - `
- Originalfundstelle: MD-Zeilen 315-321
- Ergänzungsherkunft: Aktuelle Auftraggeber-Ergänzung des ausgeschriebenen HTS-Namens im Hiddensee-Beispiel
- Verifikation: nicht verifiziert

### 9.2. Kloster

#### 9.2.1. Tourist Information im Hafencenter Kloster

- Straße: Hafenweg 15
- PLZ/Ort · Original: 18565 Kloster
- Ort: Kloster
- Ortsteil: ` - `
- Telefon · normiert: +49 38300 60654
- Fax · normiert: `03830060791`
- Internet:  - 
- E-Mail: hafencenter@seebad-hiddensee.de
- E-Mail 2: ` - `
- Originalfundstelle: MD-Zeilen 306-311
- Verifikation: nicht verifiziert

## Grenzen

Rügen Übergreifend ist eine Quellgruppe über dem Verband. Seine echte Adresse Markt 25, 18528 Bergen auf Rügen bleibt unverändert. Die rohe Gliederung ist in den Original-/Fundstellenfeldern erhalten.

Unter Seebad Insel Hiddensee stehen Vitte (Insel Information und HTS) und Kloster (Hafencenter). Die Vitte-Fundstellen MD 294 und 313 sind gemeinsam verzeichnet; Einrichtungen, Anschriften und Kontaktdaten bleiben getrennt. Keine organisatorische Beziehung zwischen HTS und Insel Information abgeleitet.

HTS bleibt als Originalname erhalten; Hiddensee Touristik & Service ist ein zusätzlicher Nutzer-Namenszusatz, nicht nachträglich in die MD geschrieben.

Fax bleibt eigenes Feld. +49-Normierung nur für Telefonnummern. Keine automatische Vererbung, keine allgemeine Zusammenführung gleichnamiger Orte.

Stufe 3 und Datenbankimport nicht begonnen.
