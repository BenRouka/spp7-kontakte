import { readOptionBArtifact } from "@/lib/option-b-alignment";

export const dynamic = "force-dynamic";
export const runtime = "nodejs";

// Only explicitly allowlisted, public-reference derivative files are returned.
// No DB writes, remote deployments, arbitrary paths or environment exports.
export async function GET(request: Request) {
  const format = new URL(request.url).searchParams.get("format") || "json";
  if (!["json", "md", "zip"].includes(format)) return Response.json({ error: "Verfügbar: json, md, zip." }, { status: 400 });
  try {
    const artifact = await readOptionBArtifact();
    const headers = { "Cache-Control": "no-store", "X-SPP7-Model-Version": artifact.summary.modelVersion };
    if (format === "json") return Response.json(artifact.summary, { headers });
    if (!artifact.summary.aligned) return Response.json({ error: "Das gespeicherte Option-B-Paket entspricht nicht mehr dem aktuellen Zeitmodell. Erneuter Abgleich erforderlich." }, { status: 409, headers });
    if (format === "md") return new Response(artifact.report, { headers: {
      ...headers, "Content-Type": "text/markdown; charset=utf-8",
      "Content-Disposition": 'attachment; filename="spp7-zeitmodell-a-b.md"',
    } });
    return new Response(new Uint8Array(artifact.zip).buffer, { headers: {
      ...headers, "Content-Type": "application/zip",
      "Content-Disposition": 'attachment; filename="option-b-zeitmodell-v2.zip"',
    } });
  } catch {
    return Response.json({ error: "Das geprüfte Option-B-Paket ist derzeit nicht verfügbar. Es wurde nichts importiert oder auf einer anderen Arena-Instanz geändert." }, { status: 503 });
  }
}
