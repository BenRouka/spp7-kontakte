# 03 — Berichte

**Status: noch leer — wird in Stufe 3 gefüllt.**

Hier landen die **Abgleich-Berichte**: gut lesbare Listen, die zeigen, wo die sauberen Quellen
und die bestehenden App-Daten voneinander abweichen.

## Zweck

Du liest den Bericht und entscheidest pro Konflikt — **ich entscheide nichts selbst.**
Erst nach deiner Freigabe wandert etwas in die Datenbank (Stufe 5).

## Was ein Bericht enthält

| Abschnitt | Inhalt |
|---|---|
| **Dubletten** | Dieselbe Einrichtung mehrfach erfasst, z. B. Kurverwaltung Putbus (`K22`, `K23`, `K70`) |
| **Widersprüche** | Saubere Quelle sagt X, App-Daten sagen Y — welcher Wert gilt? |
| **Lücken** | In der sauberen Quelle vorhanden, in der App nicht (z. B. die fehlenden Sündenfrei-Termine) |
| **Überhang** | In der App vorhanden, in der sauberen Quelle nicht — löschen? behalten? |
| **Prüfbedarf** | Von der Quelle selbst als unsicher markiert (`*`, „ohne Gewähr", „OCR unleserlich") |

Jeder Punkt bekommt eine Nummer, damit du einfach antworten kannst:
„K-03 ja, K-04 nein, K-05 Quelle gewinnt".

## Wichtig

- **Kein Auto-Merge.** Nichts wird automatisch zusammengeführt.
- **Keine Änderung an `../01-roh/`.** Die Originale bleiben unberührt.
- Berichte werden **nicht gelöscht** — sie dokumentieren, warum etwas so entschieden wurde.
