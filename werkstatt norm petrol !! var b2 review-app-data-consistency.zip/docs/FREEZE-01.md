# SPP7 · FREEZE-01 – eingefrorener Arbeitsstand

**Status: eingefroren (Pause)** · Zeitpunkt: 2026-10-01, 13:07 UTC
**Einstieg für die Wiederaufnahme ist dieses Dokument.** Es fasst den Gesamtstand zusammen.
`docs/HANDOFF.md` beschreibt den A/B-Zeitmodell-Abgleich (identisch mit dem Option-B-Paket) und bleibt dafür gültig. Für den Gesamtstand gilt dieses Dokument.

> Bis zur Wiederaufnahme: keine Code-, Layout-, Daten- oder Schemaänderung.
> Weiter erst nach ausdrücklicher Freigabe.

Zugehörige Dateien:
- `docs/FREEZE-01-pruefprotokoll.txt` – automatisch erzeugte Prüfergebnisse
- `docs/FREEZE-01.sha256` – Prüfsummen aller eingefrorenen Dateien

---

## 0. Arbeitsroutinen (vom Auftraggeber, gelten fortlaufend)

- Niemals raten, schätzen oder interpretieren. Bei ungenauen, zu komplexen oder widersprüchlichen Angaben kritisch prüfen: Macht das Sinn? Ist das schlüssig? Richtig verstanden? Dann Hinweise geben (z. B. „Vorsicht, das verändert das Datenmodell“), Vorschläge machen oder zurückfragen.
- Nichts ändern ohne ausdrückliche Bestätigung. „ja“ oder „ok“ = einverstanden, „ok leg los“ = Code starten.
- In kleinen Schritten arbeiten, jeweils mit ja/nein, bis Einigkeit besteht.

---

## 1. Stand auf einen Blick

| Bereich | Stand |
|---|---|
| Oberfläche | Option A „Datenwerkstatt“: lesende Prüfansicht im Petrol-Dunkelschema, abgenommen („ok, sieht sehr gut aus“) |
| Zeitmodell | `zeitmodell-2026-2027-v2`, identisch in Option A und im Option-B-Paket |
| Option B | `werkstatt/04-austausch/option-b-zeitmodell-v2.zip`: Zeitmodell nachgezogen; Starter-Bildschirm, Schema und Abhängigkeiten unverändert. Das Petrol-Theme gilt nur für Option A. |
| Originalquellen | unverändert: MD/TXT bytegleich, Original-Werkstatt-ZIP unverändert |
| Datenbank | 0 Tabellen, kein Import, nur lesende Verbindungsprüfung |
| Pipeline | Stufe 2 (Normierung) nicht begonnen, siehe §5 |

---

## 2. Verbindliche Entscheidungen

### 2.1 Zeitmodell (bestätigt)

| Quellzeile | Art | Zeitfenster | Datumsherkunft | Quellstatus |
|---|---|---|---|---|
| L07 · `1. - 4. Advent 2026` · Mittelalter-Advent (Do. - So.) · Herne | 4 getrennte Wochenenden | 26.–29.11. · 03.–06.12. · 10.–13.12. · 17.–20.12.2026 | berechnet | ohne Sternchen (nicht automatisch bestätigt) |
| L56 · `1. - 4. Advent 2027*` · Mittelalter-Advent (Fr.- So.) · Herne | 4 getrennte Wochenenden | 26.–28.11. · 03.–05.12. · 10.–12.12. · 17.–19.12.2027 | berechnet | unbestätigt (*) |
| L08 · `25. 11. - 23. Dezember 2026*` · Mittelalter-Weihnacht · Dresden/Stallhof | durchgehend, eigenes Datum, nicht Advent | 25.11.–23.12.2026 (29 Tage) | aus Quelle | unbestätigt (*) |
| L57 · `24.11. - 23. Dezember 2027*` · Mittelalter-Weihnacht · Dresden/Stallhof | durchgehend, eigenes Datum, nicht Advent | 24.11.–23.12.2027 (30 Tage) | aus Quelle | unbestätigt (*) |

- Jeder Herne-Quelltermin ist **ein** Event mit vier Zeitfenstern: keine vier Events, keine Veranstaltungstage dazwischen.
- Kirchenregel: Der 4. Advent ist der letzte Sonntag vor dem 25.12. (18.–24.12.). Fällt der 25.12. auf einen Sonntag, ist der 4. Advent der 18.12., nicht der 25.12. Das präzisiert die Chat-Formulierung; 2026 und 2027 sind davon nicht betroffen.
- Überholt: die alte Handoff-Rechnung (2026 durchgehend 26.11.–20.12.; 2027 Beginn 25.11., ein Donnerstag). Sie liegt historisch unter `docs/archiv/`.
- Datumsherkunft und Bestätigungsstatus sind unabhängig. „Berechnet“ heißt nicht „bestätigt“.

### 2.2 Weitere Klärungen (bestätigt)

- **F1:** Termine Januar–September 2026 werden nicht nacherfasst, weil sie vergangen sind. Die Originalzeilen bleiben erhalten.
- **F2:** „180 maps“ = 180 von 206 Event-Einträgen mit LAT und LNG, verteilt auf 149 verschiedene Koordinatenpaare; Kontakte separat 68 von 74. Das ist keine Bildzahl. Vorhandene Koordinaten sind nicht inhaltlich verifiziert.
- `*` und `**` bedeuten gleichermaßen: Termin oder Ort wahrscheinlich, jedoch noch unbestätigt.
- Die Originalschreibweise bleibt immer erhalten. Normiert wird nur zusätzlich, in einer eigenen Spalte.
- Ein Adressblock mit zwei Namen ist eine Zeile mit Haupt- und Zusatzname. Jede Zeile bekommt eine eigene ID (KV01…KV32); Ortsnamen sind kein Schlüssel, weil „Vitte“ zweimal vorkommt.
- Option A bleibt die gewählte Oberfläche; Option B wurde nur im Zeitmodell angeglichen.

### 2.3 Aus dem alten Handoff übernommen

Dort als bestätigt dokumentiert (`docs/archiv/HANDOFF-vor-abgleich.md`, §5 und §7):

- Bilder sind Flyer **und** Screenshots (Gig-Anzeigen, Posts) **und** Bewerbungen mit Gagen-Infos.
- Logo als PNG, nicht SVG: Das PDF enthält nur ein Rasterbild (1080 × 1090 px). Noch nicht umgesetzt.
- Trennung Original-Archiv (unantastbar) ↔ kuratierte Arbeitsebene.
- Der Arbeitsordner `werkstatt/` liegt dauerhaft im Projekt, nicht in `/tmp` und nicht in `public/`.
- Ablauf: erst Abgleich, dann Entscheidung, dann Datenbank.
- Grundregel Stufe 6 (Bilder): nur tote Links reparieren, ohne Umbenennung, Neubewertung oder Kuration.

---

## 3. Layout (abgenommen)

| Vorgabe | Umsetzung |
|---|---|
| Petrol-Dunkelschema wie im ☰-Menü | Hintergrund `#0c2529`, Flächen `#10323a` / `#0e2c33`, erhöht `#15404a`, Seitenleiste `#0a1f24`, Linien `#1d4b55`; Akzent Lime `#c7e86f` (sanft `#9dc34f`); Hinweise Amber `#e2b765` |
| Möglichst wenige Schriftgrößen | 7 Stufen statt über 30: 12 · 14 · 16 · 20 · 26 · 34 px plus Seitentitel 28–36 px. Mobil (≤ 760 px): 18 · 23 · 30 statt 20 · 26 · 34. |
| Technische Angaben einheitlich mit Lime („Robot“-Schrift) | Roboto Mono in Lime für Kennzahlen, ISO-Daten, Zeitfenster, Kalendertage, Dateigrößen, Prüfsummen, Zeilennummern, Modellversion sowie Datums- und Ortsspalte der Quelltabelle |
| Überschriften ok, Unterüberschriften größer | Überschriften unverändert; Unterüberschriften 20 px, Fließtext 14–16 px |
| „54 ist ok, Quellzeilen größer wie Zeiträume“ | als Breitenverteilung umgesetzt: 54-Karte breiter (1,35 : 1 : 1 : 1); Quelltabelle Veranstaltung 32 %, Datum 24 %, Ort 24 % (siehe L3) |
| Schriftdateien | Inter (Text) und Roboto Mono (technisch), lokal in `public/fonts/` mit OFL-Lizenzen |

Die Rückfrage zur Datums- und Ortsspalte in Mono/Lime ist mit „ok, sieht sehr gut aus“ beantwortet: Beide bleiben wie gezeigt.

---

## 4. Beim Freeze-Check gefunden – nicht umgesetzt, wartet auf ja/nein

| # | Befund | Vorschlag |
|---|---|---|
| L1 | Die Vorgabe „Ablage noch offen ≈ Größe von ‚9 aus 2026‘, Roboto mit leichtem Lime“ ist nicht umgesetzt. „Absage“ wurde dabei als Pipeline-Untertitel „Ablage noch offen“ gelesen. Ist-Stand: Pipeline-Untertitel (`.pipeline-step small`) 12 px Inter grau; „9 aus 2026“ (`.metric-card p`) 14 px Roboto Mono, aber grau statt Lime. Die letzte Rückmeldung hatte das fälschlich auf „Ort offen“ bezogen. | Pipeline- und Kennzahl-Untertitel einheitlich 14 px Roboto Mono in sanftem Lime |
| L2 | Der A/B-Dialog (`src/components/alignment-details.tsx`, Zeilen 29–42) nutzt noch Inline-Größen 9, 10 und 11 px sowie Farben des alten hellen Schemas (`#81916d`, `#8d9e76`) – außerhalb der 7-Stufen-Skala. | auf Skala und Petrol-Farben umstellen, Inhalt unverändert |
| L3 | „Quellzeilen größer wie Zeiträume“ wurde als Breitenverteilung gelesen. Mögliche andere Lesart: Die Schrift „Quellzeilen“ (14 px) soll so groß sein wie der Reiter „Zeiträume“ (16 px). | kurz bestätigen, welche Lesart gemeint ist |

Alle drei sind reine Darstellungsfragen. Daten, Zeitmodell und das Option-B-Paket sind nicht betroffen.

---

## 5. Pipeline-Stand

| Stufe | Stand |
|---|---|
| 1 · Quellen sichern | Das ursprüngliche Werkstatt-ZIP enthält nur 2 von 5 Originalen (MD, TXT). App-ZIP, Chat-ZIP und Logo liegen nur extern auf GitHub. Eine vollständige Ablage ist nicht nachgewiesen. |
| 2 · Normieren | Das Zeitmodell ist geklärt und als Prüfdaten abgebildet. Die Normierung der 32 Adressblöcke und 54 Terminzeilen ist **nicht begonnen**. |
| 3 · Abgleich | Nur der A/B-Zeitmodell-Abgleich ist erledigt. Der Quellen↔App-Abgleich steht aus. |
| 4 · Entscheidungen | Zeitmodell, F1, F2, Sternchen, Schreibweisen und Adressblöcke sind geklärt. Konflikt- und Dublettenentscheidungen (F3) stehen aus. |
| 5 · Import | Nicht begonnen. Kein Schema, keine Tabellen. |
| 6 · App | Option A dient als Prüfansicht. Die Bestands-App (varB) ist unverändert. |

---

## 6. Offene Entscheidungen (nichts umgesetzt)

- **E3:** Tabellen- und Zuordnungskonzept vor dem Import, einschließlich mehrerer Zeitfenster je Quelltermin. ⚠ Vorsicht, das verändert das Datenmodell.
- **E4:** Eigene Kontaktfelder (Straße, PLZ, Telefon, Fax, Website, mehrere Kanäle) statt eines Sammelfelds. ⚠ Vorsicht, das verändert das Datenmodell.
- **E5:** Datenschutz. `public/data/` der Bestands-App enthält E-Mails, Telefonnummern und den Chat und ist öffentlich abrufbar.
- **F3:** Dubletten (u. a. K22/K23/K70, K01/K02/K33/K65, K57) werden nicht automatisch zusammengeführt.
- **Stufe 1:** Sollen App-ZIP, Chat-ZIP und Logo in `werkstatt/01-roh/` abgelegt werden? Das Chat-ZIP enthält personenbezogene Daten; Ablageort und Veröffentlichung vorher klären.
- **Stufe 6:** Logo-PNG und die 79 Bilder für die toten Flyer-Links der Bestands-App sind nicht begonnen.
- **L1–L3** aus §4.

---

## 7. Hinweise und Risiken

- Die Bestands-App überschreibt bei jedem Serverstart Events, Kontakte und Chat per `onConflictDoUpdate` (`spp7-repository.ts`). Kuratierte Daten gehören deshalb später in eigene Tabellen.
- `node scripts/check-time-model.mjs` ist rein lesend. Mit `--write-option-b` werden das Paket, `docs/HANDOFF.md`, `werkstatt/01-roh/QUELLEN.md` und die Berichte neu erzeugt – nur nach Freigabe.
- `.env` (lokale DB-Verbindung) ist nicht Teil des Freezes, und es gibt keine `.gitignore`. Vor einem Push in ein öffentliches Repository klären.
- `werkstatt/` liegt nicht in `public/` und wird nicht als statische Datei ausgeliefert. Das ist keine Zugriffskontrolle. Der private Chat-Export liegt nicht im Projekt.
- Eine separate Arena-Variante B und das GitHub-Repository wurden nicht direkt geändert.

---

## 8. Dateien

```
src/app/                 Seite, Layout, globals.css (Petrol-Theme)
src/app/api/             health · review · review/export · review/option-b
src/components/          workshop.tsx (Option-A-Oberfläche) · alignment-details.tsx (A/B-Dialog) · icons.tsx
src/lib/                 calendar-model · review-report · reference-data · review-repository  (gemeinsam mit B)
                         option-b-alignment · option-b-contract                               (nur A)
scripts/                 check-time-model.mjs (Regression + A/B-Parität)
werkstatt/01-roh/        Kurverwaltungen_2025.md · Termine_2027_suendenfrei.txt (bytegleich)
                         QUELLEN.md (korrigiert) · PRUEFSUMMEN.sha256 · PRUEFSUMMEN-referenzen.sha256
                         option-b-original.zip (unverändertes Werkstatt-ZIP)
werkstatt/03-berichte/   zeitmodell-a-b.md · zeitmodell-2026/2027.md · zeitmodell-stand.json
                         zeitfenster-pruefung.csv · kalendervorschau-2026/2027.ics · option-b-manifest.json
werkstatt/04-austausch/  option-b-zeitmodell-v2.zip (aktualisierte Option B)
docs/                    FREEZE-01.md · FREEZE-01-pruefprotokoll.txt · FREEZE-01.sha256
                         HANDOFF.md (A/B-Stand) · archiv/ (historische Notizen)
public/fonts/            Inter · Roboto Mono · OFL-Lizenzen
```

Gemeinsam mit Option B (7 Dateien, bytegleich im Paket): `reference-data.ts`, `calendar-model.ts`, `review-report.ts`, `review-repository.ts`, `api/review/route.ts`, `api/review/export/route.ts`, `scripts/check-time-model.mjs`.

`werkstatt/02-normiert/` ist im Projekt noch nicht angelegt; den Ordner gibt es nur in den Paketen. Er ist das Ziel für Stufe 2.
In der Oberfläche: Menü „A/B-Abgleich“ mit Prüfbericht und Download des Option-B-ZIPs.

---

## 9. Prüfergebnisse beim Freeze (2026-10-01, UTC)

| Prüfung | Ergebnis |
|---|---|
| Regression Zeitmodell | bestanden: 8 Adventsfenster, Dresden 2026/2027, 54 Quellzeilen, Sternchen, 101 Jahre Kirchenregel inkl. Weihnachten am Sonntag |
| A/B-Parität | identische Zeitmodelle, 7/7 gemeinsame Dateien, 4/4 Quellfälle; Starter-Bildschirm, Schema und Rohquellen von B unverändert |
| Rohquellen | `Kurverwaltungen_2025.md` OK · `Termine_2027_suendenfrei.txt` OK |
| Original-Werkstatt-ZIP | SHA-256 `2cc04683a638ba264ff1932ce4ac4f4cba147506da0faacf2242f9dc11c696bd` |
| Option-B-Paket | SHA-256 `9a33e43ababbf52f47d36e334af725b4e0aaa784dbb36390a640db08f71f8e32`; der Download entspricht byteweise der gespeicherten Datei |
| Typgenerierung · TypeScript · Produktionsbuild | bestanden |
| Start + Healthcheck | bestanden (`/api/health` → `{"ok":true}`) |
| Lesende API 2026/2027 | Herne je 4 Fenster, Dresden je 1 Zeitraum, Exporte md/csv/ics je 200 |
| Datenbank | 0 Tabellen im Schema `public`; nur lesende Verbindungsprüfung |
| Versionen | Node 22.22.1 · Next 16.2.6 · React 19.2.6 · drizzle-orm 0.45.2 · pg 8.20.0 · fflate 0.8.3 · TypeScript 5.9.3 |

Details stehen in `docs/FREEZE-01-pruefprotokoll.txt`.

---

## 10. Wiederaufnahme

1. Dieses Dokument lesen.
2. Integrität in der Projektwurzel prüfen: `sha256sum -c docs/FREEZE-01.sha256` muss für jede Datei „OK“ ergeben. Ausgenommen sind nur erzeugte bzw. lokale Dateien (`node_modules/`, `.next/`, `next-env.d.ts`, `*.tsbuildinfo`, `.env`).
3. Zeitmodell und A/B-Gleichstand prüfen: `node scripts/check-time-model.mjs`
4. Rohquellen prüfen: `cd werkstatt/01-roh && sha256sum -c PRUEFSUMMEN.sha256`
5. Freigabe einholen. Vorgeschlagene Reihenfolge, jeweils mit ja/nein:
   1. L1–L3 (kleine Layoutfragen)
   2. Stufe 2 – Normierung: 32 Adressblöcke → `kurverwaltungen.csv`, 54 Terminzeilen → `suendenfrei-termine.csv`, jeweils Original plus normiert, in `werkstatt/02-normiert/`, ohne Datenbank.
