# werkstatt/02-normiert — Stufe 2 der Pipeline

Erzeugt aus den beiden sauberen Quellen in `../01-roh/`. Die Quellen werden **nur gelesen**, nie verändert.
Keine Datenbank, kein Schema, kein Import. Fehlende CSV-Felder stehen als `-` (Bindestrich).

> `-` ist die Normierungs-/Fehlwertmarkierung. Er wird **nicht** in die Originaldateien zurückgeschrieben.
> Chat-Ergänzungen, die der Auftraggeber zitiert oder als Chat-Angabe bereitstellt, stehen in separaten Spalten. Die Chat-MSG-ID ist nicht mitgeliefert; deshalb bleiben diese Angaben `nicht_verifiziert`.

## Dateien

| Datei | Inhalt |
|---|---|
| `suendenfrei-termine.csv` | 54 Quellzeilen, 1:1 aus `Termine_2027_suendenfrei.txt` (2026: 9 · 2027: 45) |
| `kurverwaltungen.csv` | 33 normierte Adress-/Organisationsdatensätze aus 32 MD-Adressblöcken; Mönchgut ist parent/child getrennt |
| `PRUEFSUMMEN.sha256` | SHA-256 der beiden CSV-Dateien |

Format: UTF-8 mit BOM, Semikolon, CRLF, jedes Feld in Anführungszeichen. Alle Datenzeilen haben eindeutige IDs; keine CSV-Zelle ist leer.

Erzeugen bzw. prüfen (rein lesend gegenüber `01-roh/`):

```bash
node scripts/normalize-sources.mjs           # CSV erzeugen
node scripts/normalize-sources.mjs --verify  # nur prüfen, nichts schreiben
```

Bei einem erneuten Erzeugen wird `02-normiert/` aktualisiert, aber `01-roh/`, die Datenbank, das Schema und Option B werden nicht verändert.

---

## Spaltenaufbau `suendenfrei-termine.csv` (20 Spalten)

| Spalte | Bedeutung | Herkunft |
|---|---|---|
| `sf_id` | eigener Schlüssel `SF01`…`SF54` in Quellreihenfolge | vergeben |
| `jahr` | Quelljahr | aus Datumstext |
| `quellzeile` | Zeilennummer in der TXT | Fundstelle |
| `datum_original` | Datumstext unverändert | **Original** |
| `name_original` | Veranstalter/Name unverändert inkl. Sternchen | **Original** |
| `name_normiert` | zusätzlich normierter Name; `-` bei „noch offen“ | abgeleitet |
| `plz_ort_original` | PLZ/Ort unverändert, einschließlich x-Platzhalter | **Original** |
| `plz_normiert`, `ort_normiert` | getrennt aus `plz_ort_original`; `-` bei x-Platzhalter | abgeleitet |
| `zeitfenster_art` | `zeitraum` oder `wochenenden` (4 getrennt) | abgeleitet |
| `datumsherkunft` | `aus_quelle` oder `berechnet` | abgeleitet |
| `zeitfenster_anzahl` | 1 oder 4 | abgeleitet |
| `zeitfenster_iso` | alle Zeiträume `jjjj-mm-tt/jjjj-mm-tt`, mit `;` getrennt | abgeleitet |
| `start_iso`, `end_iso` | frühester Beginn / spätestes Ende (zum Sortieren) | abgeleitet |
| `sternchen` | `kein`, `*` oder `**` | **Original** |
| `bestaetigungsstatus` | `unbestaetigt` bei Sternchen, sonst `nicht_markiert` | abgeleitet |
| `ort_offen` | `ja` bei Platzhalter `xxxx`/`xxxxx` | abgeleitet |
| `hinweis` | belegte Hinweise (Zeitraumstyp, Platzhalter, Sternchen) | abgeleitet |
| `status_verifikation` | durchgehend `nicht_verifiziert` | Quellenlage |

**`start_iso`/`end_iso` sind bei Advent kein durchgehender Zeitraum.** Die Datensätze
`SF05` (2026) und `SF50` (2027) enthalten je vier Einträge in `zeitfenster_iso`.
Zwischen den Wochenenden liegen Veranstaltungslücken.

---

## Spaltenaufbau `kurverwaltungen.csv` (37 Spalten)

| Spalte | Bedeutung |
|---|---|
| `kv_id` | eigene eindeutige ID, `KV01`…`KV33`; source-block IDs KV01…KV32 bleiben stabil, `KV33` ist Middelhagen als Child-Zeile |
| `quellblock_id` | verweist auf den MD-Adressblock (`KV12` und `KV33` stammen beide aus MD-Zeilen 107–112) |
| `parent_id` | Eltern-ID; für Middelhagen `KV12`, für Thiessow `KV12`, sonst `-` |
| `hierarchie_rolle` | `eintrag`, `parent` oder `aussenstelle` |
| `hierarchie_herkunft` | Parent/Child-Zuordnung nach ausdrücklicher Vorgabe des Auftraggebers; sonst `-` |
| `eintragsname_original` | Name des jeweiligen Parent- oder Außenstellen-Datensatzes |
| `region_original`, `ort_original` | Gebiets- und Ortsüberschrift der MD |
| `name_haupt_original`, `name_zusatz_original` | originale Namen des MD-Adressblocks. Im aufgeteilten Mönchgut-Block stehen dieselben Quellnamen bei Parent und Child, damit beide zum Originalblock zurückverfolgbar sind |
| `strasse_original`, `plz_ort_original` | unveränderte Adresse des physischen Eintrags; Parent-Zeile erhält `-`, damit die Adresse nicht doppelt gezählt wird |
| `plz_normiert`, `ort_normiert` | getrennt aus `plz_ort_original` |
| `telefon_original` | Telefon wie in der MD, sonst `-` |
| `telefon_chat_ergaenzung` | zusätzliche, vom Auftraggeber mit dem Chat belegte Telefonnummer, sonst `-` |
| `telefon_normiert` | vorhandene Telefonnummer im internationalen Format `+49 Ortsvorwahl Rufnummer`; Quell-Rohwert bleibt separat |
| `fax_original` | Fax wie in der MD, sonst `-` |
| `fax_chat_ergaenzung` | Fax-Ergänzung/-Fehlwert laut Nutzerangabe, sonst `-` |
| `fax_normiert` | bisherige Fax-Normierung als reine Ziffernfolge; ein `+49` wird **nur** für Telefonnummern gebildet |
| `web_original`, `web_chat_ergaenzung`, `web_normiert` | MD-Original, getrennte Nutzerergänzung aus dem Chat-Kontext und ausgewählter normalisierter Wert |
| `email_1_original`, `email_1_chat_ergaenzung`, `email_1_normiert` | MD-Original, getrennte Chat-/Nutzerergänzung und ausgewählter normalisierter Wert |
| `email_2_original`, `email_2_normiert` | zweite MD-E-Mail, falls vorhanden |
| `chat_zitat_nutzer` | wörtliches Chat-Zitat, das der Auftraggeber in diesem Gespräch bereitgestellt hat, sonst `-` |
| `quelle_ergaenzung` | Herkunftshinweis zur Nutzer-/Chat-Ergänzung; sagt nicht, dass die MSG-ID oder das vollständige Chatarchiv eigenständig geprüft wurde |
| `chat_msg_id` | `-`: im bereitgestellten Zitat wurde keine Nachrichten-ID genannt |
| `hinweis` | Saison-/Quellnotiz oder Erläuterung der Aufteilung |
| `felder_fehlend_quelle` | fehlende Felder im unveränderten MD-Quellblock |
| `felder_fehlend_arbeitsstand` | fehlende Felder nach separaten Ergänzungen; beim Organisationsknoten `nicht_anwendbar` |
| `quellzeile` | MD-Zeilenspanne |
| `status_verifikation` | durchgehend `nicht_verifiziert` |
| `quelle_stand` | Fußzeile der MD: „Stand 2025 · Alle Angaben ohne Gewähr“ |

### Mönchgut-Hierarchie nach Auftraggebervorgabe

| CSV-ID | Parent | Eintragsname | Daten |
|---|---|---|---|
| `KV12` | `-` | Kurverwaltung Mönchgut | Parent-/Organisationsknoten, keine physische Adresse oder Kontaktdaten doppelt eingetragen |
| `KV33` | `KV12` | Tourist-Information Middelhagen | Adresse, Telefon und Fax aus MD-Block KV12; Website/E-Mail als getrennte Nutzer-/Chat-Ergänzungen |
| `KV13` | `KV12` | Tourist-Information Thiessow (Außenstelle) | Adresse/Website/E-Mail aus MD-Block KV13; Telefon `+49 38308 66010` und Fax-Fehlwert `-` getrennt gekennzeichnet |

`Ostseebad Mönchgut` bleibt als regionale Überschrift in `ort_original`. Der Parent ist
`Kurverwaltung Mönchgut`; die beiden Außenstellen sind getrennte Child-Datensätze.
Die übrigen drei MD-Blöcke mit zwei fett gedruckten Namen bleiben als Hauptname plus
Zusatzname in einer Zeile, da dort keine weiteren Außenstellen-Aufteilungen vorgegeben wurden.

### Baabe — Chat-Zitat ohne falsche Übernahme

- `KV09 Kurverwaltung Baabe`: Die Chat-Angabe `willkommen@baabe.de` bestätigt den schon in der MD stehenden Wert; es entsteht keine zweite E-Mail.
- `KV10 Infopavillion KV Baabe (außer Winter)`: Telefon steht in der MD; E-Mail, Fax und Internet stehen im CSV ausdrücklich als `-`. Die E-Mail der Kurverwaltung wird **nicht** auf den Infopavillon übertragen.

---

## Normierungsregeln und Fehlwerte

1. Originalwerte bleiben in eigenen Spalten; Chat-/Nutzerergänzungen werden nie in eine Original-MD-Spalte hineingeschrieben.
2. Fehlende CSV-Werte stehen als einzelnes `-`. Das `-` ist eine Normierungsmarkierung und kein nachträglich in die Rohquelle geschriebener Wert.
3. Telefonnummer: internationale Form `+49 {Vorwahl ohne führende 0} {Teilnehmernummer}`. Beispiel `(0 38 38) 80 77 80` → `+49 3838 807780`. Bereits international angegebene Chat-Nummern werden gruppiert übernommen. Telefonnummern sind dadurch normalisiert, nicht extern verifiziert.
4. Fax: Ziffernfolge aus der Original-MD; fehlender Faxwert bleibt `-`. Es wurde **keine** Fax-Vorwahl hinzugefügt.
5. E-Mail/Web: Kleinschreibung; kein `https://` ergänzt.
6. Sternchen `*`/`**` aus normiertem Namen/Ort entfernt und im separaten Status bewahrt.
7. Bindestrich „Wort- Wort“ → „Wort-Wort“, außer vor „und“/„bzw.“. „Fantasy- und Mittelalterfest“ bleibt unverändert.
8. Schrägstrich-Schreibweise „Ort / Ort“ → „Ort/Ort“.
9. Einzige Namenskorrektur aus der dokumentierten Fehlerliste: `Mittealter` → `Mittelalter` (SF20/SF27).
10. Tippfehler/Schreibungen in Kontaktnamen bleiben unverändert; etwa `Infopavillion` oder `Tourismus-und` werden nicht still korrigiert.

---

## Status der früheren Prüfpunkte

- **P1 Parent/Child:** nach Vorgabe umgesetzt, Mönchgut Parent KV12 und Childs KV33/KV13.
- **P2 Baabe/Mönchgut E-Mail:** Chat-Ergänzung füllt Middelhagen; Baabe-Kurverwaltung hat bereits ihre E-Mail; der Infopavillon bleibt ohne E-Mail.
- **P3 Telefon:** `+49`-Normierung bestätigt und umgesetzt; Fax bleibt separat.
- **P4 Kontaktnamen „…-und…“:** weiter unverändert; keine Korrekturfreigabe.
- **P5 Vier Zeitfenster pro Event:** CSV enthält separate 4er-Liste. ⚠ Eine spätere Datenbank-Abbildung mehrerer Perioden pro Event verändert das Datenmodell (Stufe 5).
- **P6 Kontakte-Datenmodell:** CSV ist detailliert, die spätere Datenbankentscheidung bleibt offen.
- **P7 Quellenüberschrift KV01:** mechanische MD-Struktur bleibt erhalten; siehe vorherige Dokumentation/Abgleich.

## Was Stufe 2 ausdrücklich nicht tut

- Keine Datenbank, kein Schema, keine Tabellen, kein Import.
- Keine Übernahme in die bestehende App.
- Keine Dublettenentscheidung, Verifikation oder externe Anreicherung.
- Keine stillen Überschreibungen: Original-MD-Felder, ergänzende Nutzerangaben, Quelle und Status bleiben getrennt.
