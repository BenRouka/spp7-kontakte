import { relations } from "drizzle-orm";
import {
  boolean,
  integer,
  pgTable,
  serial,
  text,
  timestamp,
  date,
  index,
  uniqueIndex,
} from "drizzle-orm/pg-core";

/* ------------------------------------------------------------------ */
/* Stufe-5-Schema — Zielbild aus dem Beschlussverzeichnis:             */
/* Hierarchie Region → Ort → Einrichtung (B-16), Termine als           */
/* Quellzeile + n Zeitfenster (B-10/B-12), Beschlüsse mit              */
/* Prio-1-Basis / Prio-2-Ergänzung / Status.                           */
/* ------------------------------------------------------------------ */

export const regionen = pgTable(
  "regionen",
  {
    id: integer("id").primaryKey(), // 1–9, explizit vergeben (Reihenfolge)
    name: text("name").notNull(),
  },
  (t) => [uniqueIndex("regionen_name_uq").on(t.name)],
);

export const kontakte = pgTable(
  "kontakte",
  {
    kvId: text("kv_id").primaryKey(), // KV01 … KV32, KV01.1, KV01.2, STADT-PUTBUS
    regionId: integer("region_id")
      .notNull()
      .references(() => regionen.id, { onDelete: "restrict" }),
    ort: text("ort").notNull(),
    name: text("name").notNull(),
    anschrift: text("anschrift"),
    telefon: text("telefon"),
    fax: text("fax"),
    email1: text("email_1"),
    email2: text("email_2"),
    email3: text("email_3"),
    web: text("web"),
    typ: text("typ").notNull(),
    prio2ChatHinweis: text("prio2_chat_hinweis"),
    hatMdBlock: boolean("hat_md_block").notNull().default(true),
    sortierung: integer("sortierung").notNull(), // Zeilenposition im Freeze
  },
  (t) => [
    index("kontakte_region_idx").on(t.regionId),
    index("kontakte_ort_idx").on(t.ort),
  ],
);

export const termine = pgTable("termine", {
  sfId: text("sf_id").primaryKey(), // SF01 … SF54
  jahr: integer("jahr").notNull(),
  datumOriginal: text("datum_original").notNull(),
  nameOriginal: text("name_original").notNull(),
  plzOrtOriginal: text("plz_ort_original").notNull(),
  zeitfensterAnzahl: integer("zeitfenster_anzahl").notNull(),
  sternchen: text("sternchen").notNull().default("kein"), // kein | * | **
  hinweis: text("hinweis"),
  sortierung: integer("sortierung").notNull(),
});

export const terminZeitfenster = pgTable(
  "termin_zeitfenster",
  {
    id: serial("id").primaryKey(),
    terminSfId: text("termin_sf_id")
      .notNull()
      .references(() => termine.sfId, { onDelete: "cascade" }),
    nr: integer("nr").notNull(), // 1..n — Advent bleibt 1 Quellzeile mit 4 Fenstern (B-10)
    von: date("von", { mode: "string" }).notNull(), // ISO YYYY-MM-DD
    bis: date("bis", { mode: "string" }).notNull(),
    raw: text("raw").notNull(), // Originalfenster "von/bis" aus dem Freeze
  },
  (t) => [
    index("zeitfenster_termin_idx").on(t.terminSfId),
    index("zeitfenster_von_idx").on(t.von),
  ],
);

export const beschluesse = pgTable("beschluesse", {
  id: text("id").primaryKey(), // B-01 … B-20
  bereich: text("bereich").notNull(), // Kontakte | Termine | Archiv | Ablauf | Offen
  titel: text("titel").notNull(),
  prio1Basis: text("prio_1_basis").notNull(),
  prio2Ergaenzung: text("prio_2_ergaenzung").notNull(),
  massnahme: text("massnahme").notNull(),
  status: text("status").notNull(), // entschieden | provisorisch
  sortierung: integer("sortierung").notNull(),
});

/**
 * Audit-Trail des Imports: eine Zeile je Freeze-Datei und Lauf.
 * sha256 ist der zum Importzeitpunkt neu berechnete Wert — er muss dem
 * Manifest PRUEFSUMMEN.sha256 entsprechen, sonst bricht der Import ab.
 */
export const importProtokoll = pgTable(
  "import_protokoll",
  {
    id: serial("id").primaryKey(),
    laufId: text("lauf_id").notNull(),
    datei: text("datei").notNull(),
    sha256: text("sha256").notNull(),
    datensaetze: integer("datensaetze").notNull(),
    detail: text("detail").notNull(),
    pruefsummeOk: boolean("pruefsumme_ok").notNull(),
    importiertAm: timestamp("importiert_am", {
      withTimezone: true,
      mode: "string",
    })
      .notNull()
      .defaultNow(),
  },
  (t) => [index("import_protokoll_lauf_idx").on(t.laufId)],
);

/* ------------------------------------------------------------------ */
/* Relationen                                                          */
/* ------------------------------------------------------------------ */

export const regionenRelations = relations(regionen, ({ many }) => ({
  kontakte: many(kontakte),
}));

export const kontakteRelations = relations(kontakte, ({ one }) => ({
  region: one(regionen, {
    fields: [kontakte.regionId],
    references: [regionen.id],
  }),
}));

export const termineRelations = relations(termine, ({ many }) => ({
  zeitfenster: many(terminZeitfenster),
}));

export const terminZeitfensterRelations = relations(
  terminZeitfenster,
  ({ one }) => ({
    termin: one(termine, {
      fields: [terminZeitfenster.terminSfId],
      references: [termine.sfId],
    }),
  }),
);

export type Region = typeof regionen.$inferSelect;
export type Kontakt = typeof kontakte.$inferSelect;
export type Termin = typeof termine.$inferSelect;
export type TerminZeitfenster = typeof terminZeitfenster.$inferSelect;
export type Beschluss = typeof beschluesse.$inferSelect;
export type ImportProtokollEintrag = typeof importProtokoll.$inferSelect;

/* ================================================================== */
/* STUFE 6 — Altbestand (Alt-App / Mockup-Export, Stand 29.09.2026)    */
/* Grundsatz: Die kuratierten Tabellen oben bleiben führend und        */
/* unverändert. Alles hier ist Prio-2-Material mit Herkunftsvermerk.   */
/* Zuordnung erfolgt über Brückentabellen, nie durch Überschreiben.    */
/* ================================================================== */

export const altEvents = pgTable(
  "alt_events",
  {
    eventId: text("event_id").primaryKey(), // F01…, M…, S…, K…, C…, T…, R…
    quelleTyp: text("quelle_typ").notNull(), // Flyer | Chat | Chat (KI-Liste) | Sündenfrei | Nutzer
    quelle: text("quelle"),
    typ: text("typ").notNull(),
    name: text("name").notNull(),
    location: text("location"),
    strasse: text("strasse"),
    plz: text("plz"),
    ort: text("ort"),
    region: text("region"),
    land: text("land"),
    lat: text("lat"),
    lng: text("lng"),
    geoStatus: text("geo_status"),
    geoQualitaet: text("geo_qualitaet").notNull().default("unbekannt"), // zentroid|osm|offen|sonstige
    eintritt: text("eintritt"),
    gage: text("gage"),
    gageStatus: text("gage_status"),
    konditionen: text("konditionen"),
    bewerbung: text("bewerbung"),
    bewerbungStatus: text("bewerbung_status"),
    kiRang: text("ki_rang"),
    tags: text("tags"),
    kurzbeschreibung: text("kurzbeschreibung"),
    langbeschreibung: text("langbeschreibung"),
    passung: text("passung"),
    naechsterSchritt: text("naechster_schritt"),
    unklar: text("unklar"),
    flyer: text("flyer"),
    msg: text("msg"),
    /** kuratiert = über Prio-1-Beleg mit einem Werkstatt-Termin verknüpft */
    zuordnung: text("zuordnung").notNull().default("rest"), // kuratiert | rest
    vermerk: text("vermerk").notNull(), // Herkunfts- und Prüfvermerk (B-17/O-6)
  },
  (t) => [
    index("alt_events_zuordnung_idx").on(t.zuordnung),
    index("alt_events_quelle_idx").on(t.quelleTyp),
    index("alt_events_ort_idx").on(t.ort),
  ],
);

/** Brücke kuratierter Termin ↔ Altbestands-Event (n:m, Serien-Events). */
export const terminAltEvent = pgTable(
  "termin_alt_event",
  {
    id: serial("id").primaryKey(),
    terminSfId: text("termin_sf_id")
      .notNull()
      .references(() => termine.sfId, { onDelete: "cascade" }),
    altEventId: text("alt_event_id")
      .notNull()
      .references(() => altEvents.eventId, { onDelete: "cascade" }),
    basis: text("basis").notNull(), // Datum+Name+PLZ etc.
    score: integer("score").notNull(),
    hinweis: text("hinweis"),
  },
  (t) => [
    uniqueIndex("termin_alt_event_uq").on(t.terminSfId, t.altEventId),
    index("termin_alt_event_sf_idx").on(t.terminSfId),
  ],
);

export const altEventDates = pgTable(
  "alt_event_dates",
  {
    dateId: text("date_id").primaryKey(),
    altEventId: text("alt_event_id")
      .notNull()
      .references(() => altEvents.eventId, { onDelete: "cascade" }),
    von: text("von"),
    bis: text("bis"),
    vonIso: text("von_iso"),
    bisIso: text("bis_iso"),
    art: text("art"),
    kommentar: text("kommentar"),
  },
  (t) => [index("alt_event_dates_event_idx").on(t.altEventId)],
);

export const altActs = pgTable("alt_acts", {
  actId: text("act_id").primaryKey(),
  name: text("name").notNull(),
  namensvarianten: text("namensvarianten"),
  anzahlEvents: integer("anzahl_events").notNull().default(0),
  events: text("events"),
  rollen: text("rollen"),
});

export const altEventActs = pgTable(
  "alt_event_acts",
  {
    linkId: text("link_id").primaryKey(),
    altEventId: text("alt_event_id")
      .notNull()
      .references(() => altEvents.eventId, { onDelete: "cascade" }),
    actId: text("act_id")
      .notNull()
      .references(() => altActs.actId, { onDelete: "cascade" }),
    rolle: text("rolle"),
    slotTag: text("slot_tag"),
    unsicher: boolean("unsicher").notNull().default(false),
    notiz: text("notiz"),
  },
  (t) => [
    index("alt_event_acts_event_idx").on(t.altEventId),
    index("alt_event_acts_act_idx").on(t.actId),
  ],
);

export const altPartners = pgTable("alt_partners", {
  partnerId: text("partner_id").primaryKey(),
  name: text("name").notNull(),
  anzahlEvents: integer("anzahl_events").notNull().default(0),
  events: text("events"),
  rollen: text("rollen"),
});

export const altEventPartners = pgTable(
  "alt_event_partners",
  {
    linkId: text("link_id").primaryKey(),
    altEventId: text("alt_event_id")
      .notNull()
      .references(() => altEvents.eventId, { onDelete: "cascade" }),
    partnerId: text("partner_id")
      .notNull()
      .references(() => altPartners.partnerId, { onDelete: "cascade" }),
    rolle: text("rolle"),
    unsicher: boolean("unsicher").notNull().default(false),
  },
  (t) => [
    index("alt_event_partners_event_idx").on(t.altEventId),
    index("alt_event_partners_partner_idx").on(t.partnerId),
  ],
);

export const altEventFeatures = pgTable(
  "alt_event_features",
  {
    linkId: text("link_id").primaryKey(),
    altEventId: text("alt_event_id")
      .notNull()
      .references(() => altEvents.eventId, { onDelete: "cascade" }),
    feature: text("feature").notNull(),
    kategorie: text("kategorie"),
  },
  (t) => [index("alt_event_features_event_idx").on(t.altEventId)],
);

export const altEventChannels = pgTable(
  "alt_event_channels",
  {
    linkId: text("link_id").primaryKey(),
    altEventId: text("alt_event_id")
      .notNull()
      .references(() => altEvents.eventId, { onDelete: "cascade" }),
    kanal: text("kanal").notNull(),
    wert: text("wert").notNull(),
  },
  (t) => [index("alt_event_channels_event_idx").on(t.altEventId)],
);

export const altEventTags = pgTable(
  "alt_event_tags",
  {
    id: serial("id").primaryKey(),
    altEventId: text("alt_event_id")
      .notNull()
      .references(() => altEvents.eventId, { onDelete: "cascade" }),
    tag: text("tag").notNull(),
  },
  (t) => [
    index("alt_event_tags_event_idx").on(t.altEventId),
    index("alt_event_tags_tag_idx").on(t.tag),
  ],
);

export const altTimetable = pgTable(
  "alt_timetable",
  {
    linkId: text("link_id").primaryKey(),
    altEventId: text("alt_event_id")
      .notNull()
      .references(() => altEvents.eventId, { onDelete: "cascade" }),
    zeit: text("zeit"),
    programmpunkt: text("programmpunkt").notNull(),
  },
  (t) => [index("alt_timetable_event_idx").on(t.altEventId)],
);

export const altFeedContext = pgTable(
  "alt_feed_context",
  {
    linkId: text("link_id").primaryKey(),
    altEventId: text("alt_event_id").references(() => altEvents.eventId, {
      onDelete: "set null",
    }),
    eventRef: text("event_ref"), // Roh-Referenz, auch wenn verwaist (z. B. F29)
    account: text("account"),
    notiz: text("notiz"),
    relevanz: text("relevanz"),
    verwaist: boolean("verwaist").notNull().default(false),
  },
  (t) => [index("alt_feed_context_event_idx").on(t.altEventId)],
);

export const altFlyerSources = pgTable(
  "alt_flyer_sources",
  {
    flyer: text("flyer").primaryKey(), // "01" … "79"
    altEventId: text("alt_event_id").references(() => altEvents.eventId, {
      onDelete: "set null",
    }),
    msg: text("msg"),
    datum: text("datum"),
    montage: text("montage"),
    format: text("format"),
    status: text("status"),
    ocrKonfidenz: text("ocr_konfidenz"),
    ocrRohtext: text("ocr_rohtext"),
    hinweis: text("hinweis"),
    bildOriginal: text("bild_original").notNull(),
    bildThumb: text("bild_thumb").notNull(),
  },
  (t) => [index("alt_flyer_event_idx").on(t.altEventId)],
);

export const altContacts = pgTable(
  "alt_contacts",
  {
    contactId: text("contact_id").primaryKey(),
    organisation: text("organisation").notNull(),
    typ: text("typ"),
    kanal: text("kanal"),
    ort: text("ort"),
    region: text("region"),
    lat: text("lat"),
    lng: text("lng"),
    msg: text("msg"),
    notiz: text("notiz"),
    /** Brücke zum kuratierten Kontakt — nie überschreibend (O-09). */
    kuratiertKvId: text("kuratiert_kv_id").references(() => kontakte.kvId, {
      onDelete: "set null",
    }),
    zuordnungBasis: text("zuordnung_basis"),
    zuordnung: text("zuordnung").notNull().default("rest"),
    vermerk: text("vermerk").notNull(),
  },
  (t) => [
    index("alt_contacts_kv_idx").on(t.kuratiertKvId),
    index("alt_contacts_zuordnung_idx").on(t.zuordnung),
  ],
);

export const altChatItems = pgTable(
  "alt_chat_items",
  {
    id: serial("id").primaryKey(),
    msg: text("msg"),
    datum: text("datum"),
    typ: text("typ"),
    wert: text("wert"),
    foto: text("foto"),
    kontext: text("kontext"),
    zugeordnet: text("zugeordnet"),
  },
  (t) => [index("alt_chat_items_msg_idx").on(t.msg)],
);

export const altChatMessages = pgTable(
  "alt_chat_messages",
  {
    msg: text("msg").primaryKey(),
    datum: text("datum"),
    typ: text("typ"),
    absender: text("absender"),
    weitergeleitetVon: text("weitergeleitet_von"),
    text: text("text"),
    links: text("links"),
    medium: text("medium"),
    flyer: text("flyer"),
    altEventId: text("alt_event_id").references(() => altEvents.eventId, {
      onDelete: "set null",
    }),
    eventName: text("event_name"),
    aktion: text("aktion"),
  },
  (t) => [
    index("alt_chat_messages_event_idx").on(t.altEventId),
    index("alt_chat_messages_flyer_idx").on(t.flyer),
  ],
);

/* ------------------------------------------------------------------ */
/* Relationen Altbestand                                               */
/* ------------------------------------------------------------------ */

export const altEventsRelations = relations(altEvents, ({ many }) => ({
  dates: many(altEventDates),
  acts: many(altEventActs),
  partners: many(altEventPartners),
  features: many(altEventFeatures),
  channels: many(altEventChannels),
  tags: many(altEventTags),
  timetable: many(altTimetable),
  flyers: many(altFlyerSources),
  chat: many(altChatMessages),
  feed: many(altFeedContext),
  termine: many(terminAltEvent),
}));

export const terminAltEventRelations = relations(terminAltEvent, ({ one }) => ({
  termin: one(termine, {
    fields: [terminAltEvent.terminSfId],
    references: [termine.sfId],
  }),
  altEvent: one(altEvents, {
    fields: [terminAltEvent.altEventId],
    references: [altEvents.eventId],
  }),
}));

export const altEventDatesRelations = relations(altEventDates, ({ one }) => ({
  event: one(altEvents, {
    fields: [altEventDates.altEventId],
    references: [altEvents.eventId],
  }),
}));

export const altActsRelations = relations(altActs, ({ many }) => ({
  events: many(altEventActs),
}));

export const altEventActsRelations = relations(altEventActs, ({ one }) => ({
  event: one(altEvents, {
    fields: [altEventActs.altEventId],
    references: [altEvents.eventId],
  }),
  act: one(altActs, {
    fields: [altEventActs.actId],
    references: [altActs.actId],
  }),
}));

export const altPartnersRelations = relations(altPartners, ({ many }) => ({
  events: many(altEventPartners),
}));

export const altEventPartnersRelations = relations(
  altEventPartners,
  ({ one }) => ({
    event: one(altEvents, {
      fields: [altEventPartners.altEventId],
      references: [altEvents.eventId],
    }),
    partner: one(altPartners, {
      fields: [altEventPartners.partnerId],
      references: [altPartners.partnerId],
    }),
  }),
);

export const altEventFeaturesRelations = relations(
  altEventFeatures,
  ({ one }) => ({
    event: one(altEvents, {
      fields: [altEventFeatures.altEventId],
      references: [altEvents.eventId],
    }),
  }),
);

export const altEventChannelsRelations = relations(
  altEventChannels,
  ({ one }) => ({
    event: one(altEvents, {
      fields: [altEventChannels.altEventId],
      references: [altEvents.eventId],
    }),
  }),
);

export const altEventTagsRelations = relations(altEventTags, ({ one }) => ({
  event: one(altEvents, {
    fields: [altEventTags.altEventId],
    references: [altEvents.eventId],
  }),
}));

export const altTimetableRelations = relations(altTimetable, ({ one }) => ({
  event: one(altEvents, {
    fields: [altTimetable.altEventId],
    references: [altEvents.eventId],
  }),
}));

export const altFeedContextRelations = relations(altFeedContext, ({ one }) => ({
  event: one(altEvents, {
    fields: [altFeedContext.altEventId],
    references: [altEvents.eventId],
  }),
}));

export const altFlyerSourcesRelations = relations(
  altFlyerSources,
  ({ one }) => ({
    event: one(altEvents, {
      fields: [altFlyerSources.altEventId],
      references: [altEvents.eventId],
    }),
  }),
);

export const altContactsRelations = relations(altContacts, ({ one }) => ({
  kuratiert: one(kontakte, {
    fields: [altContacts.kuratiertKvId],
    references: [kontakte.kvId],
  }),
}));

export const altChatMessagesRelations = relations(
  altChatMessages,
  ({ one }) => ({
    event: one(altEvents, {
      fields: [altChatMessages.altEventId],
      references: [altEvents.eventId],
    }),
  }),
);

export type AltEvent = typeof altEvents.$inferSelect;
export type AltAct = typeof altActs.$inferSelect;
export type AltPartner = typeof altPartners.$inferSelect;
export type AltFlyer = typeof altFlyerSources.$inferSelect;
export type AltContact = typeof altContacts.$inferSelect;
export type AltChatMessage = typeof altChatMessages.$inferSelect;
