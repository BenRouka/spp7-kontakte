import Link from "next/link";
import {
  ArrowDownToLine,
  Database,
  FileText,
  Fingerprint,
  Hash,
  KeyRound,
  Link2,
  RefreshCcw,
  Table2,
  TerminalSquare,
} from "lucide-react";
import { getDbCounts, getLetzterImportLauf, fmtZeitstempel } from "@/lib/data";
import { VerifyWidget } from "@/components/verify-widget";
import { Badge, Card, Eyebrow, SectionHead } from "@/components/ui";

export const dynamic = "force-dynamic";

const SCHEMA = [
  {
    tabelle: "regionen",
    pk: "id (1–9, explizit)",
    bezug: "—",
    zweck: "Die 9 Regionen in Handoff-Reihenfolge, Übergreifend zuerst.",
  },
  {
    tabelle: "kontakte",
    pk: "kv_id (Text)",
    bezug: "→ regionen.id",
    zweck: "Ein Datensatz pro echter Einrichtung (B-16), email_1–email_3 als Spalten.",
  },
  {
    tabelle: "termine",
    pk: "sf_id (Text)",
    bezug: "—",
    zweck: "54 Quellzeilen mit Originalschreibweisen und Sternchen-Marker.",
  },
  {
    tabelle: "termin_zeitfenster",
    pk: "id (Serial)",
    bezug: "→ termine.sf_id (cascade)",
    zweck: "60 Fenster als echte Datumsdaten; Advent = 4 Zeilen zur selben Quellzeile (B-10).",
  },
  {
    tabelle: "beschluesse",
    pk: "id (B-01…B-20)",
    bezug: "—",
    zweck: "Verzeichnis mit Prio-1-Basis, Prio-2-Ergänzung, Maßnahme, Status.",
  },
  {
    tabelle: "import_protokoll",
    pk: "id (Serial)",
    bezug: "lauf_id gruppiert Läufe",
    zweck: "Audit-Trail: je Datei Hash, Datensatzanzahl und Zeitstempel des Imports.",
  },
];

const HANDOFF_DOWNLOADS = [
  {
    file: "00-HANDOFF-DIRECT-MODE.md",
    label: "Im neuen Chat zuerst lesen",
  },
  {
    file: "01-OFFENE-PUNKTE.csv",
    label: "13 manuell zu prüfende Befunde",
  },
  {
    file: "02-BEFUND-ABGRENZUNG-65.csv",
    label: "Audit: 52 abgedeckt + 13 offen",
  },
  {
    file: "03-EXPORT-PROTOKOLL.md",
    label: "Arena-Export & Wiederanlauf",
  },
  {
    file: "04-STARTPROMPT-DIRECT-MODE.txt",
    label: "Kopierbare Startanweisung",
  },
  {
    file: "PRUEFSUMMEN.sha256",
    label: "Manifest des Übergabepakets",
  },
];

const FREEZE_DOWNLOADS = [
  { file: "arbeitsstand-kontakte.csv", label: "Kontakte (35 Datensätze)" },
  { file: "arbeitsstand-termine.csv", label: "Termine (54 Quellzeilen)" },
  { file: "beschlussverzeichnis.csv", label: "Beschlüsse (20)" },
  { file: "PRUEFSUMMEN.sha256", label: "sha256-Manifest" },
  { file: "HANDOFF.md", label: "Übergabeprotokoll" },
];

export default async function Stufe5Page() {
  const [counts, lauf] = await Promise.all([
    getDbCounts(),
    getLetzterImportLauf(),
  ]);

  const tabellenCounts: Record<string, number> = {
    regionen: counts.regionen,
    kontakte: counts.kontakte,
    termine: counts.termine,
    termin_zeitfenster: counts.zeitfenster,
    beschluesse: counts.beschluesse,
    import_protokoll: counts.protokoll,
  };

  return (
    <div className="space-y-14">
      <section className="rise pt-4">
        <Eyebrow>Stufe 5 · Import & Datenbank · Protokoll</Eyebrow>
        <h1 className="font-display mt-4 max-w-3xl text-[clamp(2.2rem,5vw,3.8rem)] font-medium leading-[1.02] tracking-tight text-ink">
          Schema steht. Gate hält. <span className="text-lime">Import ist drin.</span>
        </h1>
        <p className="mt-4 max-w-2xl text-[14px] leading-relaxed text-ink-soft">
          Der Import läuft in drei Zügen: erst das Integritäts-Gate (sha256
          gegen das Manifest — Abweichung bricht ab, ohne eine Zeile zu
          schreiben), dann die Plausibilitätsprüfung gegen die
          Ground-Truth-Zahlen, zuletzt der transaktionale Import. Er ist
          idempotent: Jeder Lauf ersetzt den Bestand vollständig durch das
          verifizierte Paket.
        </p>
        {lauf ? (
          <div className="mt-5 flex flex-wrap items-center gap-2">
            <Badge tone="lime">
              <Fingerprint className="h-3 w-3" />
              Lauf {lauf.laufId.slice(0, 8)}…
            </Badge>
            <Badge>{fmtZeitstempel(lauf.importiertAm)}</Badge>
          </div>
        ) : null}
      </section>

      {/* Import-Protokoll ------------------------------------------- */}
      <section className="rise" style={{ animationDelay: "80ms" }}>
        <SectionHead
          eyebrow="Audit-Trail · Tabelle import_protokoll"
          title="Der letzte Importlauf"
          right={<Badge tone="lime">sha256 je Datei neu berechnet</Badge>}
        />
        {lauf ? (
          <div className="overflow-x-auto rounded-xl border border-line">
            <table className="w-full min-w-[820px] border-collapse bg-raised/80 text-left">
              <thead>
                <tr className="border-b border-line bg-raised2/60 font-mono text-[10px] uppercase tracking-[0.14em] text-muted">
                  <th className="px-4 py-2.5 font-medium">Datei</th>
                  <th className="px-4 py-2.5 font-medium">sha256 (Ist)</th>
                  <th className="px-4 py-2.5 text-right font-medium">Datensätze</th>
                  <th className="px-4 py-2.5 font-medium">Befund</th>
                  <th className="px-4 py-2.5 text-right font-medium">Importiert</th>
                </tr>
              </thead>
              <tbody>
                {lauf.eintraege.map((e) => (
                  <tr
                    key={e.datei}
                    className="border-b border-line-soft last:border-0"
                  >
                    <td className="px-4 py-3">
                      <span className="flex items-center gap-2 font-mono text-[12px] text-ink">
                        <FileText className="h-3.5 w-3.5 text-lime/70" />
                        {e.datei}
                      </span>
                    </td>
                    <td className="px-4 py-3 font-mono text-[11.5px] text-muted">
                      {e.sha256.slice(0, 20)}…
                    </td>
                    <td className="tnum px-4 py-3 text-right text-[13px] font-medium text-ink">
                      {e.datensaetze}
                    </td>
                    <td className="max-w-[320px] px-4 py-3 text-[11.5px] leading-snug text-muted">
                      {e.detail}
                    </td>
                    <td className="px-4 py-3 text-right font-mono text-[11px] text-muted">
                      {fmtZeitstempel(e.importiertAm)}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        ) : (
          <Card className="p-6 text-[13px] text-muted">
            Kein Import protokolliert — Tabelle import_protokoll ist leer.
            Import mit <code className="font-mono text-ink-soft">npx tsx src/db/seed.ts</code> starten.
          </Card>
        )}
        <p className="mt-3 flex items-center gap-2 text-[12px] text-muted">
          <Hash className="h-3.5 w-3.5 text-lime/70" />
          Vollständige Hashes stehen im Manifest
          <code className="font-mono text-[11px] text-ink-soft">/export/FREEZE/PRUEFSUMMEN.sha256</code>
          — die Freeze-Dateien selbst werden niemals geschrieben.
        </p>
      </section>

      {/* Schema + Verifikation --------------------------------------- */}
      <section className="rise grid gap-6 lg:grid-cols-[1.35fr_1fr]" style={{ animationDelay: "140ms" }}>
        <div>
          <SectionHead
            eyebrow="Schema · drizzle-kit push"
            title="Sechs Tabellen, drei Register"
            right={<Table2 className="h-4 w-4 text-muted" />}
          />
          <ul className="space-y-2.5">
            {SCHEMA.map((s) => (
              <li
                key={s.tabelle}
                className="card-lift rounded-xl border border-line bg-raised/80 p-4"
              >
                <div className="flex flex-wrap items-center gap-x-3 gap-y-1">
                  <span className="font-mono text-[13px] font-semibold text-ink">
                    {s.tabelle}
                  </span>
                  <Badge>
                    <KeyRound className="h-2.5 w-2.5" />
                    {s.pk}
                  </Badge>
                  {s.bezug !== "—" ? (
                    <Badge>
                      <Link2 className="h-2.5 w-2.5" />
                      {s.bezug}
                    </Badge>
                  ) : null}
                  <span className="tnum ml-auto font-mono text-[13px] font-medium text-lime">
                    {tabellenCounts[s.tabelle]} Zeilen
                  </span>
                </div>
                <p className="mt-2 text-[12.5px] leading-snug text-muted">
                  {s.zweck}
                </p>
              </li>
            ))}
          </ul>
        </div>
        <div>
          <SectionHead eyebrow="Gegenprobe" title="Live-Verifikation" />
          <VerifyWidget />
          <div className="mt-4 rounded-xl border border-line bg-raised/80 p-4">
            <p className="flex items-center gap-1.5 font-mono text-[10px] font-semibold uppercase tracking-[0.18em] text-muted">
              <RefreshCcw className="h-3.5 w-3.5 text-lime" />
              Wiederholbarkeit
            </p>
            <pre className="scrollbox mt-3 overflow-x-auto rounded-lg border border-line-soft bg-base/80 p-3 font-mono text-[12px] leading-relaxed text-ink-soft">
{`# Schema anwenden
npx drizzle-kit push

# Import (Gate → Plausibilität → Transaktion)
npx tsx src/db/seed.ts

# Manifest selbst prüfen
cd public/export/FREEZE
sha256sum -c PRUEFSUMMEN.sha256`}
            </pre>
            <p className="mt-3 flex items-start gap-2 text-[12px] leading-snug text-muted">
              <TerminalSquare className="mt-0.5 h-3.5 w-3.5 shrink-0 text-lime/70" />
              Der Seed ist destruktiv-idempotent: Zieltabelle leeren, Paket neu
              einspielen — niemals mergen, niemals raten (Regel 7).
            </p>
          </div>
        </div>
      </section>

      {/* Export ------------------------------------------------------ */}
      <section className="rise" style={{ animationDelay: "200ms" }}>
        <SectionHead
          eyebrow="Freeze · Übergabe in Direct Mode"
          title="Exportpaket für den nächsten Chat"
          right={<Badge tone="lime">52 abgedeckt · 13 offen</Badge>}
        />
        <div className="mb-5 rounded-xl border border-lime/25 bg-lime/[0.05] p-4">
          <p className="text-[13px] font-medium text-lime-soft">
            Arena-GUI: das gesamte Projekt als ZIP exportieren.
          </p>
          <p className="mt-1 text-[12px] leading-relaxed text-muted">
            Im neuen Chat zuerst <code className="font-mono text-[11px] text-ink-soft">00-HANDOFF-DIRECT-MODE.md</code> übergeben.
            Die Datenbank wird deterministisch aus Schema und Stufe-4-Freeze
            rekonstruiert; keine offene Zeile wird automatisch entschieden.
          </p>
        </div>
        <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
          {HANDOFF_DOWNLOADS.map((d) => (
            <a
              key={d.file}
              href={`/export/STUFE-5-FREEZE-2026-10-04/${d.file}`}
              download
              className="group"
            >
              <Card lift className="flex h-full flex-col p-4">
                <ArrowDownToLine className="h-4 w-4 text-lime" />
                <p className="mt-3 break-all font-mono text-[11.5px] leading-snug text-ink">
                  {d.file}
                </p>
                <p className="mt-1.5 flex-1 text-[11.5px] leading-snug text-muted">
                  {d.label}
                </p>
                <p className="mt-3 border-t border-line-soft pt-2 font-mono text-[9.5px] uppercase tracking-[0.12em] text-muted group-hover:text-lime">
                  Stufe 5 · Freeze 2026-10-04
                </p>
              </Card>
            </a>
          ))}
        </div>

        <div className="mt-10 flex items-center gap-3 border-b border-line pb-3">
          <Database className="h-4 w-4 text-muted" />
          <h3 className="font-display text-[1.35rem] font-medium text-ink">
            Ursprüngliches Stufe-4-Freeze · Ground Truth
          </h3>
        </div>
        <div className="mt-4 grid gap-3 sm:grid-cols-2 lg:grid-cols-5">
          {FREEZE_DOWNLOADS.map((d) => (
            <a
              key={d.file}
              href={`/export/FREEZE/${d.file}`}
              download
              className="group"
            >
              <Card lift className="flex h-full flex-col p-4">
                <ArrowDownToLine className="h-4 w-4 text-lime" />
                <p className="mt-3 break-all font-mono text-[11.5px] leading-snug text-ink">
                  {d.file}
                </p>
                <p className="mt-1.5 flex-1 text-[11.5px] leading-snug text-muted">
                  {d.label}
                </p>
                <p className="mt-3 border-t border-line-soft pt-2 font-mono text-[9.5px] uppercase tracking-[0.12em] text-muted group-hover:text-lime">
                  Byteidentisch · Stufe 4
                </p>
              </Card>
            </a>
          ))}
        </div>
        <p className="mt-4 text-[12px] leading-relaxed text-muted">
          Die Dateien unter <code className="font-mono text-[11px] text-ink-soft">public/export/FREEZE/</code> sind
          die Ground Truth. Die Datenbank ist ihre verifizierte, relational
          aufgebaute Kopie — Ansichten unter{" "}
          <Link href="/kontakte" className="text-lime-soft underline decoration-lime/30 underline-offset-2">Kontakte</Link>,{" "}
          <Link href="/termine" className="text-lime-soft underline decoration-lime/30 underline-offset-2">Termine</Link> und{" "}
          <Link href="/beschluesse" className="text-lime-soft underline decoration-lime/30 underline-offset-2">Beschlüsse</Link>{" "}
          lesen ausschließlich daraus.
        </p>
      </section>
    </div>
  );
}
