"use client";

import { useMemo, useState } from "react";
import {
  AlertCircle,
  Asterisk,
  CalendarRange,
  ChevronDown,
  CornerDownRight,
  Filter,
  MapPin,
} from "lucide-react";
import clsx from "clsx";
import type { TerminAnzeige } from "@/lib/data";

export interface TerminJahrDto {
  jahr: number;
  quellzeilen: number;
  zeitfenster: number;
  gruppen: { key: string; label: string; termine: TerminAnzeige[] }[];
}

function SternBadge({ sternchen }: { sternchen: string }) {
  if (sternchen === "kein" || !sternchen) return null;
  return (
    <span
      title="Termin oder Ort wahrscheinlich, noch unbestätigt (B-11)"
      className="inline-flex items-center gap-0.5 rounded-full border border-amber/35 bg-amber/10 px-2 py-0.5 font-mono text-[10px] font-semibold uppercase tracking-[0.08em] text-amber"
    >
      <Asterisk className="h-3 w-3" />
      {sternchen === "**" ? "** besonders unsicher" : "* unbestätigt"}
    </span>
  );
}

export function TermineBrowser({ jahre }: { jahre: TerminJahrDto[] }) {
  const [jahr, setJahr] = useState(jahre[0]?.jahr ?? 2026);
  const [nurStern, setNurStern] = useState(false);
  const [offen, setOffen] = useState<Record<string, boolean>>({});

  const aktiv = jahre.find((j) => j.jahr === jahr) ?? jahre[0];

  const gruppen = useMemo(() => {
    if (!aktiv) return [];
    if (!nurStern) return aktiv.gruppen;
    return aktiv.gruppen
      .map((g) => ({
        ...g,
        termine: g.termine.filter((t) => t.sternchen !== "kein"),
      }))
      .filter((g) => g.termine.length > 0);
  }, [aktiv, nurStern]);

  const sternAnzahl = useMemo(
    () =>
      aktiv
        ? aktiv.gruppen.reduce(
            (s, g) =>
              s + g.termine.filter((t) => t.sternchen !== "kein").length,
            0,
          )
        : 0,
    [aktiv],
  );

  const sichtbar = useMemo(
    () =>
      gruppen.reduce(
        (s, g) =>
          s +
          g.termine.reduce((x, t) => x + (t.anzahl > 1 ? 1 + t.anzahl : 1), 0),
        0,
      ),
    [gruppen],
  );

  return (
    <div>
      {/* Jahr-Schalter + Filter ------------------------------------ */}
      <div className="rise sticky top-[61px] z-30 -mx-1 space-y-2.5 bg-base/90 px-1 py-3 backdrop-blur-md" style={{ animationDelay: "120ms" }}>
        <div className="flex flex-wrap items-center gap-2">
          <div className="flex overflow-hidden rounded-lg border border-line">
            {jahre.map((j) => (
              <button
                key={j.jahr}
                onClick={() => setJahr(j.jahr)}
                className={clsx(
                  "px-4 py-2 text-[13px] font-medium transition-colors",
                  jahr === j.jahr
                    ? "bg-lime text-base"
                    : "bg-raised text-muted hover:text-ink",
                )}
              >
                {j.jahr}
              </button>
            ))}
          </div>
          <button
            onClick={() => setNurStern((s) => !s)}
            className={clsx(
              "inline-flex items-center gap-1.5 rounded-lg border px-3 py-2 text-[12px] font-medium transition-colors",
              nurStern
                ? "border-amber/40 bg-amber/10 text-amber"
                : "border-line bg-raised text-muted hover:text-ink",
            )}
          >
            <Filter className="h-3.5 w-3.5" />
            Nur unbestätigte ({sternAnzahl})
          </button>
          <span className="ml-auto text-right font-mono text-[11px] leading-tight text-muted">
            {aktiv?.quellzeilen} Quellzeilen · {aktiv?.zeitfenster} Zeitfenster
            <span className="block text-[10px] text-muted/70">
              {sichtbar} sichtbare Listenzeilen (B-12)
            </span>
          </span>
        </div>
      </div>

      {/* Monatsgruppen ---------------------------------------------- */}
      <div className="mt-6 space-y-10">
        {gruppen.map((g) => (
          <section key={g.key}>
            <div className="mb-3 flex items-baseline gap-3 border-b border-line pb-2.5">
              <CalendarRange className="h-4 w-4 translate-y-0.5 text-lime" />
              <h2 className="font-display text-[clamp(1.25rem,2.2vw,1.6rem)] font-medium tracking-tight text-ink">
                {g.label}
              </h2>
              <span className="ml-auto font-mono text-[11px] text-muted">
                {g.termine.length} {g.termine.length === 1 ? "Quellzeile" : "Quellzeilen"}
              </span>
            </div>

            <ol className="space-y-2">
              {g.termine.map((t) => {
                const f0 = t.fenster[0];
                const mehrere = t.anzahl > 1;
                const expanded = offen[t.sfId] ?? true;
                return (
                  <li
                    key={t.sfId}
                    className={clsx(
                      "card-lift rounded-xl border bg-raised/80",
                      t.sternchen !== "kein"
                        ? "border-amber/25"
                        : "border-line",
                    )}
                  >
                    <div className="flex flex-wrap items-start gap-x-4 gap-y-2 p-3.5">
                      <span className="mt-1 w-11 shrink-0 rounded border border-line-soft bg-raised2 px-1.5 py-0.5 text-center font-mono text-[10.5px] font-semibold tracking-wide text-ink-soft">
                        {t.sfId}
                      </span>
                      <div className="min-w-0 flex-1">
                        <div className="flex flex-wrap items-center gap-x-3 gap-y-1.5">
                          <h3 className="text-[14.5px] font-medium leading-snug text-ink">
                            {t.name}
                          </h3>
                          <SternBadge sternchen={t.sternchen} />
                          {mehrere ? (
                            <span className="rounded-full border border-lime/30 bg-lime/[0.06] px-2 py-0.5 font-mono text-[10px] uppercase tracking-[0.08em] text-lime">
                              1 Zeile · {t.anzahl} Fenster (B-10)
                            </span>
                          ) : null}
                        </div>
                        <p className="mt-1 flex flex-wrap items-center gap-x-3 gap-y-0.5 text-[12px] text-muted">
                          <span className="inline-flex items-center gap-1">
                            <MapPin className="h-3 w-3" />
                            {t.plzOrt}
                          </span>
                          <span className="font-mono text-[11px] text-muted/80">
                            Quelle: „{t.datumOriginal}“
                          </span>
                        </p>
                        {t.hinweis ? (
                          <p className="mt-1.5 flex items-start gap-1.5 text-[11.5px] leading-snug text-muted">
                            <AlertCircle className="mt-0.5 h-3 w-3 shrink-0 text-amber/80" />
                            {t.hinweis}
                          </p>
                        ) : null}
                      </div>
                      <div className="shrink-0 text-right">
                        <p className="tnum font-mono text-[12.5px] font-medium text-ink">
                          {f0.label}
                        </p>
                        <p className="mt-0.5 font-mono text-[10.5px] text-muted">
                          {f0.tage} {f0.tage === 1 ? "Tag" : "Tage"}
                        </p>
                      </div>
                    </div>

                    {mehrere ? (
                      <div className="border-t border-line-soft px-3.5 pb-2.5 pt-1">
                        <button
                          onClick={() =>
                            setOffen((o) => ({ ...o, [t.sfId]: !expanded }))
                          }
                          className="mt-1 inline-flex items-center gap-1 text-[11px] font-medium text-muted transition-colors hover:text-ink"
                        >
                          <ChevronDown
                            className={clsx(
                              "h-3.5 w-3.5 transition-transform",
                              expanded ? "rotate-180" : "",
                            )}
                          />
                          {expanded
                            ? "Advents-Unterzeilen einklappen"
                            : `${t.anzahl} Advents-Unterzeilen zeigen`}
                        </button>
                        {expanded ? (
                          <ol className="mt-1.5 space-y-1">
                            {t.fenster.map((f) => (
                              <li
                                key={f.nr}
                                className="flex items-center gap-2.5 rounded-lg border border-line-soft bg-raised2/50 px-3 py-1.5"
                              >
                                <CornerDownRight className="h-3.5 w-3.5 shrink-0 text-lime/60" />
                                <span className="font-mono text-[10px] uppercase tracking-[0.12em] text-muted">
                                  Fenster {f.nr}
                                </span>
                                <span className="tnum ml-auto font-mono text-[12px] text-ink-soft">
                                  {f.label}
                                </span>
                                <span className="tnum font-mono text-[10.5px] text-muted">
                                  {f.tage} Tage
                                </span>
                              </li>
                            ))}
                          </ol>
                        ) : null}
                      </div>
                    ) : null}
                  </li>
                );
              })}
            </ol>
          </section>
        ))}

        {gruppen.length === 0 ? (
          <p className="rounded-xl border border-dashed border-line px-6 py-14 text-center text-[13px] text-muted">
            Keine unbestätigten Termine im Jahr {jahr}.
          </p>
        ) : null}
      </div>
    </div>
  );
}
