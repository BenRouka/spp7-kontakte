/* ------------------------------------------------------------------ */
/* C2 — /karte: Event-Radar auf sauberer Geo-Basis.                    */
/* Vorrang hat das Kuratierte: geo_orte (frisch geocodiert, O-11-     */
/* Nachweis unten) zeichnet immer oben. Altpunkte (zuordnung „rest“,   */
/* Roaldaten Prio 2, Orts-/PLZ-Nähe) liegen integriert und gedämpft    */
/* darunter — keine Schicht, kein Toggle, keine separaten Zähler.      */
/* Wo ein Altbestand kuratiert verknüpft ist („kuratiert“) oder direkt*/
/* auf einen kuratierten Ort fällt, erscheint er nicht doppelt.        */
/* ------------------------------------------------------------------ */

import Link from "next/link";
import { Boxes, CalendarDays, MapPin } from "lucide-react";
import { and, asc, eq, isNotNull } from "drizzle-orm";
import { db } from "@/db";
import {
  altEventDates,
  altEvents,
  geoOrte,
  termine,
  terminZeitfenster,
} from "@/db/schema";
import {
  KORRIDOR_PLZ,
  normalizePlzOrt,
  projX,
  projY,
  type Pruefstatus,
} from "@/lib/geo";
import {
  KarteRadar,
  type RadarDot,
  type RadarLabel,
} from "@/components/karte-radar";
import { GeoNachweis, type NachweisZeile } from "@/components/geo-nachweis";
import { Badge, Card, Eyebrow, SectionHead } from "@/components/ui";

export const dynamic = "force-dynamic";

const MONATE = [
  "Jan", "Feb", "Mär", "Apr", "Mai", "Jun",
  "Jul", "Aug", "Sep", "Okt", "Nov", "Dez",
];

/** Kurzlabels der Korridor-Stationen (Beleg S03/S04 · T04/T09 · Nutzerplanung). */
const STATION_LABEL: Record<string, string> = {
  "23999": "Insel Poel",
  "18439": "Stralsund",
  "18556": "Rügenhof · Kap Arkona",
  "18569": "Schaprode",
  "13125": "Wagendorf Karow",
  "10965": "Arcanoa",
  "10961": "CLASH Berlin",
  "10115": "Schokoladen e.V.",
  "10247": "Supamolly",
  "10997": "Trinkteufel",
};
/** Label-Anker im Radar — handplatziert gegen Überlappung im engen NO-Eck. */
const LABEL_ANKER: Record<
  string,
  { dx: number; dy: number; anchor: "start" | "end" }
> = {
  "23999": { dx: -10, dy: 4, anchor: "end" },
  "18439": { dx: -10, dy: 14, anchor: "end" },
  "18569": { dx: 10, dy: 13, anchor: "start" },
  "18556": { dx: 10, dy: -8, anchor: "start" },
  "13125": { dx: 10, dy: -7, anchor: "start" },
  "10965": { dx: 10, dy: 13, anchor: "start" },
  "10961": { dx: -10, dy: 2, anchor: "end" },
  "10115": { dx: 10, dy: -8, anchor: "start" },
  "10247": { dx: 10, dy: 12, anchor: "start" },
  "10997": { dx: -10, dy: 13, anchor: "end" },
};
/** Archiv-Beleg je Station (Prio 2, nur als Lesepfad) — Berlin-Vormerkungen */
/*   aus der Nutzer-Tourplanung 2027 haben keinen Archiv-Beleg.              */
const STATION_ARCHIV: Record<string, string | undefined> = {
  "23999": "S04",
  "18439": "S03",
  "18556": "T04",
  "18569": "T09",
};

function fmtFenster(von: string, bis: string): string {
  // ISO YYYY-MM-DD → „05.–07.06.2027“
  const [y1, m1, d1] = von.split("-");
  const [y2, m2, d2] = bis.split("-");
  if (von === bis) return `${d1}.${m1}.${y1}`;
  if (y1 === y2 && m1 === m2) return `${d1}.–${d2}.${m2}.${y2}`;
  return `${d1}.${m1}.–${d2}.${m2}.${y2}`;
}

export default async function KartePage() {
  const [orte, termRows, fenster, altRest, altDatumRows] = await Promise.all([
    db.select().from(geoOrte).orderBy(asc(geoOrte.plz), asc(geoOrte.ort)),
    db
      .select({
        sfId: termine.sfId,
        jahr: termine.jahr,
        plzOrt: termine.plzOrtOriginal,
        name: termine.nameOriginal,
      })
      .from(termine),
    db
      .select({
        sfId: terminZeitfenster.terminSfId,
        von: terminZeitfenster.von,
        bis: terminZeitfenster.bis,
      })
      .from(terminZeitfenster),
    /* Roaldaten Prio 2: nur Rest-Altbestand (kuratiert Verknüpfte sind  */
    /* über die geo_orte-Punkte ohnehin abgedeckt). Frisch geometrisch   */
    /* projiziert, Qualität (zentroid|osm|offen) bleibt im Titel sichtbar.*/
    db
      .select({
        eventId: altEvents.eventId,
        name: altEvents.name,
        ort: altEvents.ort,
        geoQualitaet: altEvents.geoQualitaet,
        lat: altEvents.lat,
        lng: altEvents.lng,
      })
      .from(altEvents)
      .where(
        and(
          eq(altEvents.zuordnung, "rest"),
          isNotNull(altEvents.lat),
          isNotNull(altEvents.lng),
        ),
      ),
    /* Datumzeilen des Rest-Altbestands (für die Popups der Altpunkte). */
    db
      .select({
        eventId: altEventDates.altEventId,
        von: altEventDates.von,
        bis: altEventDates.bis,
        vonIso: altEventDates.vonIso,
        bisIso: altEventDates.bisIso,
      })
      .from(altEventDates)
      .orderBy(asc(altEventDates.vonIso)),
  ]);

  /* Klassifikation aus kuratierten Terminen (kein Altbestand). */
  const plz2027 = new Set<string>();
  const plz2026 = new Set<string>();
  const term2027ByPlz = new Map<
    string,
    { sfId: string; name: string }
  >();
  const namen2027 = new Map<string, Set<string>>();
  for (const t of termRows) {
    const n = normalizePlzOrt(t.plzOrt);
    if (!n) continue;
    if (t.jahr === 2027) {
      plz2027.add(n.plz);
      if (!term2027ByPlz.has(n.plz))
        term2027ByPlz.set(n.plz, { sfId: t.sfId, name: t.name });
      if (!namen2027.has(n.plz)) namen2027.set(n.plz, new Set());
      namen2027.get(n.plz)!.add(t.name);
    } else if (t.jahr === 2026) {
      plz2026.add(n.plz);
    }
  }

  /* Zeitraum 2027 + Fenster-Map */
  const sf2027 = new Set(
    termRows.filter((t) => t.jahr === 2027).map((t) => t.sfId),
  );
  const fensterBySf = new Map<string, { von: string; bis: string }[]>();
  let minVon = "9999";
  let maxBis = "0000";
  for (const f of fenster) {
    if (!fensterBySf.has(f.sfId)) fensterBySf.set(f.sfId, []);
    fensterBySf.get(f.sfId)!.push({ von: f.von, bis: f.bis });
    if (sf2027.has(f.sfId)) {
      if (f.von < minVon) minVon = f.von;
      if (f.bis > maxBis) maxBis = f.bis;
    }
  }
  const range2027 =
    minVon !== "9999"
      ? `${MONATE[Number(minVon.split("-")[1]) - 1]} – ${MONATE[Number(maxBis.split("-")[1]) - 1]} ${maxBis.split("-")[0]}`
      : "—";

  /* Datum je PLZ (aus allen Termin-Fenstern) für die Punkt-Popups. */
  const datenByPlz = new Map<string, string>();
  for (const t of termRows) {
    const n = normalizePlzOrt(t.plzOrt);
    if (!n) continue;
    const fs = fensterBySf.get(t.sfId);
    if (!fs || fs.length === 0) continue;
    const daten = fs.map((f) => fmtFenster(f.von, f.bis)).join(" · ");
    const altDatum = datenByPlz.get(n.plz);
    datenByPlz.set(n.plz, altDatum ? `${altDatum} · ${daten}` : daten);
  }

  /* Radar-Punkte */
  const korridorPlzSet = new Set<string>(KORRIDOR_PLZ);
  const byPlz = new Map(orte.map((o) => [o.plz ?? "", o]));
  const dots: RadarDot[] = [];
  for (const o of orte) {
    if (o.lat === null || o.lng === null) continue;
    const x = projX(o.lng);
    const y = projY(o.lat);
    const istKorridor = o.plz !== null && korridorPlzSet.has(o.plz);
    const ist2027 = o.plz !== null && plz2027.has(o.plz);
    const namen = o.plz ? [...(namen2027.get(o.plz) ?? [])] : [];
    const datum = o.plz ? datenByPlz.get(o.plz) : undefined;
    if (istKorridor) {
      const datiert = ist2027;
      const beleg = STATION_ARCHIV[o.plz ?? ""];
      dots.push({
        id: o.id,
        x,
        y,
        klasse: "korridor",
        korridorStatus: datiert ? "datiert" : "vorgemerkt",
        titel: `${o.label} · Tourkorridor 2027 · ${datiert ? `Veranstaltung (${namen.join(", ")})${datum ? ` · ${datum}` : ""}` : `vorgemerkt — ${beleg ? `Prio-2-Beleg ${beleg} im Archiv` : "Nutzer-Tourplanung, Termin noch offen"}`}`,
      });
    } else if (ist2027) {
      dots.push({
        id: o.id,
        x,
        y,
        klasse: "sf2027",
        titel: `${o.label} · Sündenfrei 2027 · ${namen.join(", ") || "Termin 2027"}${datum ? ` · ${datum}` : ""}`,
      });
    } else {
      dots.push({
        id: o.id,
        x,
        y,
        klasse: "rest",
        titel: `${o.label} · Terminort${plz2026.has(o.plz ?? "") ? " 2026" : ""}${datum ? ` · ${datum}` : ""}`,
      });
    }
  }

  /* Datum je Altbestands-Event (Prio 2): bevorzugt ISO-Fenster, sonst    */
  /* die Rohzeile — für die Popups der Altpunkte.                          */
  const altDatenByEvent = new Map<string, Set<string>>();
  for (const d of altDatumRows) {
    let f: string;
    if (d.vonIso) {
      f = fmtFenster(d.vonIso, d.bisIso || d.vonIso);
    } else if (d.von) {
      f = d.bis ? `${d.von} – ${d.bis}` : d.von;
    } else {
      continue;
    }
    if (!altDatenByEvent.has(d.eventId))
      altDatenByEvent.set(d.eventId, new Set());
    altDatenByEvent.get(d.eventId)!.add(f);
  }

  /* Altpunkte (Prio 2): projiziert, auf die sichtbare Deutschland-    */
  /* Projektion begrenzt. Alt fällt weg, wo Kuratiertes sitzt (Vorrang, */
  /* keine Doppelpunktwolke am selben Ort) — rein geometrisch, ohne     */
  /* Ortsvergleich zu raten.                                            */
  const EPS = 3.5; // SVG-Einheiten; deckt Ortskern-Nähe ab
  const kuratiertXY = dots.map((d) => ({ x: d.x, y: d.y }));
  const altDots: RadarDot[] = [];
  let altDubletten = 0;
  let altAusserhalb = 0;
  for (const a of altRest) {
    const lat = Number.parseFloat(a.lat ?? "");
    const lng = Number.parseFloat(a.lng ?? "");
    if (!Number.isFinite(lat) || !Number.isFinite(lng)) continue;
    const x = projX(lng);
    const y = projY(lat);
    if (x < 2 || x > 458 || y < 2 || y > 328) {
      altAusserhalb += 1;
      continue;
    }
    if (kuratiertXY.some((k) => (k.x - x) ** 2 + (k.y - y) ** 2 <= EPS * EPS)) {
      altDubletten += 1;
      continue;
    }
    const altDatum = [...(altDatenByEvent.get(a.eventId) ?? [])].join(" · ");
    altDots.push({
      id: `alt-${a.eventId}`, // Präfix: nie mit geo_orte-Ids kollidieren
      x,
      y,
      klasse: "alt",
      titel: `${a.eventId} · ${a.name}${a.ort ? ` — ${a.ort}` : ""} · Altbestand Prio 2 (${a.geoQualitaet}, ungeprüft · Orts-/PLZ-Nähe, kein Gelände)${altDatum ? ` · ${altDatum}` : ""}`,
    });
  }
  /* Altpunkte zuerst — kuratierte Punkte übermalen sie (Vorrang). */
  const alleDots: RadarDot[] = [...altDots, ...dots];

  /* Korridor-Linie, geografisch von Süd nach Ost-Nord (Alt hatte keine Linie). */
  const liniePlz = ["23999", "18439", "18569", "18556"];
  const korridorLinie = liniePlz
    .map((plz) => byPlz.get(plz))
    .filter((g): g is NonNullable<typeof g> => !!g && g.lat !== null)
    .map((g) => ({ x: projX(g.lng!), y: projY(g.lat!) }));

  /* Stations-Labels */
  const labels: RadarLabel[] = [];
  for (const plz of KORRIDOR_PLZ) {
    const g = byPlz.get(plz);
    if (!g || g.lat === null || g.lng === null) continue;
    const a = LABEL_ANKER[plz];
    labels.push({
      x: projX(g.lng) + a.dx,
      y: projY(g.lat) + a.dy,
      text: STATION_LABEL[plz],
      anchor: a.anchor,
    });
  }

  /* Stoppliste des Panels (Alt-Reihenfolge: Poel, Stralsund, Rügenhof, Schaprode). */
  const stops = KORRIDOR_PLZ.map((plz) => {
    const g = byPlz.get(plz);
    const t = term2027ByPlz.get(plz);
    const fs = t ? (fensterBySf.get(t.sfId) ?? []) : [];
    return {
      plz,
      geo: g,
      termin: t ?? null,
      fenster: fs,
      archivId: STATION_ARCHIV[plz],
    };
  });
  const stopsDatiert = stops.filter((s) => s.termin !== null).length;
  const stopsOffen = stops.length - stopsDatiert;

  /* Prüfstand */
  const mitKoord = orte.filter((o) => o.lat !== null).length;
  const geprueft = orte.filter((o) => o.pruefstatus === "geprueft").length;
  const pruefen = orte.filter((o) => o.pruefstatus === "pruefen").length;
  const sf2027Orte = orte.filter(
    (o) => o.plz !== null && plz2027.has(o.plz),
  ).length;

  const nachweisZeilen: NachweisZeile[] = orte.map((o) => ({
    id: o.id,
    plz: o.plz,
    ort: o.ort,
    label: o.label,
    art: o.art,
    lat: o.lat,
    lng: o.lng,
    quelle: o.quelle,
    genauigkeit: o.genauigkeit,
    pruefstatus: o.pruefstatus as Pruefstatus,
    geocodiertAm: o.geocodiertAm,
    geprueftAm: o.geprueftAm,
  }));

  return (
    <div className="rise">
      <SectionHead
        eyebrow="Geografische Abdeckung · C2"
        title="Event-Radar"
        right={
          <div className="flex flex-wrap gap-1.5">
            <Badge tone="lime">
              {mitKoord}/{orte.length} geocodiert
            </Badge>
            <Badge tone={geprueft > 0 ? "lime" : "neutral"}>
              {geprueft}/{orte.length} geprüft
            </Badge>
            <Badge tone={pruefen > 0 ? "amber" : "neutral"}>
              {pruefen} prüfpflichtig
            </Badge>
            <Badge tone="neutral">
              {sf2027Orte} Terminorte 2027 · {range2027}
            </Badge>
            <Badge tone="neutral">{altDots.length} Altpunkte · Prio 2</Badge>
          </div>
        }
      />

      <div className="grid gap-5 xl:grid-cols-[1.65fr_1fr]">
        {/* Radar */}
        <Card className="radar-sheen overflow-hidden p-4 sm:p-5">
          <div className="mb-3 flex flex-wrap items-end justify-between gap-2">
            <div>
              <Eyebrow>Geografische Abdeckung</Eyebrow>
              <h3 className="font-display mt-1 text-xl font-medium text-ink">
                Deutschland · Ortskerne
              </h3>
            </div>
            <Link
              href="/termine"
              className="inline-flex items-center gap-1.5 rounded-full border border-line px-3 py-1.5 text-[12px] font-medium text-muted transition-colors hover:border-lime/40 hover:text-ink"
            >
              <CalendarDays className="h-3.5 w-3.5" strokeWidth={2.2} />
              Alle Termine
            </Link>
          </div>

          <KarteRadar
            dots={alleDots}
            korridorLinie={korridorLinie}
            labels={labels}
          />

          <div className="mt-3 flex flex-wrap items-center justify-between gap-x-4 gap-y-2 border-t border-line-soft pt-3">
            <div className="flex flex-wrap items-center gap-x-4 gap-y-2 text-[11.5px] text-ink-soft">
              <span className="inline-flex items-center gap-1.5">
                <i className="h-2 w-2 rounded-full bg-amber" />
                Sündenfrei 2027
              </span>
              <span className="inline-flex items-center gap-1.5">
                <i className="h-2.5 w-2.5 rounded-full border border-lime" />
                Tourstation 2027
              </span>
              {/* Klasse „rest“ nur zeigen, wenn sie Punkte hat (derzeit 0 — jeder Terminort hat 2027-Termine). */}
              {dots.some((d) => d.klasse === "rest") ? (
                <span className="inline-flex items-center gap-1.5">
                  <i className="h-2 w-2 rounded-full bg-muted/70" />
                  Weitere Terminorte
                </span>
              ) : null}
              {altDots.length > 0 ? (
                <span
                  className="inline-flex items-center gap-1.5"
                  title={`Roaldaten aus dem Altbestand (zuordnung „rest“): ${altDots.length} Punkte. ${altDubletten} an kuratierten Orten ausgeblendet (Vorrang Kuratiertes), ${altAusserhalb} außerhalb der Projektion.`}
                >
                  <i className="h-1.5 w-1.5 rounded-full bg-muted/50" />
                  Altpunkte Prio 2 · Orts-/PLZ-Nähe · ungeprüft ({altDots.length})
                </span>
              ) : null}
            </div>
            <p className="font-mono text-[10px] uppercase tracking-[0.1em] text-muted">
              Kuratiert zuerst · Ortskerne, keine Veranstaltungsgelände (O-11)
            </p>
          </div>
        </Card>

        {/* Tour-Korridor */}
        <Card className="p-4 sm:p-5">
          <Eyebrow>Ostsee &amp; Berlin · Sommer 2027</Eyebrow>
          <h3 className="font-display mt-1 text-xl font-medium text-ink">
            Tour-Korridor
          </h3>
          <p className="mt-1 font-mono text-[10px] uppercase tracking-[0.12em] text-muted">
            {stopsDatiert} veröffentlichte Veranstaltungstermine · {stopsOffen}{" "}
            Vormerkungen
          </p>

          <ul className="mt-4 space-y-2">
            {stops.map((s) => {
              const datiert = s.termin !== null;
              return (
                <li
                  key={s.plz}
                  className="flex items-center gap-3 rounded-xl border border-line-soft bg-raised2/50 px-3 py-2.5"
                >
                  <span
                    className={
                      datiert
                        ? "flex h-8 w-8 shrink-0 items-center justify-center rounded-lg bg-lime/15 text-lime"
                        : "flex h-8 w-8 shrink-0 items-center justify-center rounded-lg border border-dashed border-lime/40 text-lime/80"
                    }
                  >
                    <MapPin className="h-4 w-4" strokeWidth={2.2} />
                  </span>
                  <span className="min-w-0 flex-1">
                    <span className="block truncate text-[13px] font-medium text-ink">
                      {s.geo?.label ?? STATION_LABEL[s.plz]}
                    </span>
                    <span className="tnum block font-mono text-[11px] text-muted">
                      {datiert && s.fenster.length > 0
                        ? s.fenster
                            .map((f) => fmtFenster(f.von, f.bis))
                            .join(" · ")
                        : "Datum noch offen"}
                    </span>
                  </span>
                  <span className="flex shrink-0 flex-col items-end gap-1">
                    <Badge tone={datiert ? "lime" : "neutral"}>
                      {datiert ? "Veranstaltung" : "Vorgemerkt"}
                    </Badge>
                    {s.archivId ? (
                      <Link
                        href={`/archiv/${s.archivId}`}
                        className="inline-flex items-center gap-1 font-mono text-[10px] uppercase tracking-[0.08em] text-muted transition-colors hover:text-ink"
                        title={`Prio-2-Beleg ${s.archivId} im Archiv`}
                      >
                        <Boxes className="h-3 w-3" />
                        {s.archivId}
                      </Link>
                    ) : (
                      <span
                        className="font-mono text-[10px] uppercase tracking-[0.08em] text-muted"
                        title="Nutzer-Tourplanung 2027 — kein Prio-2-Beleg im Archiv"
                      >
                        Tourplanung
                      </span>
                    )}
                  </span>
                </li>
              );
            })}
          </ul>

          <p className="mt-4 rounded-lg border border-amber/25 bg-amber/[0.05] px-3 py-2.5 text-[12px] leading-relaxed text-ink-soft">
            Putgarten: Zentralcamp für etwa zwei Wochen. Die
            2027-Veranstaltungstermine sind keine bestätigten
            SPP7-Auftritte.
            <span className="mt-1.5 block font-mono text-[10px] uppercase tracking-[0.1em] text-muted">
              Vormerkungen = Prio-2-Beleg (T04/T09) bzw. Nutzer-Tourplanung
              2027 (Berlin-Cluster: Wagendorf Karow, Arcanoa, CLASH,
              Schokoladen, Supamolly, Trinkteufel) · Koordinaten: OSM bzw.
              manuell (Nutzer-Tourplanung) · Prüfstand unten
            </span>
          </p>
        </Card>
      </div>

      {/* C3 — O-11-Herkunftsnachweis */}
      <Card className="mt-5 p-4 sm:p-5">
        <SectionHead
          className="mb-4"
          eyebrow="O-11 · Geo-Herkunftsnachweis · C3"
          title="Koordinaten-Prüfstand"
          right={
            <div className="flex items-center gap-3">
              <div
                className="h-1.5 w-36 overflow-hidden rounded-full bg-raised2"
                role="progressbar"
                aria-valuenow={geprueft}
                aria-valuemax={orte.length}
                aria-label="Geprüfte Koordinaten"
              >
                <div
                  className="h-full rounded-full bg-lime transition-all duration-500"
                  style={{
                    width: `${orte.length ? (geprueft / orte.length) * 100 : 0}%`,
                  }}
                />
              </div>
              <span className="tnum font-mono text-[11px] uppercase tracking-[0.1em] text-muted">
                {geprueft}/{orte.length} geprüft
              </span>
            </div>
          }
        />
        <p className="mb-4 max-w-3xl text-[12.5px] leading-relaxed text-muted">
          Jede Koordinate ist frisch per Nominatim/OpenStreetMap erzeugt
          (Spalten Quelle, Genauigkeit = OSM-addresstype, Zeitstempel) —
          ausgenommen Ziele der Nutzer-Tourplanung (Quelle{" "}
          <span className="text-ink">„manuell“</span>, Genauigkeit
          „manuell“, bereits geprüft). Einträge mit{" "}
          <span className="text-amber">addresstype „postcode“</span> sind
          Zentroide und deshalb prüfpflichtig — sie gelten nie als
          Veranstaltungsgelände. „Geprüft“-Zeilen rührt der Geocoder nicht
          mehr an.
        </p>
        <GeoNachweis zeilen={nachweisZeilen} />
      </Card>
    </div>
  );
}
