import { getKontakteHierarchie } from "@/lib/data";
import { KontakteBrowser, type KontaktDto } from "@/components/kontakte-browser";
import { Badge, Eyebrow } from "@/components/ui";

export const dynamic = "force-dynamic";

export default async function KontaktePage() {
  const hierarchie = await getKontakteHierarchie();

  const eintraege: KontaktDto[] = hierarchie.flatMap((g) =>
    g.orte.flatMap((o) =>
      o.einrichtungen.map((e) => ({
        kvId: e.kvId,
        region: g.region.name,
        regionId: g.region.id,
        ort: e.ort,
        name: e.name,
        anschrift: e.anschrift,
        telefon: e.telefon,
        fax: e.fax,
        emails: [e.email1, e.email2, e.email3].filter(
          (x): x is string => !!x,
        ),
        web: e.web,
        typ: e.typ,
        hinweis: e.prio2ChatHinweis,
        hatMdBlock: e.hatMdBlock,
      })),
    ),
  );

  const regionen = hierarchie.map((g) => ({
    id: g.region.id,
    name: g.region.name,
    anzahl: g.anzahl,
  }));

  const orte = new Set(eintraege.map((e) => e.ort)).size;
  const emails = eintraege.reduce((s, e) => s + e.emails.length, 0);

  return (
    <div className="space-y-8">
      <section className="rise pt-4">
        <Eyebrow>Kontakte · aus der Datenbank</Eyebrow>
        <div className="mt-4 flex flex-wrap items-end justify-between gap-6">
          <h1 className="font-display max-w-3xl text-[clamp(2.2rem,5vw,3.8rem)] font-medium leading-[1.02] tracking-tight text-ink">
            35 Datensätze, <span className="text-lime">9 Regionen</span> —
            jede Einrichtung genau einmal.
          </h1>
          <div className="flex flex-wrap gap-2 pb-1">
            <Badge tone="lime">Prio 1 · MD / Website / Register</Badge>
            <Badge>Prio 2 · Chat ergänzt nur</Badge>
          </div>
        </div>
        <p className="mt-4 max-w-2xl text-[14px] leading-relaxed text-ink-soft">
          Hierarchie Region → Ort → Einrichtung (B-16). Mehrere E-Mails einer
          Einrichtung stehen als Spalten email_1–email_3 am selben Datensatz —
          niemals als Dublette. Der Sonderdatensatz STADT-PUTBUS stammt
          ausschließlich aus Prio 2 und ist als solcher markiert.
        </p>
        <div className="mt-6 grid grid-cols-2 gap-px overflow-hidden rounded-xl border border-line bg-line sm:grid-cols-4">
          {[
            ["Datensätze", eintraege.length, "34 KV + 1 Sonderdatensatz"],
            ["Regionen", regionen.length, "Übergreifend steht zuerst"],
            ["Orte", orte, "Binz bis Kloster"],
            ["E-Mail-Kanäle", emails, "aus email_1 bis email_3"],
          ].map(([label, wert, sub]) => (
            <div key={label} className="bg-raised/90 px-4 py-3.5">
              <p className="font-mono text-[10px] uppercase tracking-[0.16em] text-muted">
                {label}
              </p>
              <p className="tnum mt-1 text-2xl font-medium text-ink">{wert}</p>
              <p className="mt-0.5 text-[11px] text-muted">{sub}</p>
            </div>
          ))}
        </div>
      </section>

      <KontakteBrowser eintraege={eintraege} regionen={regionen} />
    </div>
  );
}
