# Material-Inventur — Gesamtstand des Altbestands (Mockup data.js, Stand 2026-10-04)

**Art:** rein lesend. Keine Änderung. Ergänzt Befundbericht A/B.
**Zweck:** Vollständige Antwort auf die Frage, welche Materialgruppen über die bereits abgedeckten (Bilder, Termine, Adressen) hinaus im Altbestand liegen.

## Legende
- ✅ = inventarisiert / Abgleich steht (Befundbericht A + B, Abgleichmatrix)
- 🔓 = offen — noch nicht im Scope, Entscheidung ausstehend

## 1. Bereits abgedeckt

| Gruppe | Umfang | Status |
|---|---|---|
| **Bilder** (Flyer, Screens, Chat-Bilder) | 79 Flyer (35 Screens + 44 Fotos) + 79 Thumbs + QUELLE.txt · 200 Chat-Bilder · 6 App-Screenshots | ✅ Befund A §5 |
| **Bewerbungen/Gagen** | 43 Bewerbungen (9 offen, 31 geschlossen, 3 unklar) · 36 Gagen (33 bestätigt) · 41 Konditionen · 13 Eintritt | ✅ Befund A §5.3 |
| **Termine** | 54 Prio-1 (9×2026 + 45×2027) ↔ 240 Alt-Events, Matrix 54/54 | ✅ Befund B + CSV |
| **Adressen** | 35 KV ↔ 74 Alt-Kontakte, 33/35 gedeckt, 37 unmatched | ✅ Befund A §3 |

## 2. Offen — Koordinaten & Map (vom Benutzer benannt)

| Gruppe | Umfang | Hinweis |
|---|---|---|
| **Event-Koordinaten** | 212/240 Events mit LAT/LNG | ⚠️ O-11/B-GEO-Sperre: keine automatische Übernahme. **GEO_STATUS liefert Qualität/Provenienz mit:** 34 PLZ-Zentroid (Genauigkeit 1–10 km, kein Veranstaltungsgelände!) · 59 mit „verifizieren"-Flag · 39 Nominatim/OSM · 24 „offen". Vor jedem Geo-Import: Prüfliste Quelle→Genauigkeit→Status je Datensatz. |
| **Kontakt-Koordinaten** | 68/74 Alt-Kontakte mit LAT/LNG | dito |
| **Map-Panel** | SVG-„Event-Radar" (kein Leaflet/Mapbox), 2 SVG-Elemente, Sündenfrei-Marker orange | UI-Nachbau in der Werkstatt (kein Datentransfer); Datenbasis siehe oben |

## 3. Offen — weitere Materialgruppen im Altbestand (bisher nicht im Scope)

| Gruppe | Datensatz | Umfang | Felder (Kurz) |
|---|---|---|---|
| **Acts/Bands** | `acts` / `event_acts` | 221 Acts · 270 Zuordnungen | ACT_NAME, NAMENSVARIANTEN, ROLLE (Headliner/Special Guest), SLOT_TAG, UNSICHER, NOTIZ — z. B. Corvus Corax (25 Events) |
| **Partner** | `partners` / `event_partners` | 42 · 46 | PARTNER_NAME, ROLLE (Sponsor/Medienpartner) — z. B. Köstritzer, Kreissparkasse |
| **Tags** | `event_tags` | 711 Zeilen · 226 distinkte | Mittelalter 77 · Markt 53 · KI-Liste 47 · Gesuch 35 · Rock 27 … |
| **Features** | `event_features` | 47 | FEATURE + KATEGORIE (Zone/Area, z. B. „Gaming & Indie Area") |
| **Channels** | `event_channels` | 80 | KANAL + WERT (Instagram, Website …) je Event |
| **Timetable** | `timetable` | 15 | ZEIT + PROGRAMMPUNKT (z. B. Bülow Straßenmusik Festival) |
| **Beschreibungen/Einschätzungen** | Event-Felder | KURZBESCHREIBUNG 176/240 · LANGBESCHREIBUNG 32 · PASSUNG_SPP7 129 · NAECHSTER_SCHRITT 118 · UNKLAR 145 · KI_RANG 10 | ⚠️ teilweise KI-Herkunft → O-6-Regel (nie pauschal verifizieren) |
| **Herkunftsvermerke** | QUELLE_TYP je Event | Chat 80 · Flyer 71 · Chat (KI-Liste) 47 · Sündenfrei 40 · Nutzer/Tourplanung 2 | **Bereits vorhandenes Herkunftsmodell des Altbestands** — wertvolle Vorlage für das Prio-1/Prio-2-Feld der Werkstatt |
| **Chat-Verlauf** | `chat_items` / `feed_context` | 149 Zeilen (91 E-Mail, 20 URL, 16 Text, 16 URL-Link, 4 sonstige) · 22 Feed-Kontexte | MSG, DATUM, TYP, WERT, FOTO, KONTEXT, ZUGEORDNET — Quellenmaterial (B-17) |
| **OCR-Texte** | `flyer_sources` | 50/79 mit OCR_ROHTEXT + OCR_KONFIDENZ | Textauszug aus Flyern — Belegmaterial |

## 4. Bewertung (als solche gekennzeichnet, keine Entscheidung)

- **Relevanz für SPP7:** Acts, Tags, Channels, Beschreibungen betreffen überwiegend die allgemeine Festival-Sammlung (F/M-Events, Rock/Metal etc.), nicht nur die Sündenfrei-/Mittelalter-Schiene. Ob sie in die Werkstatt gehören, ist eine fachliche Entscheidung.
- **Herkunftsmodell:** QUELLE_TYP + GEO_STATUS + UNSICHER-Flags zeigen, dass der Altbestand bereits Disziplin bei der Herkunft hat — das spricht dafür, diese Vermerke bei einer Übernahme **mit** zu führen, statt sie zu verwerfen.
- **Reihenfolge-Abhängigkeit:** Koordinaten (O-11) und Beschreibungen (O-6, KI-Anteil) sind die beiden Gruppen mit Prüfsperren-Bezug; Acts/Tags/Channels sind unproblematischer, benötigen aber alle Schema-Erweiterungen.

## 5. Offene Punkte aus Befund B (unverändert)

- SF20/SF27 Schreibweise: Option 1 (belassen) / Option 2 (Prio-1-korrigiert) — Werkstatt-DB-Änderung, nur nach „ja".
- Alt-Termine ohne Prio-1-Beleg (S05, D198, D200) — O-6-Fälle.
- 2026er-Termine im Mockup unvollständig — Zuordnung teilweise manuell.

**Ende Material-Inventur.**
