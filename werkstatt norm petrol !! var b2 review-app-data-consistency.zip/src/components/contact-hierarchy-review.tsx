"use client";

import { useEffect, useState } from "react";
import { Icon } from "@/components/icons";
import { missingContactMarker, type ContactKind, type ContactReview, type ContactValue } from "@/lib/contact-hierarchy";

const labels: Record<ContactKind, string> = { internet: "Internet", email: "E-Mail", telefon: "Telefon", fax: "Fax" };
function sourceLabel(value: ContactValue) {
  if (value.status === "fehlt_laut_nutzer") return "- laut Nutzervorgabe";
  if (value.value === null) return "Nicht angegeben";
  return value.origin === "nutzer" ? "Nutzerergänzung" : "MD-Quelle";
}

export function ContactHierarchyReview() {
  const [review, setReview] = useState<ContactReview | null>(null);
  const [groupId, setGroupId] = useState("KVG01");
  const [error, setError] = useState("");
  const [attempt, setAttempt] = useState(0);
  useEffect(() => {
    const controller = new AbortController();
    async function load() {
      setError("");
      try {
        const response = await fetch("/api/review/contact-hierarchy", { cache: "no-store", signal: controller.signal });
        if (!response.ok) throw new Error("Kontaktprüfung nicht verfügbar.");
        const data = await response.json() as ContactReview;
        if (!controller.signal.aborted) setReview(data);
      } catch {
        if (!controller.signal.aborted) setError("Die Kontaktklärung konnte nicht geladen werden. Originale und Datenbank bleiben unverändert.");
      }
    }
    load();
    return () => controller.abort();
  }, [attempt]);

  if (error) return <div className="contact-load-error" role="alert"><Icon name="info" size={19} /><p>{error}</p><button className="secondary-button" onClick={() => setAttempt((value) => value + 1)}>Erneut prüfen</button></div>;
  if (!review) return <div className="contact-loading" role="status"><Icon name="clock" size={17} /> Parent/Child und Kontaktbelege werden gelesen …</div>;
  const group = review.groups.find((item) => item.id === groupId) ?? review.groups[0];

  return <section className="contact-review" aria-label="Parent/Child-Kontaktklärung">
    <div className="contact-review-heading">
      <div><span className="schema-kicker">Deine Kontaktklärung · keine vollständige Normierung</span><h2>Parents und Außenstellen getrennt halten.</h2><p>MD-Original, Nutzerergänzung und Telefonableitung bleiben einzeln nachvollziehbar.</p></div>
      <a className="secondary-button" href="/api/review/contact-hierarchy?format=md"><Icon name="download" size={16} /> Kontaktklärung als MD</a>
    </div>

    <div className="contact-review-summary">
      <span><b>{review.counts.originalContactValues}</b> Kontaktwerte im Original</span>
      <Icon name="arrowRight" size={16} />
      <span><b>{review.counts.supplementedContactValues}</b> mit deinen Ergänzungen</span>
      <span className="contact-summary-missing"><b>{review.counts.remainingMissingEmails}</b> E-Mail weiterhin nicht angegeben</span>
    </div>

    <div className="contact-group-switch" aria-label="Standortgruppe auswählen">
      {review.groups.map((item) => <button type="button" key={item.id} aria-pressed={item.id === group.id} className={item.id === group.id ? "selected" : ""} onClick={() => setGroupId(item.id)}><Icon name="layers" size={16} />{item.name.replace("Ostseebad ", "")}<span>{item.children.length} Standorte</span></button>)}
    </div>

    <div className="contact-parent">
      <span className="contact-parent-icon"><Icon name="layers" size={23} /></span>
      <div><small>Parent · Standortgruppe aus Nutzervorgabe</small><h3>{group.displayNumber} · {group.name}</h3></div>
      <code>{group.id}</code>
    </div>
    <div className="contact-child-grid">
      {group.children.map((location) => <article className="contact-child" key={location.id} data-location={location.id}>
        <div className="contact-child-heading"><span className="contact-node-number">{location.displayNumber}</span><div><h3>{location.title}</h3>{location.subtitle && <p>{location.subtitle}</p>}</div><code>{location.id}</code></div>
        <div className="contact-address"><Icon name="pin" size={16} /><p>{location.street}<br />{location.postalCity}</p></div>
        <div className="contact-channel-list">
          {location.channels.map((value) => <div className="contact-channel" data-contact={value.type} key={value.type}>
            <div className="contact-channel-label"><b>{labels[value.type]}</b><span className={`contact-origin origin-${value.origin}`}>{sourceLabel(value)}</span></div>
            <div className="contact-channel-value">
              {value.type === "telefon" && value.phone?.international
                ? <a href={`tel:${value.phone.international}`} title="Telefonnummer wählen">{value.phone.display}<Icon name="external" size={12} /></a>
                : value.type === "email" && value.value
                  ? <a href={`mailto:${value.value}`} title="E-Mail öffnen">{value.value}<Icon name="external" size={12} /></a>
                  : <code>{value.value ?? missingContactMarker}</code>}
            </div>
            {value.type === "telefon" && value.phone?.status === "abgeleitet" && <small className="contact-derived">+49-Form aus dem Original berechnet · nicht extern verifiziert</small>}
            {value.type === "telefon" && value.phone?.status === "vorhanden" && <small className="contact-derived">Internationale Form bereits in deiner Ergänzung</small>}
            {value.value === null && <small className="contact-derived">Keine Übernahme vom Parent oder anderen Standort</small>}
          </div>)}
        </div>
        <details className="contact-source-details"><summary><Icon name="file" size={15} /> MD-Original und Ergänzungen vergleichen <Icon name="chevronDown" size={13} /></summary>
          <div className="contact-evidence-list">{location.channels.map((value) => <div key={value.type}><b>{labels[value.type]}</b><p><span>MD-Original:</span> <code>{value.mdValue ?? "- (nicht angegeben)"}</code></p><p><span>Aktueller Quellenwert:</span> <code>{value.value ?? missingContactMarker}</code></p>{value.phone?.international && <p><span>Telefon maschinenlesbar:</span> <code>{value.phone.international}</code></p>}<small>{value.evidence}</small></div>)}</div>
          <p className="contact-source-ref">Kurverwaltungen_2025.md · Zeilen {location.sourceLines.from}–{location.sourceLines.to}</p>
          <pre className="contact-original-block">{location.originalBlock}</pre>
        </details>
      </article>)}
    </div>
    <div className="contact-review-note"><Icon name="shield" size={19} /><p>{group.id === "KVG01"
      ? "Middelhagen und Thiessow teilen nach deiner Vorgabe Telefon und E-Mail. Die beiden Adressen bleiben trotzdem getrennt. Zwei Namen bei Middelhagen allein sind kein Beleg für einen weiteren Standort."
      : "Der Infopavillion hat eine eigene Telefonnummer und den Hinweis „außer Winter“. E-Mail, Internet und Fax bleiben -; willkommen@baabe.de wird nicht aus der Kurverwaltung übernommen."}</p></div>
    <p className="contact-review-scope">Geklärt sind zwei Parents und vier Children. Weitere Hierarchien bleiben offen. Die Original-MD hat weiter zwei E-Mail-Lücken; mit Middelhagens Ergänzung verbleibt eine. Kein Datenbankimport.</p>
  </section>;
}
