# SPP7 · FREEZE-05 — Stufe 2 als normierter Entwurf

**Status: Stufe 2 erzeugt und reproduzierbar; Abgleich/Entscheidungen warten.**
**Aktueller Einstieg bei Wiederaufnahme.** Ergänzt FREEZE-04; FREEZE-01 bis FREEZE-04 und deren SHA256-Manifeste bleiben unverändert.

> Die Arbeitsebene ist eingefroren. Keine Code-, CSV-, Daten- oder Schemaänderung ohne nächste ausdrückliche Freigabe.

Begleitdateien:
- `docs/FREEZE-05-pruefprotokoll.txt` — automatisch erhobene Validierung
- `docs/FREEZE-05.sha256` — Prüfsummen des gesamten Arbeitsstands
- `werkstatt/02-normiert/LIESMICH.md` — vollständiger CSV-Vertrag, Herkunft, Fehlwert-Regeln und offene Prüfpunkte

---

## 1. Was Stufe 2 erzeugt hat

| Datei | Umfang | Status |
|---|---:|---|
| `werkstatt/02-normiert/suendenfrei-termine.csv` | 54 Quellzeilen (2026: 9; 2027: 45) · 60 Zeitfenster | reproduzierbar |
| `werkstatt/02-normiert/kurverwaltungen.csv` | 33 Datensätze aus 32 MD-Adressblöcken | reproduzierbar; Mönchgut Parent/Child wie freigegeben |
| `werkstatt/02-normiert/PRUEFSUMMEN.sha256` | 2 CSV-Dateien | beide OK |
| `scripts/normalize-sources.mjs` | Erzeugung und `--verify`-Modus | nur Rohquellen lesend, schreibt nur nach `02-normiert/` |

Format: UTF-8 mit BOM, Semikolon, CRLF, jedes Feld in Anführungszeichen. Alle Zellen mit fehlenden Angaben enthalten `-` (keine leeren CSV-Zellen). `-` ist eine Kennzeichnung in der normierten Datei, nicht ein nachträglicher Eintrag in den Rohdateien.

Die 54 Termine bleiben an ihre Quellzeilen gekoppelt. Adventszeilen haben je vier getrennte Fenster; Dresden 2027 bleibt ein einzelner Zeitraum aus der Quelle. * und ** bleiben unbestätigt. „Berechnet“ bleibt von Bestätigung getrennt.

### Mönchgut — freigegebene Parent/Child-Struktur

- `KV12` — Parent `Kurverwaltung Mönchgut` ohne duplizierte Kontaktfelder.
- `KV33` — Child/Außenstelle `Tourist-Information Middelhagen`, `parent_id=KV12`; MD-Adresse/Telefon/Fax, Website und E-Mail als Chat-/Auftraggeber-Ergänzung in separaten Feldern.
- `KV13` — Child/Außenstelle `Tourist-Information Thiessow`, `parent_id=KV12`; MD-Adresse/Web/E-Mail, Telefonnummer `+49 38308 66010` als Chat-Ergänzung und Fax `-` nach Nutzerangabe.

Es verbleibt **ein Parent und zwei Außenstellen**, nachvollziehbar über `parent_id`; die H2/H3-Region bleibt in den Regions-/Ortsfeldern. Die 32 Rohblöcke bleiben unberührt. Der zusätzliche KV33 ist eine abgeleitete Child-Zeile.

### Telefon, Fax und Chat-Ergänzungen

- Telefonnummern werden zusätzlich in das von dir bestätigte internationale Format `+49 Vorwahl Teilnehmer` gebracht, z. B. `(03 83 08) 6 60 10` → `+49 38308 66010`.
- MD-Originalnummer und normalisierte Telefonnummer stehen in getrennten Feldern. Fax bleibt eigenständig und wird als Ziffernfolge normiert; fehlendes Fax bleibt `-`.
- Chat-/Nutzerergänzungen stehen ausschließlich in eigenen Ergänzungsspalten. `quelle_ergaenzung` kennzeichnet sie als Nutzer-/Chat-Angabe; fehlende Nachrichten-IDs bleiben `-`. Der vollständige private Chat-Export wurde hier nicht eingelesen oder unabhängig gegen eine MSG-ID geprüft.
- `KV09 Kurverwaltung Baabe` behält die MD-E-Mail `willkommen@baabe.de`; das Nutzerzitat bestätigt den vorhandenen Wert.
- `KV10 Infopavillion KV Baabe (außer Winter)` bleibt ohne E-Mail, Fax und Web (`-`). Die E-Mail der Kurverwaltung wird ausdrücklich **nicht** auf den Pavillon übertragen.
- Mönchgut/Middelhagen erhält die vom Auftraggeber gelieferte Website und E-Mail als Ergänzung. Die fehlenden MD-Felder bleiben gleichzeitig in `felder_fehlend_quelle` sichtbar; der aktuelle Bearbeitungsstand steht separat in `felder_fehlend_arbeitsstand`.

### Normierung

- Originalschreibweisen bleiben neben den normierten/ergänzten Werten erhalten.
- Mechanische Bindestrich-/Schrägstrichbereinigung plus der schon dokumentierte Tippfehler `Mittealter` → `Mittelalter`; Änderungen sind aus der Skriptausgabe und dem CSV-Vergleich nachvollziehbar.
- Keine Änderungen an übrigen Kontaktnamen, keine stillen Adresskorrekturen, kein Raten und keine Geocodierung.
- Unbestätigte und fehlende Angaben werden markiert, nicht ergänzt.

---

## 2. Offene Punkte — bleiben offen

- **P4:** Schreibweisen `Fremdenverkehrs-und`, `Tourismus-und`, `Hafen-und` in Kontaktnamen. Original bleibt, bis eine Korrektur entschieden ist.
- **P7:** Die ungewöhnliche Markdown-Hierarchie von KV01 bleibt mechanisch abgebildet; keine Umdeutung der Überschrift.
- Die verbleibenden Dublettenentscheidungen F3 bleiben für Stufe 4 offen.
- E3 (spätere Event-/Zeitfenstertabellen) und E4 (Kontaktdatenmodell) bleiben für einen eventuellen Stufe-5-Import offen. ⚠ Änderungen dort würden das Datenmodell betreffen.

---

## 3. Sicherheits- und Pipeline-Grenze

- Roh-MD und Roh-TXT sowie Original-ZIP und Option-B-ZIP sind unverändert.
- `src/db/schema.ts` ist unverändert; Datenbank weiterhin ohne Tabellen, keine Schreibzugriffe.
- `public/data/` der ursprünglichen verlinkten App wurde nicht verändert.
- Stufe 3 (vollständiger Quellen↔App-Abgleich) wurde **nicht** begonnen.
- Stufe 4 (Freigaben von Konflikten/Dubletten) wurde **nicht** begonnen.
- Stufe 5 (DB-Import) wurde **nicht** begonnen.
- A/B-Zeitmodell bleibt identisch (`zeitmodell-2026-2027-v2`). Option-B-Paket ist unverändert.

---

## 4. Wiederaufnahme

1. Dieses Dokument lesen.
2. `sha256sum -c docs/FREEZE-05.sha256` aus der Projektwurzel.
3. `node scripts/normalize-sources.mjs --verify` ausführen.
4. Rohquellen prüfen: `cd werkstatt/01-roh && sha256sum -c PRUEFSUMMEN.sha256`.
5. Erst nach Freigabe Stufe 3 als Bericht (ohne DB-Schreibzugriff) beginnen. P4/P7, Dubletten F3 und alle Widersprüche werden nummeriert zur Entscheidung vorgelegt.
