# HANDOFF · Direct Mode · Werkstatt-Freeze nach Stufe 5

**Paket:** `STUFE-5-FREEZE-2026-10-04`  
**Freeze-Stand:** 2026-10-04  
**Stufe:** 5 abgeschlossen — Schema, Import und Verifikation erledigt  
**Modus im nächsten Chat:** Direct Mode, Fortsetzung ohne erneute Grundlagenrecherche  
**Datenschutz:** ausschließlich interner Bandgebrauch (B-17)

---

## 0. Anweisung für den neuen Chat

1. Diese Datei zuerst vollständig lesen.
2. Danach `PRUEFSUMMEN.sha256` prüfen.
3. `01-OFFENE-PUNKTE.csv` ist die einzige Arbeitsliste für spätere manuelle Entscheidungen.
4. `02-BEFUND-ABGRENZUNG-65.csv` dient nur als Audit: 65 Ausgangsbefunde = 52 abgedeckt + 13 offen.
5. Keine bereits entschiedenen Fälle neu recherchieren oder umdeuten.
6. Keinen offenen Punkt automatisch lösen. Immer genau eine Befund-ID auswählen, Beleg prüfen, Nutzerentscheidung abwarten und erst danach einen neuen Beschluss ab B-21 formulieren.
7. Freeze-Dateien, Archiv A und Altbestände niemals still ändern.

---

## 1. Verbindlicher aktueller Stand

### Stufe-4-Freeze (Ground Truth)

Unverändert unter `public/export/FREEZE/`:

- `HANDOFF.md`
- `arbeitsstand-kontakte.csv`
- `arbeitsstand-termine.csv`
- `beschlussverzeichnis.csv`
- `PRUEFSUMMEN.sha256`

Alle vier im Manifest geführten Inhaltsdateien sind byteidentisch und sha256-verifiziert.

### Stufe-5-Datenbank

Schema in `src/db/schema.ts`, Import in `src/db/seed.ts`.

| Tabelle | Sollbestand |
|---|---:|
| `regionen` | 9 |
| `kontakte` | 35 |
| `termine` | 54 |
| `termin_zeitfenster` | 60 |
| `beschluesse` | 20 |
| `import_protokoll` | 3 Einträge je aktuellem Lauf |

Der Import ist transaktional und idempotent. Vor jedem Schreiben prüft er die vier Freeze-Dateien gegen das sha256-Manifest und die Ground-Truth-Zahlen. Eine Abweichung führt zum Abbruch ohne Schreibvorgang.

Wiederaufbau einer leeren Datenbank:

```bash
npx drizzle-kit push --force
npx tsx src/db/seed.ts
```

Live-Prüfung im laufenden Projekt:

```text
/api/import/verify
```

Erwartung: `ok: true`, alle Freeze-Hashes `match: true`, alle fünf Bestandszahlen `match: true`.

---

## 2. Ergebnis der Befund-Triage

Quelle: Variante A, `werkstatt/03-berichte/abgleich-01-entscheidungen.csv`, 65 Ausgangsbefunde, Berichtsversion `abgleich-01-v1`, ZIP-Zeitstempel 2026-10-01 21:07.

| Status | Anzahl | Bedeutung |
|---|---:|---|
| `abgedeckt_durch_bulk_beschluss` | 42 | Terminlücken des Altbestands, durch vollständige Übernahme B-09/B-12 erledigt |
| `abgedeckt_durch_beschluss` | 9 | Durch B-01 bis B-07/B-15 entschieden |
| `abgedeckt_durch_implementierung` | 1 | K-08 durch das Stufe-5-Kontaktschema umgesetzt |
| `offen_manuell` | **13** | Keine automatische Entscheidung; spätere Einzelprüfung nötig |
| **Gesamt** | **65** | lückenlos in `02-BEFUND-ABGRENZUNG-65.csv` nachgewiesen |

### Die 13 offenen Befunde

**Kontakte (2):**
- `K-05` — Lohme: gleiche E-Mail, anderer Organisationstyp
- `K-09` — Herkunftsnachweis PDF gegenüber bereitgestellter MD

**Termine (4):**
- `T-SF17` — Name/Ort in offizieller Quelle noch offen (`xxxxx`)
- `T-SF37` — Datum und Ort passen, Name weicht vom Altbestand ab
- `T-SF38` — Ort in offizieller Quelle noch offen (`xxxx`)
- `T-KI` — Referenzbeleg und KI-Altbestand müssen getrennte Provenienz behalten

**Altbestand / Technik (7):**
- `B-REL-feed_context-EVENT_ID` — verwaister Verweis auf F29
- `B-DATE-D113-D198` — mehrere Datumszeilen für Event/Intervall
- `B-CONTACT-CHANNEL-K64-K73` — gemeinsamer Kanal ohne Identitätsnachweis
- `B-EVENTNAMEN` — gleiche Namen an verschiedenen Orten sind keine Dubletten
- `B-GEO` — 180 Event- und 68 Kontaktkoordinaten nicht inhaltlich geprüft
- `B-MEDIEN` — Bildverweise/Bilddateien nicht neu gezählt oder zugeordnet
- `B-SYNC` — alter JSON-Sync kann kuratierte DB-Werte überschreiben

Die offene CSV enthält Originalbeleg, Originalfrage, Risiko, vorhandenen Schutz und die spätere manuelle Aktion. Keine der Zeilen ist eine bereits getroffene Entscheidung.

---

## 3. Kritikalität

Für den aktuellen Freeze und die neue Stufe-5-App besteht **kein akuter Blocker**:

- Altbestands-JSON, Koordinaten und Medien wurden nicht importiert.
- Es gibt im neuen Projekt keinen alten JSON-`onConflictDoUpdate`-Synchronisationspfad.
- Unbekannte Orte in SF17/SF38 bleiben sichtbar als Original-Platzhalter mit Prüfhinweis; es wurde nichts geraten.
- Gleiche Namen oder E-Mail-Adressen wurden nicht als alleiniger Merge-Beweis verwendet.

Vor einer Rückportierung in die Alt-App sind jedoch `B-SYNC` und `B-REL-feed_context-EVENT_ID` mit Priorität P1 zu prüfen. `K-05` ist wegen des ungeklärten Organisationstyps ebenfalls P1.

---

## 4. Verbindliche Regeln bleiben bestehen

1. Prio 1 = MD / offizielle Website / Register. Sie gilt.
2. Prio 2 = Chat / App-Altbestand. Ergänzt Lücken, überschreibt nie Prio 1.
3. Platzhalter aus dem Altbestand wie `(nicht genannt)` werden nicht gepflegt. Original-Platzhalter einer offiziellen Terminquelle bleiben dagegen als Qualitätsbefund sichtbar, bis ein Beleg vorliegt.
4. Ein Datensatz pro echter Einrichtung. Andere Rechtsform, anderer Zweck oder eigener Standort = eigener Datensatz.
5. Mehrere E-Mails derselben Einrichtung bleiben `email_1`, `email_2`, `email_3`.
6. Hierarchie: Region → Ort → Einrichtung; `Übergreifend` steht zuerst.
7. Nicht genauer sein als die Quelle. Kein Rätselraten, kein stilles Mergen.
8. Sternchen bei Terminen sind Qualitätsmarker, keine Formatierung.
9. Herne-Advent bleibt je Jahr eine Quellzeile mit vier Zeitfenstern.
10. Archiv A bleibt unangetastet (B-13).
11. Personendaten und persönliche Kanäle nicht öffentlich weitergeben (B-17).

---

## 5. Empfohlener Ablauf im nächsten Direct-Mode-Chat

1. Paket prüfen (`sha256sum -c PRUEFSUMMEN.sha256`).
2. Projekt bauen und `/api/import/verify` prüfen.
3. Nutzer nennt genau eine `offen_nr` oder `befund_id` aus `01-OFFENE-PUNKTE.csv`.
4. Nur die für diesen Befund erforderlichen Quellen prüfen.
5. Entscheidung als Entwurf `B-21` ff. zeigen; nichts automatisch importieren.
6. Nach Nutzerfreigabe Beschluss, Daten und Audit-Trail gemeinsam aktualisieren.
7. Prüfungen erneut ausführen und einen neuen Freeze mit neuem Datum erstellen.

---

## 6. Nicht enthalten / nicht vorgeben

- Keine der 13 offenen Fragen ist entschieden.
- Keine Medien- oder Geo-Reparatur wurde ausgeführt.
- Die Variante-A-CSV wurde nicht repariert. Ihr Manifest erwartet bei vier CSVs ein UTF-8-BOM; im ZIP fehlt dieses. Der Inhalt wurde nur gelesen.
- Die ZIPs `var a2` und `var b2` bleiben ungeprüft.
- Die Datenbank selbst ist kein portables Artefakt im ZIP. Sie wird deterministisch aus dem Stufe-4-Freeze über `src/db/seed.ts` rekonstruiert.

---

## 7. Datenschutz und Weitergabe

Das Gesamtprojekt enthält Personen- und Kontaktdaten. Die Bereitstellung unter einer Dashboard- oder Download-URL ist keine Zugriffskontrolle. ZIP, Freeze und Datenbankkopie nur intern übergeben; nicht in ein öffentliches Repository oder einen öffentlichen Dateidienst hochladen.

---

**Ende des Direct-Mode-Handoffs.**
