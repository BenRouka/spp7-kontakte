"use client";

import { useEffect, useMemo, useRef, useState, type ReactNode } from "react";
import { addDays, dateLabel, shortRange, type Period, type ReviewData, type ReviewedEvent, type ReviewYear, type SourceRow } from "@/lib/calendar-model";
import { repositoryUrl, sourceFiles } from "@/lib/reference-data";
import { Icon, type IconName } from "@/components/icons";
import { AlignmentDetails } from "@/components/alignment-details";

type View = "overview" | "sources" | "model" | "decisions";
type Tab = "periods" | "originals" | "decisions";
type DialogState = { kind: "rule" | "source" | "model" | "activity" | "stage" | "inventory" | "alignment"; period?: Period; row?: SourceRow; stage?: number } | null;
const steps = ["Quellen sichern", "Normieren", "Abgleichen", "Entscheiden", "Importieren", "Anzeigen"];
const decisions = [
  { code: "A", title: "Vier Adventswochenenden, ein Quelltermin", description: "Herne wird mit vier getrennten Zeitfenstern dargestellt. Die Tage dazwischen sind kein Teil dieses Termins. Adventssonntage werden nach der Kirchenregel berechnet.", icon: "calendar" as IconName },
  { code: "F1", title: "Vergangene Termine nicht nacherfassen", description: "Januar bis September 2026 werden für die geplante Arbeit nicht benötigt. Die vorhandenen Originalzeilen bleiben trotzdem erhalten.", icon: "history" as IconName },
  { code: "F2", title: "„180 maps“ meint geocodierte Event-Einträge", description: "180 von 206 Events haben LAT und LNG. Sie verteilen sich auf 149 unterschiedliche Koordinatenpaare. Die Zahl bezieht sich nicht auf Bilder.", icon: "pin" as IconName },
  { code: "*", title: "Ein und zwei Sternchen bedeuten unbestätigt", description: "* und ** kennzeichnen gleichermaßen: Termin oder Ort wahrscheinlich, jedoch noch unbestätigt. Ein berechnetes Datum ändert diesen Status nicht.", icon: "info" as IconName },
  { code: "TXT", title: "Originalschreibweisen immer erhalten", description: "Normierte Angaben werden später nur zusätzlich geführt. Tippfehler, Leerzeichen und Schreibvarianten werden nicht stillschweigend im Original korrigiert.", icon: "file" as IconName },
  { code: "KV", title: "Zwei Namen bleiben ein Adressblock", description: "Ein Hauptname und ein Zusatzname werden in einer Zeile geführt. Jeder Adressblock erhält später eine eigene ID; Ortsnamen sind keine eindeutigen Schlüssel.", icon: "layers" as IconName },
];
function Badge({ children, tone = "neutral", icon }: { children: ReactNode; tone?: "neutral" | "green" | "amber" | "blue"; icon?: IconName }) {
  return <span className={`badge badge-${tone}`}>{icon && <Icon name={icon} size={12} />}{children}</span>;
}
function OriginalExcerpt({ event, onOpen }: { event: ReviewedEvent; onOpen: () => void }) {
  return <button className="original-excerpt" onClick={onOpen} type="button" title="Originalzeile und Herkunft ansehen">
    <span className="excerpt-label"><Icon name="file" size={12} /> Original aus der Quelle <Icon name="external" size={12} /></span>
    <strong>{event.source.dateOriginal}</strong>
    <span className="excerpt-name">{event.source.nameOriginal}</span>
  </button>;
}
function DayChips({ period }: { period: Period }) {
  const days: string[] = [];
  for (let iso = period.start; iso <= period.end; iso = addDays(iso, 1)) days.push(iso);
  return <span className="day-chips" aria-hidden="true">{days.map((iso) => <span className="day-chip" key={iso}><small>{dateLabel(iso, { weekday: "short", day: undefined, month: undefined }).replace(".", "")}</small><b>{Number(iso.slice(8))}</b></span>)}</span>;
}
function MonthCalendar({ year, month, period }: { year: ReviewYear; month: number; period: Period }) {
  const first = new Date(Date.UTC(year, month - 1, 1));
  const offset = (first.getUTCDay() + 6) % 7;
  const days = new Date(Date.UTC(year, month, 0)).getUTCDate();
  const cells = Array.from({ length: Math.ceil((offset + days) / 7) * 7 }, (_, i) => {
    const day = i - offset + 1;
    if (day < 1 || day > days) return <span key={i} className="calendar-empty" />;
    const iso = `${year}-${String(month).padStart(2, "0")}-${String(day).padStart(2, "0")}`;
    const active = iso >= period.start && iso <= period.end;
    return <span key={i} className={`calendar-day ${active ? "in-range" : ""} ${iso === period.start || iso === period.end ? "range-edge" : ""}`} title={`${dateLabel(iso)} ${year}${active ? " · im Quellzeitraum" : ""}`}>{day}</span>;
  });
  return <div className="month-grid" aria-label={`Kalender ${month === 11 ? "November" : "Dezember"} ${year}`}>{["Mo", "Di", "Mi", "Do", "Fr", "Sa", "So"].map((day) => <span className="calendar-weekday" key={day}>{day}</span>)}{cells}</div>;
}

export function Workshop({ initialData }: { initialData: ReviewData }) {
  const [data, setData] = useState(initialData);
  const [view, setView] = useState<View>("model");
  const [tab, setTab] = useState<Tab>("periods");
  const [dialog, setDialog] = useState<DialogState>(null);
  const [search, setSearch] = useState("");
  const [statusFilter, setStatusFilter] = useState("all");
  const [page, setPage] = useState(1);
  const [calendarMonth, setCalendarMonth] = useState(11);
  const [exportOpen, setExportOpen] = useState(false);
  const [mobileOpen, setMobileOpen] = useState(false);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");
  const dialogRef = useRef<HTMLDivElement>(null);
  const exportRef = useRef<HTMLDivElement>(null);
  const requestCounter = useRef(0);

  useEffect(() => {
    if (!dialog) return;
    const previous = document.activeElement as HTMLElement | null;
    const oldOverflow = document.body.style.overflow;
    document.body.style.overflow = "hidden";
    dialogRef.current?.querySelector<HTMLElement>("button")?.focus();
    function keydown(event: KeyboardEvent) {
      if (event.key === "Escape") setDialog(null);
      if (event.key === "Tab") {
        const elements = dialogRef.current?.querySelectorAll<HTMLElement>('button:not([disabled]), a[href], input, select, [tabindex="0"]');
        if (!elements?.length) return;
        const first = elements[0], last = elements[elements.length - 1];
        if (event.shiftKey && document.activeElement === first) { event.preventDefault(); last.focus(); }
        else if (!event.shiftKey && document.activeElement === last) { event.preventDefault(); first.focus(); }
      }
    }
    document.addEventListener("keydown", keydown);
    return () => { document.body.style.overflow = oldOverflow; document.removeEventListener("keydown", keydown); previous?.focus(); };
  }, [dialog]);
  useEffect(() => {
    if (!exportOpen) return;
    function close(event: MouseEvent) { if (!exportRef.current?.contains(event.target as Node)) setExportOpen(false); }
    function escape(event: KeyboardEvent) { if (event.key === "Escape") setExportOpen(false); }
    document.addEventListener("mousedown", close); document.addEventListener("keydown", escape);
    return () => { document.removeEventListener("mousedown", close); document.removeEventListener("keydown", escape); };
  }, [exportOpen]);

  const filteredRows = useMemo(() => data.rows.filter((row) => {
    const matchesSearch = `${row.dateOriginal} ${row.nameOriginal} ${row.placeOriginal}`.toLocaleLowerCase("de-DE").includes(search.toLocaleLowerCase("de-DE"));
    return matchesSearch && (statusFilter === "all" || (statusFilter === "uncertain" && row.uncertain) || (statusFilter === "open" && row.locationOpen));
  }), [data.rows, search, statusFilter]);
  const pageCount = Math.max(1, Math.ceil(filteredRows.length / 10));
  const displayedPage = Math.min(page, pageCount);
  const visibleRows = filteredRows.slice((displayedPage - 1) * 10, displayedPage * 10);
  const christmasPeriod = data.christmas.periods[0];

  async function changeYear(value: string) {
    const requestId = ++requestCounter.current;
    setLoading(true); setError("");
    try {
      const response = await fetch(`/api/review?year=${value}`, { cache: "no-store" });
      if (!response.ok) throw new Error("Die Prüfdaten konnten nicht geladen werden.");
      const result = await response.json() as ReviewData;
      if (requestId !== requestCounter.current) return;
      setData(result); setCalendarMonth(11); setPage(1);
    } catch {
      if (requestId === requestCounter.current) setError("Das Jahr konnte nicht geladen werden. Die bisherigen Daten bleiben sichtbar.");
    } finally { if (requestId === requestCounter.current) setLoading(false); }
  }
  function navigate(next: View) { setView(next); setTab("periods"); setSearch(""); setStatusFilter("all"); setPage(1); setMobileOpen(false); }
  function exportHref(format: string, kind?: string) { return `/api/review/export?year=${data.year}&format=${format}${kind ? `&kind=${kind}` : ""}`; }

  const titles: Record<View, { title: string; subtitle: string; crumb: string }> = {
    model: { title: "Termine richtig abbilden", subtitle: "Vier Adventswochenenden sind kein durchgehender Weihnachtsmarkt.", crumb: "Normierung" },
    overview: { title: "Eine saubere Grundlage. Schritt für Schritt.", subtitle: "Was belegt ist, was noch offen ist und wo wir gerade stehen.", crumb: "Übersicht" },
    sources: { title: "Original bleibt Original", subtitle: "Fünf Referenz- und Originalquellen. Unverändert, nachvollziehbar, getrennt.", crumb: "Quellen" },
    decisions: { title: "Festgehalten, nicht geraten", subtitle: "Deine Klarstellungen bilden die Grundlage für die nächsten Schritte.", crumb: "Festlegungen" },
  };
  const modalTitle = dialog?.kind === "rule" ? "So werden die Adventstage berechnet" : dialog?.kind === "source" ? "Die unveränderte Quellzeile" : dialog?.kind === "model" ? "Ein Quelltermin, mehrere Zeitfenster" : dialog?.kind === "inventory" ? "Was die „180 maps“ tatsächlich zählen" : dialog?.kind === "alignment" ? "Einheitlicher Zeitmodell-Stand A / B" : dialog?.kind === "stage" ? `${String(dialog.stage).padStart(2, "0")} · ${steps[(dialog.stage || 1) - 1]}` : "Stand dieser Prüfansicht";

  function DecisionsView({ compact = false }: { compact?: boolean }) {
    return <div className={compact ? "compact-decisions" : "decisions-grid"}>{(compact ? decisions.slice(1, 4) : decisions).map((decision) => <article className={compact ? "compact-decision" : "decision-card"} key={decision.code}>
      {compact ? <span className="little-check"><Icon name="check" size={12} /></span> : <span className="decision-icon"><Icon name={decision.icon} size={20} /></span>}
      <div><div className="decision-heading"><h3>{decision.title}</h3>{!compact && <Badge tone="green">Geklärt</Badge>}</div>{!compact && <p>{decision.description}</p>}</div>
      {!compact && <span className="decision-code">{decision.code}</span>}
    </article>)}</div>;
  }

  function SourcesView() {
    return <section className="sources-section"><div className="section-heading"><div><h2>Die fünf Originalquellen</h2><p>Externe Dateien im bereitgestellten GitHub-Repository.</p></div><Badge icon="lock">Nur lesen</Badge></div>
      <div className="source-list">{sourceFiles.map((file) => <a className="source-file" href={repositoryUrl + file.file} target="_blank" rel="noreferrer" key={file.id}><span className={`file-tile file-${file.type.toLowerCase()}`}><Icon name={file.type === "ZIP" ? "folder" : "file"} size={22} /><small>{file.type}</small></span><div className="source-file-description"><h3>{file.label}</h3><p>{file.detail}</p><span>{file.name}</span></div><Badge tone={file.role === "Referenzquelle" ? "green" : "neutral"}>{file.role}</Badge><span className="file-size">{file.size}</span><Icon name="external" size={17} /></a>)}</div>
      <div className="source-notice"><Icon name="info" size={18} /><div><strong>Abrufbar ist nicht dasselbe wie dauerhaft gesichert.</strong><p>Diese Prüfansicht verändert keine Originaldatei. Die vollständige Ablage aller fünf Originale in <code>werkstatt/01-roh/</code> ist im vorliegenden Werkstatt-ZIP nicht belegt. Der private Chat wird hier nicht veröffentlicht.</p></div></div>
      <div className="checksum-card"><Icon name="shield" size={20} /><div><strong>SHA-256 der ursprünglichen Termin-Datei</strong><code>{data.inventory.originalScheduleSha256}</code><p>Die Prüfsumme bezieht sich auf die GitHub-Originaldatei, nicht auf die Anzeigeaufbereitung.</p></div></div>
    </section>;
  }

  function OriginalsView() {
    return <section className="originals-panel"><div className="table-heading"><div><h2>Originaltermine {data.year}</h2><p>{data.rows.length} Quellzeilen · Schreibweise und Sternchen bleiben erhalten.</p></div><a className="text-button" href={exportHref("csv", "originals")}><Icon name="download" size={16} /> CSV herunterladen</a></div>
      <div className="table-scroll"><table><thead><tr><th>Veranstaltung</th><th>Datum · Original</th><th>PLZ / Ort · Original</th><th>Quellhinweis</th><th aria-label="Details" /></tr></thead><tbody>{visibleRows.map((row) => <tr key={row.id}><td><button onClick={() => setDialog({ kind: "source", row })}>{row.nameOriginal}<small>Zeile {row.lineNumber}</small></button></td><td className="tech">{row.dateOriginal}</td><td className="tech">{row.placeOriginal}</td><td>{row.locationOpen ? <Badge tone="amber">Ort offen</Badge> : row.uncertain ? <Badge tone="amber">Unbestätigt</Badge> : <span className="not-marked">Nicht markiert <span title="Keine Sternchenmarkierung bedeutet nicht automatisch bestätigt.">ⓘ</span></span>}</td><td><button className="icon-button" aria-label={`Quelle zu ${row.nameOriginal} ansehen`} onClick={() => setDialog({ kind: "source", row })}><Icon name="chevron" size={16} /></button></td></tr>)}</tbody></table>
        {!visibleRows.length && <div className="empty-state"><Icon name="search" size={32} /><h3>Keine passenden Quelltermine</h3><p>Versuche einen anderen Suchbegriff oder entferne den Filter.</p><button className="secondary-button" onClick={() => { setSearch(""); setStatusFilter("all"); }}>Filter zurücksetzen</button></div>}
      </div><div className="pagination"><span>{filteredRows.length ? `${(displayedPage - 1) * 10 + 1}–${Math.min(displayedPage * 10, filteredRows.length)}` : "0"} von {filteredRows.length} Ergebnissen</span><div><button className="icon-button" aria-label="Vorherige Seite" disabled={displayedPage === 1} onClick={() => setPage(displayedPage - 1)}><Icon name="chevron" size={16} className="rotate-180" /></button><span>Seite {displayedPage} von {pageCount}</span><button className="icon-button" aria-label="Nächste Seite" disabled={displayedPage === pageCount} onClick={() => setPage(displayedPage + 1)}><Icon name="chevron" size={16} /></button></div></div>
      <div className="table-legend"><Icon name="info" size={15} /><span><b>* und **</b> = Termin oder Ort wahrscheinlich, jedoch noch unbestätigt. „Nicht markiert“ ist kein Verifikationsnachweis.</span></div>
    </section>;
  }

  return <div className="app-shell">
    {mobileOpen && <button className="sidebar-backdrop" aria-label="Menü schließen" onClick={() => setMobileOpen(false)} />}
    <aside className={`sidebar ${mobileOpen ? "sidebar-open" : ""}`}>
      <a className="brand" href="/" aria-label="SPP7 Werkstatt Startseite"><span className="brand-mark"><Icon name="layers" size={24} /></span><span><b>SPP7<span className="brand-dot">.</span></b><small>Tour Intelligence</small></span></a>
      <div className="workspace-label"><span className="workspace-dot" /> Datenwerkstatt <Badge>V.01</Badge></div>
      <span className="nav-label">Arbeitsbereich</span>
      <nav aria-label="Arbeitsbereich">
        <button className={`nav-item ${view === "overview" ? "active" : ""}`} onClick={() => navigate("overview")}><Icon name="grid" size={19} /><span>Übersicht</span></button>
        <button className={`nav-item ${view === "sources" ? "active" : ""}`} onClick={() => navigate("sources")}><Icon name="folder" size={19} /><span>Quellen</span><span className="nav-count">5</span></button>
        <button className={`nav-item ${view === "model" ? "active" : ""}`} onClick={() => navigate("model")}><Icon name="sliders" size={19} /><span>Normierung</span><span className="nav-active-dot" /></button>
        <button className="nav-item muted" onClick={() => { setDialog({ kind: "stage", stage: 3 }); setMobileOpen(false); }}><Icon name="compare" size={19} /><span>Abgleich</span><Icon name="lock" size={12} /></button>
        <button className={`nav-item ${view === "decisions" ? "active" : ""}`} onClick={() => navigate("decisions")}><Icon name="decisions" size={19} /><span>Festlegungen</span><span className="nav-count">6</span></button>
        <button className="nav-item muted" onClick={() => { setDialog({ kind: "stage", stage: 5 }); setMobileOpen(false); }}><Icon name="database" size={19} /><span>Datenbankimport</span><Icon name="lock" size={12} /></button>
      </nav>
      <div className="sidebar-separator" />
      <button className="nav-item" onClick={() => { setDialog({ kind: "activity" }); setMobileOpen(false); }}><Icon name="history" size={19} /><span>Prüfprotokoll</span></button>
      <button className="nav-item" onClick={() => { setDialog({ kind: "alignment" }); setMobileOpen(false); }}><Icon name="compare" size={19} /><span>A/B-Abgleich</span><Icon name="chevron" size={13} /></button>
      <div className="sidebar-bottom"><div className="safe-card"><span className="safe-icon"><Icon name="shield" size={21} /></span><strong>Erst klären. Dann ändern.</strong><p>Originale bleiben unangetastet.<br />Kein automatischer Import.</p><div><span className="live-dot" /> Reine Prüfansicht</div></div><div className="workspace-profile"><span className="profile-avatar">S7</span><div><b>SPP7 Arbeitsbereich</b><small>Lesender Arbeitsbereich</small></div><Icon name="chevronDown" size={15} /></div></div>
    </aside>

    <div className="main-shell">
      <header className="topbar"><div className="breadcrumb"><button className="icon-button mobile-menu" aria-label="Menü öffnen" onClick={() => setMobileOpen(true)}><Icon name="menu" /></button><Icon name="folder" size={17} /><span>Werkstatt</span><Icon name="chevron" size={13} /><b>{titles[view].crumb}</b></div><div className="topbar-right"><span className="protected-label"><Icon name="shield" size={15} /> Originale unverändert</span><span className="topbar-divider" /><button className="icon-button notification-button" title="Prüfprotokoll öffnen" aria-label="Prüfprotokoll öffnen" onClick={() => setDialog({ kind: "activity" })}><Icon name="bell" size={19} /><span /></button><button className="top-avatar" title="Arbeitsbereich ansehen" aria-label="Arbeitsbereich ansehen" onClick={() => navigate("overview")}>S7</button></div></header>
      <main className="main-content" aria-busy={loading}>
        <div className="page-heading"><div><div className="eyebrow">Klärung vor Stufe 2 <span /> Option A</div><h1>{titles[view].title}</h1><p>{titles[view].subtitle}</p></div><div className="heading-actions"><a className="secondary-button" href={data.sourceUrl} target="_blank" rel="noreferrer"><Icon name="external" size={16} /> Originalquelle</a><div className="export-container" ref={exportRef}><button className="primary-button" aria-haspopup="menu" aria-expanded={exportOpen} onClick={() => setExportOpen(!exportOpen)}><Icon name="download" size={16} /> Prüfbericht <Icon name="chevronDown" size={13} /></button>{exportOpen && <div className="export-menu" role="menu"><span>Zeitmodell {data.year}</span><a role="menuitem" href={exportHref("md")} onClick={() => setExportOpen(false)}><Icon name="file" size={17} /><div><b>Lesbarer Prüfbericht</b><small>Markdown · .md</small></div></a><a role="menuitem" href={exportHref("csv")} onClick={() => setExportOpen(false)}><Icon name="grid" size={17} /><div><b>Zeitfenster als Tabelle</b><small>CSV · nur Prüfdaten</small></div></a><a role="menuitem" href={exportHref("ics")} onClick={() => setExportOpen(false)}><Icon name="calendar" size={17} /><div><b>Kalendervorschau</b><small>ICS · mit Quellstatus</small></div></a><p>Kein Datenbankimport.</p></div>}</div></div></div>

        <section className="pipeline" aria-label="Die sechs Stufen der Datenpipeline">{steps.map((step, index) => <button className={`pipeline-step ${index === 1 ? "current-step" : ""} ${index === 0 ? "source-step" : ""}`} key={step} onClick={() => index === 0 ? navigate("sources") : index === 1 ? navigate("model") : index === 3 ? navigate("decisions") : setDialog({ kind: "stage", stage: index + 1 })}><span className="step-number">{String(index + 1).padStart(2, "0")}</span><span><b>{step}</b><small>{index === 0 ? "Ablage noch offen" : index === 1 ? "In Klärung" : index === 3 ? "Regeln festgehalten" : "Nicht begonnen"}</small></span>{index < 5 && <Icon name="chevron" size={13} className="step-chevron" />}</button>)}</section>

        <div className="metric-grid"><article className="metric-card"><div className="metric-label">Termine in der Quelle <Icon name="file" size={17} /></div><strong>{data.totals.all}<span>Quellzeilen</span></strong><p>{data.totals.year2026} aus 2026 <span>·</span> {data.totals.year2027} aus 2027</p></article><article className="metric-card"><div className="metric-label">Adventswochenenden <Icon name="calendar" size={17} /></div><strong>4<span>Zeitfenster</span></strong><p>Ein Quelltermin <span>·</span> {data.advent.weekdayLabel}</p></article><article className="metric-card"><div className="metric-label">Weihnachtsmarkt Dresden <Icon name="clock" size={17} /></div><strong>{data.christmas.dayCount}<span>Kalendertage</span></strong><p><span className="tiny-dot" /> Durchgehender Zeitraum</p></article><button className="metric-card metric-button" onClick={() => setDialog({ kind: "inventory" })}><div className="metric-label">Events mit Koordinaten <Icon name="pin" size={17} /></div><strong>{data.inventory.geocodedEvents}<span>von {data.inventory.events}</span></strong><p>{data.inventory.uniqueEventCoordinates} verschiedene Punkte <Icon name="arrowRight" size={13} /></p></button></div>

        {error && <div className="error-notice" role="alert"><Icon name="info" size={17} />{error}<button onClick={() => changeYear(String(data.year))}>Erneut versuchen</button></div>}

        {view === "model" && <>
          <div className="tab-toolbar"><div className="tabs" role="tablist" aria-label="Normierungsprüfung"><button role="tab" aria-selected={tab === "periods"} className={tab === "periods" ? "selected" : ""} onClick={() => setTab("periods")}><Icon name="calendar" size={16} /> Zeiträume</button><button role="tab" aria-selected={tab === "originals"} className={tab === "originals" ? "selected" : ""} onClick={() => setTab("originals")}><Icon name="file" size={16} /> Originaltermine <span>{data.totals.all}</span></button><button role="tab" aria-selected={tab === "decisions"} className={tab === "decisions" ? "selected" : ""} onClick={() => setTab("decisions")}><Icon name="checkCircle" size={16} /> Festlegungen <span>6</span></button></div><div className="toolbar-controls"><label className="search-input"><Icon name="search" size={15} /><input aria-label="Originaltermine durchsuchen" placeholder="Termin suchen…" value={search} onChange={(event) => { setSearch(event.target.value); setTab("originals"); setPage(1); }} />{search && <button aria-label="Suche leeren" onClick={() => { setSearch(""); setPage(1); }}><Icon name="close" size={13} /></button>}</label><label className="year-select"><Icon name="calendar" size={15} /><select aria-label="Quelljahr auswählen" value={data.year} disabled={loading} onChange={(event) => changeYear(event.target.value)}><option value="2027">2027</option><option value="2026">2026</option></select><Icon name="chevronDown" size={12} /></label></div></div>
          {tab === "originals" && <div className="filter-bar"><span><Icon name="filter" size={15} /> Quellhinweis</span><select aria-label="Nach Quellhinweis filtern" value={statusFilter} onChange={(event) => { setStatusFilter(event.target.value); setPage(1); }}><option value="all">Alle Termine</option><option value="uncertain">Mit Sternchen · unbestätigt</option><option value="open">Ort noch offen</option></select><span className="filter-count">{filteredRows.length} Ergebnisse für {data.year}</span></div>}
          {tab === "periods" && <section className="periods-panel" role="tabpanel" aria-label="Zeitmodelle"><div className="section-intro"><div><span className="little-check"><Icon name="check" size={12} /></span><span>Geklärte Darstellung <b>·</b> zwei unterschiedliche Zeitmodelle</span></div><span className="read-only-caption"><Icon name="lock" size={12} /> Darstellung, kein Import</span></div>
            <div className="time-model-grid">
              <article className="event-card advent-card"><div className="event-card-header"><span className="event-icon"><Icon name="calendar" size={22} /></span><div><h2>Mittelalter-Advent</h2><p><Icon name="pin" size={12} /> Herne · Schloss Strünkede</p></div><span className="event-type">4 Wochenenden</span></div><div className="event-badges"><Badge tone="blue" icon="code">Berechnet</Badge>{data.advent.source.uncertain ? <Badge tone="amber">Unbestätigt *</Badge> : <Badge>Nicht mit * markiert</Badge>}<button className="text-button rule-link" onClick={() => setDialog({ kind: "rule" })}><Icon name="info" size={13} /> Berechnungsregel</button></div><OriginalExcerpt event={data.advent} onOpen={() => setDialog({ kind: "source", row: data.advent.source })} />
                <div className="advent-periods">{data.advent.periods.map((period) => <button className="advent-period" key={period.id} onClick={() => setDialog({ kind: "rule", period })}><span className="advent-number">{period.ordinal}</span><span className="advent-period-text"><small>{period.ordinal}. Advent</small><strong>{shortRange(period)}</strong></span><DayChips period={period} /><Icon name="chevron" size={14} /></button>)}</div>
                <div className="event-card-footer"><Icon name="layers" size={14} /><span>Ein Quelltermin, vier getrennte Zeitfenster</span><a href={`${data.sourceUrl}#L${data.advent.source.lineNumber}`} target="_blank" rel="noreferrer">Zeile {data.advent.source.lineNumber} <Icon name="external" size={12} /></a></div>
              </article>
              <article className="event-card christmas-card"><div className="event-card-header"><span className="event-icon warm-icon"><Icon name="calendar" size={22} /></span><div><h2>Mittelalter-Weihnacht</h2><p><Icon name="pin" size={12} /> Dresden · Stallhof</p></div><span className="event-type warm-type">Durchgehend</span></div><div className="event-badges"><Badge icon="file">Aus Quelle</Badge><Badge tone="amber">Unbestätigt *</Badge></div><OriginalExcerpt event={data.christmas} onOpen={() => setDialog({ kind: "source", row: data.christmas.source })} />
                <div className="continuous-content"><div className="range-summary"><div><strong>{Number(christmasPeriod.start.slice(8))}</strong><span>Nov {data.year}</span></div><div className="range-connector"><span>{data.christmas.dayCount} Tage</span><i /></div><div><strong>{Number(christmasPeriod.end.slice(8))}</strong><span>Dez {data.year}</span></div></div><div className="month-selector"><button className={calendarMonth === 11 ? "selected" : ""} onClick={() => setCalendarMonth(11)}>November</button><button className={calendarMonth === 12 ? "selected" : ""} onClick={() => setCalendarMonth(12)}>Dezember</button><span>{data.year}</span></div><MonthCalendar year={data.year} month={calendarMonth} period={christmasPeriod} /></div>
                <div className="event-card-footer"><span className="tiny-dot" /><span>Ein Startdatum. Ein Enddatum. Keine Lücke.</span></div>
              </article>
            </div>
            <div className="model-note"><span className="note-icon"><Icon name="info" size={19} /></span><div><strong>Nicht zu einem durchgehenden Adventstermin zusammenziehen.</strong><p>Die vier Wochenenden bleiben getrennt. „Berechnet“ beschreibt die Datumsherkunft – nicht die Bestätigung.</p></div><button className="text-button" onClick={() => setDialog({ kind: "model" })}>Zeitmodell ansehen <Icon name="arrowRight" size={15} /></button></div>
            <div className="bottom-grid"><section className="settled-card"><div className="mini-section-heading"><h2>Bereits geklärt</h2><button className="text-button" onClick={() => setTab("decisions")}>Alle 6 anzeigen <Icon name="arrowRight" size={14} /></button></div><DecisionsView compact /></section><section className="next-step-card"><span className="eyebrow">Bevor Stufe 2 beginnt</span><h2>Nachvollziehbar normieren.</h2><p>Original, Datumsherkunft und Bestätigungsstatus getrennt halten. Keine stillen Korrekturen.</p><button className="text-button" onClick={() => setDialog({ kind: "model" })}>Details zum Zeitmodell <Icon name="arrowRight" size={15} /></button></section></div>
          </section>}
          {tab === "originals" && <OriginalsView />}{tab === "decisions" && <><div className="section-heading"><div><h2>Sechs geklärte Regeln</h2><p>Aus deinen Klarstellungen, nicht aus Vermutungen.</p></div><Badge tone="green" icon="check">Festgehalten</Badge></div><DecisionsView /></>}
        </>}
        {view === "sources" && <SourcesView />}
        {view === "decisions" && <><div className="section-heading"><div><h2>Sechs geklärte Regeln</h2><p>Keine dieser Klarstellungen startet automatisch einen Import.</p></div><Badge tone="green" icon="check">Geklärt</Badge></div><DecisionsView /><div className="model-note"><Icon name="shield" size={21} /><div><strong>Klärung ist keine Freigabe für Schemaänderungen.</strong><p>Stufe 2 und die folgenden Schritte werden hier nicht automatisch ausgeführt.</p></div></div></>}
        {view === "overview" && <><div className="section-heading"><div><h2>Zwei ZIPs. Zwei unterschiedliche Aufgaben.</h2><p>Der App-Bestand und die Werkstatt sind nicht zwei fertige App-Versionen.</p></div><Badge icon="file">Geprüfter Bestand</Badge></div><div className="comparison-grid"><article className="comparison-card"><span className="comparison-icon"><Icon name="grid" size={25} /></span><Badge tone="green">App A</Badge><h2>Die Dashboard-App</h2><p>SPP7 mit Dashboard, Tabellen, Chatansicht und Karte. 14 strukturierte Datensätze sind vorhanden.</p><ul><li><Icon name="check" size={15} /> 206 Events und 74 Kontakte</li><li><Icon name="check" size={15} /> 121 aufbereitete Chatnachrichten</li><li><Icon name="info" size={15} /> Bilddateien fehlen im App-ZIP</li><li><Icon name="info" size={15} /> JSON-Synchronisation kann DB-Werte überschreiben</li></ul><button className="text-button" onClick={() => navigate("sources")}>Originalquellen ansehen <Icon name="arrowRight" size={16} /></button></article><article className="comparison-card"><span className="comparison-icon"><Icon name="folder" size={25} /></span><Badge>Werkstatt</Badge><h2>Die Prüfgrundlage</h2><p>Starter-App mit Übergabenotizen, zwei sauberen Textquellen und einer vorbereiteten Arbeitsstruktur.</p><ul><li><Icon name="check" size={15} /> 32 Adressblöcke und 54 Terminzeilen</li><li><Icon name="check" size={15} /> Herkunftsnotizen und Prüfsummenliste</li><li><Icon name="info" size={15} /> Drei referenzierte Originale fehlen im ZIP</li><li><Icon name="info" size={15} /> Normierung und Abgleich noch nicht abgeschlossen</li></ul><button className="text-button" onClick={() => navigate("model")}>Geklärtes Zeitmodell ansehen <Icon name="arrowRight" size={16} /></button></article></div><div className="model-note"><Icon name="info" size={20} /><div><strong>Koordinaten vorhanden heißt nicht automatisch Koordinaten verifiziert.</strong><p>Die 180 Einträge sind gezählt. Ihre inhaltliche Richtigkeit muss separat geprüft werden.</p></div><button className="text-button" onClick={() => setDialog({ kind: "inventory" })}>Zählung ansehen <Icon name="arrowRight" size={14} /></button></div></>}
        <footer className="page-footer"><span><Icon name="file" size={13} /> Referenzstand 2027: 22. September 2026</span><span><span className={`live-dot ${data.database.connected ? "" : "offline-dot"}`} /> {data.database.connected ? "Datenbank verbunden" : "Datenbank nicht erreichbar"}<b>·</b> ausschließlich lesend</span></footer>
      </main>
    </div>

    {dialog && <div className="dialog-backdrop" onMouseDown={(event) => { if (event.target === event.currentTarget) setDialog(null); }}><div className="dialog" role="dialog" aria-modal="true" aria-labelledby="dialog-title" ref={dialogRef}><div className="dialog-header"><span className="dialog-eyebrow">SPP7 · Prüfansicht</span><button className="icon-button" aria-label="Dialog schließen" onClick={() => setDialog(null)}><Icon name="close" size={20} /></button></div><h2 id="dialog-title">{modalTitle}</h2><div className="dialog-content">
      {dialog.kind === "alignment" && <AlignmentDetails modelVersion={data.modelVersion} />}
      {dialog.kind === "rule" && <><p>{data.adventRule.fourthSunday} Die übrigen drei Adventssonntage liegen jeweils eine Woche davor.</p><div className="dialog-info"><Icon name="calendar" size={19} /><span>Die Quelle {data.year} sagt <b>{data.advent.weekdayLabel}</b>. Der Beginn wird vom jeweiligen Adventssonntag zurückgerechnet.</span></div><div className="calculation-table">{(dialog.period ? [dialog.period] : data.advent.periods).map((period) => <div key={period.id}><b>{period.ordinal}. Advent</b><span>{dateLabel(period.start)} – {dateLabel(period.end)} {data.year}</span><code>{period.start} → {period.end}</code></div>)}</div><p className="dialog-fineprint">2027: Freitag bis Sonntag. 2026: Donnerstag bis Sonntag, entsprechend der jeweiligen Originalzeile. Kein durchgehender Zeitraum zwischen den Wochenenden.</p><p className="dialog-fineprint">{data.adventRule.christmasSunday} <a className="text-button" href={data.adventRule.sourceUrl} target="_blank" rel="noreferrer">Regel nachlesen <Icon name="external" size={12} /></a></p><div className="dialog-warning"><Icon name="info" size={18} /><span><b>Berechnet ist nicht bestätigt.</b> Die Sternchenmarkierung der Quelle bleibt unabhängig von der Datumsberechnung erhalten.</span></div></>}
      {dialog.kind === "source" && dialog.row && <><p>Terminliste der Sündenfrei Mittelalteragentur · Originalzeile {dialog.row.lineNumber}. Die Schreibweise wurde nicht korrigiert.</p><dl className="source-detail"><div><dt>Datum · Original</dt><dd>{dialog.row.dateOriginal}</dd></div><div><dt>Name · Original</dt><dd>{dialog.row.nameOriginal}</dd></div><div><dt>PLZ / Ort · Original</dt><dd>{dialog.row.placeOriginal}</dd></div><div><dt>Quellhinweis</dt><dd>{dialog.row.uncertain ? "Termin oder Ort wahrscheinlich, jedoch noch unbestätigt (* / **)." : "Keine Sternchenmarkierung. Das ist kein Nachweis einer Bestätigung."}</dd></div></dl><pre className="raw-line">{dialog.row.originalLine}</pre><a className="secondary-button" href={`${data.sourceUrl}#L${dialog.row.lineNumber}`} target="_blank" rel="noreferrer"><Icon name="external" size={16} /> Original auf GitHub öffnen</a></>}
      {dialog.kind === "model" && <><p>Die Quelle enthält <b>eine Veranstaltung</b>. Zu dieser Veranstaltung gehören vier einzelne Datumsabschnitte – nicht vier neue Events.</p><div className="model-diagram"><div className="diagram-event"><Icon name="calendar" size={22} /><b>Mittelalter-Advent {data.year}</b><small>Eine unveränderte Quellzeile</small></div><div className="diagram-line" /><div className="diagram-periods">{data.advent.periods.map((period) => <div key={period.id}><small>{period.ordinal}. Advent</small><b>{shortRange(period)}</b></div>)}</div></div><div className="field-pair"><div><small>Datumsherkunft</small><Badge tone="blue">berechnet</Badge></div><div><small>Bestätigungsstatus</small><Badge tone={data.advent.source.uncertain ? "amber" : "neutral"}>{data.advent.source.uncertain ? "unbestätigt" : "nicht markiert"}</Badge></div></div><div className="dialog-warning"><Icon name="info" size={18} /><span><b>Vorsicht, das betrifft das spätere Datenmodell.</b> Mehrere Zeitfenster müssen einem Quelltermin zugeordnet werden können. Hier wurde weder das Schema geändert noch etwas importiert.</span></div></>}
      {dialog.kind === "inventory" && <><p>Unabhängig im Datensatz <code>events</code> des bereitgestellten App-ZIPs gezählt. Ein Eintrag wird nur gezählt, wenn sowohl LAT als auch LNG vorhanden sind.</p><dl className="inventory-detail"><div><dt>Events insgesamt</dt><dd>{data.inventory.events}</dd></div><div><dt>Events mit beiden Koordinaten</dt><dd>{data.inventory.geocodedEvents}</dd></div><div><dt>Events ohne Koordinaten</dt><dd>{data.inventory.events - data.inventory.geocodedEvents}</dd></div><div><dt>Unterschiedliche Koordinatenpaare</dt><dd>{data.inventory.uniqueEventCoordinates}</dd></div><div><dt>Kontakte mit Koordinaten · separat</dt><dd>{data.inventory.geocodedContacts} / {data.inventory.contacts}</dd></div><div><dt>Bilder im separaten Chat-ZIP</dt><dd>{data.inventory.originalImages} + {data.inventory.thumbnailImages}</dd></div></dl><div className="dialog-info"><Icon name="checkCircle" size={20} /><span>„180“ passt exakt zur Anzahl der <b>Event-Einträge mit Koordinaten</b>. Es sind nicht 180 unterschiedliche Standorte und nicht 180 Bilder.</span></div><p className="dialog-fineprint">Diese Zählung bestätigt nicht die inhaltliche Richtigkeit jedes einzelnen Kartenpunkts.</p></>}
      {dialog.kind === "stage" && <><Badge tone="amber">Nicht begonnen</Badge><p className="stage-description">{dialog.stage === 3 ? "Der Abgleich soll saubere Referenzquellen mit den App-Daten vergleichen und einen lesbaren Bericht erzeugen. Dubletten werden nicht automatisch zusammengeführt." : dialog.stage === 5 ? "Ein Import gehört erst in Stufe 5. Diese Prüfansicht enthält bewusst keine Schreibfunktion. Quelle, Status und entschiedene Konflikte müssen vorher nachvollziehbar feststehen." : "Die spätere App-Anzeige soll Datumsherkunft, unbestätigte Angaben und offene Felder sichtbar machen. Diese Stufe wird nicht automatisch ausgeführt."}</p><div className="dialog-warning"><Icon name="lock" size={18} /><span>Die Kalenderanzeige ist kein Import und keine Änderung der Bestands-App.</span></div></>}
      {dialog.kind === "activity" && <><p>Lesbare Sitzungsübersicht. Kein dauerhaft gespeichertes Änderungsprotokoll.</p><div className="activity-list"><div><span><Icon name="check" size={15} /></span><section><h3>Zeiträume unterschieden</h3><p>Vier Adventswochenenden in Herne; ein durchgehender Weihnachtsmarkt in Dresden.</p></section></div><div><span><Icon name="check" size={15} /></span><section><h3>Quellstatus beibehalten</h3><p>* und ** bleiben unbestätigt. Berechnete Daten erhalten eine eigene Herkunftsangabe.</p></section></div><div><span><Icon name="shield" size={15} /></span><section><h3>Originale nicht geändert</h3><p>Die Quellansicht erhält die Originalschreibweisen. Kein Überschreiben oder Zusammenführen.</p></section></div><div><span><Icon name="database" size={15} /></span><section><h3>Keine Datenbankschreibzugriffe</h3><p>{data.database.connected ? "Verbindung erfolgreich geprüft." : "Verbindung derzeit nicht verfügbar."} Es werden ausschließlich lesende Abfragen ausgeführt.</p></section></div></div></>}
    </div><div className="dialog-footer"><span><Icon name="lock" size={13} /> Nur Prüfung, kein Import</span><button className="primary-button" onClick={() => setDialog(null)}>Schließen</button></div></div></div>}
  </div>;
}
