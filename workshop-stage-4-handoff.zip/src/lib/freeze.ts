import { readFileSync } from "node:fs";
import path from "node:path";

/**
 * Schreibgeschützter Zugriff auf das Freeze-Paket (Stufe 4).
 * Quelle: public/export/FREEZE — Dateien bleiben byteidentisch,
 * geprüft über PRUEFSUMMEN.sha256. Kein Datenbankzugriff (B-20).
 */

export const FREEZE_DIR = path.join(
  process.cwd(),
  "public",
  "export",
  "FREEZE"
);

export const FREEZE_FILES = [
  "HANDOFF.md",
  "arbeitsstand-kontakte.csv",
  "arbeitsstand-termine.csv",
  "beschlussverzeichnis.csv",
] as const;

export function readFreeze(name: string): string {
  return readFileSync(path.join(FREEZE_DIR, name), "utf8");
}

/** Regionenreihenfolge laut HANDOFF §3 — verbindlich, Übergreifend zuerst. */
export const REGION_ORDER = [
  "Übergreifend",
  "Rund um die Granitz",
  "Halbinsel Mönchgut",
  "Halbinsel Jasmund",
  "Halbinsel Wittow",
  "Nord-West-Rügen",
  "Süd-Rügen",
  "Zentralrügen",
  "Seebad Insel Hiddensee",
] as const;

/* ------------------------------------------------------------------ */
/* Kontakte                                                            */
/* ------------------------------------------------------------------ */

export interface KontaktRow {
  felder: number; // Anzahl Rohfelder der Zeile (Dateibefund, Kopf hat 13)
  kvId: string;
  region: string;
  ort: string;
  name: string;
  anschrift: string;
  telefon: string;
  fax: string;
  email1: string;
  email2: string;
  email3: string;
  web: string;
  typ: string;
  hinweis: string;
}

export function parseKontakte(csv: string): KontaktRow[] {
  const lines = csv.trimEnd().split(/\r?\n/);
  return lines
    .slice(1)
    .filter((l) => l.trim().length > 0)
    .map((l) => {
      const p = l.split(";");
      const last = p.length - 1;
      // Kopf hat 13 Felder. Weicht eine Zeile ab (Dateibefund: STADT-PUTBUS
      // mit 14 Feldern), werden typ/hinweis endbündig gelesen — die Rohzeile
      // in der Datei bleibt unverändert.
      return {
        felder: p.length,
        kvId: p[0] ?? "",
        region: p[1] ?? "",
        ort: p[2] ?? "",
        name: p[3] ?? "",
        anschrift: p[4] ?? "",
        telefon: p[5] ?? "",
        fax: p[6] ?? "",
        email1: p[7] ?? "",
        email2: p[8] ?? "",
        email3: p[9] ?? "",
        web: p[10] ?? "",
        typ: p.length === 13 ? p[11] ?? "" : p[last - 1] ?? "",
        hinweis: p[last] ?? "",
      };
    });
}

export interface KontaktStats {
  datensaetze: number;
  kvGekennzeichnet: number;
  sonderdatensaetze: number;
  email1: number;
  email2: number;
  email3: number;
  regionen: number;
}

export function kontaktStats(rows: KontaktRow[]): KontaktStats {
  return {
    datensaetze: rows.length,
    kvGekennzeichnet: rows.filter((r) => r.kvId.startsWith("KV")).length,
    sonderdatensaetze: rows.filter((r) => !r.kvId.startsWith("KV")).length,
    email1: rows.filter((r) => r.email1 !== "").length,
    email2: rows.filter((r) => r.email2 !== "").length,
    email3: rows.filter((r) => r.email3 !== "").length,
    regionen: new Set(rows.map((r) => r.region)).size,
  };
}

export function groupByRegion<K extends { region: string }>(
  rows: K[]
): { region: string; rows: K[] }[] {
  const map = new Map<string, K[]>();
  for (const r of rows) {
    const list = map.get(r.region) ?? [];
    list.push(r);
    map.set(r.region, list);
  }
  const ordered: { region: string; rows: K[] }[] = REGION_ORDER.filter((reg) =>
    map.has(reg)
  ).map((reg) => ({
    region: reg,
    rows: map.get(reg)!,
  }));
  const others = [...map.keys()].filter(
    (reg) => !(REGION_ORDER as readonly string[]).includes(reg)
  );
  for (const reg of others) ordered.push({ region: reg, rows: map.get(reg)! });
  return ordered;
}

export function groupByOrt<K extends { ort: string }>(rows: K[]) {
  const out: { ort: string; rows: K[] }[] = [];
  for (const r of rows) {
    const lastGroup = out[out.length - 1];
    if (lastGroup && lastGroup.ort === r.ort) lastGroup.rows.push(r);
    else out.push({ ort: r.ort, rows: [r] });
  }
  return out;
}

/* ------------------------------------------------------------------ */
/* Termine                                                             */
/* ------------------------------------------------------------------ */

export interface Zeitfenster {
  nr: number;
  von: string;
  bis: string;
  raw: string;
}

export interface TerminRow {
  sfId: string;
  jahr: string;
  datumOriginal: string;
  name: string;
  plzOrt: string;
  anzahl: number;
  fenster: Zeitfenster[];
  sternchen: string;
  hinweis: string;
}

export function parseTermine(csv: string): TerminRow[] {
  const lines = csv.trimEnd().split(/\r?\n/);
  return lines
    .slice(1)
    .filter((l) => l.trim().length > 0)
    .map((l) => {
      const p = l.split(";");
      const anzahl = Number.parseInt(p[5] ?? "1", 10);
      const fensterRaw = p.slice(6, 6 + anzahl);
      return {
        sfId: p[0] ?? "",
        jahr: p[1] ?? "",
        datumOriginal: p[2] ?? "",
        name: p[3] ?? "",
        plzOrt: p[4] ?? "",
        anzahl,
        fenster: fensterRaw.map((raw, i) => {
          const [von, bis] = raw.split("/");
          return { nr: i + 1, von: von ?? "", bis: bis ?? "", raw };
        }),
        sternchen: p[6 + anzahl] ?? "",
        hinweis: p.slice(7 + anzahl).join(";").trim(),
      };
    });
}

export interface TerminStats {
  quellzeilen: number;
  zeitfenster: number;
  sichtbareZeilen: number;
  stern1: number;
  stern2: number;
  mehrfach: number;
}

export function terminStats(rows: TerminRow[], jahr: string): TerminStats {
  const r = rows.filter((x) => x.jahr === jahr);
  return {
    quellzeilen: r.length,
    zeitfenster: r.reduce((s, x) => s + x.anzahl, 0),
    // Sichtbare Zeilen = Haupteinträge + je Advent-Unterzeile (B-12)
    sichtbareZeilen: r.reduce((s, x) => s + (x.anzahl > 1 ? 1 + x.anzahl : 1), 0),
    stern1: r.filter((x) => x.sternchen === "*").length,
    stern2: r.filter((x) => x.sternchen === "**").length,
    mehrfach: r.filter((x) => x.anzahl > 1).length,
  };
}

/* ------------------------------------------------------------------ */
/* Beschlüsse                                                          */
/* ------------------------------------------------------------------ */

export interface BeschlussRow {
  id: string;
  bereich: string;
  titel: string;
  prio1: string;
  prio2: string;
  massnahme: string;
  status: string;
}

export function parseBeschluesse(csv: string): BeschlussRow[] {
  const lines = csv.trimEnd().split(/\r?\n/);
  return lines
    .slice(1)
    .filter((l) => l.trim().length > 0)
    .map((l) => {
      const p = l.split(";");
      return {
        id: p[0] ?? "",
        bereich: p[1] ?? "",
        titel: p[2] ?? "",
        prio1: p[3] ?? "",
        prio2: p[4] ?? "",
        massnahme: p[5] ?? "",
        status: p.slice(6).join(";").trim(),
      };
    });
}

/* ------------------------------------------------------------------ */
/* Prüfsummen + Protokoll                                              */
/* ------------------------------------------------------------------ */

export interface Pruefsumme {
  file: string;
  hash: string;
}

export function parsePruefsummen(text: string): Pruefsumme[] {
  return text
    .trimEnd()
    .split(/\r?\n/)
    .filter((l) => l.trim().length > 0)
    .map((l) => {
      const m = l.match(/^([0-9a-f]{64})\s+(.+)$/);
      return { hash: m?.[1] ?? "", file: m?.[2] ?? l };
    });
}

export function loadFreeze() {
  const kontakteCsv = readFreeze("arbeitsstand-kontakte.csv");
  const termineCsv = readFreeze("arbeitsstand-termine.csv");
  const beschluesseCsv = readFreeze("beschlussverzeichnis.csv");
  return {
    handoff: readFreeze("HANDOFF.md"),
    header: {
      kontakte: kontakteCsv.split(/\r?\n/, 1)[0].split(";"),
      termine: termineCsv.split(/\r?\n/, 1)[0].split(";"),
      beschluesse: beschluesseCsv.split(/\r?\n/, 1)[0].split(";"),
    },
    kontakte: parseKontakte(kontakteCsv),
    termine: parseTermine(termineCsv),
    beschluesse: parseBeschluesse(beschluesseCsv),
    pruefsummen: parsePruefsummen(readFreeze("PRUEFSUMMEN.sha256")),
  };
}
