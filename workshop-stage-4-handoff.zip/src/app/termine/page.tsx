import type { Metadata } from "next";
import { Asterisk, CalendarDays, Layers, Sigma } from "lucide-react";
import { TerminRow, loadFreeze, terminStats } from "@/lib/freeze";
import { Badge, Panel, RefChip, Section, Stat, cx } from "@/components/ui";

export const metadata: Metadata = {
  title: "Termine · Werkstatt Stufe 4",
};

function Stern({ value }: { value: string }) {
  if (value === "kein" || value === "") {
    return <span className="font-mono text-[11px] text-muted/50">—</span>;
  }
  return (
    <span
      title="Termin oder Ort wahrscheinlich, noch unbestätigt"
      className={cx(
        "inline-flex items-center gap-0.5 rounded-md border px-1.5 py-0.5 font-mono text-[11px] font-semibold",
        value === "**"
          ? "border-amber/50 bg-amber/15 text-amber-soft"
          : "border-amber/30 bg-amber/[0.07] text-amber"
      )}
    >
      <Asterisk className="h-3 w-3" />
      {value}
    </span>
  );
}

function FensterChip({ nr, raw, multi }: { nr: number; raw: string; multi: boolean }) {
  const [von, bis] = raw.split("/");
  return (
    <span className="inline-flex items-center gap-1.5 rounded-md border border-line bg-raised2/70 px-2 py-1 font-mono text-[10.5px] text-ink-soft">
      {multi ? (
        <span className="rounded bg-lime/15 px-1 font-semibold text-lime">F{nr}</span>
      ) : null}
      <span className="text-lime-soft">{von}</span>
      <span className="text-muted">→</span>
      <span className="text-lime-soft">{bis}</span>
    </span>
  );
}

function TerminZeile({ t }: { t: TerminRow }) {
  const multi = t.anzahl > 1;
  return (
    <div
      className={cx(
        "grid gap-3 border-b border-line-soft px-4 py-3.5 last:border-b-0 lg:grid-cols-[64px_minmax(0,1fr)_auto] lg:gap-6",
        multi && "bg-lime/[0.02]"
      )}
    >
      <span className="font-mono text-[11px] font-semibold text-lime">{t.sfId}</span>

      <div className="min-w-0">
        <p className="text-[13.5px] font-medium leading-snug text-ink">{t.name}</p>
        <p className="mt-1 font-mono text-[11.5px] text-ink-soft">{t.datumOriginal}</p>
        <p className="mt-0.5 text-[11.5px] text-muted">{t.plzOrt}</p>
        {t.hinweis ? (
          <p className="mt-1.5 font-mono text-[10.5px] leading-relaxed text-amber-soft">
            {t.hinweis}
          </p>
        ) : null}
        {multi ? (
          <p className="mt-1.5 flex items-center gap-1.5 font-mono text-[10px] uppercase tracking-[0.12em] text-lime">
            <Layers className="h-3 w-3" />
            1 Quellzeile · {t.anzahl} Zeitfenster · keine Aufteilung (B-10)
          </p>
        ) : null}
      </div>

      <div className="flex flex-col items-start gap-1.5 lg:items-end">
        <div className="flex flex-wrap gap-1.5 lg:justify-end">
          {t.fenster.map((f) => (
            <FensterChip key={f.nr} nr={f.nr} raw={f.raw} multi={multi} />
          ))}
        </div>
        <Stern value={t.sternchen} />
      </div>
    </div>
  );
}

function JahrBlock({ jahr, rows }: { jahr: string; rows: TerminRow[] }) {
  const s = terminStats(rows, jahr);
  return (
    <Section
      eyebrow={`Saison ${jahr}`}
      title={`Sündenfrei ${jahr}`}
      aside={
        <div className="mb-1 flex flex-wrap gap-1.5">
          <Badge tone="a">{s.quellzeilen} Quellzeilen</Badge>
          <Badge tone="a">{s.zeitfenster} Zeitfenster</Badge>
          <Badge tone="mute">{s.sichtbareZeilen} sichtbare Zeilen</Badge>
          {s.stern1 > 0 ? <Badge tone="warn">* × {s.stern1}</Badge> : null}
          {s.stern2 > 0 ? <Badge tone="warn">** × {s.stern2}</Badge> : null}
        </div>
      }
    >
      <Panel className="p-0">
        <div className="flex items-center justify-between gap-3 border-b border-line bg-base/40 px-4 py-2">
          <span className="font-mono text-[9.5px] uppercase tracking-[0.16em] text-muted">
            ID · Quellzeile (Originalwortlaut) · ISO-Zeitfenster · Qualitätsmarker
          </span>
          <span className="font-mono text-[9.5px] text-muted">Zeitzone: wie Quelle</span>
        </div>
        <div>
          {rows
            .filter((t) => t.jahr === jahr)
            .map((t) => (
              <TerminZeile key={t.sfId} t={t} />
            ))}
        </div>
      </Panel>
    </Section>
  );
}

export default function TerminePage() {
  const { termine } = loadFreeze();
  const s26 = terminStats(termine, "2026");
  const s27 = terminStats(termine, "2027");
  const gesamtFenster = termine.reduce((s, t) => s + t.anzahl, 0);
  const gesamtStern1 = s26.stern1 + s27.stern1;
  const gesamtStern2 = s26.stern2 + s27.stern2;

  return (
    <>
      <div className="border-b border-line pb-8">
        <p className="font-mono text-[10.5px] font-semibold uppercase tracking-[0.24em] text-lime">
          Arbeitsstand · arbeitsstand-termine.csv
        </p>
        <h1 className="mt-3 text-[30px] font-semibold tracking-tight text-ink sm:text-[38px]">
          Termine — {termine.length} Quellzeilen, {gesamtFenster} Zeitfenster
        </h1>
        <p className="mt-4 max-w-3xl text-[13px] leading-relaxed text-muted">
          Ground Truth von der offiziellen Sündenfrei-Website (Stand September 2026,
          B-09). Vollständige Übernahme: die alte App hatte nur 14 dieser {termine.length}{" "}
          Termine erfasst — ein Befund über den Altbestand, keine Lücke in dieser Liste.
        </p>
      </div>

      <div className="mt-8 grid grid-cols-2 gap-3 md:grid-cols-4">
        <Stat
          label="2026 · Quellzeilen / Fenster"
          value={`${s26.quellzeilen} / ${s26.zeitfenster}`}
          sub={`${s26.quellzeilen} Haupteinträge + ${s26.sichtbareZeilen - s26.quellzeilen} Advents-Unterzeilen = ${s26.sichtbareZeilen} sichtbar`}
        />
        <Stat
          label="2027 · Quellzeilen / Fenster"
          value={`${s27.quellzeilen} / ${s27.zeitfenster}`}
          sub={`${s27.quellzeilen - 1} Einzeiler + ${s27.mehrfach} Herne-Zeile (${s27.mehrfach * 4} Fenster)`}
        />
        <Stat
          label="Herne-Advent"
          value="2 × 1 Zeile"
          sub="je 4 Zeitfenster — keine Aufteilung, sonst 58 statt 54 Zeilen (B-10)"
          tone="lime"
        />
        <Stat
          label="Sternchen * / **"
          value={`${gesamtStern1} / ${gesamtStern2}`}
          sub="Qualitätsmarker: wahrscheinlich, unbestätigt (B-11)"
          tone="amber"
        />
      </div>

      <JahrBlock jahr="2026" rows={termine} />
      <JahrBlock jahr="2027" rows={termine} />

      <Section
        eyebrow="B-12 · Zählweise"
        title="Quellzeilen und Zeitfenster getrennt zählen"
        desc="Immer beide Zahlen angeben — die Balance muss aufgehen."
      >
        <Panel>
          <div className="grid gap-3 font-mono text-[11.5px] leading-relaxed sm:grid-cols-2">
            <div className="rounded-lg border border-line bg-base/60 p-3.5">
              <p className="mb-2 flex items-center gap-1.5 text-[10px] uppercase tracking-[0.16em] text-muted">
                <Sigma className="h-3.5 w-3.5 text-lime" /> 2026
              </p>
              <p className="text-ink-soft">
                {s26.quellzeilen} Quellzeilen = {s26.quellzeilen - 1} Einzelzeilen + 1 Herne-Zeile
              </p>
              <p className="text-ink-soft">
                {s26.zeitfenster} Zeitfenster = {s26.zeitfenster - 4} andere + 4 Herne-Wochenenden
              </p>
              <p className="text-lime-soft">
                {s26.sichtbareZeilen} sichtbare Zeilen = {s26.quellzeilen} Haupteinträge +{" "}
                {s26.sichtbareZeilen - s26.quellzeilen} Advents-Unterzeilen
              </p>
            </div>
            <div className="rounded-lg border border-line bg-base/60 p-3.5">
              <p className="mb-2 flex items-center gap-1.5 text-[10px] uppercase tracking-[0.16em] text-muted">
                <Sigma className="h-3.5 w-3.5 text-lime" /> 2027
              </p>
              <p className="text-ink-soft">
                {s27.quellzeilen} Quellzeilen = {s27.quellzeilen - 1} Einzeiler + 1 Herne-Zeile
              </p>
              <p className="text-ink-soft">
                {s27.zeitfenster} Zeitfenster = {s27.zeitfenster - 4} Einzel-Fenster + 4 Herne-Wochenenden
              </p>
              <p className="text-lime-soft">
                {s27.sichtbareZeilen} sichtbare Zeilen = {s27.quellzeilen} Haupteinträge +{" "}
                {s27.sichtbareZeilen - s27.quellzeilen} Advents-Unterzeilen
              </p>
            </div>
          </div>
          <p className="mt-3 flex items-start gap-2 text-[12px] leading-relaxed text-muted">
            <CalendarDays className="mt-0.5 h-3.5 w-3.5 shrink-0 text-lime" />
            <span>
              Sternchen werden als Status geführt, nicht als Formatierung entfernt (B-11).
              Felder <RefChip>F1–F4</RefChip> sind reine Anzeige-Indizes der Fenster einer
              Quellzeile — die Datei bleibt unverändert.
            </span>
          </p>
        </Panel>
      </Section>
    </>
  );
}
