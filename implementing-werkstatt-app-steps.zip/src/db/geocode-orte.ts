/* ------------------------------------------------------------------ */
/* Schritt C1 — Frisch-Geocodierung der geo_orte (O-11).               */
/*                                                                     */
/* Verbindlicher Ablauf:                                               */
/*   1. Ziele = alle PLZ+Ort-Schlüssel der kuratierten termine         */
/*      (plz_ort_original) plus die Tour-Korridor-Orte (KORRIDOR),     */
/*      deren PLZ nicht in den terminen vorkommt (Rügenhof/Puttgarten  */
/*      18556, Schaprode 18569 — Schlüssel aus den Alt-Brückenzeilen). */
/*   2. Je Ziel: Nominatim (OSM), User-Agent gesetzt, 1,1 s Pause,     */
/*      Kandidaten der Reihe nach (links vom „/“, dann rechte Seite).  */
/*   3. Liefert der Geocoder nichts → statische Fallback-Koordinate    */
/*      (ortsüblich, quelle = statisch-fallback, pruefstatus = prüfen).*/
/*   4. Idempotent: vorhandene Schlüssel werden übersprungen;          */
/*      pruefstatus = geprueft wird NIEMALS überschrieben.             */
/*      --aktualisieren erzwingt Neu-Geocodierung aller ungeprueften.  */
/*                                                                     */
/* Alt-Koordinaten aus alt_events werden hier nicht verwendet.         */
/* Ausführung:  npx tsx --env-file=.env src/db/geocode-orte.ts         */
/* ------------------------------------------------------------------ */

import { db, pool } from "./index";
import { geoOrte, termine } from "./schema";
import {
  FALLBACK_KOORDINATEN,
  geoKey,
  KORRIDOR,
  parsePlzOrt,
} from "../lib/geo";

const USER_AGENT = "spp7-werkstatt-geo/1.0 (interner Pruefimport; Kontakt: werkstatt)";
const BASIS = "https://nominatim.openstreetmap.org/search";

interface GeocodeTreffer {
  lat: string;
  lng: string;
  anzeige: string;
  genauigkeit: string;
}

interface Ziel {
  plz: string;
  kandidaten: string[];
  herkunft: string; // z. B. „termine SF35“ oder „korridor T04“
}

function pause(ms: number) {
  return new Promise((r) => setTimeout(r, ms));
}

async function nominatim(plz: string, ort: string): Promise<GeocodeTreffer | null> {
  const varianten = [
    `postalcode=${encodeURIComponent(plz)}&city=${encodeURIComponent(ort)}`,
    `city=${encodeURIComponent(ort)}`,
  ];
  for (const q of varianten) {
    const url = `${BASIS}?format=jsonv2&countrycodes=de&limit=1&${q}`;
    try {
      const res = await fetch(url, { headers: { "User-Agent": USER_AGENT } });
      if (!res.ok) continue;
      const treffer = (await res.json()) as Array<{
        lat?: string;
        lon?: string;
        display_name?: string;
        addresstype?: string;
        type?: string;
      }>;
      await pause(1100); // Nominatim-Richtlinie: max. 1 Anfrage/s
      const t = treffer[0];
      if (t?.lat && t?.lon) {
        return {
          lat: t.lat,
          lng: t.lon,
          anzeige: t.display_name ?? "",
          genauigkeit: t.addresstype ?? t.type ?? "unbekannt",
        };
      }
    } catch {
      await pause(1100);
    }
  }
  return null;
}

async function main() {
  console.log("— Schritt C1 · Geocodierung geo_orte (O-11) —");
  const aktualisieren = process.argv.includes("--aktualisieren");

  /* 1 · Ziele aufbauen ------------------------------------------------ */
  const terminZeilen = await db
    .select({ sfId: termine.sfId, plzOrt: termine.plzOrtOriginal })
    .from(termine);

  const ziele = new Map<string, Ziel>(); // Schlüssel: plz|kandidat[0]
  for (const z of terminZeilen) {
    const parsed = parsePlzOrt(z.plzOrt);
    if (!parsed) continue;
    const schluessel = geoKey(parsed.plz, parsed.kandidaten[0]);
    if (!ziele.has(schluessel)) {
      ziele.set(schluessel, { ...parsed, herkunft: `termine ${z.sfId}` });
    }
  }
  for (const k of KORRIDOR) {
    const schluessel = geoKey(k.plz, k.ort);
    if (!ziele.has(schluessel)) {
      ziele.set(schluessel, {
        plz: k.plz,
        kandidaten: [k.ort],
        herkunft: `korridor ${k.altEventId}`,
      });
    }
  }

  /* 2 · Vorhandene Einträge (Idempotenz) ----------------------------- */
  const vorhanden = await db.select().from(geoOrte);
  const index = new Map(
    vorhanden.map((g) => [geoKey(g.plz, g.ort), g.pruefstatus]),
  );
  const offene = [...ziele.values()].filter((z) => {
    const status = index.get(geoKey(z.plz, z.kandidaten[0]));
    if (status === "geprueft") return false; // manuell geprüft: nie anfassen
    if (status && !aktualisieren) return false; // bereits vorhanden: überspringen
    return true;
  });

  console.log(
    `  Ziele ${ziele.size} · vorhanden ${vorhanden.length} · zu codieren ${offene.length}` +
      (aktualisieren ? " (--aktualisieren)" : ""),
  );

  /* 3 · Codieren ------------------------------------------------------ */
  let viaNominatim = 0;
  let viaFallback = 0;
  let uebersprungen = 0;

  for (const ziel of offene) {
    let treffer: GeocodeTreffer | null = null;
    let benutzt = ziel.kandidaten[0];

    for (const kandidat of ziel.kandidaten) {
      treffer = await nominatim(ziel.plz, kandidat);
      if (treffer) {
        benutzt = kandidat;
        break;
      }
    }

    if (treffer) {
      viaNominatim++;
      await schreibe(ziel.plz, benutzt, {
        ...treffer,
        quelle: "nominatim-osm",
        pruefstatus: "ungeprueft",
      });
      console.log(
        `  OK  ${ziel.plz} ${benutzt}  ← ${treffer.anzeige.split(",").slice(0, 2).join(",")}  [${treffer.genauigkeit}]  (${ziel.herkunft})`,
      );
      continue;
    }

    const fb = FALLBACK_KOORDINATEN[geoKey(ziel.plz, benutzt)];
    if (fb) {
      viaFallback++;
      await schreibe(ziel.plz, benutzt, {
        lat: fb.lat,
        lng: fb.lng,
        anzeige: "statische Tabelle (Ortskern)",
        genauigkeit: "statisch",
        quelle: "statisch-fallback",
        pruefstatus: "pruefen",
      });
      console.log(
        `  FB  ${ziel.plz} ${benutzt}  ← statische Tabelle, ZUM PRÜFEN  (${ziel.herkunft})`,
      );
    } else {
      uebersprungen++;
      console.log(
        `  --  ${ziel.plz} ${ziel.kandidaten.join(" / ")}  KEIN Treffer und kein Fallback  (${ziel.herkunft})`,
      );
    }
  }

  console.log(
    `\nGeocodierung abgeschlossen: nominatim ${viaNominatim} · fallback ${viaFallback} · ohne Treffer ${uebersprungen}`,
  );
  const stand = await db.select().from(geoOrte);
  console.log(`geo_orte gesamt: ${stand.length}`);
}

async function schreibe(
  plz: string,
  ort: string,
  t: GeocodeTreffer & { quelle: string; pruefstatus: string },
) {
  await db
    .insert(geoOrte)
    .values({
      plz,
      ort,
      lat: t.lat,
      lng: t.lng,
      anzeige: t.anzeige,
      quelle: t.quelle,
      genauigkeit: t.genauigkeit,
      pruefstatus: t.pruefstatus,
    })
    .onConflictDoUpdate({
      target: [geoOrte.plz, geoOrte.ort],
      set: {
        lat: t.lat,
        lng: t.lng,
        anzeige: t.anzeige,
        quelle: t.quelle,
        genauigkeit: t.genauigkeit,
        pruefstatus: t.pruefstatus,
        geocodiertAm: new Date().toISOString(),
      },
      // pruefstatus = geprueft wurde oben schon ausgefiltert
    });
}

main()
  .catch((e) => {
    console.error("Geocodierung fehlgeschlagen:", e);
    process.exit(1);
  })
  .finally(() => pool.end());
