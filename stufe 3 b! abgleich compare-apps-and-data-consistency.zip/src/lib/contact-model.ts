import { NORMALIZED_MISSING_VALUE } from "@/lib/normalization-csv";

export const CONTACT_MODEL_VERSION = "kontaktstruktur-region-ort-einrichtung-v4";
export const MISSING_CONTACT_VALUE = NORMALIZED_MISSING_VALUE;

export const contactCsvHeaders = [
  "kv_id", "quellblock_id", "region_id", "ort_id", "parent_id", "hierarchie_pfad",
  "hierarchie_rolle", "hierarchie_herkunft", "organisations_parent_id", "beziehungsherkunft",
  "eintragsname_original", "region_original", "region_anzeige", "ort_original", "ort_anzeige",
  "name_haupt_original", "name_zusatz_original", "name_zusatz_ergaenzung", "name_zusatz_normiert", "name_zusatz_herkunft",
  "strasse_original", "plz_ort_original", "plz_normiert", "ort_normiert", "ortsteil_original", "ortsteil_normiert", "ortsteil_herkunft",
  "telefon_original", "telefon_ergaenzung", "telefon_normiert", "telefon_herkunft",
  "fax_original", "fax_ergaenzung", "fax_normiert", "fax_herkunft",
  "web_original", "web_ergaenzung", "web_normiert", "web_herkunft",
  "email_1_original", "email_1_ergaenzung", "email_1_normiert", "email_1_herkunft",
  "email_2_original", "email_2_normiert", "nutzer_zitat", "quelle_ergaenzung", "chat_msg_id",
  "hinweis", "felder_fehlend_quelle", "felder_fehlend_arbeitsstand", "quellzeile", "status_verifikation", "quelle_stand",
] as const;
export type NormalizedContact = Record<typeof contactCsvHeaders[number], string>;
export type ContactNodeType = "region" | "gruppe" | "ort" | "einrichtung";
export type SourceNodeOccurrence = { id: string; name: string; quellzeile: string };
export type ContactNode = {
  id: string; parent_id: string; typ: ContactNodeType; name: string; name_original: string;
  zusatzname: string; hierarchie_pfad: string; quellzeile: string; herkunft: string;
  quellknoten_ids: string; quellvorkommen: SourceNodeOccurrence[];
};
export const contactTreeCsvHeaders = ["id", "parent_id", "typ", "name", "name_original", "zusatzname", "hierarchie_pfad", "quellzeile", "quellknoten_ids", "herkunft"] as const;

type ContactField = "telefon" | "fax" | "web" | "email_1";
export type ContactSupplement = {
  kv_id: string; zitat: string; fundstelle: string; herkunft: string;
  werte: Partial<Record<ContactField, string>>;
  organisations_parent_id?: string; beziehungsherkunft?: string; namenszusatz?: string;
};
export type ContactStructureRule =
  | { art: "uebergreifende_gruppe"; region_id: string; quell_ort_id: string; region_original: string;
      quell_ort_original: string; anzeigename: string; fundstelle: string; herkunft: string }
  | { art: "orte_zusammenfuehren"; region_id: string; quell_ort_ids: string[]; kanonische_ort_id: string;
      quell_ort_original: string; fundstelle: string; herkunft: string };
export type ContactSupplements = {
  version: string; beschreibung: string; eintraege: ContactSupplement[]; strukturregeln: ContactStructureRule[];
};
export type ContactWorkspace = {
  version: typeof CONTACT_MODEL_VERSION; missingValue: string; nodes: ContactNode[]; contacts: NormalizedContact[]; sourceStand: string;
  counts: { rawBlocks: number; contacts: number; regions: number; groups: number; places: number; sourcePlaceHeadings: number;
    treeNodes: number; explicitDistricts: number; supplementedContacts: number };
  source: { file: string; url: string; sha256: string; supplementFile: string; supplementSha256: string };
};
type SourceBlock = {
  region: ContactNode; place: ContactNode; names: string[]; street: string; plzOrt: string;
  telefon: string; fax: string; web: string; emails: string[]; note: string; from: number; to: number;
};
const clean = (value: string) => value.replace(/\s+/g, " ").trim();
const digits = (value: string) => value.replace(/\D+/g, "");
const hasValue = (value: string | undefined) => !!value && value !== MISSING_CONTACT_VALUE;

export function internationalContactPhone(value: string): string {
  if (!hasValue(value)) return MISSING_CONTACT_VALUE;
  const local = value.match(/^\s*\(([^)]+)\)\s*(.+)$/);
  if (local) {
    const area = digits(local[1]), subscriber = digits(local[2]);
    if (!area.startsWith("0") || area.length < 2 || !subscriber) throw new Error(`Telefon-Vorwahl ist nicht eindeutig: ${value}`);
    return `+49 ${area.slice(1)} ${subscriber}`;
  }
  const international = value.match(/^\s*\+49\s+(\d+)\s+([\d\s]+)$/);
  if (international) return `+49 ${international[1]} ${digits(international[2])}`;
  throw new Error(`Keine eindeutige Telefonaufteilung: ${value}`);
}
function sourceNode(id: string, parent_id: string, typ: ContactNodeType, name: string, hierarchie_pfad: string, line: number): ContactNode {
  const quellzeile = String(line);
  return { id, parent_id, typ, name, name_original: name, zusatzname: MISSING_CONTACT_VALUE,
    hierarchie_pfad, quellzeile, herkunft: typ === "region" ? "MD-Gliederung: ##" : "MD-Gliederung: ###",
    quellknoten_ids: id, quellvorkommen: [{ id, name, quellzeile }] };
}
function parseContactSource(markdown: string) {
  const lines = markdown.replaceAll("\r\n", "\n").split("\n");
  const blocks: SourceBlock[] = [], nodes: ContactNode[] = [], footer: string[] = [];
  let region: ContactNode | null = null, place: ContactNode | null = null, current: SourceBlock | null = null;
  let inFooter = false, regionIndex = 0, placeIndex = 0, localPlaceIndex = 0;
  const flush = () => { if (current) { blocks.push(current); current = null; } };
  for (let index = 0; index < lines.length; index++) {
    const line = clean(lines[index]);
    if (line === "---") { flush(); inFooter = true; continue; }
    if (inFooter) { if (line) footer.push(line.replace(/^\*\*|\*\*$|^_|_$/g, "")); continue; }
    if (!line) { flush(); continue; }
    if (line.startsWith("## ")) {
      flush(); regionIndex++; localPlaceIndex = 0; place = null;
      region = sourceNode(`REG${String(regionIndex).padStart(2, "0")}`, MISSING_CONTACT_VALUE, "region", line.slice(3), String(regionIndex), index + 1);
      nodes.push(region); continue;
    }
    if (line.startsWith("### ")) {
      flush(); if (!region) throw new Error("Ortsüberschrift ohne Regionsüberschrift.");
      placeIndex++; localPlaceIndex++;
      place = sourceNode(`ORT${String(placeIndex).padStart(2, "0")}`, region.id, "ort", line.slice(4), `${region.hierarchie_pfad}.${localPlaceIndex}`, index + 1);
      nodes.push(place); continue;
    }
    if (line.startsWith("# ")) { flush(); continue; }
    if (/^_\(.+\)_$/.test(line)) {
      if (!current) throw new Error(`Notiz ohne Eintrag in MD-Zeile ${index + 1}`);
      current.note = line.slice(1, -1); current.to = index + 1; continue;
    }
    if (/^_.*_$/.test(line)) { flush(); continue; }
    if (!current) {
      if (!region || !place) throw new Error(`Adressblock ohne Gliederung in MD-Zeile ${index + 1}`);
      current = { region, place, names: [], street: "", plzOrt: "", telefon: "", fax: "", web: "", emails: [], note: "", from: index + 1, to: index + 1 };
    }
    current.to = index + 1;
    const field = line.match(/^(Telefon|Fax|Internet|E-Mail):\s*(.*)$/);
    if (field) {
      const [, key, value] = field;
      if (key === "Telefon") current.telefon = value;
      else if (key === "Fax") current.fax = value;
      else if (key === "Internet") current.web = value;
      else current.emails.push(value);
      continue;
    }
    const name = line.match(/^\*\*(.+?)\*\*$/);
    if (name) { current.names.push(name[1]); continue; }
    if (/^\d{5}\s/.test(line)) { current.plzOrt = line; continue; }
    if (/^\(.+\)$/.test(line)) { current.note = line; continue; }
    if (!current.street && !current.plzOrt) { current.street = line; continue; }
    throw new Error(`Nicht zugeordnete MD-Zeile ${index + 1}: ${line}`);
  }
  flush();
  const sourceStand = footer.join(" · ");
  if (blocks.length !== 32 || !sourceStand.includes("Stand 2025") || !sourceStand.includes("ohne Gewähr")) throw new Error("Unerwarteter Rohquellenstand.");
  return { blocks, nodes, sourceStand };
}
function explicitDistrict(plzPlace: string, street: string, sourceLine: string) {
  const inPlace = plzPlace.match(/^(.*?)\s+OT\s+(.+)$/);
  if (inPlace) return { place: inPlace[1], district: inPlace[2], origin: `MD, Zeilen ${sourceLine}: explizites OT im PLZ-/Ort-Feld` };
  const inStreet = street.match(/^OT\s+(.+?)\s+\d+[a-zA-Z]?(?:\s|$)/);
  if (inStreet) return { place: plzPlace, district: inStreet[1], origin: `MD, Zeilen ${sourceLine}: explizites OT in der Adresszeile` };
  return { place: plzPlace, district: MISSING_CONTACT_VALUE, origin: MISSING_CONTACT_VALUE };
}

function applyExplicitStructureRules(sourceNodes: ContactNode[], rules: ContactStructureRule[]) {
  if (!Array.isArray(rules)) throw new Error("Strukturregeln fehlen.");
  const nodes = sourceNodes.map((node) => ({ ...node, quellvorkommen: node.quellvorkommen.map((source) => ({ ...source })) }));
  const aliases = new Map(sourceNodes.map((node) => [node.id, node.id]));
  const removed = new Set<string>();
  function joinSources(target: ContactNode, source: ContactNode) {
    target.quellvorkommen.push(...source.quellvorkommen.map((value) => ({ ...value })));
    target.quellzeile = target.quellvorkommen.map((value) => value.quellzeile).join(";");
    target.quellknoten_ids = target.quellvorkommen.map((value) => value.id).join(";");
  }
  for (const rule of rules) {
    if (!rule.fundstelle || !rule.herkunft) throw new Error("Strukturregel ohne Herkunft.");
    const root = nodes.find((node) => node.id === rule.region_id);
    if (!root || root.parent_id !== MISSING_CONTACT_VALUE || root.typ !== "region") throw new Error("Strukturregel ohne unveränderte Quellregion.");
    if (rule.art === "uebergreifende_gruppe") {
      const child = nodes.find((node) => node.id === rule.quell_ort_id);
      if (!child || child.typ !== "ort" || child.parent_id !== root.id || child.name !== rule.quell_ort_original ||
        root.name !== rule.region_original || !rule.anzeigename || removed.has(child.id)) throw new Error("Übergreifende Quellgruppe nicht eindeutig.");
      root.name = rule.anzeigename; root.typ = "gruppe";
      root.herkunft = `MD-Gliederung + ${rule.herkunft}: ${rule.fundstelle}`;
      joinSources(root, child); aliases.set(child.id, root.id); removed.add(child.id);
    } else if (rule.art === "orte_zusammenfuehren") {
      if (rule.quell_ort_ids.length < 2 || new Set(rule.quell_ort_ids).size !== rule.quell_ort_ids.length ||
        !rule.quell_ort_ids.includes(rule.kanonische_ort_id)) throw new Error("Unvollständige freigegebene Ortszuordnung.");
      const target = nodes.find((node) => node.id === rule.kanonische_ort_id);
      if (!target || target.typ !== "ort" || removed.has(target.id)) throw new Error("Kanonischer Ort fehlt.");
      for (const id of rule.quell_ort_ids) {
        const source = nodes.find((node) => node.id === id);
        if (!source || source.parent_id !== root.id || source.typ !== "ort" || source.name !== rule.quell_ort_original || removed.has(id)) throw new Error("Nicht passende Ortsfundstelle in Nutzerregel.");
      }
      for (const id of rule.quell_ort_ids) {
        aliases.set(id, target.id);
        if (id !== target.id) { joinSources(target, nodes.find((node) => node.id === id)!); removed.add(id); }
      }
      target.herkunft = `MD-Fundstellen + ${rule.herkunft}: ${rule.fundstelle}`;
    } else throw new Error("Nicht erlaubte Strukturregel.");
  }
  const active = nodes.filter((node) => !removed.has(node.id));
  const placeCounts = new Map<string, number>();
  for (const node of active) {
    if (node.typ === "ort") {
      const order = (placeCounts.get(node.parent_id) || 0) + 1; placeCounts.set(node.parent_id, order);
      const root = active.find((value) => value.id === node.parent_id)!;
      node.hierarchie_pfad = `${root.hierarchie_pfad}.${order}`;
    }
  }
  return { nodes: active, aliases };
}

export function buildContactStructure(markdown: string, supplementFile: ContactSupplements): Omit<ContactWorkspace, "source"> {
  const { blocks, nodes: sourceNodes, sourceStand } = parseContactSource(markdown);
  const { nodes, aliases } = applyExplicitStructureRules(sourceNodes, supplementFile.strukturregeln);
  const additions = new Map(supplementFile.eintraege.map((item) => [item.kv_id, item]));
  if (additions.size !== supplementFile.eintraege.length) throw new Error("Doppelte Nutzerergänzung.");
  const sourceIds = new Set(blocks.map((_, index) => `KV${String(index + 1).padStart(2, "0")}`));
  for (const item of additions.values()) {
    if (!sourceIds.has(item.kv_id)) throw new Error(`Ergänzung ohne Quellblock: ${item.kv_id}`);
    for (const [field, value] of Object.entries(item.werte)) {
      if (!["telefon", "fax", "web", "email_1"].includes(field) || typeof value !== "string" || !value || value === "-") throw new Error(`Nicht erlaubte Ergänzung für ${item.kv_id}`);
    }
    if (item.namenszusatz !== undefined && (!hasValue(item.namenszusatz) || item.namenszusatz === "-" || typeof item.namenszusatz !== "string")) throw new Error("Ungültiger Nutzer-Namenszusatz.");
    if (item.organisations_parent_id && !sourceIds.has(item.organisations_parent_id)) throw new Error("Organisationszuordnung ohne Parent.");
  }
  const localEntryCounts = new Map<string, number>();
  const contacts = blocks.map((block, index): NormalizedContact => {
    const id = `KV${String(index + 1).padStart(2, "0")}`;
    if (!block.names.length || block.names.length > 2) throw new Error(`Namensstruktur prüfen: ${id}`);
    const postal = block.plzOrt.match(/^(\d{5})\s+(.+)$/);
    if (!postal) throw new Error(`PLZ/Ort fehlt für ${id}`);
    const sourceLine = `${block.from}-${block.to}`, origin = `MD, Zeilen ${sourceLine}`;
    const region = nodes.find((node) => node.id === aliases.get(block.region.id))!;
    const parent = nodes.find((node) => node.id === aliases.get(block.place.id))!;
    if (!region || !parent) throw new Error("Fehlende kanonische Quellgruppe.");
    const addition = additions.get(id);
    const sourceFields: Record<ContactField, string> = { telefon: block.telefon || MISSING_CONTACT_VALUE,
      fax: block.fax || MISSING_CONTACT_VALUE, web: block.web || MISSING_CONTACT_VALUE, email_1: block.emails[0] || MISSING_CONTACT_VALUE };
    function selected(field: ContactField) {
      const supplement = addition && Object.hasOwn(addition.werte, field) ? addition.werte[field]! : MISSING_CONTACT_VALUE;
      const supplemented = !!addition && Object.hasOwn(addition.werte, field);
      return { original: sourceFields[field], supplement, value: supplemented ? supplement : sourceFields[field],
        origin: supplemented ? `${addition!.herkunft}: ${addition!.fundstelle}` : hasValue(sourceFields[field]) ? origin : MISSING_CONTACT_VALUE };
    }
    const tel = selected("telefon"), fax = selected("fax"), web = selected("web"), email = selected("email_1");
    const originalSecondaryName = block.names[1] || MISSING_CONTACT_VALUE;
    const addedSecondaryName = addition?.namenszusatz || MISSING_CONTACT_VALUE;
    const secondaryName = hasValue(addedSecondaryName) ? addedSecondaryName : originalSecondaryName;
    const secondaryOrigin = hasValue(addedSecondaryName) ? `${addition!.herkunft}: ${addition!.fundstelle}` : hasValue(originalSecondaryName) ? origin : MISSING_CONTACT_VALUE;
    const district = explicitDistrict(postal[2], block.street, sourceLine);
    const order = (localEntryCounts.get(parent.id) || 0) + 1; localEntryCounts.set(parent.id, order);
    const entryPath = `${parent.hierarchie_pfad}.${order}`;
    const notes = block.note ? [block.note] : [];
    for (const name of block.names) {
      const note = name.match(/\(([^)]+)\)\s*$/);
      if (note) notes.push(`Klammerzusatz im Namen: (${note[1]}) — Original bleibt erhalten`);
    }
    if (addition) notes.push("Ergänzungen ausschließlich nach expliziter Nutzerangabe, keine automatische Kontaktvererbung.");
    const missingSource = Object.entries(sourceFields).filter(([, value]) => !hasValue(value)).map(([key]) => key.replace("_1", "")).join(",") || MISSING_CONTACT_VALUE;
    const missingCurrent = [["telefon", tel.value], ["fax", fax.value], ["web", web.value], ["email", email.value]]
      .filter(([, value]) => !hasValue(value)).map(([key]) => key).join(",") || MISSING_CONTACT_VALUE;
    const contact: NormalizedContact = {
      kv_id: id, quellblock_id: id, region_id: region.id, ort_id: parent.typ === "ort" ? parent.id : MISSING_CONTACT_VALUE,
      parent_id: parent.id, hierarchie_pfad: entryPath, hierarchie_rolle: "einrichtung",
      hierarchie_herkunft: `MD-Gliederung + explizite Nutzerregeln; Parent: ${parent.herkunft}`,
      organisations_parent_id: addition?.organisations_parent_id || MISSING_CONTACT_VALUE,
      beziehungsherkunft: addition?.beziehungsherkunft || MISSING_CONTACT_VALUE,
      eintragsname_original: block.names[0], region_original: block.region.name, region_anzeige: region.name,
      ort_original: block.place.name, ort_anzeige: parent.typ === "ort" ? parent.name : MISSING_CONTACT_VALUE,
      name_haupt_original: block.names[0], name_zusatz_original: originalSecondaryName,
      name_zusatz_ergaenzung: addedSecondaryName, name_zusatz_normiert: secondaryName, name_zusatz_herkunft: secondaryOrigin,
      strasse_original: block.street || MISSING_CONTACT_VALUE, plz_ort_original: block.plzOrt, plz_normiert: postal[1],
      ort_normiert: district.place, ortsteil_original: district.district, ortsteil_normiert: district.district, ortsteil_herkunft: district.origin,
      telefon_original: tel.original, telefon_ergaenzung: tel.supplement,
      telefon_normiert: internationalContactPhone(tel.value), telefon_herkunft: tel.origin,
      fax_original: fax.original, fax_ergaenzung: fax.supplement, fax_normiert: hasValue(fax.value) ? digits(fax.value) : MISSING_CONTACT_VALUE, fax_herkunft: fax.origin,
      web_original: web.original, web_ergaenzung: web.supplement, web_normiert: hasValue(web.value) ? web.value.toLowerCase() : MISSING_CONTACT_VALUE, web_herkunft: web.origin,
      email_1_original: email.original, email_1_ergaenzung: email.supplement,
      email_1_normiert: hasValue(email.value) ? email.value.toLowerCase() : MISSING_CONTACT_VALUE, email_1_herkunft: email.origin,
      email_2_original: block.emails[1] || MISSING_CONTACT_VALUE, email_2_normiert: block.emails[1]?.toLowerCase() || MISSING_CONTACT_VALUE,
      nutzer_zitat: addition?.zitat || MISSING_CONTACT_VALUE, quelle_ergaenzung: addition?.fundstelle || MISSING_CONTACT_VALUE, chat_msg_id: MISSING_CONTACT_VALUE,
      hinweis: notes.join(" · ") || MISSING_CONTACT_VALUE, felder_fehlend_quelle: missingSource, felder_fehlend_arbeitsstand: missingCurrent,
      quellzeile: sourceLine, status_verifikation: "nicht_verifiziert", quelle_stand: sourceStand,
    };
    nodes.push({ id, parent_id: contact.parent_id, typ: "einrichtung", name: contact.name_haupt_original,
      name_original: contact.name_haupt_original, zusatzname: secondaryName, hierarchie_pfad: entryPath, quellzeile: sourceLine,
      herkunft: contact.hierarchie_herkunft, quellknoten_ids: id,
      quellvorkommen: [{ id, name: contact.name_haupt_original, quellzeile: sourceLine }] });
    return contact;
  });
  nodes.sort((a, b) => {
    const left = a.hierarchie_pfad.split(".").map(Number), right = b.hierarchie_pfad.split(".").map(Number);
    for (let index = 0; index < Math.max(left.length, right.length); index++) {
      if (left[index] === undefined) return -1;
      if (right[index] === undefined) return 1;
      if (left[index] !== right[index]) return left[index] - right[index];
    }
    return 0;
  });
  if (new Set(nodes.map((n) => n.id)).size !== nodes.length) throw new Error("Doppelte Struktur-ID.");
  for (const node of nodes) {
    if (node.parent_id !== MISSING_CONTACT_VALUE && !nodes.some((n) => n.id === node.parent_id)) throw new Error("Verwaister Strukturknoten.");
  }
  return { version: CONTACT_MODEL_VERSION, missingValue: MISSING_CONTACT_VALUE, nodes, contacts, sourceStand,
    counts: { rawBlocks: blocks.length, contacts: contacts.length, regions: nodes.filter((n) => n.typ === "region").length,
      groups: nodes.filter((n) => n.typ === "gruppe").length, places: nodes.filter((n) => n.typ === "ort").length,
      sourcePlaceHeadings: sourceNodes.filter((n) => n.typ === "ort").length, treeNodes: nodes.length,
      explicitDistricts: contacts.filter((c) => c.ortsteil_normiert !== MISSING_CONTACT_VALUE).length, supplementedContacts: additions.size } };
}
