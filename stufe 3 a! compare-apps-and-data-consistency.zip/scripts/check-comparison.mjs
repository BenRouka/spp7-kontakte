#!/usr/bin/env node
import assert from "node:assert/strict";
import { readFileSync } from "node:fs";
import { createRequire } from "node:module";
import { createHash } from "node:crypto";
import { unzipSync, strFromU8 } from "fflate";
import ts from "typescript";
const require = createRequire(import.meta.url), cache = new Map();
function load(file) {
  const resolved = file.startsWith("@/") ? `src/${file.slice(2)}.ts` : file;
  if (cache.has(resolved)) return cache.get(resolved).exports;
  const module = { exports: {} }; cache.set(resolved, module);
  const output = ts.transpileModule(readFileSync(resolved, "utf8"), { compilerOptions: { target: ts.ScriptTarget.ES2022, module: ts.ModuleKind.CommonJS, esModuleInterop: true } }).outputText;
  new Function("require", "module", "exports", output)((id) => id.startsWith("@/") ? load(id) : require(id), module, module.exports);
  return module.exports;
}
function csvRecords(text) {
  const rows = []; let row = [], cell = "", quoted = false;
  const input = text.replace(/^\uFEFF/, "");
  for (let index = 0; index < input.length; index++) {
    const char = input[index];
    if (quoted) { if (char === '"' && input[index + 1] === '"') { cell += '"'; index++; } else if (char === '"') quoted = false; else cell += char; }
    else if (char === '"') quoted = true;
    else if (char === ";") { row.push(cell); cell = ""; }
    else if (char === "\r" && input[index + 1] === "\n") { row.push(cell); rows.push(row); row = []; cell = ""; index++; }
    else cell += char;
  }
  assert.equal(quoted, false); if (cell || row.length) { row.push(cell); rows.push(row); }
  const headers = rows.shift(); return rows.map((values) => { assert.equal(values.length, headers.length); return Object.fromEntries(headers.map((header, index) => [header, values[index]])); });
}
const root = "werkstatt/03-berichte/";
const report = JSON.parse(readFileSync(root + "abgleich-01.json", "utf8"));
const workspace = JSON.parse(readFileSync("werkstatt/02-normiert/kontakte-struktur.json", "utf8"));
const references = csvRecords(readFileSync("werkstatt/02-normiert/suendenfrei-termine.csv", "utf8"));
const archive = unzipSync(readFileSync("werkstatt/01-roh/app-workflow-setup.zip"));
const datasets = JSON.parse(strFromU8(archive["public/data/spp7-datasets.json"])).datasets;
const messages = JSON.parse(strFromU8(archive["public/data/spp7-chat.json"])).messages;
const model = load("src/lib/comparison-model.ts");
const generated = model.buildComparisonReport(workspace, references, datasets, messages, report.inputFiles);
assert.deepEqual(report, generated, "Bericht ist nicht reproduzierbar");
assert.equal(report.contacts.length, 32); assert.equal(report.schedules.length, 54);
assert.deepEqual(report.summary.contacts.byStatus, { name_und_kanal: 20, nur_kanal: 12, nur_name: 0, kein_kandidat: 0 });
assert.equal(report.summary.schedules.datePlaceRows, 10);
assert.equal(report.summary.schedules.nameSupportedDatePlaceRows, 9);
assert.equal(report.summary.schedules.noDatePlaceRows, 44);
assert.equal(report.summary.schedules.openSourceRows, 2);
assert.equal(report.summary.schedules.matchedPeriodCount, 10);
assert.equal(report.summary.schedules.referencePeriodCount, 60);
assert.equal(report.findings.length, 65); assert.ok(report.findings.every((f) => f.decision === "offen"));
assert.equal(new Set(report.findings.map((f) => f.id)).size, report.findings.length);
assert.ok(report.issues.some((i) => i.id === "REL-feed_context-EVENT_ID" && i.evidence.includes("F29")));
assert.ok(report.issues.some((i) => i.id === "DATE-D113-D198" && i.kind === "gleicher_zeitraum_unterschiedliche_art"));
assert.ok(report.issues.some((i) => i.id === "KANAL-K09"));
const byContact = Object.fromEntries(report.contacts.map((r) => [r.id, r]));
assert.deepEqual(byContact.KV27.candidates.map((c) => c.id), ["K22", "K23", "K70"]);
assert.equal(byContact.KV10.status, "nur_kanal"); assert.equal(byContact.KV10.candidates[0].id, "K08");
assert.ok(byContact.KV09.candidates[0].sharedWith.includes("KV10"));
assert.equal(byContact.KV12.status, "nur_kanal"); assert.ok(byContact.KV12.candidates.some((c) => c.id === "K09" && c.channelEvidence.length === 0));
assert.ok(byContact.KV12.candidates.some((c) => c.id === "K10" && c.sharedWith.includes("KV13")));
assert.equal(byContact.KV17.status, "nur_kanal"); assert.equal(byContact.KV24.status, "nur_kanal");
const privateCandidate = byContact.KV24.candidates.find((c) => c.id === "K57");
assert.equal(privateCandidate.personal, true); assert.ok(privateCandidate.label.includes("ausgeblendet"));
assert.ok(privateCandidate.channel.includes("ausgeblendet"));
const bySchedule = Object.fromEntries(report.schedules.map((r) => [r.id, r]));
assert.deepEqual(report.schedules.filter((r) => r.status === "datum_ort").map((r) => r.id), ["SF03", "SF09", "SF10", "SF11", "SF15", "SF24", "SF35", "SF36", "SF37", "SF54"]);
assert.equal(bySchedule.SF37.candidates.find((c) => c.id === "S06").nameEvidence, " - ");
assert.equal(bySchedule.SF17.status, "quelle_offen"); assert.equal(bySchedule.SF38.status, "quelle_offen");
assert.equal(bySchedule.SF05.periods.length, 4); assert.equal(bySchedule.SF50.periods.length, 4);
assert.equal(bySchedule.SF03.candidates.find((c) => c.id === "M14").fields.find((f) => f.field === "Zeitfenster").result, "enthalten");
assert.ok(report.findings.find((f) => f.id === "T-KI").inventoryIds.includes("M14"));
for (const [name, data] of Object.entries(model.comparisonCsvReports(report))) {
  const expectedRows = name.includes("-kontakte") ? 32 : name.includes("-termine") ? 54 : name.includes("-entscheidungen") ? 65 : null;
  const records = csvRecords(readFileSync(root + name, "utf8"));
  if (expectedRows) assert.equal(records.length, expectedRows);
  assert.equal(readFileSync(root + name, "utf8"), data);
  assert.ok(records.every((r) => Object.values(r).every((v) => v !== "" && v !== "-")));
}
for (const evidence of report.inputFiles) assert.equal(createHash("sha256").update(readFileSync(evidence.path)).digest("hex"), evidence.sha256);
const json = JSON.stringify(report), markdown = readFileSync(root + "abgleich-01.md", "utf8");
assert.ok(report.unmatchedContacts.every((r) => r.label.includes("ausgeblendet")));
assert.ok(report.unmatchedEvents.every((r) => r.label.includes("ausgeblendet")));
assert.equal(json.includes("ludwig@extratours.live") || markdown.includes("ludwig@extratours.live"), false, "Nicht zugeordnete Chat-/Event-Kanalbezeichnung darf nicht veröffentlicht werden");
for (const contact of datasets.contacts.filter((r) => r.TYP === "Person")) {
  assert.equal(json.includes(contact.ORGANISATION) || markdown.includes(contact.ORGANISATION), false);
  if (contact.CONTACT_ID !== "K57") assert.equal(json.includes(contact.EMAIL_TELEFON) || markdown.includes(contact.EMAIL_TELEFON), false);
}

// Counterexamples: exact date with wrong place, post date, generic name, shared channel, Advent envelope.
const changedPlace = structuredClone(datasets);
changedPlace.events.find((e) => e.EVENT_ID === "S02").ORT = "Unbelegter Ort";
const placeResult = model.buildComparisonReport(workspace, references, changedPlace, messages, []);
assert.notEqual(placeResult.schedules.find((r) => r.id === "SF09").status, "datum_ort");
const changedKind = structuredClone(datasets);
changedKind.event_dates.find((r) => r.DATE_ID === "D105").ART = "Post-Datum";
assert.notEqual(model.buildComparisonReport(workspace, references, changedKind, messages, []).schedules.find((r) => r.id === "SF03").status, "datum_ort");
const changedChannel = structuredClone(datasets);
changedChannel.contacts.find((c) => c.CONTACT_ID === "K08").EMAIL_TELEFON = "abweichend@beispiel.invalid";
assert.equal(model.buildComparisonReport(workspace, references, changedChannel, messages, []).contacts.find((r) => r.id === "KV10").candidates.length, 0);
const fakeEvent = { ...datasets.events[0], EVENT_ID: "TEST_ADVENT", NAME: "Mittelalter-Advent", ORT: "Herne", PLZ: "44629" };
const adventReference = references.find((r) => r.sf_id === "SF50");
const singleEnvelope = structuredClone(datasets);
singleEnvelope.events.push(fakeEvent);
singleEnvelope.event_dates.push({ DATE_ID: "TEST_OUTER", EVENT_ID: fakeEvent.EVENT_ID, VON_ISO: adventReference.start_iso, BIS_ISO: adventReference.end_iso, ART: "Haupttermin" });
assert.notEqual(model.buildComparisonReport(workspace, references, singleEnvelope, messages, []).schedules.find((r) => r.id === "SF50").status, "datum_ort", "Outer envelope must not replace four weekends");
const splitDates = structuredClone(datasets); splitDates.events.push(fakeEvent);
for (const [index, period] of adventReference.zeitfenster_iso.split(";").entries()) {
  const [from, to] = period.split("/"); splitDates.event_dates.push({ DATE_ID: `TEST_WINDOW_${index}`, EVENT_ID: fakeEvent.EVENT_ID, VON_ISO: from, BIS_ISO: to, ART: "Haupttermin" });
}
assert.equal(model.buildComparisonReport(workspace, references, splitDates, messages, []).schedules.find((r) => r.id === "SF50").status, "datum_ort");
assert.deepEqual(report.contacts.map((r) => r.id), workspace.contacts.map((r) => r.kv_id));
assert.deepEqual(report.schedules.map((r) => r.id), references.map((r) => r.sf_id));
console.log("Abgleich unabhängig geprüft: 32 Kontakte / 54 Termine, 38 Kandidatenpaare, 10 Datum-/Ort-Hinweise und 65 offene Entscheidungspunkte.");
console.log("Feldstatus gleich/enthalten getrennt, Quellpointer und Prüfsummen korrekt, Personenwerte ausgeblendet.");
console.log("Gegenproben bestanden: falscher Ort, Post-/Fristdatum, gemeinsamer Kanal und Advent als durchgehender Zeitraum erzeugen keine falsche Identitätsentscheidung.");
