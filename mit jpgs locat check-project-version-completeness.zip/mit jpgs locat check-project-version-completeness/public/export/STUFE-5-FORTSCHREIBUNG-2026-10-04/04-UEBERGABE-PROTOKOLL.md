# Übergabeprotokoll · Fortschreibung Stufe 5 → Neuer Chat

**Stand:** 2026-10-04  
**Zweck:** Saubere Übergabe des Gesprächsstands in einen neuen Direct-Mode-Chat.  
**Grundlage:** Stufe-4-Freeze, Stufe-5-Handoff, Fortschreibung dieser Besprechungsrunde.

---

## 1. Was übergeben wird

| Artefakt | Pfad im ZIP | Status |
|---|---|---|
| Stufe-4-Freeze · Ground Truth | `public/export/FREEZE/` | byteidentisch, SHA-256 OK |
| Stufe-5-Handoff · Original | `public/export/STUFE-5-FREEZE-2026-10-04/` | byteidentisch, SHA-256 OK |
| Fortschreibung · Gesprächsstand | `public/export/STUFE-5-FORTSCHREIBUNG-2026-10-04/` | SHA-256 OK |
| Werkstatt-App · Code und Schema | `src/` | Build OK, TypeScript OK |
| Datenbank | nicht im ZIP | deterministisch aus Seed wiederherstellbar |

---

## 2. Was nicht übergeben wird

- Die Alt-App (liegt diesem Projekt nicht bei).
- Das Alt-App-ZIP mit `spp7-datasets.json`, D113/D196/D197/D198, K64/K73, Bildordner.
- Formelle Beschlüsse B-21 ff. (wurden im Chat fachlich bestätigt, aber nicht in DB oder Beschluss-CSV eingetragen).
- Geo-Daten, Bildquellen, JSON-Sync-Code — alle zurückgestellt.

---

## 3. Verbindliche Prüfsperren für den neuen Chat

Diese Punkte dürfen ohne erneute manuelle Freigabe **nicht** technisch umgesetzt werden:

1. **O-13 · B-SYNC:** Vor jeder Rückportierung Alt-App JSON-Sync prüfen, absichern und Regressionstest bestehen. Die Freigabe „ok, leg los" für Alt-App-Codearbeit wurde noch nicht erteilt.
2. **O-04 · Stolpen Datum:** Screenshot zeigt D196 als 08.–09.08.**2026**; frühere Formulierung nannte 08.08.**2027**. Jahresabweichung muss gegen den Alt-App-Originalbestand aufgelöst werden, bevor eine Zeile gelöscht wird.
3. **O-02 · MD-Vollständigkeit:** Erst prüfen, welche MD-Felder bereits in der DB vorhanden sind und ob eine Schemaänderung nötig wäre; danach separate Freigabe.
4. **B-SYNC vor allem anderen:** Ohne abgesicherten JSON-Sync keine Daten aus der Werkstatt in die Alt-App übertragen.

---

## 4. Anleitung für den neuen Direct-Mode-Chat

### Schritt 1 — ZIP hochladen
Das vollständige Projekt-ZIP hochladen, das du erstellt hast. Nicht nur den Exportordner — der vollständige Projektexport enthält den App-Code und alle Exportdateien.

### Schritt 2 — Erste Nachricht im neuen Chat

Kopiere den folgenden Block **als erste Nachricht** in den neuen Chat:

---

```
DIRECT-MODE-FORTSETZUNG · BITTE NICHT NEU RECHERCHIEREN

Lies zuerst vollständig in dieser Reihenfolge:
1. public/export/STUFE-5-FORTSCHREIBUNG-2026-10-04/00-HANDOFF-DIRECT-MODE.md
2. public/export/STUFE-5-FORTSCHREIBUNG-2026-10-04/01-ENTSCHEIDUNGSSTAND-13-PUNKTE.md
3. public/export/STUFE-5-FORTSCHREIBUNG-2026-10-04/02-AUDIT-UND-RESTPUNKTE.md
4. public/export/STUFE-5-FREEZE-2026-10-04/00-HANDOFF-DIRECT-MODE.md

Prüfe danach alle drei Manifeste:
1. public/export/STUFE-5-FORTSCHREIBUNG-2026-10-04/PRUEFSUMMEN.sha256
2. public/export/STUFE-5-FREEZE-2026-10-04/PRUEFSUMMEN.sha256
3. public/export/FREEZE/PRUEFSUMMEN.sha256

Verbindlicher Stand:
- Stufe 5 ist abgeschlossen. Werkstatt-DB: 9/35/54/60/20.
- 13 Ausgangsbefunde wurden in einem Gespräch fachlich durchgearbeitet.
- Die Ergebnisse stehen in 01-ENTSCHEIDUNGSSTAND-13-PUNKTE.md — keine davon ist in der Alt-App oder in formellen Beschlüssen technisch umgesetzt.
- Drei Prüfsperren gelten: O-13 JSON-Sync, O-04 Jahresabweichung Stolpen, O-02 MD-Vollständigkeit.
- Keine dieser Sperren darf ohne neue manuelle Freigabe aufgehoben werden.
- Prio 1 für Kontakte: MD/offizielle Quelle.
- Prio 1 für Termine: offizielle Website / sündenfrei.txt.
- Datenschutz B-17: nur intern weitergeben.

Nächster Schritt: Alt-App-ZIP bereitstellen.
Dann rein lesend: JSON-Sync in der Alt-App lokalisieren und Befund erklären.
Erst nach separater Freigabe "ok, leg los" Codearbeit beginnen.

Zunächst nur Integrität und Build prüfen. Status mit diesen Punkten zurückmelden:
1. Manifeste OK/abweichend
2. Build OK/fehlgeschlagen
3. Datenbankzahlen
4. Prüfsperren gelesen und verstanden: ja/nein
5. Keine Änderung ausgeführt
```

---

### Schritt 3 — Wiederanlauf der Datenbank

Falls die Datenbank im neuen Chat leer ist:

```bash
npx drizzle-kit push --force
npx tsx src/db/seed.ts
```

Erwartetes Ergebnis: `sha256 OK` für alle vier Freeze-Dateien, dann `regionen 9 · kontakte 35 · termine 54 · zeitfenster 60 · beschluesse 20`.

### Schritt 4 — Live-Verifikation

```
/api/import/verify
```

Erwartung: `ok: true`, alle Freeze-Hashes `match: true`, alle fünf Bestandszahlen `match: true`.

---

## 5. Was im neuen Chat als Erstes passiert — und was nicht

| Aktion | Erlaubt ohne Freigabe |
|---|---|
| Manifeste prüfen | ✅ ja |
| Build und Datenbank prüfen | ✅ ja |
| Handoff- und Fortschreibungs-Dokumente lesen | ✅ ja |
| Alt-App-ZIP hochladen und rein lesend analysieren | ✅ ja |
| JSON-Sync in Alt-App lokalisieren und beschreiben | ✅ ja (nur lesen) |
| Alt-App-Code ändern | ❌ erst nach „ok, leg los" |
| Daten aus Werkstatt in Alt-App rückportieren | ❌ erst nach bestandenem Regressionstest |
| Neue Beschlüsse B-21 ff. in DB eintragen | ❌ erst nach separater Freigabe |
| Schemaänderungen (O-02 MD-Vollständigkeit) | ❌ erst nach Feldabgleich und Freigabe |

---

## 6. Prüfstatus beim Freeze

- Next.js Typegen: bestanden
- TypeScript `tsc --noEmit`: bestanden (0 Fehler)
- Next.js Production Build: bestanden (7 Routen)
- Production Start / `/api/health`: OK
- `/api/import/verify`: `ok: true`, alle Hashes und Bestandszahlen match
- Alle drei SHA-256-Manifeste: OK

---

## 7. Datenschutz

Das Projekt-ZIP enthält E-Mail-Adressen und Kontaktdaten. Nur intern weitergeben. Nicht in ein öffentliches Repository, einen öffentlichen Chat oder einen frei zugänglichen Dateidienst hochladen. Eine ausgeblendete URL ist keine Zugriffskontrolle.

---

**Ende des Übergabeprotokolls.**
