"use client";

import { useEffect, useState } from "react";
import {
  AlertTriangle,
  Database,
  FileCheck2,
  Loader2,
  ShieldCheck,
} from "lucide-react";

interface FreezeRow {
  file: string;
  expected: string;
  actual: string;
  match: boolean;
}
interface DbRow {
  tabelle: string;
  erwartet: number;
  ist: number;
  match: boolean;
}
interface VerifyResponse {
  ok: boolean;
  checkedAt?: string;
  freeze?: FreezeRow[];
  db?: DbRow[];
  error?: string;
}

export function VerifyWidget() {
  const [state, setState] = useState<"loading" | "ready" | "error">("loading");
  const [data, setData] = useState<VerifyResponse | null>(null);

  useEffect(() => {
    let alive = true;
    fetch("/api/import/verify", { cache: "no-store" })
      .then((r) => r.json())
      .then((j: VerifyResponse) => {
        if (!alive) return;
        setData(j);
        setState(j.ok ? "ready" : "error");
      })
      .catch(() => {
        if (!alive) return;
        setState("error");
      });
    return () => {
      alive = false;
    };
  }, []);

  const dbOk = data?.db?.every((r) => r.match) ?? false;

  return (
    <div className="rounded-xl border border-line bg-raised/80 p-4">
      <div className="mb-3 flex items-center justify-between gap-3">
        <p className="flex items-center gap-1.5 font-mono text-[10px] font-semibold uppercase tracking-[0.18em] text-muted">
          <ShieldCheck className="h-3.5 w-3.5 text-lime" />
          Live-Verifikation · Freeze ↔ Datenbank
        </p>
        {state === "ready" && data?.ok ? (
          <span className="rounded-full border border-lime/35 bg-lime/10 px-2 py-0.5 font-mono text-[10px] uppercase tracking-[0.14em] text-lime">
            Alles konsistent
          </span>
        ) : null}
        {state === "error" ? (
          <span className="rounded-full border border-amber/35 bg-amber/10 px-2 py-0.5 font-mono text-[10px] uppercase tracking-[0.14em] text-amber">
            Abweichung
          </span>
        ) : null}
      </div>

      {state === "loading" ? (
        <p className="flex items-center gap-2 py-3 text-[12px] text-muted">
          <Loader2 className="h-3.5 w-3.5 animate-spin" />
          Prüfsummen werden neu berechnet, Tabellen gezählt …
        </p>
      ) : null}

      {state !== "loading" && data?.freeze ? (
        <div className="space-y-4">
          <ul className="space-y-1.5">
            {data.freeze.map((r) => (
              <li
                key={r.file}
                className="flex items-center justify-between gap-3 rounded-lg border border-line-soft bg-raised2/60 px-2.5 py-1.5"
              >
                <span className="flex min-w-0 items-center gap-2">
                  {r.match ? (
                    <FileCheck2 className="h-3.5 w-3.5 shrink-0 text-lime" />
                  ) : (
                    <AlertTriangle className="h-3.5 w-3.5 shrink-0 text-amber" />
                  )}
                  <span className="truncate font-mono text-[11.5px] text-ink-soft">
                    {r.file}
                  </span>
                </span>
                <span className="flex items-center gap-2">
                  <span className="hidden font-mono text-[10px] text-muted sm:inline">
                    {r.actual.slice(0, 12) || "—"}…
                  </span>
                  <span
                    className={
                      r.match
                        ? "font-mono text-[10px] font-semibold uppercase text-lime"
                        : "font-mono text-[10px] font-semibold uppercase text-amber"
                    }
                  >
                    {r.match ? "sha256 OK" : "FAIL"}
                  </span>
                </span>
              </li>
            ))}
          </ul>

          <div>
            <p className="mb-2 flex items-center gap-1.5 font-mono text-[10px] font-semibold uppercase tracking-[0.18em] text-muted">
              <Database className="h-3.5 w-3.5 text-lime" />
              Tabellenbestand
              {dbOk ? (
                <span className="text-lime/80 normal-case tracking-normal">
                  · erwartet = Ist
                </span>
              ) : null}
            </p>
            <ul className="grid grid-cols-2 gap-1.5 sm:grid-cols-5">
              {data.db?.map((r) => (
                <li
                  key={r.tabelle}
                  className="rounded-lg border border-line-soft bg-raised2/60 px-2.5 py-2"
                >
                  <p className="truncate font-mono text-[9.5px] uppercase tracking-[0.1em] text-muted">
                    {r.tabelle}
                  </p>
                  <p
                    className={
                      r.match
                        ? "tnum mt-0.5 text-[15px] font-medium text-ink"
                        : "tnum mt-0.5 text-[15px] font-medium text-amber"
                    }
                  >
                    {r.ist}
                    <span className="text-muted/70"> / {r.erwartet}</span>
                  </p>
                </li>
              ))}
            </ul>
          </div>
        </div>
      ) : null}

      {state === "error" && !data?.freeze ? (
        <p className="py-1 text-[12px] text-amber">
          Verifikation nicht erreichbar — Freeze bleibt unverändert, Import
          ruht.
        </p>
      ) : null}
    </div>
  );
}
