"use client";

import { useEffect, useState } from "react";
import { shortRange } from "@/lib/calendar-model";
import type { OptionBAlignment } from "@/lib/option-b-contract";
import { Icon } from "@/components/icons";

export function AlignmentDetails({ modelVersion }: { modelVersion: string }) {
  const [summary, setSummary] = useState<OptionBAlignment | null>(null);
  const [error, setError] = useState("");
  const [attempt, setAttempt] = useState(0);

  useEffect(() => {
    const controller = new AbortController();
    setSummary(null);
    setError("");

    async function readAlignment() {
      try {
        const response = await fetch("/api/review/option-b", {
          cache: "no-store",
          signal: controller.signal,
        });
        if (!response.ok) throw new Error("Das gespeicherte Option-B-Paket konnte nicht geprüft werden.");
        const result = await response.json() as OptionBAlignment;
        if (!controller.signal.aborted) setSummary(result);
      } catch {
        if (!controller.signal.aborted) {
          setError("Der Paket-Abgleich ist derzeit nicht verfügbar. Es wurde kein Import ausgeführt.");
        }
      }
    }

    readAlignment();
    return () => controller.abort();
  }, [modelVersion, attempt]);

  if (error) {
    return (
      <div className="dialog-warning" role="alert">
        <Icon name="info" size={18} />
        <div>
          <p>{error}</p>
          <button className="text-button alignment-retry" onClick={() => setAttempt((value) => value + 1)}>
            Erneut prüfen <Icon name="arrowRight" size={14} />
          </button>
        </div>
      </div>
    );
  }

  if (!summary) {
    return (
      <p className="alignment-loading" role="status">
        Gespeichertes Option-B-Paket wird mit der aktuellen Prüfansicht verglichen …
      </p>
    );
  }

  const aligned = summary.aligned && summary.modelVersion === modelVersion;

  return (
    <>
      <div className={aligned ? "dialog-info" : "dialog-warning"} role="status">
        <Icon name={aligned ? "checkCircle" : "info"} size={21} />
        <span>
          <b>{aligned ? "Gleicher Zeitmodell-Stand im Option-B-Paket." : "Der gespeicherte Option-B-Stand weicht ab."}</b>
          <br />
          <code className="alignment-version">{summary.modelVersion}</code>
        </span>
      </div>

      <p className="alignment-intro">
        Option A bleibt die gewählte Oberfläche. Die folgende Prüfung bezieht sich auf die{" "}
        <b>aktualisierte lokale Werkstatt-Kopie von Option B</b>, nicht auf eine andere Arena-Instanz.
      </p>

      <div className="calculation-table">
        {summary.checks.map((check) => (
          <div className="alignment-case" key={check.id}>
            <b className="alignment-case-label">{check.label}</b>
            <span className={`alignment-case-status ${check.matches ? "is-matched" : "is-mismatched"}`}>
              <Icon name={check.matches ? "check" : "info"} size={14} />
              {check.matches ? "A / B identisch" : "Abweichung"}
            </span>
            <code className="alignment-periods">
              {check.optionA.periods.map(shortRange).join(" · ")} {check.year}
            </code>
            <small className="alignment-source-status">
              {check.optionA.dateOrigin} · {check.optionA.uncertain
                ? "unbestätigt (*)"
                : "ohne Sternchen, nicht automatisch bestätigt"}
            </small>
          </div>
        ))}
      </div>

      <dl className="inventory-detail">
        <div>
          <dt>Gemeinsame Code-Dateien</dt>
          <dd>{summary.sharedFiles.filter((file) => file.matches).length} / {summary.sharedFiles.length} identisch</dd>
        </div>
        <div>
          <dt>Original-MD / TXT</dt>
          <dd>{summary.originalSourcesPreserved ? "bytegleich" : "Abweichung"}</dd>
        </div>
        <div>
          <dt>Datenbank / Schema</dt>
          <dd>nicht verändert</dd>
        </div>
      </dl>

      {aligned && (
        <div className="alignment-downloads">
          <a className="primary-button" href={summary.downloads.zip}>
            <Icon name="download" size={16} /> Option B · ZIP herunterladen
          </a>
          <a className="secondary-button" href={summary.downloads.report}>
            <Icon name="file" size={16} /> A/B-Prüfbericht
          </a>
        </div>
      )}

      <div className="dialog-warning">
        <Icon name="info" size={18} />
        <span>
          Der alte Handoff ist überholt und im Paket historisch archiviert. <b>GitHub und eine separate
          Arena-Variante wurden hier nicht direkt verändert.</b> Das Paket enthält keinen privaten
          Chat-Export und keine Zugangsdaten.
        </span>
      </div>

      <p className="dialog-fineprint">
        Kirchenregel präzisiert: Wenn Weihnachten auf einen Sonntag fällt, ist der 4. Advent am
        18. Dezember. Die bestätigten Termine 2026 und 2027 bleiben davon unberührt.
      </p>
    </>
  );
}
