import { createHash } from "node:crypto";
import { readFileSync } from "node:fs";
import path from "node:path";

/* ------------------------------------------------------------------ */
/* Freeze-Paket (Stufe 4) — byteidentisch unter public/export/FREEZE   */
/* Integrität über PRUEFSUMMEN.sha256. Die Dateien sind Ground Truth:  */
/* Prio 1 gilt, Prio 2 ergänzt, Platzhalter sind bereits entfernt.     */
/* ------------------------------------------------------------------ */

export const FREEZE_DIR = path.join(
  process.cwd(),
  "public",
  "export",
  "FREEZE",
);

export const FREEZE_FILES = [
  "HANDOFF.md",
  "arbeitsstand-kontakte.csv",
  "arbeitsstand-termine.csv",
  "beschlussverzeichnis.csv",
] as const;

export function readFreeze(name: string): string {
  return readFileSync(path.join(FREEZE_DIR, name), "utf8");
}

export function sha256OfFile(name: string): string {
  return createHash("sha256")
    .update(readFileSync(path.join(FREEZE_DIR, name)))
    .digest("hex");
}

/** Regionenreihenfolge laut HANDOFF §3 — verbindlich, Übergreifend zuerst. */
export const REGION_ORDER = [
  "Übergreifend",
  "Rund um die Granitz",
  "Halbinsel Mönchgut",
  "Halbinsel Jasmund",
  "Halbinsel Wittow",
  "Nord-West-Rügen",
  "Süd-Rügen",
  "Zentralrügen",
  "Seebad Insel Hiddensee",
] as const;

/* ------------------------------------------------------------------ */
/* Prüfsummen-Manifest                                                  */
/* ------------------------------------------------------------------ */

export interface Pruefsumme {
  file: string;
  hash: string;
}

export function parsePruefsummen(text: string): Pruefsumme[] {
  return text
    .trimEnd()
    .split(/\r?\n/)
    .filter((l) => l.trim().length > 0)
    .map((l) => {
      const m = l.match(/^([0-9a-f]{64})\s+(.+)$/);
      return { hash: m?.[1] ?? "", file: m?.[2] ?? l };
    });
}

/** Verifikation der Freeze-Dateien gegen das Manifest (Integritäts-Gate). */
export function verifyFreeze(): {
  ok: boolean;
  rows: { file: string; expected: string; actual: string; match: boolean }[];
} {
  const expected = parsePruefsummen(readFreeze("PRUEFSUMMEN.sha256"));
  const rows = expected.map(({ file, hash }) => {
    let actual = "";
    try {
      actual = sha256OfFile(file);
    } catch {
      actual = "";
    }
    return { file, expected: hash, actual, match: actual === hash };
  });
  return { ok: rows.every((r) => r.match), rows };
}

/* ------------------------------------------------------------------ */
/* Kontakte                                                            */
/* ------------------------------------------------------------------ */

export interface KontaktRow {
  felder: number;
  kvId: string;
  region: string;
  ort: string;
  name: string;
  anschrift: string;
  telefon: string;
  fax: string;
  email1: string;
  email2: string;
  email3: string;
  web: string;
  typ: string;
  hinweis: string;
}

export function parseKontakte(csv: string): KontaktRow[] {
  const lines = csv.trimEnd().split(/\r?\n/);
  return lines
    .slice(1)
    .filter((l) => l.trim().length > 0)
    .map((l) => {
      const p = l.split(";");
      const last = p.length - 1;
      // Kopf hat 13 Felder. Dateibefund: STADT-PUTBUS hat 14 Felder —
      // typ/hinweis werden endbündig gelesen, die Rohzeile bleibt im
      // Freeze unverändert (dokumentierte Abweichung).
      return {
        felder: p.length,
        kvId: p[0] ?? "",
        region: p[1] ?? "",
        ort: p[2] ?? "",
        name: p[3] ?? "",
        anschrift: p[4] ?? "",
        telefon: p[5] ?? "",
        fax: p[6] ?? "",
        email1: p[7] ?? "",
        email2: p[8] ?? "",
        email3: p[9] ?? "",
        web: p[10] ?? "",
        typ: p.length === 13 ? (p[11] ?? "") : (p[last - 1] ?? ""),
        hinweis: p[last] ?? "",
      };
    });
}

export const hatMdBlock = (r: KontaktRow) => !r.hinweis.includes("Kein MD-Block");

export interface KontaktStats {
  datensaetze: number;
  kvGekennzeichnet: number;
  sonderdatensaetze: number;
  email1: number;
  email2: number;
  email3: number;
  regionen: number;
  orte: number;
}

export function kontaktStats(rows: KontaktRow[]): KontaktStats {
  return {
    datensaetze: rows.length,
    kvGekennzeichnet: rows.filter((r) => r.kvId.startsWith("KV")).length,
    sonderdatensaetze: rows.filter((r) => !r.kvId.startsWith("KV")).length,
    email1: rows.filter((r) => r.email1 !== "").length,
    email2: rows.filter((r) => r.email2 !== "").length,
    email3: rows.filter((r) => r.email3 !== "").length,
    regionen: new Set(rows.map((r) => r.region)).size,
    orte: new Set(rows.map((r) => r.ort)).size,
  };
}

/* ------------------------------------------------------------------ */
/* Termine                                                             */
/* ------------------------------------------------------------------ */

export interface Zeitfenster {
  nr: number;
  von: string;
  bis: string;
  raw: string;
}

export interface TerminRow {
  sfId: string;
  jahr: string;
  datumOriginal: string;
  name: string;
  plzOrt: string;
  anzahl: number;
  fenster: Zeitfenster[];
  sternchen: string;
  hinweis: string;
}

export function parseTermine(csv: string): TerminRow[] {
  const lines = csv.trimEnd().split(/\r?\n/);
  return lines
    .slice(1)
    .filter((l) => l.trim().length > 0)
    .map((l) => {
      const p = l.split(";");
      const anzahl = Number.parseInt(p[5] ?? "1", 10);
      const fensterRaw = p.slice(6, 6 + anzahl);
      return {
        sfId: p[0] ?? "",
        jahr: p[1] ?? "",
        datumOriginal: p[2] ?? "",
        name: p[3] ?? "",
        plzOrt: p[4] ?? "",
        anzahl,
        fenster: fensterRaw.map((raw, i) => {
          const [von, bis] = raw.split("/");
          return { nr: i + 1, von: von ?? "", bis: bis ?? "", raw };
        }),
        sternchen: p[6 + anzahl] ?? "",
        hinweis: p
          .slice(7 + anzahl)
          .join(";")
          .trim(),
      };
    });
}

export interface TerminStats {
  quellzeilen: number;
  zeitfenster: number;
  sichtbareZeilen: number;
  stern1: number;
  stern2: number;
  mehrfach: number;
}

export function terminStats(rows: TerminRow[], jahr: string): TerminStats {
  const r = rows.filter((x) => x.jahr === jahr);
  return {
    quellzeilen: r.length,
    zeitfenster: r.reduce((s, x) => s + x.anzahl, 0),
    // Sichtbare Zeilen = Haupteinträge + je Advent-Unterzeile (B-12)
    sichtbareZeilen: r.reduce(
      (s, x) => s + (x.anzahl > 1 ? 1 + x.anzahl : 1),
      0,
    ),
    stern1: r.filter((x) => x.sternchen === "*").length,
    stern2: r.filter((x) => x.sternchen === "**").length,
    mehrfach: r.filter((x) => x.anzahl > 1).length,
  };
}

/* ------------------------------------------------------------------ */
/* Beschlüsse                                                          */
/* ------------------------------------------------------------------ */

export interface BeschlussRow {
  id: string;
  bereich: string;
  titel: string;
  prio1: string;
  prio2: string;
  massnahme: string;
  status: string;
}

export function parseBeschluesse(csv: string): BeschlussRow[] {
  const lines = csv.trimEnd().split(/\r?\n/);
  return lines
    .slice(1)
    .filter((l) => l.trim().length > 0)
    .map((l) => {
      const p = l.split(";");
      return {
        id: p[0] ?? "",
        bereich: p[1] ?? "",
        titel: p[2] ?? "",
        prio1: p[3] ?? "",
        prio2: p[4] ?? "",
        massnahme: p[5] ?? "",
        status: p
          .slice(6)
          .join(";")
          .trim(),
      };
    });
}

export const BESCHLUSS_BEREICH_ORDER = [
  "Kontakte",
  "Termine",
  "Archiv",
  "Ablauf",
  "Offen",
] as const;

/* ------------------------------------------------------------------ */
/* Aggregat — liest das komplette Freeze-Paket                          */
/* ------------------------------------------------------------------ */

export function loadFreeze() {
  const kontakteCsv = readFreeze("arbeitsstand-kontakte.csv");
  const termineCsv = readFreeze("arbeitsstand-termine.csv");
  const beschluesseCsv = readFreeze("beschlussverzeichnis.csv");
  return {
    handoff: readFreeze("HANDOFF.md"),
    kontakte: parseKontakte(kontakteCsv),
    termine: parseTermine(termineCsv),
    beschluesse: parseBeschluesse(beschluesseCsv),
    pruefsummen: parsePruefsummen(readFreeze("PRUEFSUMMEN.sha256")),
  };
}

/* ------------------------------------------------------------------ */
/* Deutsche Datumsformatierung — deterministisch (kein ICU nötig)       */
/* ------------------------------------------------------------------ */

const WT = ["So", "Mo", "Di", "Mi", "Do", "Fr", "Sa"] as const;
export const MONATE = [
  "Januar",
  "Februar",
  "März",
  "April",
  "Mai",
  "Juni",
  "Juli",
  "August",
  "September",
  "Oktober",
  "November",
  "Dezember",
] as const;

export function parseIso(iso: string) {
  const [y, m, d] = iso.split("-").map((s) => Number.parseInt(s, 10));
  return { y, m, d, date: new Date(Date.UTC(y, m - 1, d)) };
}

/** "Do 26.11.26" */
export function fmtTag(iso: string): string {
  const { y, m, d, date } = parseIso(iso);
  const yy = String(y).slice(2);
  return `${WT[date.getUTCDay()]} ${String(d).padStart(2, "0")}.${String(m).padStart(2, "0")}.${yy}`;
}

/** "26.11.2026" */
export function fmtDatum(iso: string): string {
  const { y, m, d } = parseIso(iso);
  return `${String(d).padStart(2, "0")}.${String(m).padStart(2, "0")}.${y}`;
}

/** "November 2026" */
export function fmtMonat(iso: string): string {
  const { y, m } = parseIso(iso);
  return `${MONATE[m - 1]} ${y}`;
}

/** Schlusssel "2026-11" für Monatsgruppierung */
export function monatKey(iso: string): string {
  const { y, m } = parseIso(iso);
  return `${y}-${String(m).padStart(2, "0")}`;
}

/** Dauer in Kalendertagen (inkl.) */
export function tageZwischen(von: string, bis: string): number {
  const a = parseIso(von).date.getTime();
  const b = parseIso(bis).date.getTime();
  return Math.round((b - a) / 86_400_000) + 1;
}
