import Link from "next/link";
import { ArrowLeft, Music2 } from "lucide-react";
import { Badge, Card, Empty, SectionHead } from "@/components/ui";
import { getActListe } from "@/lib/altbestand";

export const dynamic = "force-dynamic";

export default async function ActsPage({
  searchParams,
}: {
  searchParams: Promise<{ q?: string }>;
}) {
  const sp = await searchParams;
  const suche = sp.q ?? "";
  const acts = await getActListe(suche);

  return (
    <div className="space-y-8">
      <Link
        href="/archiv"
        className="inline-flex items-center gap-1.5 font-mono text-[11px] uppercase tracking-[0.14em] text-muted transition-colors hover:text-lime"
      >
        <ArrowLeft className="h-3.5 w-3.5" /> Archiv
      </Link>

      <SectionHead
        eyebrow="Altbestand · Band-Sicht"
        title={
          <>
            Bands & Acts
            <span className="block text-[14px] font-normal leading-snug text-muted">
              Von der Band aus gedacht: welche Festivals, welche Rolle, welche
              Chat-Belege.
            </span>
          </>
        }
        right={
          <form action="/archiv/acts">
            <input
              name="q"
              defaultValue={suche}
              placeholder="Band suchen …"
              className="w-56 rounded-full border border-line bg-raised px-4 py-1.5 text-[12px] text-ink outline-none placeholder:text-muted/60 focus:border-lime/40"
            />
          </form>
        }
      />

      <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
        {acts.map((a) => (
          <Link key={a.actId} href={`/archiv/acts/${a.actId}`}>
            <Card lift className="h-full p-4 transition-colors hover:border-lime/35">
              <div className="flex items-start justify-between gap-3">
                <div className="min-w-0">
                  <p className="truncate text-[13px] font-medium text-ink">
                    {a.name}
                  </p>
                  <p className="mt-1 font-mono text-[10px] uppercase tracking-[0.12em] text-muted">
                    {a.actId}
                  </p>
                </div>
                <Badge tone={a.verknuepft > 1 ? "lime" : "neutral"}>
                  <Music2 className="h-2.5 w-2.5" />
                  {a.verknuepft}
                </Badge>
              </div>
              {a.rollen ? (
                <p className="mt-2 line-clamp-2 text-[11px] leading-snug text-muted">
                  {a.rollen}
                </p>
              ) : null}
            </Card>
          </Link>
        ))}
        {acts.length === 0 ? (
          <Card className="p-8 text-center sm:col-span-2 lg:col-span-3">
            <Empty>keine Treffer</Empty>
          </Card>
        ) : null}
      </div>
      <p className="font-mono text-[11px] text-muted">
        {acts.length} Acts · Prio 2 · Altbestand, nicht kuratiert
      </p>
    </div>
  );
}
