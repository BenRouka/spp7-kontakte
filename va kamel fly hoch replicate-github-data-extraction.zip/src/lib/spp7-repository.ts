import "server-only";

import { readFile } from "node:fs/promises";
import path from "node:path";
import { db } from "@/db";
import { spp7Contacts, spp7Events, spp7FlyerSources } from "@/db/schema";
import { count, desc, sql } from "drizzle-orm";

type ExportRecord = Record<string, string>;
type ArchiveData = {
  datasets: {
    events: ExportRecord[];
    contacts: ExportRecord[];
    flyer_sources: ExportRecord[];
  };
};

function optional(value?: string) {
  const clean = value?.trim();
  return clean ? clean : null;
}

function coordinate(value?: string) {
  if (!value?.trim()) return null;
  const parsed = Number(value.replace(",", "."));
  return Number.isFinite(parsed) ? parsed : null;
}

function rank(value?: string) {
  if (!value?.trim()) return null;
  const match = value.match(/\d+/);
  return match ? Number(match[0]) : null;
}

async function readArchive(): Promise<ArchiveData> {
  const dataPath = path.join(process.cwd(), "public", "data", "spp7-datasets.json");
  return JSON.parse(await readFile(dataPath, "utf8")) as ArchiveData;
}

async function seedArchive() {
  const archive = await readArchive();
  const [contactCount, flyerSourceCount] = await Promise.all([
    db.select({ total: count() }).from(spp7Contacts),
    db.select({ total: count() }).from(spp7FlyerSources),
  ]);
  const contactTotal = contactCount[0].total;
  const flyerTotal = flyerSourceCount[0].total;

  const eventRows = archive.datasets.events.map((record) => ({
    eventId: record.EVENT_ID,
    sourceType: record.QUELLE_TYP || "Unbekannt",
    flyer: optional(record.FLYER),
    message: optional(record.MSG),
    type: record.TYP || "Event",
    name: record.NAME || "Ohne Namen",
    location: optional(record.LOCATION),
    street: optional(record.STRASSE),
    postalCode: optional(record.PLZ),
    city: optional(record.ORT),
    region: optional(record.REGION),
    country: optional(record.LAND),
    latitude: coordinate(record.LAT),
    longitude: coordinate(record.LNG),
    geoStatus: optional(record.GEO_STATUS),
    admission: optional(record.EINTRITT),
    fee: optional(record.GAGE),
    conditions: optional(record.KONDITIONEN),
    application: optional(record.BEWERBUNG),
    applicationStatus: record.BEWERBUNG_STATUS || "unklar",
    applicationStatusBasis: optional(record.BEWERBUNG_STATUS_BASIS),
    aiRank: rank(record.KI_RANG),
    tags: optional(record.TAGS),
    shortDescription: optional(record.KURZBESCHREIBUNG),
    longDescription: optional(record.LANGBESCHREIBUNG),
    fit: optional(record.PASSUNG_SPP7),
    nextStep: optional(record.NAECHSTER_SCHRITT),
    unknown: optional(record.UNKLAR),
    source: optional(record.QUELLE),
  }));

  // Refresh only the explicitly classified application state. Event facts are
  // not overwritten when an event already exists in PostgreSQL.
  await db.insert(spp7Events).values(eventRows).onConflictDoUpdate({
    target: spp7Events.eventId,
    set: {
      applicationStatus: sql`excluded.application_status`,
      applicationStatusBasis: sql`excluded.application_status_basis`,
    },
  });

  if (contactTotal < archive.datasets.contacts.length) {
    const rows = archive.datasets.contacts.map((record) => ({
      contactId: record.CONTACT_ID,
      organisation: record.ORGANISATION || "Ohne Organisation",
      type: optional(record.TYP),
      channel: optional(record.EMAIL_TELEFON),
      city: optional(record.ORT),
      region: optional(record.REGION),
      latitude: coordinate(record.LAT),
      longitude: coordinate(record.LNG),
      message: optional(record.MSG),
      note: optional(record.NOTIZ),
    }));

    await db.insert(spp7Contacts).values(rows).onConflictDoNothing();
  }

  if (flyerTotal < archive.datasets.flyer_sources.length) {
    const rows = archive.datasets.flyer_sources.map((record) => ({
      flyerId: record.FLYER_ID,
      flyerNumber: Number(record.FLYER),
      messageId: record.MSG,
      sourceFile: record.SOURCE_FILE,
      sourceDate: optional(record.SOURCE_DATE),
      thumbnailUrl: optional(record.THUMB_URL),
      sourceStatus: record.SOURCE_STATUS,
      sourceKind: record.SOURCE_KIND,
      eventId: optional(record.EVENT_ID),
      name: optional(record.NAME),
      performance: optional(record.PERFORMANCE),
      provider: optional(record.PROVIDER),
      location: optional(record.LOCATION),
      dateText: optional(record.DATE_TEXT),
      freeSlots: optional(record.FREE_SLOTS),
      actsSought: optional(record.ACTS_SOUGHT),
      genres: optional(record.GENRES),
      excludedGenres: optional(record.EXCLUDED_GENRES),
      fee: optional(record.FEE),
      costs: optional(record.COSTS),
      posted: optional(record.POSTED),
      applicationStatus: record.APPLICATION_STATUS || "unklar",
      applicationStatusBasis: optional(record.STATUS_BASIS),
      reviewStatus: record.REVIEW_STATUS,
      ocrConfidence: coordinate(record.OCR_CONFIDENCE),
      ocrText: optional(record.OCR_TEXT),
    }));

    await db.insert(spp7FlyerSources).values(rows).onConflictDoNothing();
  }
}

export type Spp7Overview = {
  eventCount: number;
  contactCount: number;
  geocodedCount: number;
  openApplicationCount: number;
  unclearApplicationCount: number;
  closedApplicationCount: number;
  bookingRequestCount: number;
  flyerSourceCount: number;
  featuredEvents: Array<{
    eventId: string;
    name: string;
    city: string | null;
    type: string;
    fit: string | null;
  }>;
};

export async function getSpp7Overview(): Promise<Spp7Overview> {
  await seedArchive();

  const [
    eventResult,
    contactResult,
    geoResult,
    confirmedApplicationResult,
    unclearApplicationResult,
    closedApplicationResult,
    bookingRequestResult,
    flyerSourceResult,
    featuredEvents,
  ] = await Promise.all([
    db.select({ total: count() }).from(spp7Events),
    db.select({ total: count() }).from(spp7Contacts),
    db
      .select({ total: count() })
      .from(spp7Events)
      .where(sql`${spp7Events.latitude} is not null and ${spp7Events.longitude} is not null`),
    db
      .select({ total: count() })
      .from(spp7Events)
      .where(sql`${spp7Events.application} is not null and ${spp7Events.applicationStatus} = 'bestätigt'`),
    db
      .select({ total: count() })
      .from(spp7Events)
      .where(sql`${spp7Events.application} is not null and ${spp7Events.applicationStatus} = 'unklar'`),
    db
      .select({ total: count() })
      .from(spp7Events)
      .where(sql`${spp7Events.application} is not null and ${spp7Events.applicationStatus} = 'geschlossen'`),
    db
      .select({ total: count() })
      .from(spp7FlyerSources)
      .where(sql`${spp7FlyerSources.sourceKind} = 'booking_listing'`),
    db.select({ total: count() }).from(spp7FlyerSources),
    db
      .select({
        eventId: spp7Events.eventId,
        name: spp7Events.name,
        city: spp7Events.city,
        type: spp7Events.type,
        fit: spp7Events.fit,
      })
      .from(spp7Events)
      .orderBy(desc(spp7Events.aiRank), spp7Events.eventId)
      .limit(6),
  ]);

  return {
    eventCount: eventResult[0].total,
    contactCount: contactResult[0].total,
    geocodedCount: geoResult[0].total,
    openApplicationCount: confirmedApplicationResult[0].total,
    unclearApplicationCount: unclearApplicationResult[0].total,
    closedApplicationCount: closedApplicationResult[0].total,
    bookingRequestCount: bookingRequestResult[0].total,
    flyerSourceCount: flyerSourceResult[0].total,
    featuredEvents,
  };
}