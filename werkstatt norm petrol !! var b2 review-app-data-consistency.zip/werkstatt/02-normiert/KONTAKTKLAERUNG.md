# Kontaktklärung · Parent/Child und Nutzerergänzungen

Stand: kontaktklaerung-v2. Vier Beispielstandorte, keine vollständige Stufe-2-Normierung und keine Datenbankänderung.

Original-MD: Kurverwaltungen_2025.md · SHA-256 28512c72423ac270d4c423007b29dc85266e6938441d830bf0ec8a3239c1bfa1.
Die Originalquelle behält 32 Blöcke und 119 Kontaktwerte. Mit drei ausdrücklich ergänzten Werten sind 122 Kontaktwerte belegt.

## Regeln

- Parents sind Standortgruppen aus Nutzervorgabe; getrennte Adressen/Außenstellen bleiben getrennte Child-Datensätze.
- Zwei Namen an derselben Adresse allein begründen keine neue Außenstelle. Die vier originalen Doppel-Namensblöcke bleiben als Quellenbefund bestehen.
- Kein automatisches Erben von E-Mail, Telefon, Website oder Fax. Baabes Infopavillion bekommt nicht die E-Mail der Kurverwaltung.
- Fehlende Werte werden als - angezeigt; intern null plus Fehlstatus. Originalfelder werden nicht mit einem erfundenen Strich überschrieben.
- Zusätzliche +49-Form ist für die deutsche/Rügen-Quelle freigegeben. Original bleibt erhalten; die Umrechnung ist keine Erreichbarkeitsprüfung.
- www-Adressen werden nicht stillschweigend um http:// oder https:// ergänzt.

## 1 · Ostseebad Mönchgut (KVG01)

Parent-Herkunft: ausdrückliche Nutzerzuordnung.

### 1.1 · Kurverwaltung Mönchgut (KV12)

Zusatzname: Tourist-Information Middelhagen
Adresse: Dorfstraße 4 · 18586 Ostseebad Mönchgut OT Middelhagen
MD-Quelle: Zeilen 107–112.

| Feld | Aktueller Wert | MD-Wert | Herkunft / Status | Internationale Telefonform |
|---|---|---|---|---|
| internet | www.ostseebad-moenchgut.de | - (nicht angegeben) | nutzer-kontaktklaerung-01; nutzerangabe | - |
| email | info@ostseebad-moenchgut.de | - (nicht angegeben) | nutzer-kontaktklaerung-01; nutzerangabe | - |
| telefon | (03 83 08) 6 60 10 | (03 83 08) 6 60 10 | Kurverwaltungen_2025.md:L111; aus_md | +49 38308 66010 |
| fax | (03 83 08) 6 60 110 | (03 83 08) 6 60 110 | Kurverwaltungen_2025.md:L112; aus_md | - |

### 1.2 · Tourist-Information Thiessow (Außenstelle) (KV13)

Zusatzname: -
Adresse: Hauptstraße 36 · 18586 Ostseebad Mönchgut OT Thiessow
MD-Quelle: Zeilen 114–118.

| Feld | Aktueller Wert | MD-Wert | Herkunft / Status | Internationale Telefonform |
|---|---|---|---|---|
| internet | www.ostseebad-moenchgut.de | www.ostseebad-moenchgut.de | Kurverwaltungen_2025.md:L117; aus_md | - |
| email | info@ostseebad-moenchgut.de | info@ostseebad-moenchgut.de | Kurverwaltungen_2025.md:L118; aus_md | - |
| telefon | +49 38308 66010 | - (nicht angegeben) | nutzer-kontaktklaerung-01; nutzerangabe | +49 38308 66010 |
| fax | - | - (nicht angegeben) | nutzer-kontaktklaerung-01; fehlt_laut_nutzer | - |

## 2 · Ostseebad Baabe (KVG02)

Parent-Herkunft: ausdrückliche Nutzerzuordnung.

### 2.1 · Kurverwaltung Baabe (KV09)

Zusatzname: -
Adresse: Am Kurpark 9 (Haus des Gastes) · 18586 Ostseebad Baabe
MD-Quelle: Zeilen 84–90.

| Feld | Aktueller Wert | MD-Wert | Herkunft / Status | Internationale Telefonform |
|---|---|---|---|---|
| internet | www.baabe.de | www.baabe.de | Kurverwaltungen_2025.md:L89; aus_md | - |
| email | willkommen@baabe.de | willkommen@baabe.de | Kurverwaltungen_2025.md:L90; aus_md | - |
| telefon | (03 83 03) 1 42 0 | (03 83 03) 1 42 0 | Kurverwaltungen_2025.md:L87; aus_md | +49 38303 1420 |
| fax | (03 83 03) 1 42 99 | (03 83 03) 1 42 99 | Kurverwaltungen_2025.md:L88; aus_md | - |

### 2.2 · Infopavillion KV Baabe (außer Winter) (KV10)

Zusatzname: -
Adresse: Strandstraße · 18586 Ostseebad Baabe
MD-Quelle: Zeilen 92–95.

| Feld | Aktueller Wert | MD-Wert | Herkunft / Status | Internationale Telefonform |
|---|---|---|---|---|
| internet | - | - (nicht angegeben) | Kurverwaltungen_2025.md:L92-L95 (nicht angegeben); nicht_genannt | - |
| email | - | - (nicht angegeben) | Kurverwaltungen_2025.md:L92-L95 (nicht angegeben); nicht_genannt | - |
| telefon | (03 83 03) 1 42 41 | (03 83 03) 1 42 41 | Kurverwaltungen_2025.md:L95; aus_md | +49 38303 14241 |
| fax | - | - (nicht angegeben) | Kurverwaltungen_2025.md:L92-L95 (nicht angegeben); nicht_genannt | - |

## E-Mail-Lücken

Unveränderte MD: 2 Blöcke ohne E-Mail. Nach der Nutzerergänzung von Middelhagen verbleibt 1: Infopavillion KV Baabe.
Die leere E-Mail im MD-Original von Mönchgut/Middelhagen bleibt erhalten; der ergänzte Wert ist ausschließlich als Nutzerangabe geführt.

## Telefonnummer-Test

(0 38 38) 80 77 80 → +49 3838 807780 (maschinenlesbar +493838807780).

Middelhagen und Thiessow haben nach Nutzervorgabe dieselbe Telefonnummer; ihre eigenständigen Adressen werden deshalb nicht zusammengeführt.

