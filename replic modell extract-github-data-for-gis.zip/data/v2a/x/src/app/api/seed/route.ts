import { NextResponse } from "next/server";
import { db } from "@/db";
import { festivals, bands, locations, performances } from "@/db/schema";

export async function GET() {
  try {
    console.log("🌱 Seeding database via API...");

    // 1. Create Location
    const [location] = await db.insert(locations).values({
      name: "Bookwood Festival Ground",
      address: "Südharz",
      city: "Nordhausen / Umgebung",
      latitude: 51.3, 
      longitude: 10.8,
    }).returning();

    // 2. Create Festival
    const [festival] = await db.insert(festivals).values({
      name: "BOOKWOOD",
      website: "www.mf-suedharz.de",
      locationId: location.id,
      tags: "Metal, Suedharz, Festival",
    }).returning();

    // 3. Create Bands
    const bandsData = [
      { name: "BRAINSTORM", genre: "Heavy/Power Metal", tags: "HeavyMetal, PowerMetal" },
      { name: "Lacrimas Profundere", genre: "Gothic/Doom Metal", tags: "GothicMetal, DoomMetal" },
      { name: "Zero Degree", genre: "Metal", tags: "Metal" },
      { name: "RÜCKHALT", genre: "Metal", tags: "Metal" },
      { name: "FIGHTING CHANCE", genre: "Metal", tags: "Metal" },
      { name: "VIREPTIC", genre: "Metal", tags: "Metal" },
      { name: "Buchfinken", genre: "Folk/Acoustic", tags: "Folk, Acoustic" },
      { name: "OUR MIRAGE", genre: "Metal", tags: "Metal" },
      { name: "Restrisiko", genre: "Metal", tags: "Metal" },
      { name: "MYRA", genre: "Metal", tags: "Metal" },
      { name: "Mandragora", genre: "Metal", tags: "Metal" },
      { name: "Titanith", genre: "Metal", tags: "Metal" },
      { name: "LETTERSSENT", genre: "Metal", tags: "Metal" },
      { name: "Prophecy / Rising Dead", genre: "Metal", tags: "Metal" },
      { name: "CALLING CHARISMA", genre: "Metal", tags: "Metal" },
      { name: "Endless Core", genre: "Metalcore/Deathcore", tags: "Metalcore, Deathcore" },
      { name: "MAGICAL HEART", genre: "Metal", tags: "Metal" },
      { name: "BURNING MISERY", genre: "Metal", tags: "Metal" },
    ];

    const insertedBands = await db.insert(bands).values(bandsData).returning();

    // 4. Create Performances
    const performanceValues = insertedBands.map(band => ({
      festivalId: festival.id,
      bandId: band.id,
    }));

    await db.insert(performances).values(performanceValues);

    return NextResponse.json({ message: "✅ Seeding complete!" });
  } catch (error: any) {
    console.error("Seed error:", error);
    return NextResponse.json({ error: error.message }, { status: 500 });
  }
}
