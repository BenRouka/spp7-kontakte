# SPP7 · Zwischenstand / Freeze

**Zeitpunkt der Sicherung:** 26.09.2026, UTC (Sandbox-Zeit)  
**Umfang:** Datenmodell, Arbeitsdatensatz, Zuordnungen und UI-Stand. In diesem Schritt wurden **nur Dateien unter `docs/freeze/` angelegt**. App-Code, Live-Datensatz und PostgreSQL wurden nicht geändert. Die Sicherung ist ein dokumentierter Zwischenstand, keine technische Schreibsperre.

## Wiederherstellbare Sicherung

- `docs/freeze/2026-09-26-spp7-datasets.json`: bytegenaue Kopie von `public/data/spp7-datasets.json`.
- `docs/freeze/2026-09-26-drizzle-schema.txt`: bytegenaue Kopie von `src/db/schema.ts` (als `.txt`, damit sie nicht zusätzlich kompiliert wird).
- SHA-256 Datensatz (Live-Datei und Sicherung): `c6fe9ba258ab190f4fca11138194f51df25d1e3745db3dacc287c4b75b46e462`.
- SHA-256 Schema (Live-Datei und Sicherung): `4c77e8fd79ceff1dc6dcf2d8ed1f8b8e649d34cd9254975bb96b2fb4ed1f62ca`.
- Dokumentierte UI-Referenz: `src/components/spp7-dashboard.tsx` SHA-256 `2acf047632262ee96784406b0283fc2810d7c79c17c58a2785dc1b335f5fbfc8`; `src/app/globals.css` SHA-256 `a57c256d03d39d55793fb2ddf2fbabc0a39eeb1387712e2f06df65f1621846d3`.
- Server-Datenzugriff `src/lib/spp7-repository.ts` SHA-256 `9eef7fa3b23e14c2d785a0b87d66bdeb25b09da9516f0133799a08b00e822850`.

**Wiederherstellung nur nach ausdrücklicher Freigabe:** Sicherung des Datensatzes zurück nach `public/data/spp7-datasets.json` kopieren; bei Schemaänderungen die gesicherte Textdatei zurück nach `src/db/schema.ts` übernehmen und Drizzle-Schema bewusst prüfen/anwenden. Der Server synchronisiert Events und Kontakte aus der JSON-Datei in PostgreSQL; dabei bestehende Einträge anhand ihrer ID aktualisieren. Der Freeze ist **kein** automatischer Rollback einer Datenbank.

## Aktueller Datenstand (Live und Sicherung)

| Datenbereich | Anzahl |
|---|---:|
| Events | 206 |
| Event-Termine | 203 |
| Event × Acts | 270 |
| Acts | 221 |
| Event × Partner | 46 |
| Partner | 42 |
| Event-Features | 47 |
| Event-Kanäle | 80 |
| Event-Tags | 711 |
| Timetable | 15 |
| Feed-Kontext | 22 |
| Kontakte | 74 |
| Chat-Items | 149 |
| Bild-/Flyerquellen | 79 |

PostgreSQL bei Sicherung: `spp7_events` **206**, `spp7_contacts` **74**. Die übrigen Tabellen liegen im versionierten JSON-Datensatz; PostgreSQL-Schema derzeit mit Event- und Kontakt-Tabellen. `flyersCaptured` im JSON = 71. Von 79 Bildquellen: **71 als eigene Events**, **5 vorhandenen Events zugeordnet** (2 Duplikate + 3 Zusatzquellen, eine Zuordnung unsicher), **3 manuell zu sichten**.

Der Datensatz ist die Arbeitsgrundlage; Herkunft, Status und ein möglicher Widerspruch dürfen nicht durch bloße OCR-Texterkennung als gesichert gelten.

## Festgehaltene Sachverhalte / Grenzen

- **F11** ist nach Bildprüfung „Burgbrand Open Air“, nicht mehr Hatikwa; Termin der Veranstaltung 29.–31.07.2027, E-Mail als Event-Kanal. Daraus folgt **keine** bestätigte Bandbuchung.
- **T04 Rügenhof Putgarten:** SPP7-Auftritt am **21.07.2026** beim Piratenfest gespielt und öffentlich belegt. Die August-2026-Daten aus Chat 44031 sind **Tourplan**, nicht als gespielte Auftritte bestätigt.
- **T09 Hafen Schaprode:** SPP7-Auftritt am **22.07.2026** beim Piraten-/Hafenfest gespielt und öffentlich belegt. Die Blauzahntage 21.–23.08.2026 sind eine **andere Veranstaltung**, kein bestätigter SPP7-Auftritt.
- **2027-Tourkorridor:** Poel **16.–18.07.2027** und Stralsund **22.–25.07.2027** sind veröffentlichte **Veranstaltungstermine** aus der Sündenfrei-Terminübersicht, keine Buchungszusagen für SPP7. Rügenhof und Schaprode sind von der Band **vorgemerkt, ohne veröffentlichtes Datum oder Zusage 2027**. T10 Zentralcamp Putgarten (ca. zwei Wochen) ist Logistik, kein Gig.
- **Veranstalter:** Kontakte mit Typ `Veranstalter` und `Agentur` sowie Event-Feld `ANBIETER` existieren. „Heureka/Eureka“ steht nicht als Kontakt im Bestand und ist nicht mit Sündenfrei gleichzusetzen. Sündenfrei ist bislang als Event-Anbieter/Quelle, nicht als eigener Kontakt eingetragen.
- **Anfragen/Gagen:** In der Arbeitsfassung 9 Bewerbungen `offen`, 3 `unklar`, 31 `geschlossen`, weitere ohne Status. Gage: 33 `bestätigt`, 12 `unklar`, 161 `keine Angabe`. Diese Statuswerte sind **nicht automatisch tagesaktuell**; vor Outreach muss das Bewerbungsfenster beim Veranstalter geprüft werden. Gage und Buy-in/Kosten sind getrennt zu behandeln.

## Offene Punkte — spätere kleine, einzeln freizugebende Schritte

### 1. Inhalt und Zuordnung

- **Bildquellen 19, 21, 74** manuell lesen. Unleserliche Inhalte nicht schätzen oder aus ähnlichen Veranstaltungen ableiten.
- **F32 und F79**: Neu aus OCR erfasst, OCR-Qualität niedrig; Namen, Termine und Quellen am Originalbild gegenlesen.
- **Bild 78**: Zuordnung als Zusatzquelle zu F13 ist unsicher und bleibt so markiert; Jahr auf Flyer 31/Gößnitz bei Bedarf am Bild klären.
- Kontaktaufnahme zu **Rügenhof/Schaprode für 2027**: existieren erneute Veranstaltungen und gibt es eine Zusage? Bis dahin kein 2027-Datum, keine Buchung. Für Sündenfrei Poel/Stralsund ebenfalls zwischen Veranstaltung und tatsächlichem Bandauftritt unterscheiden.
- Heureka/Eureka als **eigene** Veranstalterorganisation nur mit belegter Quelle und Kontaktmöglichkeit aufnehmen; Sündenfrei-Kontaktdatensatz nur bei bestätigter Anschrift/Kanal/Verantwortung.
- Die übrigen Sündenfrei-Termine 2026/2027 liegen bislang separat in `docs/audit/suendenfrei_2026_2027.json`; vor einer Übernahme einzeln auf Dubletten, Jahresbezug, Sternchen/Unbestätigt und Relevanz prüfen.

### 2. Datenqualität / Semantik

- Quelle-/Bewerbungsstatus, abgelaufener Veranstaltungstermin und **heutige** Outreach-Eignung künftig getrennt führen. `offen` darf nicht unbesehen als aktuelle Bewerbungsfreigabe präsentiert werden.
- `GAGE`, `KOSTEN` und Originalwortlaut/Beleg bei weiteren Importen getrennt halten; OCR- oder Werbetext nicht als gesicherte Gage ausweisen.
- Vor weiterer Kontaktanreicherung prüfen, ob Mail/Telefon schon vorhanden oder nur ein zusätzlicher Kanal einer bestehenden Organisation ist; neue Termine an bestehende IDs verknüpfen statt Events doppelt anzulegen.
- Die älteren Dateien unter `docs/audit/` beschreiben **Zeitpunkte vor** späteren Freigaben (z. B. F11, Barmstedt-Kontakte). Für diesen Zwischenstand gelten die gesicherten JSON-Daten und die vorliegende Freeze-Notiz, nicht die früheren „noch offen“-Abschnitte jener Berichte.

### 3. GUI-Lesbarkeit — ausdrücklich erst später

- Typografie, Kontrast und Größe der Event-/Termintabellen, Mobilnavigation, Suchtreffer und Flyer-Vorschau gemeinsam prüfen, **ohne jetzt Layout zu ändern**.
- Kartendarstellung/Beschriftung und Status „Veranstaltung 2027“ vs. „Vormerkung“ vs. „gespielt 2026“ auf Lesbarkeit prüfen; Zentralcamp nicht als eigener Auftritt darstellen.
- Statische UI-Texte gegen Daten prüfen: In der Übersicht stehen zurzeit z. B. `+12 seit letztem Import`, `13 relationale Tabellen` und `nächste Frist 01.11.` als feste Texte. Nicht automatisch als aktuelle Fakten behandeln. Behebung erst im separaten GUI-Schritt.

## Vorgehen nach dem Zwischenstopp

Erst eine klar abgegrenzte Änderung auswählen, vorab ihre Quelle prüfen, bestehende ID/Quellenbezüge erhalten und dann **einen** Schritt mit Differenzprüfung, Build und Sichtkontrolle umsetzen. Keine generelle Neuinterpretation der Daten und keine automatische Massenübernahme ohne Freigabe.
