/* Text-Ergaenzungen fuer einzelne Chat-Nachrichten.
 *
 * Schluessel = MSG-Nummer, Wert = Text. Wird unterhalb des vorhandenen
 * Nachrichtentextes angezeigt und in der Blase als "ergaenzt" markiert.
 * Leere Werte werden ignoriert. Leere Zeilen sind erlaubt.
 *
 * Beispiel:
 *   window.SPP7_NOTES = {
 *     "43965": "Kurzfilm vom Suedenfrei-Aufbau, Aufnahme vom 12.09.2026."
 *   };
 */
window.SPP7_NOTES = {
  "43965": "",
};
