import { Spp7Dashboard } from "@/components/spp7-dashboard";
import { getSpp7Overview } from "@/lib/spp7-repository";

export const dynamic = "force-dynamic";

export default async function HomePage() {
  const overview = await getSpp7Overview();
  return <Spp7Dashboard overview={overview} />;
}
