/* ------------------------------------------------------------------ */
/* C3 — Prüf-Workflow: setzt den Prüfstatus eines geo_orte-Eintrags.   */
/* Erlaubte Übergänge: → „geprueft“ (mit Zeitstempel) und zurück       */
/* → „ungeprueft“. Andere Felder werden nicht angerührt; der           */
/* Geocoder respektiert „geprueft“-Zeilen (überspringt sie).           */
/* ------------------------------------------------------------------ */

import { NextResponse } from "next/server";
import { revalidatePath } from "next/cache";
import { eq } from "drizzle-orm";
import { db } from "@/db";
import { geoOrte } from "@/db/schema";

export const dynamic = "force-dynamic";

export async function POST(
  req: Request,
  { params }: { params: Promise<{ id: string }> },
) {
  const { id } = await params;
  const geoId = Number(id);
  if (!Number.isInteger(geoId) || geoId <= 0) {
    return NextResponse.json(
      { ok: false, error: "ungültige id" },
      { status: 400 },
    );
  }

  let body: unknown;
  try {
    body = await req.json();
  } catch {
    return NextResponse.json(
      { ok: false, error: "ungültiger body" },
      { status: 400 },
    );
  }
  const status = (body as { status?: unknown }).status;
  if (status !== "geprueft" && status !== "ungeprueft") {
    return NextResponse.json(
      { ok: false, error: "status muss „geprueft“ oder „ungeprueft“ sein" },
      { status: 422 },
    );
  }

  const aktualisiert = await db
    .update(geoOrte)
    .set({
      pruefstatus: status,
      geprueftAm: status === "geprueft" ? new Date().toISOString() : null,
    })
    .where(eq(geoOrte.id, geoId))
    .returning({
      id: geoOrte.id,
      pruefstatus: geoOrte.pruefstatus,
      geprueftAm: geoOrte.geprueftAm,
    });

  if (aktualisiert.length === 0) {
    return NextResponse.json(
      { ok: false, error: "eintrag nicht gefunden" },
      { status: 404 },
    );
  }

  revalidatePath("/karte");
  return NextResponse.json({ ok: true, eintrag: aktualisiert[0] });
}
