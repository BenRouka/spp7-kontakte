"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import {
  CalendarDays,
  Compass,
  Database,
  Gavel,
  LayoutDashboard,
  MapPinned,
  Boxes,
} from "lucide-react";

const LINKS = [
  { href: "/", label: "Übersicht", icon: LayoutDashboard },
  { href: "/kontakte", label: "Kontakte", icon: MapPinned },
  { href: "/termine", label: "Termine", icon: CalendarDays },
  { href: "/karte", label: "Karte", icon: Compass },
  { href: "/beschluesse", label: "Beschlüsse", icon: Gavel },
  { href: "/archiv", label: "Archiv", icon: Boxes },
  { href: "/stufe-5", label: "Stufe 5", icon: Database },
];

export function ShellNav() {
  const pathname = usePathname();
  return (
    <nav className="scrollbox -mx-1 flex items-center gap-1 overflow-x-auto px-1 py-0.5">
      {LINKS.map(({ href, label, icon: Icon }) => {
        const active =
          href === "/" ? pathname === "/" : pathname.startsWith(href);
        return (
          <Link
            key={href}
            href={href}
            scroll={false}
            className={
              active
                ? "inline-flex shrink-0 items-center gap-1.5 rounded-full border border-lime/35 bg-lime/10 px-3 py-1.5 text-[12px] font-medium text-lime transition-colors"
                : "inline-flex shrink-0 items-center gap-1.5 rounded-full border border-transparent px-3 py-1.5 text-[12px] font-medium text-muted transition-colors hover:border-line hover:text-ink"
            }
          >
            <Icon className="h-3.5 w-3.5" strokeWidth={2.2} />
            {label}
          </Link>
        );
      })}
    </nav>
  );
}
