# SPP7 · Klärung des Zeitmodells 2027

Gemeinsamer Stand A/B: zeitmodell-2026-2027-v2.
Nur Prüfansicht. Keine Änderung der Originalquellen, kein Datenbankimport.

## Vier Adventswochenenden · Herne / Schloss Strünkede

Original: 1. - 4. Advent 2027*  | Mittelalter- Advent (Fr.- So.)  | 44629 Herne/ Schloss Strünkede
Datumsherkunft: berechnet. Bestätigungsstatus: unbestätigt.

| Advent | Beginn | Ende | Wochentage |
|---|---|---|---|
| 1. Advent | 2027-11-26 | 2027-11-28 | Fr.–So. |
| 2. Advent | 2027-12-03 | 2027-12-05 | Fr.–So. |
| 3. Advent | 2027-12-10 | 2027-12-12 | Fr.–So. |
| 4. Advent | 2027-12-17 | 2027-12-19 | Fr.–So. |

Ein Quelltermin mit vier getrennten Zeitfenstern; die Tage dazwischen sind keine Veranstaltungstage dieses Eintrags.

Kirchenregel: Der 4. Advent ist der letzte Sonntag vor dem 25. Dezember (18.–24. Dezember).
Fällt der 25. Dezember auf einen Sonntag, ist der 4. Advent am 18. Dezember, nicht am 25. Dezember.
Beleg zur Regel: https://katholisch.de/artikel/15657-das-bedeuten-die-vier-advenssonntage

## Durchgehender Weihnachtsmarkt · Dresden / Stallhof

Original: 24.11. - 23. Dezember 2027*  | Mittelalter- Weihnacht  | 01067 Dresden / Stallhof
Zeitraum: 24. November – 23. Dezember 2027 (30 Kalendertage).
Datumsherkunft: aus Quelle. Bestätigungsstatus: unbestätigt.
Eigener Termin. Keine Adventsberechnung und keine Aufteilung in Wochenenden.

## Festgehaltene Regeln

- Termine Januar–September 2026 werden nicht nacherfasst; die Originalquelle bleibt erhalten.
- „180 maps“ entspricht 180 Event-Einträgen mit Koordinaten, nicht der Bilderzahl. Es sind 149 unterschiedliche Koordinatenpaare.
- * und ** bedeuten gleichermaßen: Termin oder Ort wahrscheinlich, jedoch noch unbestätigt.
- Originalschreibweisen bleiben erhalten; eine spätere Normierung wird nur zusätzlich geführt.
- Zwei Namen in einem Adressblock bleiben eine Zeile mit Haupt- und Zusatzname.
- Berechnete Daten sind nicht automatisch bestätigte Termine.

Vorsicht: Vier getrennte Zeitfenster erfordern beim späteren Import eine Zuordnung mehrerer Zeiträume zu einem Quelltermin. Eine Schemaänderung ist hier nicht vorgenommen worden.

Quelle: https://github.com/BenRouka/spp7-kontakte/blob/main/Termine%202027%20Veranstalter%20suendenfrei.txt
Stand der Terminliste 2027: 22. September 2026. 54 Quellzeilen (9 aus 2026, 45 aus 2027).
