#!/usr/bin/env node
// Stufe 2 – Normierung der beiden sauberen Quellen in werkstatt/02-normiert/.
// Liest NUR aus werkstatt/01-roh/, schreibt ausschließlich nach werkstatt/02-normiert/.
// Datenbank und Schema bleiben unberührt. Fehlende Werte bleiben leer – nichts wird erfunden.
//
// Aufruf:  node scripts/normalize-sources.mjs            (CSV erzeugen)
//          node scripts/normalize-sources.mjs --verify    (nur prüfen, nichts schreiben)

import assert from "node:assert/strict";
import { createHash } from "node:crypto";
import { mkdir, readFile, writeFile } from "node:fs/promises";
import { existsSync, readFileSync } from "node:fs";
import { createRequire } from "node:module";
import path from "node:path";
import ts from "typescript";

const verifyOnly = process.argv.includes("--verify");
const require = createRequire(import.meta.url);

// Eigener Lader für die gemeinsame Kalenderlogik. src/lib/calendar-model.ts bleibt
// die einzige Quelle der Kirchenregel; sie wird hier nur gelesen, nicht verändert.
const moduleCache = new Map();
function loadTs(specifier) {
  const file = specifier.startsWith("@/") ? `src/${specifier.slice(2)}.ts` : specifier;
  if (moduleCache.has(file)) return moduleCache.get(file).exports;
  const module = { exports: {} };
  moduleCache.set(file, module);
  const code = ts.transpileModule(readFileSync(file, "utf8"), {
    compilerOptions: { module: ts.ModuleKind.CommonJS, target: ts.ScriptTarget.ES2022, esModuleInterop: true },
  }).outputText;
  new Function("require", "module", "exports", code)(
    (id) => id === "server-only" ? {} : id.startsWith("@/") ? loadTs(id) : require(id), module, module.exports);
  return module.exports;
}
const calendar = loadTs("src/lib/calendar-model.ts");
const reference = loadTs("src/lib/reference-data.ts");
const reviews = { 2026: calendar.buildCalendarReview(2026), 2027: calendar.buildCalendarReview(2027) };

const RAW_MD = "werkstatt/01-roh/Kurverwaltungen_2025.md";
const RAW_TXT = "werkstatt/01-roh/Termine_2027_suendenfrei.txt";
const OUT = "werkstatt/02-normiert";

// ---------------------------------------------------------------- CSV-Helfer
function csvCell(value) {
  const text = value == null || value === "" ? "-" : String(value);
  // International telephone numbers are generated from validated digits and may safely retain +49.
  const isNormalizedInternationalPhone = /^\+49 \d+ \d+$/.test(text);
  const safe = !isNormalizedInternationalPhone && text !== "-" && /^[=+@\-]/.test(text) ? `'${text}` : text;
  return `"${safe.replaceAll('"', '""')}"`;
}
function csvFile(headers, rows) {
  return "\uFEFF" + [headers, ...rows].map((row) => row.map(csvCell).join(";")).join("\r\n") + "\r\n";
}

// ------------------------------------------------------- Normierungsregeln
const clean = (value) => value.replace(/\s+/g, " ").trim();
const stripStars = (value) => value.replace(/\*+$/, "").trim();
// Bindestrich-Schreibvariante "Wort- Wort" → "Wort-Wort". Ausnahme: "…- und/bzw. …"
// ist im Deutschen korrekt und bleibt unverändert.
const joinHyphen = (value) => value.replace(/([A-Za-zÄÖÜäöüß])-\s+(?!(und|bzw)\b)([A-Za-zÄÖÜäöüß])/g, "$1-$3");
const joinSlash = (value) => value.replace(/\s*\/\s*/g, "/");
const digits = (value) => value.replace(/\D+/g, "");
const lower = (value) => value.trim().toLowerCase();
const MISSING = "-";
function internationalPhone(value) {
  if (!value || value === MISSING) return MISSING;
  const local = value.match(/^\s*\(([^)]+)\)\s*(.+)$/);
  if (local) {
    const areaCode = digits(local[1]);
    const subscriber = digits(local[2]);
    assert.ok(areaCode.startsWith("0") && areaCode.length > 1 && subscriber, `Telefon nicht eindeutig zerlegbar: ${value}`);
    return `+49 ${areaCode.slice(1)} ${subscriber}`;
  }
  const international = value.match(/^\s*\+49\s+(\d+)\s+([\d\s]+)$/);
  if (international) return `+49 ${digits(international[1])} ${digits(international[2])}`;
  throw new Error(`Telefonnummer ohne eindeutige Vorwahlgruppe: ${value}`);
}
// Belegter Tippfehler (werkstatt/01-roh/QUELLEN.md: „Mitt**e**alterspektakel“ (2×)),
// tritt in der Quelle genau zweimal auf: Zeilen 26 und 33.
const fixTypo = (value) => value.replaceAll("Mittealter", "Mittelalter");

// ============================================================ 1 · Termine (TXT)
const MONTHS = {
  Januar: 1, Februar: 2, März: 3, April: 4, Mai: 5, Juni: 6,
  Juli: 7, August: 8, September: 9, Oktober: 10, November: 11, Dezember: 12,
};
function iso(year, month, day) {
  const date = new Date(Date.UTC(year, month - 1, day, 12));
  assert.equal(date.getUTCFullYear(), year, `ungültiges Datum ${year}-${month}-${day}`);
  assert.equal(date.getUTCMonth(), month - 1, `ungültiges Datum ${year}-${month}-${day}`);
  return date.toISOString().slice(0, 10);
}
function parseScheduleDate(original) {
  const text = stripStars(original);
  let m = text.match(/^1\.\s*-\s*4\.\s*Advent\s+(\d{4})$/);           // 1. - 4. Advent 2026
  if (m) return { kind: "advent", year: Number(m[1]) };
  m = text.match(/^(\d{1,2})\.\s*(\d{1,2})\.\s*-\s*(\d{1,2})\.\s*([^\d\s]+)\s+(\d{4})$/); // 25. 11. - 23. Dezember 2026
  if (m) {
    const [, d1, mo1, d2, moName2, yearText] = m;
    const month2 = MONTHS[moName2];
    assert.ok(month2, `Monat unbekannt: ${moName2}`);
    return { kind: "range", year: Number(yearText), from: iso(Number(yearText), Number(mo1), Number(d1)), to: iso(Number(yearText), month2, Number(d2)) };
  }
  m = text.match(/^(\d{1,2})\.\s*([^\d\s]+)\s*-\s*(\d{1,2})\.\s*([^\d\s]+)\s+(\d{4})$/);   // 30. April - 2. Mai 2027
  if (m) {
    const [, d1, moName1, d2, moName2, yearText] = m;
    const month1 = MONTHS[moName1], month2 = MONTHS[moName2];
    assert.ok(month1 && month2, `Monat unbekannt: ${moName1}/${moName2}`);
    let year = Number(yearText);
    if (month2 < month1) year += 1;                                    // Jahreswechsel nur bei Dez→Jan
    return { kind: "range", year: Number(yearText), from: iso(Number(yearText), month1, Number(d1)), to: iso(year, month2, Number(d2)) };
  }
  m = text.match(/^(\d{1,2})\.\s*-\s*(\d{1,2})\.\s*([^\d\s]+)\s+(\d{4})$/);                 // 3. - 4. Oktober 2026
  if (m) {
    const [, d1, d2, moName, yearText] = m;
    const month = MONTHS[moName];
    assert.ok(month, `Monat unbekannt: ${moName}`);
    return { kind: "range", year: Number(yearText), from: iso(Number(yearText), month, Number(d1)), to: iso(Number(yearText), month, Number(d2)) };
  }
  return null;
}

async function buildScheduleRows() {
  const raw = (await readFile(RAW_TXT, "utf8")).replace(/\r\n/g, "\n");
  // Sicherstellen, dass die gemeinsame Referenz dieselbe Quelle zeigt.
  assert.equal(raw.trimEnd(), reference.originalSchedule.trimEnd(), "TXT und Referenz-Snapshot weichen ab");
  const rows = [];
  for (const [index, originalLine] of raw.split("\n").entries()) {
    const parts = originalLine.split("\t");
    if (parts.length !== 3) continue;
    const [dateOriginalRaw, nameOriginalRaw, placeOriginalRaw] = parts;
    const dateOriginal = dateOriginalRaw.trim();
    const nameOriginal = nameOriginalRaw.trim();
    const placeOriginal = placeOriginalRaw.trim();
    const stars = (originalLine.match(/\*+/) || [""])[0];
    const parsed = parseScheduleDate(dateOriginal);
    assert.ok(parsed, `Quellzeile ${index + 1} nicht maschinenlesbar: ${dateOriginal}`);
    const year = parsed.year;

    let periods = [];
    let dateOrigin = "aus_quelle";
    let periodKind = "zeitraum";
    let hint = "";
    if (parsed.kind === "advent") {
      periods = reviews[year].advent.periods.map((p) => ({ start: p.start, end: p.end }));
      dateOrigin = "berechnet";
      periodKind = "wochenenden";
      hint = `1 Quelltermin, 4 getrennte Adventswochenenden (${reviews[year].advent.weekdayLabel}) – kein durchgehender Zeitraum`;
    } else {
      assert.equal(parsed.from <= parsed.to, true, `Zeitraum verkehrt: ${dateOriginal}`);
      assert.equal(parsed.from.slice(0, 4), parsed.to.slice(0, 4), `unerwarteter Jahreswechsel: ${dateOriginal}`);
      periods = [{ start: parsed.from, end: parsed.to }];
      hint = "durchgehender Zeitraum aus der Quelle, keine Adventsberechnung";
    }

    const placeClean = fixTypo(joinSlash(stripStars(clean(placeOriginal))));
    const placeOpen = /^x+$/.test(placeOriginal.trim());
    const nameOpen = /^noch offen$/i.test(nameOriginal);
    let nameNorm = fixTypo(joinHyphen(joinSlash(stripStars(clean(nameOriginal)))));
    if (nameOpen) nameNorm = MISSING;
    const placeNorm = placeOpen ? MISSING : placeClean;
    const plzMatch = placeNorm.match(/^(\d{5})\s+(.*)$/);

    const remarks = [hint];
    if (stars) remarks.push("Sternchen laut Quelle: Termin oder Ort wahrscheinlich, jedoch noch unbestätigt");
    if (placeOpen) remarks.push("Ort ist Platzhalter (xxxx/xxxxx); PLZ und Ort sind als - markiert");
    if (nameOpen) remarks.push("Name ist Platzhalter (noch offen); name_normiert ist als - markiert");

    rows.push({
      sf_id: `SF${String(rows.length + 1).padStart(2, "0")}`,
      jahr: String(year),
      quellzeile: String(index + 1),
      datum_original: dateOriginal,
      name_original: nameOriginal,
      name_normiert: nameNorm,
      plz_ort_original: placeOriginal,
      plz_normiert: plzMatch ? plzMatch[1] : MISSING,
      ort_normiert: plzMatch ? plzMatch[2] : MISSING,
      zeitfenster_art: periodKind,
      datumsherkunft: dateOrigin,
      zeitfenster_anzahl: String(periods.length),
      zeitfenster_iso: periods.map((p) => `${p.start}/${p.end}`).join(";"),
      start_iso: periods[0].start,
      end_iso: periods[periods.length - 1].end,
      sternchen: stars === "**" ? "**" : stars === "*" ? "*" : "kein",
      bestaetigungsstatus: stars ? "unbestaetigt" : "nicht_markiert",
      ort_offen: placeOpen ? "ja" : "nein",
      hinweis: remarks.join(" · "),
      status_verifikation: "nicht_verifiziert",
    });
  }
  return rows;
}

// ====================================================== 2 · Kurverwaltungen (MD)
function buildContactBlocks(markdown) {
  const lines = markdown.replace(/\r\n/g, "\n").split("\n");
  const blocks = [];
  const footer = [];
  let region = "", place = "", current = null, inFooter = false;
  const flush = () => { if (current) { blocks.push(current); current = null; } };
  for (let i = 0; i < lines.length; i++) {
    const rawLine = lines[i];
    const line = clean(rawLine.replace(/\s{2,}$/, ""));
    if (line === "---") { flush(); inFooter = true; continue; }
    if (inFooter) { if (line) footer.push(clean(line.replace(/^\*\*|\*\*$|^_|_$/g, ""))); continue; }
    if (!line) { flush(); continue; }
    if (/^#/.test(line)) {
      flush();
      if (/^## /.test(line)) region = clean(line.slice(3));
      else if (/^### /.test(line)) place = clean(line.slice(4));
      continue;
    }
    // Kursive Klammer-Notiz gehört zum Adressblock; andere Kursivzeilen sind Vorspann.
    if (/^_\(.+\)_$/.test(line)) {
      if (!current) throw new Error(`Notiz ohne Block in Zeile ${i + 1}`);
      current.notiz = clean(line.replace(/^_\(|\)_$/g, ""));
      continue;
    }
    if (/^_.*_$/.test(line)) { flush(); continue; }
    if (!current) current = { region, place, names: [], street: "", plzOrt: "", telefon: "", fax: "", web: "", emails: [], notiz: "", from: i + 1, to: i + 1 };
    current.to = i + 1;
    const field = line.match(/^(Telefon|Fax|Internet|E-Mail):\s*(.*)$/);
    if (field) {
      const [, key, value] = field;
      if (key === "Telefon") current.telefon = clean(value);
      else if (key === "Fax") current.fax = clean(value);
      else if (key === "Internet") current.web = clean(value);
      else current.emails.push(clean(value));
      continue;
    }
    if (/^\d{5}\s/.test(line)) { current.plzOrt = line; continue; }
    if (/^\(.+\)$/.test(line)) { current.notiz = clean(line); continue; }
    const name = line.match(/^\*\*(.+?)\*\*$/);
    if (name) { current.names.push(clean(name[1])); continue; }
    if (!current.street && current.plzOrt === "") { current.street = line; continue; }
    throw new Error(`MD-Zeile ${i + 1} nicht zugeordnet: ${line}`);
  }
  flush();
  return { blocks, footer };
}

async function buildContactRows() {
  const markdown = await readFile(RAW_MD, "utf8");
  const { blocks, footer } = buildContactBlocks(markdown);
  const quelleStand = footer.join(" · ");
  assert.ok(/Stand 2025/.test(quelleStand) && /ohne Gewähr/.test(quelleStand), `Fußzeile nicht erkannt: ${quelleStand}`);

  function missingSource(block) {
    const fields = [];
    if (!block.telefon) fields.push("telefon");
    if (!block.fax) fields.push("fax");
    if (!block.web) fields.push("web");
    if (!block.emails.length) fields.push("email");
    return fields.length ? fields.join(",") : MISSING;
  }

  function makeRecord({ block, kvId, sourceBlockId, parentId = MISSING, role = "eintrag",
    entryName, chat = {}, extraNote = MISSING, notApplicable = false }) {
    const plzMatch = block.plzOrt?.match(/^(\d{5})\s+(.*)$/);
    if (block.plzOrt) assert.ok(plzMatch, `Block ${sourceBlockId}: PLZ/Ort nicht lesbar`);
    const names = block.names ?? [];
    const primary = names[0] ?? MISSING;
    const secondary = names[1] ?? MISSING;
    const telephone = block.telefon || MISSING;
    const fax = block.fax || MISSING;
    const web = block.web || MISSING;
    const email1 = block.emails?.[0] || MISSING;
    const email2 = block.emails?.[1] || MISSING;
    const telephoneChat = chat.telefon || MISSING;
    const faxChat = Object.hasOwn(chat, "fax") ? chat.fax : MISSING;
    const webChat = chat.web || MISSING;
    const emailChat = chat.email || MISSING;
    const selectedTelephone = telephone !== MISSING ? telephone : telephoneChat;
    const selectedFax = fax !== MISSING ? fax : faxChat;
    const selectedWeb = web !== MISSING ? web : webChat;
    const selectedEmail1 = email1 !== MISSING ? email1 : emailChat;
    const currentMissing = [];
    if (selectedTelephone === MISSING) currentMissing.push("telefon");
    if (selectedFax === MISSING) currentMissing.push("fax");
    if (selectedWeb === MISSING) currentMissing.push("web");
    if (selectedEmail1 === MISSING) currentMissing.push("email");
    const notes = [...(block.notiz ? [block.notiz] : [])];
    for (const name of names) {
      const nameHint = name.match(/\(([^)]+)\)\s*$/);
      if (nameHint) notes.push(`Klammerzusatz im Namen: (${nameHint[1]}) – Bestandteil des Originalnamens`);
    }
    if (extraNote !== MISSING) notes.push(extraNote);
    return {
      kv_id: kvId,
      quellblock_id: sourceBlockId,
      parent_id: parentId,
      hierarchie_rolle: role,
      hierarchie_herkunft: role === "eintrag" ? MISSING : "Auftraggeberangabe im Gespräch",
      eintragsname_original: entryName || primary,
      region_original: block.region || MISSING,
      ort_original: block.place || MISSING,
      name_haupt_original: primary,
      name_zusatz_original: secondary,
      strasse_original: block.street || MISSING,
      plz_ort_original: block.plzOrt || MISSING,
      plz_normiert: plzMatch ? plzMatch[1] : MISSING,
      ort_normiert: plzMatch ? plzMatch[2] : MISSING,
      telefon_original: telephone,
      telefon_chat_ergaenzung: telephoneChat,
      telefon_normiert: selectedTelephone === MISSING ? MISSING : internationalPhone(selectedTelephone),
      fax_original: fax,
      fax_chat_ergaenzung: faxChat,
      // Telefon wird internationalisiert; Fax bleibt – wie zuvor vereinbart – reine Ziffernfolge.
      fax_normiert: selectedFax === MISSING ? MISSING : digits(selectedFax),
      web_original: web,
      web_chat_ergaenzung: webChat,
      web_normiert: selectedWeb === MISSING ? MISSING : lower(selectedWeb),
      email_1_original: email1,
      email_1_chat_ergaenzung: emailChat,
      email_1_normiert: selectedEmail1 === MISSING ? MISSING : lower(selectedEmail1),
      email_2_original: email2,
      email_2_normiert: email2 === MISSING ? MISSING : lower(email2),
      chat_zitat_nutzer: chat.quote || MISSING,
      quelle_ergaenzung: chat.provenance || MISSING,
      chat_msg_id: MISSING,
      hinweis: notes.length ? notes.join(" · ") : MISSING,
      felder_fehlend_quelle: notApplicable ? MISSING : missingSource(block),
      felder_fehlend_arbeitsstand: notApplicable ? "nicht_anwendbar" : currentMissing.length ? currentMissing.join(",") : MISSING,
      quellzeile: `${block.from}-${block.to}`,
      status_verifikation: "nicht_verifiziert",
      quelle_stand: quelleStand,
    };
  }

  const records = [];
  for (const [index, block] of blocks.entries()) {
    assert.ok(block.names.length >= 1 && block.names.length <= 2, `Block ${index + 1}: ${block.names.length} Namen`);
    assert.ok(block.plzOrt, `Block ${index + 1} ohne PLZ/Ort`);
    const kvId = `KV${String(index + 1).padStart(2, "0")}`;

    if (kvId === "KV12") {
      assert.deepEqual(block.names, ["Kurverwaltung Mönchgut", "Tourist-Information Middelhagen"]);
      // Organisationsknoten: die Quell-Kontaktdaten gehören zur benannten Außenstelle,
      // werden deshalb nicht doppelt auf dem Parent abgelegt.
      records.push(makeRecord({
        block: { ...block, street: "", plzOrt: "", telefon: "", fax: "", web: "", emails: [] },
        kvId, sourceBlockId: kvId, role: "parent", entryName: "Kurverwaltung Mönchgut",
        notApplicable: true,
        extraNote: "Organisationsknoten; Kontaktdaten sind der Außenstelle Middelhagen zugeordnet.",
      }));
      records.push(makeRecord({
        block, kvId: "KV33", sourceBlockId: kvId, parentId: kvId, role: "aussenstelle",
        entryName: "Tourist-Information Middelhagen",
        chat: {
          web: "www.ostseebad-moenchgut.de",
          email: "info@ostseebad-moenchgut.de",
          provenance: "Ergänzung vom Auftraggeber als Chat-Angabe geliefert; keine Chat-MSG-ID beigefügt",
        },
        extraNote: "Außenstelle Middelhagen; Ergänzung von Web und E-Mail durch Auftraggeberangabe aus dem Chat.",
      }));
      continue;
    }

    if (kvId === "KV13") {
      assert.deepEqual(block.names, ["Tourist-Information Thiessow (Außenstelle)"]);
      records.push(makeRecord({
        block, kvId, sourceBlockId: kvId, parentId: "KV12", role: "aussenstelle",
        entryName: "Tourist-Information Thiessow (Außenstelle)",
        chat: {
          telefon: "+49 38308 66010",
          fax: MISSING,
          email: "info@ostseebad-moenchgut.de",
          quote: "Tourist-Info Thiessow info@ostseebad-moenchgut.de Insel Rügen",
          provenance: "Vom Auftraggeber als Chat-Zitat geliefert; keine Chat-MSG-ID beigefügt",
        },
        extraNote: "Außenstelle der Kurverwaltung Mönchgut; Telefon ergänzt, Fax laut Auftraggeber als fehlend markiert.",
      }));
      continue;
    }

    const baabeConfirmation = block.names[0] === "Kurverwaltung Baabe" ? {
      quote: "Kurverwaltung Baabe willkommen@baabe.de Insel Rügen",
      provenance: "Chat-Zitat des Auftraggebers bestätigt den bereits in der MD vorhandenen E-Mail-Wert; keine Chat-MSG-ID beigefügt",
    } : {};
    records.push(makeRecord({ block, kvId, sourceBlockId: kvId, chat: baabeConfirmation }));
  }
  assert.equal(records.length, 33, `Kontaktdatensätze inkl. Parent/Child: ${records.length}`);
  assert.equal(records.filter((r) => r.hierarchie_rolle === "parent").length, 1);
  assert.equal(records.filter((r) => r.parent_id === "KV12").length, 2);
  assert.equal(records.find((r) => r.kv_id === "KV12").eintragsname_original, "Kurverwaltung Mönchgut");
  assert.equal(records.find((r) => r.kv_id === "KV33").telefon_normiert, "+49 38308 66010");
  assert.equal(records.find((r) => r.kv_id === "KV13").fax_normiert, MISSING);
  assert.equal(records.find((r) => r.kv_id === "KV10").email_1_normiert, MISSING, "KV-Baabe-E-Mail darf nicht auf Pavillon übertragen werden");
  return records;
}

// ================================================================== Ausgabe
const scheduleHeaders = ["sf_id", "jahr", "quellzeile", "datum_original", "name_original", "name_normiert",
  "plz_ort_original", "plz_normiert", "ort_normiert", "zeitfenster_art", "datumsherkunft", "zeitfenster_anzahl",
  "zeitfenster_iso", "start_iso", "end_iso", "sternchen", "bestaetigungsstatus", "ort_offen", "hinweis",
  "status_verifikation"];
const contactHeaders = ["kv_id", "quellblock_id", "parent_id", "hierarchie_rolle", "hierarchie_herkunft",
  "eintragsname_original", "region_original", "ort_original", "name_haupt_original", "name_zusatz_original",
  "strasse_original", "plz_ort_original", "plz_normiert", "ort_normiert",
  "telefon_original", "telefon_chat_ergaenzung", "telefon_normiert",
  "fax_original", "fax_chat_ergaenzung", "fax_normiert",
  "web_original", "web_chat_ergaenzung", "web_normiert",
  "email_1_original", "email_1_chat_ergaenzung", "email_1_normiert", "email_2_original", "email_2_normiert",
  "chat_zitat_nutzer", "quelle_ergaenzung", "chat_msg_id", "hinweis",
  "felder_fehlend_quelle", "felder_fehlend_arbeitsstand", "quellzeile", "status_verifikation", "quelle_stand"];

const scheduleRows = await buildScheduleRows();
const contactRows = await buildContactRows();

assert.equal(scheduleRows.length, 54, `Termine: ${scheduleRows.length}`);
assert.equal(new Set(scheduleRows.map((r) => r.sf_id)).size, 54);
assert.equal(scheduleRows.filter((r) => r.jahr === "2026").length, 9);
assert.equal(scheduleRows.filter((r) => r.jahr === "2027").length, 45);
assert.equal(scheduleRows.filter((r) => r.sternchen !== "kein").length, 14);
assert.equal(scheduleRows.filter((r) => r.ort_offen === "ja").length, 2);
assert.equal(scheduleRows.filter((r) => r.datumsherkunft === "berechnet").length, 2);
assert.equal(scheduleRows.filter((r) => r.zeitfenster_art === "wochenenden").length, 2);
assert.equal(scheduleRows.reduce((n, r) => n + Number(r.zeitfenster_anzahl), 0), 60);
assert.equal(contactRows.length, 33, `Kontaktdatensätze inkl. Parent/Child: ${contactRows.length}`);
assert.equal(new Set(contactRows.map((r) => r.kv_id)).size, 33);
for (const row of [...scheduleRows, ...contactRows]) {
  assert.ok(Object.values(row).every((value) => value !== "" && value != null), `Leeres Feld in ${row.sf_id ?? row.kv_id}`);
}
for (const row of scheduleRows) {
  assert.ok(row.datum_original && row.quellzeile, "Originalspalten müssen gefüllt sein");
  assert.equal(row.status_verifikation, "nicht_verifiziert");
}
const moenchgutParent = contactRows.find((r) => r.kv_id === "KV12");
assert.deepEqual(contactRows.filter((r) => r.parent_id === "KV12").map((r) => r.kv_id), ["KV33", "KV13"]);
assert.equal(moenchgutParent.hierarchie_rolle, "parent");
assert.equal(contactRows.find((r) => r.kv_id === "KV13").telefon_original, MISSING);
assert.equal(contactRows.find((r) => r.kv_id === "KV13").email_1_original, "info@ostseebad-moenchgut.de");

const files = [
  ["suendenfrei-termine.csv", csvFile(scheduleHeaders, scheduleRows.map((r) => scheduleHeaders.map((h) => r[h])))],
  ["kurverwaltungen.csv", csvFile(contactHeaders, contactRows.map((r) => contactHeaders.map((h) => r[h])))],
];

const checksums = files.map(([name, content]) => `${createHash("sha256").update(content).digest("hex")}  ${name}`).join("\n") + "\n";

if (!verifyOnly) {
  await mkdir(OUT, { recursive: true });
  for (const [name, content] of files) await writeFile(path.join(OUT, name), content, "utf8");
  await writeFile(path.join(OUT, "PRUEFSUMMEN.sha256"), checksums, "utf8");
} else {
  for (const [name, content] of files) {
    assert.ok(existsSync(path.join(OUT, name)), `fehlt: ${name}`);
    assert.equal(await readFile(path.join(OUT, name), "utf8"), content, `abweichend: ${name}`);
  }
  assert.equal(await readFile(path.join(OUT, "PRUEFSUMMEN.sha256"), "utf8"), checksums, "Prüfsummen weichen ab");
}

// Kontrollierte Übersicht – dient der Prüfung, keine Ersatzdokumentation.
const contactMissing = {};
for (const row of contactRows.filter((r) => r.hierarchie_rolle !== "parent")) {
  for (const field of row.felder_fehlend_quelle.split(",").filter((v) => v && v !== MISSING)) contactMissing[field] = (contactMissing[field] ?? 0) + 1;
}
const changed = scheduleRows.filter((r) => r.name_normiert !== r.name_original);
console.log(`Modus: ${verifyOnly ? "nur prüfen" : "CSV erzeugt"} · ${OUT}`);
console.log(`Termine: ${scheduleRows.length} Zeilen (2026: 9, 2027: 45) · Zeitfenster gesamt: ${scheduleRows.reduce((n, r) => n + Number(r.zeitfenster_anzahl), 0)}`);
console.log(`  davon berechnet: ${scheduleRows.filter((r) => r.datumsherkunft === "berechnet").length} (Advent, je 4 Wochenenden)`);
console.log(`  davon unbestätigt (*/**): ${scheduleRows.filter((r) => r.sternchen !== "kein").length} · Ort offen: ${scheduleRows.filter((r) => r.ort_offen === "ja").length}`);
console.log(`  name_normiert von name_original verschieden: ${changed.length}`);
for (const row of changed) console.log(`    ${row.sf_id} Z${row.quellzeile}: "${row.name_original}" → "${row.name_normiert}"`);
const sourceBlockTwins = contactRows.filter((r) => r.hierarchie_rolle !== "aussenstelle" && r.name_zusatz_original !== MISSING);
const noEmailSource = contactRows.filter((r) => r.hierarchie_rolle !== "parent" && r.email_1_original === MISSING);
const noEmailCurrent = contactRows.filter((r) => r.hierarchie_rolle !== "parent" && r.email_1_normiert === MISSING);
const placeCounts = new Map();
for (const row of contactRows.filter((r) => r.hierarchie_rolle !== "parent")) placeCounts.set(row.ort_original, (placeCounts.get(row.ort_original) ?? 0) + 1);
const repeatedPlaces = [...placeCounts].filter(([, n]) => n > 1);
console.log(`Kurverwaltungen: ${contactRows.length} Datensätze aus 32 MD-Blöcken (1 Parent, 2 Außenstellen); ` +
  `${new Set(sourceBlockTwins.map((r) => r.quellblock_id)).size} Quellblöcke mit zwei Namen.`);
for (const row of contactRows.filter((r) => r.parent_id === "KV12")) console.log(`    ${row.kv_id} parent=${row.parent_id}: ${row.eintragsname_original}`);
console.log(`  fehlende MD-Felder: ${JSON.stringify(contactMissing)} · Quellblöcke mit 2 E-Mails: ${contactRows.filter((r) => r.email_2_original !== MISSING).length}`);
console.log(`  E-Mail fehlt in MD: ${noEmailSource.map((r) => `${r.kv_id} ${r.eintragsname_original}`).join("; ")}`);
console.log(`  E-Mail fehlt im aktuellen Arbeitsstand: ${noEmailCurrent.map((r) => `${r.kv_id} ${r.eintragsname_original}`).join("; ")}`);
console.log(`  Ortsüberschriften mit mehreren Adressblöcken: ${repeatedPlaces.map(([p, n]) => `${p} ×${n}`).join(", ")}`);
console.log("  P1/P2 gemäß Auftraggeber umgesetzt; verbleibende historische Strukturabweichungen sind im LIESMICH dokumentiert.");
