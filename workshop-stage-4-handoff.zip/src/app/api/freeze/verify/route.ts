import { createHash } from "node:crypto";
import { readFileSync } from "node:fs";
import { NextResponse } from "next/server";
import { FREEZE_DIR, parsePruefsummen } from "@/lib/freeze";
import path from "node:path";

export const dynamic = "force-dynamic";

/**
 * Live-Verifikation der Freeze-Dateien gegen PRUEFSUMMEN.sha256.
 * Rein lesend — es wird nichts in Quellen, Archive oder Datenbank geschrieben.
 */
export async function GET() {
  try {
    const expected = parsePruefsummen(
      readFileSync(path.join(FREEZE_DIR, "PRUEFSUMMEN.sha256"), "utf8")
    );
    const rows = expected.map(({ file, hash }) => {
      let actual = "";
      try {
        actual = createHash("sha256")
          .update(readFileSync(path.join(FREEZE_DIR, file)))
          .digest("hex");
      } catch {
        actual = "";
      }
      return { file, expected: hash, actual, match: actual === hash };
    });
    return NextResponse.json({
      ok: rows.every((r) => r.match),
      checkedAt: new Date().toISOString(),
      rows,
    });
  } catch (err) {
    return NextResponse.json(
      { ok: false, error: err instanceof Error ? err.message : "unbekannt" },
      { status: 500 }
    );
  }
}
