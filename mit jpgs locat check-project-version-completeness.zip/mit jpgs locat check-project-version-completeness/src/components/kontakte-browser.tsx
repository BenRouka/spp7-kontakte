"use client";

import { useMemo, useState } from "react";
import {
  Eye,
  EyeOff,
  Globe,
  Mail,
  MapPin,
  Phone,
  Search,
  StickyNote,
} from "lucide-react";
import clsx from "clsx";

export interface KontaktDto {
  kvId: string;
  region: string;
  regionId: number;
  ort: string;
  name: string;
  anschrift: string | null;
  telefon: string | null;
  fax: string | null;
  emails: string[];
  web: string | null;
  typ: string;
  hinweis: string | null;
  hatMdBlock: boolean;
}

interface RegionChip {
  id: number;
  name: string;
  anzahl: number;
}

const TYP_TONE: Record<string, string> = {
  Kurverwaltung: "border-lime/30 bg-lime/[0.07] text-lime",
  Verein: "border-amber/30 bg-amber/[0.07] text-amber",
  "Gewerbe/GmbH": "border-ink-soft/25 bg-ink-soft/[0.06] text-ink-soft",
  Infostelle: "border-lime-soft/25 bg-lime-soft/[0.05] text-lime-soft",
  "Körperschaft/Gemeinde": "border-amber-soft/30 bg-amber-soft/[0.06] text-amber-soft",
};

export function KontakteBrowser({
  eintraege,
  regionen,
}: {
  eintraege: KontaktDto[];
  regionen: RegionChip[];
}) {
  const [query, setQuery] = useState("");
  const [regionId, setRegionId] = useState<number | null>(null);
  const [masked, setMasked] = useState(false);

  const filtered = useMemo(() => {
    const q = query.trim().toLowerCase();
    return eintraege.filter((e) => {
      if (regionId !== null && e.regionId !== regionId) return false;
      if (!q) return true;
      const hay = [
        e.kvId,
        e.name,
        e.ort,
        e.typ,
        e.anschrift ?? "",
        e.web ?? "",
        ...e.emails,
      ]
        .join(" ")
        .toLowerCase();
      return hay.includes(q);
    });
  }, [eintraege, query, regionId]);

  const gruppen = useMemo(() => {
    const map = new Map<number, { name: string; rows: KontaktDto[] }>();
    for (const r of regionen) map.set(r.id, { name: r.name, rows: [] });
    for (const e of filtered) map.get(e.regionId)?.rows.push(e);
    return [...map.entries()]
      .filter(([, g]) => g.rows.length > 0)
      .map(([id, g]) => {
        const orte: { ort: string; rows: KontaktDto[] }[] = [];
        for (const e of g.rows) {
          const last = orte[orte.length - 1];
          if (last && last.ort === e.ort) last.rows.push(e);
          else orte.push({ ort: e.ort, rows: [e] });
        }
        return { id, name: g.name, orte, anzahl: g.rows.length };
      });
  }, [filtered, regionen]);

  return (
    <div className={masked ? "masked" : undefined}>
      {/* Werkzeugleiste ------------------------------------------- */}
      <div className="rise sticky top-[61px] z-30 -mx-1 space-y-2.5 bg-base/90 px-1 py-3 backdrop-blur-md" style={{ animationDelay: "120ms" }}>
        <div className="flex flex-wrap items-center gap-2">
          <label className="flex min-w-[220px] flex-1 items-center gap-2 rounded-lg border border-line bg-raised px-3 py-2 transition-colors focus-within:border-lime/40 sm:max-w-xs">
            <Search className="h-4 w-4 shrink-0 text-muted" />
            <input
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              placeholder="Name, Ort, E-Mail, KV-ID …"
              className="w-full bg-transparent text-[13px] text-ink outline-none placeholder:text-muted/70"
            />
          </label>
          <button
            onClick={() => setMasked((m) => !m)}
            className={clsx(
              "inline-flex items-center gap-2 rounded-lg border px-3 py-2 text-[12px] font-medium transition-colors",
              masked
                ? "border-amber/40 bg-amber/10 text-amber"
                : "border-line bg-raised text-ink-soft hover:border-lime/30 hover:text-ink",
            )}
          >
            {masked ? (
              <EyeOff className="h-4 w-4" />
            ) : (
              <Eye className="h-4 w-4" />
            )}
            {masked ? "Datenschutz-Ansicht aktiv" : "Kanäle ausblenden"}
          </button>
          <span className="ml-auto font-mono text-[11px] text-muted">
            {filtered.length} / {eintraege.length} Datensätze
          </span>
        </div>
        <div className="scrollbox -mx-1 flex gap-1.5 overflow-x-auto px-1 pb-0.5">
          <button
            onClick={() => setRegionId(null)}
            className={clsx(
              "shrink-0 rounded-full border px-3 py-1.5 text-[12px] transition-colors",
              regionId === null
                ? "border-lime/40 bg-lime/10 text-lime"
                : "border-line bg-raised/60 text-muted hover:text-ink",
            )}
          >
            Alle Regionen
          </button>
          {regionen.map((r) => (
            <button
              key={r.id}
              onClick={() => setRegionId(regionId === r.id ? null : r.id)}
              className={clsx(
                "shrink-0 rounded-full border px-3 py-1.5 text-[12px] transition-colors",
                regionId === r.id
                  ? "border-lime/40 bg-lime/10 text-lime"
                  : "border-line bg-raised/60 text-muted hover:text-ink",
              )}
            >
              {r.name}
              <span className="tnum ml-1.5 text-[10px] opacity-60">
                {r.anzahl}
              </span>
            </button>
          ))}
        </div>
        {masked ? (
          <p className="rounded-lg border border-amber/25 bg-amber/[0.05] px-3 py-2 text-[11.5px] leading-snug text-amber-soft">
            B-17: Diese Ausblendung ist keine Zugriffskontrolle — die Werte
            bleiben im Bundle enthalten. Interner Bandgebrauch, keine
            Weitergabe außerhalb des Teams.
          </p>
        ) : null}
      </div>

      {/* Gruppen --------------------------------------------------- */}
      <div className="mt-6 space-y-12">
        {gruppen.map((g, gi) => (
          <section key={g.id} className="rise" style={{ animationDelay: `${gi * 40}ms` }}>
            <div className="mb-4 flex items-baseline gap-3 border-b border-line pb-3">
              <span className="font-mono text-[11px] font-semibold text-lime">
                {String(g.id).padStart(2, "0")}
              </span>
              <h2 className="font-display text-[clamp(1.35rem,2.4vw,1.8rem)] font-medium tracking-tight text-ink">
                {g.name}
              </h2>
              <span className="ml-auto font-mono text-[11px] text-muted">
                {g.anzahl} {g.anzahl === 1 ? "Datensatz" : "Datensätze"}
              </span>
            </div>

            <div className="space-y-6">
              {g.orte.map((o) => (
                <div key={o.ort}>
                  <p className="mb-3 flex items-center gap-1.5 font-mono text-[11px] uppercase tracking-[0.16em] text-muted">
                    <MapPin className="h-3 w-3 text-lime/70" />
                    {o.ort}
                  </p>
                  <div className="grid gap-3 lg:grid-cols-2">
                    {o.rows.map((e) => (
                      <article
                        key={e.kvId}
                        className="card-lift rounded-xl border border-line bg-raised/80 p-4"
                      >
                        <div className="flex items-start justify-between gap-3">
                          <div className="min-w-0">
                            <div className="flex flex-wrap items-center gap-1.5">
                              <span className="rounded border border-line-soft bg-raised2 px-1.5 py-0.5 font-mono text-[10.5px] font-semibold tracking-wide text-ink-soft">
                                {e.kvId}
                              </span>
                              <span
                                className={clsx(
                                  "rounded-full border px-2 py-0.5 font-mono text-[10px] uppercase tracking-[0.08em]",
                                  TYP_TONE[e.typ] ??
                                    "border-line bg-raised2 text-ink-soft",
                                )}
                              >
                                {e.typ}
                              </span>
                              {!e.hatMdBlock ? (
                                <span className="rounded-full border border-amber/40 bg-amber/10 px-2 py-0.5 font-mono text-[10px] uppercase tracking-[0.08em] text-amber">
                                  nur Prio 2 · kein MD-Block
                                </span>
                              ) : null}
                            </div>
                            <h3 className="font-display mt-2 text-[17.5px] font-medium leading-snug text-ink">
                              {e.name}
                            </h3>
                          </div>
                        </div>

                        <dl className="mt-3 space-y-1.5 text-[12.5px] leading-snug">
                          {e.anschrift ? (
                            <div className="flex gap-2">
                              <dt className="w-14 shrink-0 font-mono text-[10px] uppercase tracking-[0.1em] text-muted">
                                Anschr.
                              </dt>
                              <dd className="text-ink-soft">{e.anschrift}</dd>
                            </div>
                          ) : null}
                          {e.telefon || e.fax ? (
                            <div className="flex gap-2">
                              <dt className="flex w-14 shrink-0 items-center gap-1 font-mono text-[10px] uppercase tracking-[0.1em] text-muted">
                                <Phone className="h-3 w-3" /> Tel.
                              </dt>
                              <dd className="tnum text-ink-soft">
                                {e.telefon}
                                {e.fax ? (
                                  <span className="text-muted">
                                    {" "}
                                    · Fax {e.fax}
                                  </span>
                                ) : null}
                              </dd>
                            </div>
                          ) : null}
                          {e.emails.map((mail, i) => (
                            <div key={mail} className="flex gap-2">
                              <dt className="flex w-14 shrink-0 items-center gap-1 font-mono text-[10px] uppercase tracking-[0.1em] text-muted">
                                <Mail className="h-3 w-3" /> ·{i + 1}
                              </dt>
                              <dd>
                                <a
                                  href={`mailto:${mail}`}
                                  className="person break-all font-mono text-[12px] text-lime-soft underline decoration-lime/25 underline-offset-2 transition-colors hover:decoration-lime"
                                >
                                  {mail}
                                </a>
                              </dd>
                            </div>
                          ))}
                          {e.web ? (
                            <div className="flex gap-2">
                              <dt className="flex w-14 shrink-0 items-center gap-1 font-mono text-[10px] uppercase tracking-[0.1em] text-muted">
                                <Globe className="h-3 w-3" /> Web
                              </dt>
                              <dd>
                                <a
                                  href={`https://${e.web}`}
                                  target="_blank"
                                  rel="noreferrer"
                                  className="font-mono text-[12px] text-ink-soft underline decoration-line underline-offset-2 transition-colors hover:text-lime-soft hover:decoration-lime"
                                >
                                  {e.web}
                                </a>
                              </dd>
                            </div>
                          ) : null}
                        </dl>

                        {e.hinweis ? (
                          <p className="mt-3 flex gap-2 rounded-lg border border-line-soft bg-raised2/50 px-2.5 py-2 text-[11.5px] leading-snug text-muted">
                            <StickyNote className="mt-0.5 h-3 w-3 shrink-0 text-amber/80" />
                            <span>
                              <span className="font-mono text-[9.5px] font-semibold uppercase tracking-[0.12em] text-amber/90">
                                Prio 2 · Chat-Hinweis —{" "}
                              </span>
                              {e.hinweis}
                            </span>
                          </p>
                        ) : null}
                      </article>
                    ))}
                  </div>
                </div>
              ))}
            </div>
          </section>
        ))}

        {filtered.length === 0 ? (
          <p className="rounded-xl border border-dashed border-line px-6 py-14 text-center text-[13px] text-muted">
            Kein Datensatz passt zu „{query}“.
            {regionId !== null ? " Region-Filter ist aktiv." : ""}
          </p>
        ) : null}
      </div>
    </div>
  );
}
