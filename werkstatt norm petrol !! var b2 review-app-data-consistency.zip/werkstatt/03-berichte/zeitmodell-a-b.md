# SPP7 · Zeitmodell-Abgleich Option A / Option B

Gemeinsamer Stand: **zeitmodell-2026-2027-v2**.
Freigegebener Umfang: Zeitmodelle und überholte Werkstatt-Angaben angleichen. Option A bleibt die gewählte Arena-Oberfläche.
Das aktualisierte Option-B-Paket ist eine lokale Ableitung des verlinkten Werkstatt-ZIPs. Eine andere Arena-Instanz und GitHub wurden nicht verändert.

## Ergebnis

| Quelle | Art | Datumsherkunft | Quellstatus |
|---|---|---|---|
| 1. - 4. Advent 2026  · Mittelalter- Advent (Do. - So.)  · 44629 Herne/ Schloss Strünkede | vier getrennte Wochenenden | berechnet | in Quelle nicht als unbestätigt markiert |
| 25. 11. - 23. Dezember 2026*  · Mittelalter- Weihnacht  · 01067 Dresden / Stallhof | durchgehend; eigenes Datum, nicht Advent | aus Quelle | unbestätigt |
| 1. - 4. Advent 2027*  · Mittelalter- Advent (Fr.- So.)  · 44629 Herne/ Schloss Strünkede | vier getrennte Wochenenden | berechnet | unbestätigt |
| 24.11. - 23. Dezember 2027*  · Mittelalter- Weihnacht  · 01067 Dresden / Stallhof | durchgehend; eigenes Datum, nicht Advent | aus Quelle | unbestätigt |

Jeder Herne-Quelltermin bleibt ein Event mit vier zugeordneten Zeitfenstern. Keine Veranstaltungstage zwischen den Wochenenden und keine vier neuen Events.

## Herne 2026 · Do.–So.

| Advent | Beginn ISO | Ende ISO |
|---|---|---|
| 1. Advent | 2026-11-26 | 2026-11-29 |
| 2. Advent | 2026-12-03 | 2026-12-06 |
| 3. Advent | 2026-12-10 | 2026-12-13 |
| 4. Advent | 2026-12-17 | 2026-12-20 |

Dresden 2026: **25. November – 23. Dezember 2026**. Ein durchgehender Zeitraum aus der eigenen Quellzeile; keine Adventsberechnung.

## Herne 2027 · Fr.–So.

| Advent | Beginn ISO | Ende ISO |
|---|---|---|
| 1. Advent | 2027-11-26 | 2027-11-28 |
| 2. Advent | 2027-12-03 | 2027-12-05 |
| 3. Advent | 2027-12-10 | 2027-12-12 |
| 4. Advent | 2027-12-17 | 2027-12-19 |

Dresden 2027: **24. November – 23. Dezember 2027**. Ein durchgehender Zeitraum aus der eigenen Quellzeile; keine Adventsberechnung.

## Überholte Angaben

- Die frühere Zusammenfassung 26.11.–20.12.2026 ist kein durchgehender Herne-Termin.
- Der frühere Herne-Beginn 25.11.2027 ist falsch: Dieser Tag ist Donnerstag. Die Quelle 2027 nennt Fr.–So.; das erste Fenster beginnt am 26.11.2027.
- Die alten Handoff- und QUELLEN-Texte liegen unverändert unter docs/archiv/. Sie sind historisch, nicht maßgeblich für neue Berechnungen.

## Kirchenregel – Präzisierung

Der 4. Advent ist der letzte Sonntag vor dem 25. Dezember (18.–24. Dezember).
Fällt der 25. Dezember auf einen Sonntag, ist der 4. Advent am 18. Dezember, nicht am 25. Dezember.
Der Zusatz „oder der 25.12., wenn er Sonntag ist“ wird deshalb nicht als Kirchenregel übernommen. Für 2026 (Weihnachten Freitag) und 2027 (Weihnachten Samstag) bleiben alle bestätigten Wochenenden gleich.
Beleg: https://katholisch.de/artikel/15657-das-bedeuten-die-vier-advenssonntage

## Weitere geklärte Regeln

- F1: Januar–September 2026 werden nicht nacherfasst; Originalzeilen bleiben erhalten.
- F2: 180 von 206 Events haben LAT und LNG, verteilt auf 149 unterschiedliche Koordinatenpaare. Die Zahl bezeichnet keine Bilder. Vorhanden bedeutet nicht inhaltlich verifiziert.
- * und ** kennzeichnen gleichermaßen unbestätigte Termine oder Orte.
- Originalschreibweisen bleiben erhalten. Eine spätere Normierung wird zusätzlich geführt.
- Ein Adressblock mit zwei Namen bleibt eine Zeile mit Haupt- und Zusatzname.

## Grenzen dieser Angleichung

- Keine vollständige Normierung der 32 Adressblöcke oder 54 Terminzeilen; Stufe 2 ist nicht abgeschlossen.
- Kein vollständiger Quellen↔App-Abgleich; keine Dublettenentscheidungen.
- Keine Schemaänderung, kein Import, keine Datenbankschreibzugriffe.
- Option B behält seinen bisherigen Starter-Bildschirm. Ergänzt sind ausschließlich die gemeinsame lesende Kalender-/Berichtslogik, API-Endpunkte und korrigierte Werkstatt-Unterlagen.
- Die zwei im ursprünglichen Werkstatt-ZIP vorhandenen MD-/TXT-Quellen bleiben bytegleich. Die drei dort fehlenden Originale (App-ZIP, Chat-ZIP, Logo) wurden nicht stillschweigend ergänzt.
- Das Paket enthält keine .env-Datei, keinen privaten Chat-Export und keine Datenbankexporte.

Vorsicht: Beim späteren Import muss ein Quelltermin mehrere Zeitfenster besitzen können. Diese Zuordnung betrifft das Datenmodell und ist hier nicht implementiert.

Terminquelle: https://github.com/BenRouka/spp7-kontakte/blob/main/Termine%202027%20Veranstalter%20suendenfrei.txt
